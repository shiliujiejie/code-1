//
//  ViewController.swift
//  TestForVpn
//
//  Created by pro5 on 2019/2/19.
//  Copyright © 2019年 pro5. All rights reserved.
//

import UIKit
import NetworkExtension

class ViewController: UIViewController {

    private lazy var connectButton: UIButton = {
        let button = UIButton(type: .custom)
        button.frame = CGRect(x: (UIScreen.main.bounds.width - 150)/2, y: 120, width: 150, height: 150)
        button.setTitle("Connect", for: .normal)
        button.backgroundColor = UIColor.orange
        button.layer.cornerRadius = 75
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(connect(_:)), for: .touchUpInside)
        return button
    }()
    
    var status: VPNStatus {
        didSet(o) {
            updateConnectButton()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        self.status = .off
        super.init(coder: aDecoder)
        NotificationCenter.default.addObserver(self, selector: #selector(onVPNStatusChanged), name: NSNotification.Name(rawValue: kProxyServiceVPNStatusNotification), object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addSubview(connectButton)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.status = VpnManager.shared.vpnStatus
    }
  
    func updateConnectButton(){
        switch status {
        case .connecting:
            connectButton.setTitle("connecting", for: .normal)
        case .disconnecting:
            connectButton.setTitle("disconnect", for: .normal)
        case .on:
            connectButton.setTitle("Disconnect", for: .normal)
        case .off:
            connectButton.setTitle("Connect", for: .normal)
            
        }
        connectButton.isEnabled = [VPNStatus.on,VPNStatus.off].contains(VpnManager.shared.vpnStatus)
        
        
    }
    
    @objc func onVPNStatusChanged(){
        self.status = VpnManager.shared.vpnStatus
    }
    
    @objc func connect(_ sender: UIButton) {
        print("connect tap")
        if(VpnManager.shared.vpnStatus == .off) {
            VpnManager.shared.connect()
            sender.isSelected = true
            sender.backgroundColor = UIColor.green
        } else {
            VpnManager.shared.disconnect()
            sender.isSelected = false
            sender.backgroundColor = UIColor.orange
        }
    }

    
}


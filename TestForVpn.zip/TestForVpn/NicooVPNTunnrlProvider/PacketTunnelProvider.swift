//
//  PacketTunnelProvider.swift
//  NicooVPNTunnrlProvider
//
//  Created by pro5 on 2019/2/19.
//Copyright © 2019年 pro5. All rights reserved.
//

import NetworkExtension

class PacketTunnelProvider: NEPacketTunnelProvider {
	var connection: NWTCPConnection? = nil
	var pendingStartCompletion: ((NSError?) -> Void)?

    override func startTunnel(options: [String : NSObject]? = nil, completionHandler: @escaping (Error?) -> Void) {
        let ipv4Settings = NEIPv4Settings(addresses: ["192.169.89.1"], subnetMasks: ["255.255.255.0"])
        let networkSettings = NEPacketTunnelNetworkSettings(tunnelRemoteAddress: "8.8.8.8")
        networkSettings.mtu = 1500
        networkSettings.ipv4Settings = ipv4Settings
        setTunnelNetworkSettings(networkSettings) {
            error in
            guard error == nil else {
                completionHandler(error)
                return
            }
            completionHandler(nil)
        }
        
    }
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "state" {
            if let conn = object as? NWTCPConnection {
                if conn.state == .connected {
                    if let ra = conn.remoteAddress as? NWHostEndpoint {
                        setTunnelNetworkSettings(NEPacketTunnelNetworkSettings.init(tunnelRemoteAddress: ra.hostname)) { (error) in
                            if error == nil {
                                self.addObserver(self, forKeyPath: "defaultPath", options: .initial, context: nil)
                                self.packetFlow.readPackets(completionHandler: { (packets, protocals) in
                                    // Add code here to deal with packets, and call readPacketsWithCompletionHandler again when ready for more.
                                })
                                conn.readMinimumLength(0, maximumLength: 8192, completionHandler: { (data, error) in
                                    self.packetFlow.writePackets([Data]() as [Data], withProtocols: [NSNumber]())
                                })
                            }
                            self.pendingStartCompletion?((error! as NSError))
                            self.pendingStartCompletion = nil
                        }
                    }
                } else if conn.state == .disconnected {
                    let error = NSError(domain:"PacketTunnelProviderDomain", code:-1, userInfo:[NSLocalizedDescriptionKey:"Failed to connect"])
                    if pendingStartCompletion != nil {
                        self.pendingStartCompletion?(error)
                        self.pendingStartCompletion = nil
                    } else {
                        cancelTunnelWithError(error)
                    }
                    conn.cancel()
                } else if conn.state == .cancelled {
                    conn.removeObserver(self, forKeyPath:"state")
                    self.removeObserver(self, forKeyPath:"defaultPath")
                    connection = nil
                }
            }
        } else if keyPath == "defaultPath" {
            // Add code here to deal with changes to the network
        } else {
            super.observeValue(forKeyPath: keyPath, of:object, change:(change as! [NSKeyValueChangeKey : Any]), context:context)
        }
       
    }
	
    override func stopTunnel(with reason: NEProviderStopReason, completionHandler: @escaping () -> Void) {
        // Add code here to start the process of stopping the tunnel
        connection?.cancel()
        completionHandler()
    }

    override func handleAppMessage(_ messageData: Data, completionHandler: ((Data?) -> Void)? = nil) {
        if let handler = completionHandler {
            handler(messageData)
        }
    }

    override func sleep(completionHandler: @escaping () -> Void) {
        // Add code here to get ready to sleep
        completionHandler()
    }

	override func wake() {
		// Add code here to wake up
	}
}

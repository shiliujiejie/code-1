# NicooExtension

[![CI Status](https://img.shields.io/travis/504672006@qq.com/NicooExtension.svg?style=flat)](https://travis-ci.org/504672006@qq.com/NicooExtension)
[![Version](https://img.shields.io/cocoapods/v/NicooExtension.svg?style=flat)](https://cocoapods.org/pods/NicooExtension)
[![License](https://img.shields.io/cocoapods/l/NicooExtension.svg?style=flat)](https://cocoapods.org/pods/NicooExtension)
[![Platform](https://img.shields.io/cocoapods/p/NicooExtension.svg?style=flat)](https://cocoapods.org/pods/NicooExtension)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

NicooExtension is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'NicooExtension'
```

## Author

504672006@qq.com, yangxin@tzpt.com

## License

NicooExtension is available under the MIT license. See the LICENSE file for more info.

//
//  UIViewControllerAssistant.swift
//  NicooExtension
//
//  Created by 小星星 on 2018/11/15.
//

import Foundation

public extension UIViewController {
    
    /// 显示对话框
    func showDialog(title: String?, message: String, okTitle: String, cancelTitle: String, okHandler: (() -> Void)?, cancelHandler: (() -> Void)?) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: cancelTitle, style: .cancel, handler: { alertAction in
            if let cancelHandler = cancelHandler {
                cancelHandler()
            }
        })
        let OkAction = UIAlertAction(title: okTitle, style: .default, handler: { alertAction in
            if let okHandler = okHandler {
                okHandler()
            }
        })
        alert.addAction(cancelAction)
        alert.addAction(OkAction)
        present(alert, animated: true, completion: nil)
    }
    
    func showErrorMessage(_ message: String, cancelHandler: (() -> Void)?) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: UIAlertControllerStyle.alert)
        let cancelAction = UIAlertAction(title: "确定", style: UIAlertActionStyle.cancel, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
            cancelHandler?()
        })
        alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    class func currentViewController(_ baseVC: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {
        if let nav = baseVC as? UINavigationController {
            return currentViewController(nav.visibleViewController)
        }
        if let tab = baseVC as? UITabBarController {
            return currentViewController(tab.selectedViewController)
        }
        if let presented = baseVC?.presentedViewController {
            return currentViewController(presented)
        }
        return baseVC
    }
    
    func isVisible() -> Bool {
        return self.isViewLoaded && self.view.window != nil
    }
    
}


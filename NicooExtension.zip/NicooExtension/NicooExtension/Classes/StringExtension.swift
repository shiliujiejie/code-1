//
//  StringExtension.swift
//  NicooExtension
//
//  Created by 小星星 on 2018/11/15.
//

/*
 Description:
 对String的扩展方法
 
 History:
 */

import UIKit

public extension String {
    
    func encodeStringToBase64String() -> String {
        let utf8Data: Data = self.data(using: String.Encoding.utf8)!
        let base64EncodedString = utf8Data.base64EncodedString(options: NSData.Base64EncodingOptions(rawValue: 0))
        return base64EncodedString
    }
    
   
    
    /*
     func md5String() -> String {
     let str = self.cString(using: String.Encoding.utf8)
     let strLen = CC_LONG(self.lengthOfBytes(using: String.Encoding.utf8))
     let digestLen = Int(CC_MD5_DIGEST_LENGTH)
     let digestPointer = UnsafeMutablePointer<CUnsignedChar>.allocate(capacity: digestLen)
     CC_MD5(str!, strLen, digestPointer)
     let hash = NSMutableString()
     for i in 0 ..< digestLen {
     hash.appendFormat("%02x", digestPointer[i])
     }
     digestPointer.deallocate(capacity: digestLen)
     return String(format: hash as String)
     }
     */
    func isAvailableIdCard() -> Bool {
        if self.count != 18 {
            return false
        }
        var sum = 0
        for i in 0..<17 {
            let index1 = self.index(self.startIndex, offsetBy: i)
            let index2 = self.index(self.startIndex, offsetBy: i + 1)
            let idNum = self[index1 ..< index2]
            //            let idNum = String(self[self.index(self.startIndex, offsetBy: i) ..< self.index(self.startIndex, offsetBy: i + 1)])
            if let num = Int(idNum) {
                let x = powf(2, 17 - Float(i))
                let y = NSInteger(x) % 11
                sum += num * y
            } else {
                return false
            }
        }
        //        var checkCode = String(self[self.index(self.startIndex, offsetBy: 17) ..< self.index(self.startIndex, offsetBy: 18)])
        let index3 = self.index(self.startIndex, offsetBy: 17)
        let index4 = self.index(self.startIndex, offsetBy: 18)
        var checkCode = String(self[index3 ..< index4])
        checkCode = checkCode == "x" ? "X" : checkCode
        let x = sum % 11
        let checkDictionary:Dictionary<Int, String> = [0: "1", 1: "0", 2: "X", 3: "9", 4: "8", 5: "7", 6: "6", 7: "5", 8: "4", 9: "3", 10: "2"]
        if checkDictionary[x] == checkCode {
            return true
        }
        return false
    }
    
    // String to Dictionary
    func stringToDictioanry() -> NSDictionary? {
        if let data: Data = self.data(using: String.Encoding.utf8, allowLossyConversion: false) {
            do {
                let json: Any = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers)
                return json as? NSDictionary
            } catch {
                return nil
            }
        }
        return nil
    }
    
    func urlEncoded() -> String {
        let encodeUrlString = self.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
        return encodeUrlString ?? ""
    }
    
    func urlDecoded() -> String {
        return self.removingPercentEncoding ?? ""
    }
}


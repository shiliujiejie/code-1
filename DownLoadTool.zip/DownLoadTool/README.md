# TZFileDownloaderTool

[![CI Status](https://img.shields.io/travis/Jiexiang/TZFileDownloaderTool.svg?style=flat)](https://travis-ci.org/Jiexiang/TZFileDownloaderTool)
[![Version](https://img.shields.io/cocoapods/v/TZFileDownloaderTool.svg?style=flat)](https://cocoapods.org/pods/TZFileDownloaderTool)
[![License](https://img.shields.io/cocoapods/l/TZFileDownloaderTool.svg?style=flat)](https://cocoapods.org/pods/TZFileDownloaderTool)
[![Platform](https://img.shields.io/cocoapods/p/TZFileDownloaderTool.svg?style=flat)](https://cocoapods.org/pods/TZFileDownloaderTool)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

TZFileDownloaderTool is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'TZFileDownloaderTool'
```

## Author

Jiexiang, jiexiang@tzpt.com

## License

TZFileDownloaderTool is available under the MIT license. See the LICENSE file for more info.

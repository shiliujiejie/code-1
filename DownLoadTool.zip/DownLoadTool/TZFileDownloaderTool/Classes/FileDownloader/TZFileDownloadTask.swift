//
//  TZFileDownloadTask.swift
//  DownloadDemo
//
//  Created by TyroneZhang on 2018/6/27.
//  Copyright © 2018 TyroneZhang. All rights reserved.
//

import Foundation
import OSSSourceLinkTool

public enum DownloadState: Int32 {
    /// 等待状态(等待前面的任务没有下载完)
    case waitting = 0
    /// 下载中状态
    case downloading
    /// 暂停状态
    case pause
    /// 失败状态
    case failed
    /// 完成状态
    case completed
}

/// 文件下载过程中的错误类型
public enum DownloadBrokenErrorType: Int {
    /// 未知错误
    case unknown = 0
    /// 网络故障
    case networkError
    /// 因为当前使用的是蜂窝网而被取消
    case canceledByCellularNetwork
    /// 未找到资源文件
    case noResource
    /// 手动取消
    case cancel
}

class TZFileDownloadTask: NSObject {
    /// 系统提供的文件下载类
    var sessionDownloadTask: URLSessionDataTask?
    /// 开始下载，系统分配的下载id
    var taskIdentifier: Int = -1
    /// 下载源
    var sourceUrlStr: String?
    /// 已经开始下载回调
    var didBecomeActiveState: (() -> Void)?
    /// 已经创建下载缓存文件
    var didCreateDownloadingCacheFile: ((String) -> Void)?
    /// 数据回调
    var dataResponse: ((_ bytesReceived: Int64, _ totalBytesReceived: Int64, _ bytesExpectToReceive: Int64) -> Void)? {
        didSet {
            if state == .downloading {
                didBecomeActiveState?()
            }
        }
    }
    /// 意外中断回调
    var brokenHandler: ((_ errorType: DownloadBrokenErrorType) -> Void)?
    /// 完成下载
    var completeHandler:((_ path: String,_ suggestName: String?, _ suggestType: String?) -> Void)?
    /// 继续下载任务时,它的已下载大小
    var downloadedSize: Int64 = 0
    /// 缓存
    var resumePath: String?
    /// 下载状态
    var state: DownloadState = .waitting
    /// 错误原因
    var errorType: DownloadBrokenErrorType?
    
    deinit {
        print("\(taskIdentifier) ===== released")
    }
}

extension TZFileDownloadTask {
    
    func startTask() {
        guard let path = sourceUrlStr else {
            brokenHandler?(.noResource)
            return
        }
        state = .downloading
        if dataResponse != nil {
            didBecomeActiveState?()
        }
        
        OSSSourceLinkParser().signUrl(path) {[weak self] (urlStr) in
            guard let strongSelf = self else {
                return
            }
            if urlStr == nil {
                TZFileDownloader.shared.taskOssLinkError(strongSelf)
            } else {
                let url = URL(string: urlStr!)!
                var request = URLRequest(url: url)
                request.httpMethod = "get"
                strongSelf.downloadedSize = TZDownloadFileOperator.shared.getDownloadedOffset(by: path, resumePath: strongSelf.resumePath)
                if strongSelf.downloadedSize > 0 {
                    request.setValue("bytes=\(strongSelf.downloadedSize)-", forHTTPHeaderField: "Range")
                }
                strongSelf.sessionDownloadTask = TZFileDownloader.shared.session.dataTask(with: request)
                strongSelf.taskIdentifier = strongSelf.sessionDownloadTask!.taskIdentifier
                strongSelf.sessionDownloadTask!.resume()
            }
        }
        
//        let url = URL(string: path)!
//        var request = URLRequest(url: url)
//        request.httpMethod = "get"
//        downloadedSize = TZDownloadFileOperator.shared.getDownloadedOffset(by: path, resumePath: resumePath)
//        if downloadedSize > 0 {
//            request.setValue("bytes=\(downloadedSize)-", forHTTPHeaderField: "Range")
//        }
//        sessionDownloadTask = TZFileDownloader.shared.session.dataTask(with: request)
//        taskIdentifier = sessionDownloadTask!.taskIdentifier
//        sessionDownloadTask!.resume()

    }
    
}


//
//  TZDownloadFileOperator.swift
//  TZFileDownloaderTool
//
//  Created by TyroneZhang on 2018/8/16.
//

import Foundation

class FileOperator {
    private var fileName: String!
    private var queue: DispatchQueue!
    private var fileHandle: FileHandle!
    private var filePath: String!
    var path: String!
    
    static let tmpDirectoryURL: URL = {
        let urls = FileManager.default.urls(for: FileManager.SearchPathDirectory.documentDirectory, in: FileManager.SearchPathDomainMask.userDomainMask)
        var  document = urls[0]
        return document.appendingPathComponent("DownloadTmp")
    }()
    
    init(path: String, resumePath: String?) {
        self.path = path
        createFile(resumePath: resumePath)
        filePath = FileOperator.tmpDirectoryURL.appendingPathComponent(fileName).path
        queue = DispatchQueue(label: filePath)
        fileHandle = FileHandle(forWritingAtPath: filePath)!
    }
    
    func writeData(_ data: Data) {
        queue.async { [weak self] in
            self?.fileHandle.seekToEndOfFile()
            self?.fileHandle.write(data)
            self?.fileHandle.synchronizeFile()
        }
    }
    
    func getDownloadedFilePath() -> String {
        return filePath
    }
    
    func removeFile() {
        queue.sync { [weak self] in
            guard let strongSelf = self else {
                return
            }
            strongSelf.fileHandle.closeFile()
            do {
                try FileManager.default.removeItem(atPath: strongSelf.filePath)
            } catch {
                print("删除文件失败")
            }
        }
    }
    
    func closeFileHanle() {
        queue.async { [weak self] in
            guard let strongSelf = self else {
                return
            }
            strongSelf.fileHandle.closeFile()
        }
    }
    
    func getDownloadedOffset() -> Int64 {
        let dict = try? FileManager.default.attributesOfItem(atPath: filePath)
        if let size = dict?[FileAttributeKey.size] as? Int64 {
            return size
        }
        return 0
    }
    
    func isEqual(to op: FileOperator) -> Bool {
        return filePath == op.filePath
    }
    
    private func createFile(resumePath: String?) {
        if resumePath != nil {
            let resumeUrl = URL(fileURLWithPath: resumePath!)
            let resumeName = resumeUrl.lastPathComponent
            let resumePath = FileOperator.tmpDirectoryURL.appendingPathComponent(resumeName).path
            if FileManager.default.fileExists(atPath: resumePath) {
                fileName = resumeName
                filePath = resumePath
                return
            }
        }
        var hashValue = path.hashValue
        var isExit = checkIfFileNameExist("\(hashValue)")
        while isExit {
            hashValue += 1 // 解决碰撞
            isExit = checkIfFileNameExist("\(hashValue)")
        }
        fileName = "\(hashValue)"
        generateFile()
    }
    
    private func generateFile() {
        let fm = FileManager.default
        let tmpDirURL = FileOperator.tmpDirectoryURL
        if !fm.fileExists(atPath: tmpDirURL.path) {
            try! fm.createDirectory(at: tmpDirURL, withIntermediateDirectories: true, attributes: nil)
        }
        let tempFileURL = tmpDirURL.appendingPathComponent(fileName)
        if !fm.fileExists(atPath: tempFileURL.path, isDirectory: nil) {
            fm.createFile(atPath: tempFileURL.path, contents: nil, attributes: nil)
            print("===== 创建文件\(fileName): \(tempFileURL.path)")
        }
    }
    
    private func checkIfFileNameExist(_ name: String) -> Bool {
        let manager = FileManager.default
        if !manager.fileExists(atPath: FileOperator.tmpDirectoryURL.path, isDirectory: nil) {
            return false
        }
        if let childFiles = manager.subpaths(atPath: FileOperator.tmpDirectoryURL.path) {
            for aName in childFiles {
                if name == aName {
                    return true
                }
            }
        }
        return false
    }

}

class TZDownloadFileOperator {
    
    static let shared = TZDownloadFileOperator()
    
    lazy private var operators: [FileOperator] = {
       return [FileOperator]()
    }()
    
}

// MARK: - Public funcs

extension TZDownloadFileOperator {
    
    
    /// 根据下载路径,将data写入该路径创建的文件里
    ///
    /// - Parameters:
    ///   - data: 将要被写入的数据
    ///   - path: 文件下载路径
    func writeDownloadData(data: Data, to path: String, resumePath: String?) {
        var op = getOperator(by: path)
        if op == nil {
            op = FileOperator(path: path, resumePath: resumePath)
            operators.append(op!)
        }
        op!.writeData(data)
    }
    
    /// 获取文件已下载大小
    ///
    /// - Parameters:
    ///   - path: 文件下载路径
    ///   - resumePath: 缓存路径
    /// - Returns: 已下载大小
    func getDownloadedOffset(by path: String, resumePath: String?) -> Int64 {
        let op = getOperator(by: path)
        if op != nil {
            return op!.getDownloadedOffset()
        }
        if resumePath != nil {
            let resumeUrl = URL(fileURLWithPath: resumePath!)
            let resumeName = resumeUrl.lastPathComponent
            let resumePath = FileOperator.tmpDirectoryURL.appendingPathComponent(resumeName).path
            let dict = try? FileManager.default.attributesOfItem(atPath: resumePath)
            if let size = dict?[FileAttributeKey.size] as? Int64 {
                return size
            }
        }
        return 0
    }
    
    /// 根据下载地址获取下载文件临时存储路径
    ///
    /// - Parameter path: 下载路径
    /// - Returns: 下载的临时文件存储路径
    func getDownloadedFilePath(by path: String) -> String? {
        let op = getOperator(by: path)
        if op != nil {
            return op!.getDownloadedFilePath()
        }
        return nil
    }
    
    /// 根据下载地址移除下载的临时文件
    ///
    /// - Parameter path: 文件下载地址
    func removeFile(by path: String, resumePath: String?) {
        let op = getOperator(by: path)
        if op != nil {
            op!.removeFile()
            let index = operators.index { (op1) -> Bool in
                return op!.isEqual(to: op1)
            }
            operators.remove(at: index!)
        } else {
            if resumePath != nil {
                let resumeUrl = URL(fileURLWithPath: resumePath!)
                try? FileManager.default.removeItem(at: resumeUrl)
            }
        }
    }
    
    func removeOperator(by path: String) {
        if let op = getOperator(by: path) {
            let index = operators.index { (op1) -> Bool in
                return op.isEqual(to: op1)
            }
            operators.remove(at: index!)
            op.closeFileHanle()
        }
    }
    
}

// MARK: - Private funcs

private extension TZDownloadFileOperator {
    
    func getOperator(by path: String) -> FileOperator? {
        for op in operators {
            if path == op.path {
                return op
            }
        }
        return nil
    }
    
}

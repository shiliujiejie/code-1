//
//  TZFileDownloader.swift
//  DownloadDemo
//
//  Created by TyroneZhang on 2018/6/27.
//  Copyright © 2018 TyroneZhang. All rights reserved.
//

import UIKit

class TZFileDownloader: NSObject {
  
    static private let kMaximumConnection = 3
    static let shared = TZFileDownloader()
    private let taskQueue = DispatchQueue(label: "com.tz.taskQueue")
    lazy private var sessionConfiguration: URLSessionConfiguration = {
        let configuration = URLSessionConfiguration.background(withIdentifier: "com.tz.downloadIdentifier")
        //        configuration.httpMaximumConnectionsPerHost = 1 // 最大并发任务量 (这个完全没用)
        //        configuration.timeoutIntervalForResource = 30 // 数据包完全下载下来，超时，默认7天
        configuration.timeoutIntervalForRequest = 30 // 数据请求超时，默认60s
        return configuration
    }()
    lazy var session: URLSession = {
        let session = URLSession(configuration: self.sessionConfiguration, delegate: self, delegateQueue: OperationQueue.main)
        return session
    }()
    lazy private var downloadingQueue: [TZFileDownloadTask] = {
       return [TZFileDownloadTask]()
    }()
    lazy private var waittingQueue: [TZFileDownloadTask] = {
        return [TZFileDownloadTask]()
    }()
    
}

// MARK: - Public funcs

extension TZFileDownloader {
    
    /// 根据资源地址，开始一个下载任务，并且返回下载任务
    ///
    /// - Parameter path: 资源路径
    /// - Parameter resumePath: 缓存文件路径
    /// - Returns: 若地址错误，返回空，否则返回下载任务
    func addDownloadTask(_ path: String, resumePath: String?) -> TZFileDownloadTask? {
        let task = TZFileDownloadTask()
        task.resumePath = resumePath
        task.sourceUrlStr = path
        addTask(task: task)
        return task
    }
    
    /// 通过链接地址将某个任务置为暂停，并且返回找到的下载任务对象
    ///
    /// - Parameter urlStr: 下载链接地址
    func suspendDownload(_ urlStr: String) {
        guard let task = getTask(by: urlStr) else {
            return
        }
        removeTask(by: urlStr)
        if task.state == .downloading {
            task.sessionDownloadTask?.cancel()
            TZDownloadFileOperator.shared.removeOperator(by: task.sourceUrlStr!)
        }
    }
    
    /// 根据下载地址删除某个下载任务
    ///
    /// - Parameter urlStr: 下载地址
    func deleteDownload(_ urlStr: String, resumePath: String?) {
        TZDownloadFileOperator.shared.removeFile(by: urlStr, resumePath: resumePath)
        for task in waittingQueue {
            TZDownloadFileOperator.shared.removeFile(by: task.sourceUrlStr!, resumePath: task.resumePath)
        }
        waittingQueue.removeAll()
        for task in downloadingQueue {
            task.sessionDownloadTask?.cancel()
            TZDownloadFileOperator.shared.removeFile(by: task.sourceUrlStr!, resumePath: task.resumePath)
        }
        downloadingQueue.removeAll()
    }
    
    func getTask(by urlStr: String) -> TZFileDownloadTask? {
        var findedTask = waittingQueue.filter { (task) -> Bool in
            return task.sourceUrlStr == urlStr
        }
        if findedTask.count > 0 {
            return findedTask.first!
        }
        findedTask = downloadingQueue.filter { (task) -> Bool in
            return task.sourceUrlStr == urlStr
        }
        if findedTask.count > 0 {
            return findedTask.first!
        }
        return nil
    }
    
    func taskOssLinkError(_ task: TZFileDownloadTask) {
        task.brokenHandler?(.noResource)
        removeTask(by: task.sourceUrlStr!)
    }
    
}

// MARK: - 封装蜂窝网被外界主动暂停的逻辑

extension TZFileDownloader {
    
    /// 当使用移动网络下载的时候,所有下载任务被主动取消,并改变对应的状态
    func cancelAllTasksByCellularNetwork() {
        waittingQueue.removeAll()
        let tasks = downloadingQueue
        downloadingQueue.removeAll()
        for task in tasks {
            task.sessionDownloadTask?.cancel()
            TZDownloadFileOperator.shared.removeOperator(by: task.sourceUrlStr!)
        }
        downloadingQueue.removeAll()
    }
    
    /// 由于监测不到网络断开的情况,所以将此监听抛出去
    func cancelAllTasksByNetworkError(){
        waittingQueue.removeAll()
        let tasks = downloadingQueue
        downloadingQueue.removeAll()
        for task in tasks {
            task.sessionDownloadTask?.cancel()
            TZDownloadFileOperator.shared.removeOperator(by: task.sourceUrlStr!)
        }
    }
    
}

// MARK: - Private funcs

private extension TZFileDownloader {
    
    /*
    private func getEncodedUrl(_ urlStr: String) -> URL? {
        let array = urlStr.components(separatedBy: "?")
        guard let encodedBaseUrlStr = array[0].addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed) else {
            return nil
        }
        var finalUrlStr = encodedBaseUrlStr
        if array.count > 0 {
            var paramsStr = ""
            for i in 1 ..< array.count {
                paramsStr.append(array[i])
            }
            finalUrlStr = "\(finalUrlStr)?\(paramsStr)"
        }
        guard let url = URL(string: finalUrlStr) else {
            return nil
        }
        return url
    }*/
    
    func getTask(by taskIdentifier: Int) -> TZFileDownloadTask? {
        var findedTask = waittingQueue.filter { (task) -> Bool in
            return task.taskIdentifier == taskIdentifier
        }
        if findedTask.count > 0 {
            return findedTask.first!
        }
        findedTask = downloadingQueue.filter { (task) -> Bool in
            return task.taskIdentifier == taskIdentifier
        }
        if findedTask.count > 0 {
            return findedTask.first!
        }
        return nil
    }
    
    
}

// MARK: - 队列操作

private extension TZFileDownloader {
    
    func addTask(task: TZFileDownloadTask) {
        taskQueue.sync { [unowned self] in
            if self.downloadingQueue.count < TZFileDownloader.kMaximumConnection {
                self.addTaskToDownloadingQueue(task: task)
            } else {
                self.addTaskToWaittingQueue(task: task)
            }
        }
    }
    
    func addTaskToDownloadingQueue(task: TZFileDownloadTask) {
        print(" add then start \(task.sourceUrlStr!)")
        downloadingQueue.append(task)
        task.startTask()
    }
    
    func addTaskToWaittingQueue(task: TZFileDownloadTask) {
        print(" add to waitting \(task.sourceUrlStr!)")
        task.state = .waitting
        waittingQueue.append(task)
    }
    
    func removeTask(by urlStr: String) {
        taskQueue.sync { [unowned self] in
            var index = self.waittingQueue.index { (task) -> Bool in
                return task.sourceUrlStr == urlStr
            }
            if index != nil {
                print("remove waitting \(urlStr)")
                self.waittingQueue.remove(at: index!)
                return
            }
            index = self.downloadingQueue.index { (task) -> Bool in
                return task.sourceUrlStr == urlStr
            }
            if index != nil {
                print("remove downloading \(urlStr)")
                self.downloadingQueue.remove(at: index!)
                self.startFirstTaskInWaittingQueue()
            }
        }
    }
    
    func removeDonwloadingTask(by taskIdentifier: Int) {
        taskQueue.sync { [unowned self] in
            let index = self.downloadingQueue.index { (task) -> Bool in
                return task.taskIdentifier == taskIdentifier
            }
            if index != nil {
                print("remove downloading \(downloadingQueue[index!].sourceUrlStr!)")
                self.downloadingQueue.remove(at: index!)
                self.startFirstTaskInWaittingQueue()
            }
        }
    }
    
    func startFirstTaskInWaittingQueue() {
//        taskQueue.sync { [unowned self] in
            if let first = self.waittingQueue.first {
                self.waittingQueue.removeFirst()
                self.addTaskToDownloadingQueue(task: first)
                print("remove from waitting to downloading \(first.sourceUrlStr!)")
            }
//        }
    }
    
}

private extension TZFileDownloader {

    func downloadFailed(task: URLSessionTask, error: Error) {
        let aTask = getTask(by: task.taskIdentifier)
        if aTask != nil {
            TZDownloadFileOperator.shared.removeOperator(by: aTask!.sourceUrlStr!)
        }
        let nsError = (error as NSError)
        if let errorDescription = nsError.userInfo["NSLocalizedDescription"] as? String {
            if errorDescription != "cancelled" {
                print("didCompleteWithError: \(error)")
                aTask?.brokenHandler?(.unknown)
            }
        }
        removeDonwloadingTask(by: task.taskIdentifier)
    }
    
    func downloadSuccess(task: URLSessionTask) {
        guard let downloadTask = getTask(by: task.taskIdentifier) else {
            return
        }
        /*
         为了解决在链接地址出错,但是下载下来一个xml文件或者其它错误的文件,并且下载下来的文件大小很小,小到小于1k.
         在这种情况下,我们任务链接是错的,并且任务下载失败.
         */
        var realType: String? // 实际获取到的文件类型
        var expectedType: String? // 期望的文件类型
        let receivedSize: Int64 = task.countOfBytesReceived // 实际获取的文件大小
        let minimumSize: Int64 = 1024 // 期望得到的文件最小值
        if let array = task.response?.mimeType?.components(separatedBy: "/") {
            realType = array.last
        }
        if let array = task.response?.suggestedFilename?.components(separatedBy: ".") {
            expectedType = array.last
        }
        if realType != expectedType && receivedSize < minimumSize {
            downloadTask.brokenHandler?(.noResource)
            TZDownloadFileOperator.shared.removeFile(by: downloadTask.sourceUrlStr!, resumePath: downloadTask.resumePath)
            print("====== 未找到资源 ==== ")
        } else {
            let tmpPath = TZDownloadFileOperator.shared.getDownloadedFilePath(by: downloadTask.sourceUrlStr!)!
            downloadTask.completeHandler?(tmpPath, task.response?.suggestedFilename, task.response!.mimeType)
        }
        TZDownloadFileOperator.shared.removeOperator(by: downloadTask.sourceUrlStr!)
        removeDonwloadingTask(by: task.taskIdentifier)
    }
    
}

// MARK: - URLSessionDataDelegate

extension TZFileDownloader: URLSessionDataDelegate {
    
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse, completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        completionHandler(.allow)
    }
    
    public func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        guard let downloadTask = getTask(by: dataTask.taskIdentifier) else {
            dataTask.cancel()
            return
        }
        let bytesWritten = data.count
        let totalBytesWritten = dataTask.countOfBytesReceived + downloadTask.downloadedSize
        let expectedBytes = dataTask.countOfBytesExpectedToReceive + downloadTask.downloadedSize
        downloadTask.dataResponse?(Int64(bytesWritten), totalBytesWritten, expectedBytes)
        TZDownloadFileOperator.shared.writeDownloadData(data: data, to: downloadTask.sourceUrlStr!, resumePath: downloadTask.resumePath)
        if downloadTask.resumePath == nil {
            downloadTask.resumePath = TZDownloadFileOperator.shared.getDownloadedFilePath(by: downloadTask.sourceUrlStr!)
            downloadTask.didCreateDownloadingCacheFile?(downloadTask.resumePath!)
        }
    }
    
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if error != nil {
            downloadFailed(task: task, error: error!)
        } else {
            downloadSuccess(task: task)
        }
    }
    
    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        print("============ urlSessionDidFinishEvents")
        //        guard let appdelegate = UIApplication.shared.delegate  as? AppDelegate else {
        //            return
        //        }
        //        if appdelegate.backgroundTransferCompletionHandler == nil {
        //            return
        //        }
        //
        //        session.getTasksWithCompletionHandler { (dataTasks, uploadTasks, downloadTasks) in
        //            appdelegate.backgroundTransferCompletionHandler = nil
        //            guard let completionHandler = appdelegate.backgroundTransferCompletionHandler else {
        //                return
        //            }
        //
        //            OperationQueue.main.addOperation({
        //                completionHandler()
        //            })
        //        }
    }
    
}



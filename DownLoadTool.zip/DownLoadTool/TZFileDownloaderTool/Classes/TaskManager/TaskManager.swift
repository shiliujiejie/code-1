//
//  TaskManager.swift
//  DownloadDemo
//
//  Created by TyroneZhang on 2018/6/27.
//  Copyright © 2018 TyroneZhang. All rights reserved.
//

import Foundation
import CoreData
import TZNetworking

open class DownloadTask {
    public var taskID: Int64 = 0
    public var fileType: FileType
    public var taskName: String
    public var downloadUrlStr: String
    public var previewPath: String?
    public var isExist: Bool = false
    public var downloadState: DownloadState?
    
    public init(taskID: Int64, fileType: FileType, taskName: String, downloadUrlStr: String, previewPath: String?) {
        self.taskID = taskID
        self.fileType = fileType
        self.taskName = taskName
        self.downloadUrlStr = downloadUrlStr
        self.previewPath = previewPath
    }
}

public struct TaskWrapper {
    public var wrapperID: Int64 = 0
    public var fileType: FileType
    public var wrapperName: String
    public var previewPath: String?
    
    public init(wrapperID: Int64, fileType: FileType, wrapperName: String, previewPath: String?) {
        self.wrapperID = wrapperID
        self.fileType = fileType
        self.wrapperName = wrapperName
        self.previewPath = previewPath
    }
}

public enum FileType: Int32 {
    case video = 0
    case audio
}


/**
 该类采用单列模式，用于创建并且管理所有的下载任务model。
 注意：创建TaskWrapperInfo以及DownloadTaskInfo对象请使用该类来创建，切勿通过它们的init方法去创建。删除任务也请使用TaskManager里的删除方法。
 “一级目录”的解释：这里所说的“一级目录”是指没有目录的下载任务，和包含了子任务的目录的集合。
 */
open class TaskManager {
    
    public static let shared = TaskManager()
    
    static fileprivate let destDirectoryURL: URL = {
        let urls = FileManager.default.urls(for: FileManager.SearchPathDirectory.documentDirectory, in: FileManager.SearchPathDomainMask.userDomainMask)
        var  document = urls[0]
        return document.appendingPathComponent("Download")
    }()
    static fileprivate let cacheDirectoryURL: URL = {
        let urls = FileManager.default.urls(for: FileManager.SearchPathDirectory.documentDirectory, in: FileManager.SearchPathDomainMask.userDomainMask)
        var  document = urls[0]
        return document.appendingPathComponent("Cache")
    }()
    
    /// 所有未完成下载的一级目录集合
    private(set) var uncompletedTasks: [FileDownloadTaskProtocol]?
    
    private init() {
        NotificationCenter.default.addObserver(self, selector: #selector(TaskManager.didNetworkingStatusChanged), name: NSNotification.Name.kRealReachabilityStatusChanged, object: nil)
        initializeTasksFromCoreData()
    }
    
}

// MARK: - Public funcs for other components

public extension TaskManager {
    
    /// 创建一个不包含目录的独立下载任务
    ///
    /// - Parameters:
    ///   - task: 下载任务的属性struct
    ///   - taskDelegate: 下载任务的delegate回调
    /// - Returns: 下载任务
    public func createTask(_ task: DownloadTask) -> DownloadTaskInfo {
        if let taskInfo = getTask(by: task.downloadUrlStr) {
            return taskInfo
        }
        let taskInfo = DownloadTaskInfo(task.taskName, downloadSource: task.downloadUrlStr, taskID: task.taskID,fileType: task.fileType, previewPath: task.previewPath, wrapperID: nil)
        
        addANewTask(taskInfo)
        taskInfo.startDownloadTask()
        
        return taskInfo
    }
    
    /// 创建一组下载任务
    ///
    /// - Parameters:
    ///   - wrapper: 该组下载任务的目录
    ///   - subTasks: 下载任务数组
    /// - Returns: 一个包含子任务数组的目录对象
    public func createWrapper(_ wrapper: TaskWrapper, with subTasks: [DownloadTask]) -> TaskWrapperInfo {
        // 对相同任务进行一次过滤
        var filterSubTasks = [DownloadTask]()
        for task in subTasks {
            if filterSubTasks.contains(where: { (aTask) -> Bool in
                return aTask.downloadUrlStr == task.downloadUrlStr
            }) {
                continue
            } else {
                filterSubTasks.append(task)
            }
        }
        var subTaskInfos = [DownloadTaskInfo]()
        for task in filterSubTasks {
            var taskInfo = getTask(by: task.downloadUrlStr)
            if taskInfo == nil {
                taskInfo = DownloadTaskInfo(task.taskName, downloadSource: task.downloadUrlStr, taskID: task.taskID, fileType: task.fileType, previewPath: task.previewPath, wrapperID: wrapper.wrapperID)
            }
            subTaskInfos.append(taskInfo!)
        }
        
        var wrapperInfo = getWrapper(by: wrapper.wrapperID)
        if wrapperInfo == nil {
            wrapperInfo = TaskWrapperInfo(wrapper.wrapperName, wrapperID: wrapper.wrapperID, fileType: wrapper.fileType, previewPath: wrapper.previewPath, subTasks: subTaskInfos)
            addANewTask(wrapperInfo!)
        } else {
            wrapperInfo!.addNewTasks(subTaskInfos)
        }
        for subTask in subTaskInfos {
            subTask.startDownloadTask()
        }
        return wrapperInfo!
    }
    
    // 获取所有未完成下载任务（一级目录）
    public func getAllFirstLevelUncompletedTasks() -> [FileDownloadTaskProtocol]? {
        guard let tasks = uncompletedTasks, tasks.count > 0 else {
            return nil
        }
        let tempTasks = tasks.filter { (obj) -> Bool in
            return obj.downloadState != .completed
        }
        uncompletedTasks = tempTasks
        return uncompletedTasks
    }
    
    // 获取所有已完成下载任务（一级目录）
    public func getAllCompletedTasks() -> [FileDownloadTaskProtocol]? {
        let wrappers = TZTaskWrapper.fetchAllCompletedWrappers(nil)
        let tasksWithoutWrapper = TZDownloadTask.fetchAllCompletedTasksWithoutWrapper(nil)
        if wrappers == nil && tasksWithoutWrapper == nil {
            return nil
        }
        let models = sort(wrappers, tasks: tasksWithoutWrapper, byCreateDate: false)
        
        guard let taskModels = models, taskModels.count > 0 else {
            return nil
        }
        var completedTasks = [FileDownloadTaskProtocol]()
        for task in taskModels {
            if task is TZTaskWrapper {
                if let wrapperInfo = generateTaskWrapperInfo(by: task as! TZTaskWrapper, isCompleted: false) {
                    wrapperInfo.removeUncompletedSubTasks()
                    completedTasks.append(wrapperInfo)
                } else {
                    (task as! TZTaskWrapper).deleteTaskWrapper()
                }
            } else {
                let taskInfo = DownloadTaskInfo(task as! TZDownloadTask)
                completedTasks.append(taskInfo)
            }
        }
        return completedTasks
    }
    
    
    /// 查看传递进来的下载任务是否已经任务列表中,并且返回对应的状态
    ///
    /// - Parameter tasks: 需要被查询的下载任务
    /// - Returns: 返回每一个被查询下载任务的查询结果
    public func checkExist(by tasks: [DownloadTask]) -> [DownloadTask] {
        if tasks.count == 0 {
            return []
        }
        guard let taskModels = TZDownloadTask.fetchAllTasks(nil) else {
            return tasks
        }
        for i in 0 ..< tasks.count {
            let result = tasks[i]
            for model in taskModels {
                if (result.downloadUrlStr == model.fileURLStr!) {
                    tasks[i].isExist = true
                    tasks[i].downloadState = DownloadState(rawValue: model.downloadState)
                }
            }
        }
        return tasks
    }
    
    /// 删除某个任务或者目录
    ///
    /// - Parameter task: 将要被删除的任务或者目录
    public func removeTask(task: FileDownloadTaskProtocol) {
        
        if task is TaskWrapperInfo {
            let wrapper = task as! TaskWrapperInfo
            if uncompletedTasks != nil && uncompletedTasks!.count >= 0 { // 先在未完成任务中查找，如果查找到，那就要从任务管理器中删除该组任务
                let index = uncompletedTasks!.index { (obj) -> Bool in
                    let aWrapper = obj as? TaskWrapperInfo
                    if aWrapper == nil {
                        return false
                    }
                    return wrapper.isEqualTo(aWrapper!)
                }
                if index != nil {
                    // 如果找到，从未完成任务数组中删除
                    uncompletedTasks!.remove(at: index!)
                }
            }
            // 让目录自己去做删除操作
            wrapper.deleteSubTasks(wrapper.subTasks ?? [])
        } else {
            let aTask = task as! DownloadTaskInfo
            if uncompletedTasks != nil && uncompletedTasks!.count >= 0 { // 先在未完成任务中查找，如果查找到，那就要从任务管理器中删除该组任务
                // 先查看该task的model是否有wrapper，没有就说明它是单独的任务
                if aTask.taskModel!.wrapper == nil {
                    // 如果找到，就删除任务管理器中的该任务
                    let index = uncompletedTasks!.index { (obj) -> Bool in
                        if obj is DownloadTaskInfo {
                            return aTask.isEqualTo(obj)
                        }
                        return false
                    }
                    if index != nil {
                        uncompletedTasks!.remove(at: index!)
                    }
                    // 如果没找到，让任务自己去做删除操作
                    
                } else { // 在每个wrapper中查找
                    let index = uncompletedTasks!.index { (obj) -> Bool in
                        let wrapper = obj as? TaskWrapperInfo
                        if wrapper == nil {
                            return false
                        }
                        var findResult = false
                        if wrapper!.subTasks != nil && wrapper!.subTasks!.count > 0 {
                            for subTask in wrapper!.subTasks! {
                                if subTask.isEqualTo(aTask) {
                                    findResult = true
                                    break
                                }
                            }
                        }
                        return findResult
                    }
                    if index != nil {
                        let wrapper = uncompletedTasks![index!] as! TaskWrapperInfo
                        wrapper.deleteSubTasks([aTask])
                        if wrapper.subTasks == nil || wrapper.subTasks!.count == 0 {
                            uncompletedTasks!.remove(at: index!)
                        }
                        return
                    }
                    
                    // 如果没有找到，让任务自己去做删除操作
                }
            }
            // 让任务自己去做删除操作
            aTask.deleteDownloadTask()
        }
        
    }
    
    /// 获取已使用存储空间大小,单位为G
    ///
    /// - Returns: 已经经过转换的的磁盘空间大小
    public func getUsedDiskSized() -> Double {
        let downloadedSize = folderSize(at: TaskManager.destDirectoryURL.path)
        let cacheSize = folderSize(at: TaskManager.cacheDirectoryURL.path)
        let totalSize = downloadedSize + cacheSize
        return Double(totalSize) / 1073741824.0
    }
    
    
    /// 获取系统文件系统可用空间大小.单位为G
    ///
    /// - Returns: 经过转换的磁盘空间大小
    public func getAvailableSize() -> Double {
        let path = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true).first!
        let fileManager = FileManager.default
        do {
            let attributes = try fileManager.attributesOfFileSystem(forPath: path)
            let freeSpace = (attributes[FileAttributeKey.systemFreeSize]! as! Double) / 1073741824.0
            print("remain freeSpace: \(freeSpace)")
            return freeSpace
        } catch {
            print("获取剩余空间大小失败!")
        }
        return 0
    }
    
    /// 程序一启动，继续下载未完成的任务
    public func launchAllTasks() {
        if uncompletedTasks == nil || uncompletedTasks!.count < 1 {
            return
        }
        switch TZNetworkManager.currentNetworkType() {
        case .notReachable, .unKnown:
            cancelAllTasksByNetworkError()
            return
        case .wwan:
            didBecameCellularNetwork()
            return
        default: break
        }
        for task in uncompletedTasks! {
            if task is DownloadTaskInfo {
                if task.downloadState == .waitting || task.downloadState == .downloading {
                    task.startDownloadTask()
                }
            } else {
                for subTask in (task as! TaskWrapperInfo).subTasks! {
                    if task.downloadState == .waitting || subTask.downloadState == .downloading {
                        subTask.startDownloadTask()
                    }
                }
            }
        }
    }
    
    
    /// 通过文件下载地址,获取本地已下载的该文件的本地存储地址
    ///
    /// - Parameter downloadUrlStr: 文件下载地址
    /// - Returns: 若该文件已经下载了,返回该文件的下载地址,否者返回nil
    public func findLocalDownloadedFile(by downloadUrlStr: String) -> String? {
        guard let completedTasks = TZDownloadTask.fetchAllCompletedTasks(.video), completedTasks.count > 0 else {
            return nil
        }
        for task in completedTasks {
            if task.fileURLStr == downloadUrlStr {
                guard let path = task.storeDestinationPath else {
                    return nil
                }
                let destURL = DownloadTaskInfo.destDirectoryURL.appendingPathComponent(path)
                return destURL.path
            }
        }
        return nil
    }
    
}

// MARK: - Public funcs for other components
// MARK: - 由于需求修改,将正在下载全部统一放到一起,最外层展示下载中的“焦点”任务的信息(“焦点”代表第一个正在下载的任务,若没有正在下载的任务,代表第一个未完成的下载任务)

public extension TaskManager {
    
    /// 将所有未完成任务组合到一起
    ///
    /// - Returns: 返回所有未完成任务
    public func getAllUncompletedTasks() -> [FileDownloadTaskProtocol]? {
        guard let tasks = uncompletedTasks, tasks.count > 0 else {
            return nil
        }
        let tempTasks = tasks.filter { (obj) -> Bool in
            return obj.downloadState != .completed
        }
        uncompletedTasks = tempTasks
        if tempTasks.count == 0 {
            return nil
        }
        
        var unfinishedTasks = [DownloadTaskInfo]()
        for task in tempTasks {
            if task is TaskWrapperInfo {
                if let subTasks = (task as! TaskWrapperInfo).subTasks, subTasks.count > 0 {
                    unfinishedTasks.append(contentsOf: subTasks)
                }
            } else {
                unfinishedTasks.append(task as! DownloadTaskInfo)
            }
        }
        
        // 排序
        unfinishedTasks = unfinishedTasks.sorted(by: { (task1, task2) -> Bool in
            guard let createDate1 = task1.taskModel?.createDate else {
                return false
            }
            guard let createDate2 = task2.taskModel?.createDate else {
                return false
            }
            return createDate1.compare(createDate2 as Date) == .orderedAscending
        })
        
        return unfinishedTasks
    }

    /// 返回当前“焦点”任务,如果没有未完成下载任务,则返回nil
    ///
    /// - Returns: 返回“焦点”任务
    public func getFocusedDownloadTask() -> FileDownloadTaskProtocol? {
        guard let unfinishedTasks = getAllUncompletedTasks(), unfinishedTasks.count > 0 else {
            return nil
        }
        
        for task in unfinishedTasks {
            if task.downloadState == .downloading {
                return task
            }
        }
        return unfinishedTasks.first
    }
    
    /// 返回当前未完成下载任务的数量
    ///
    /// - Returns: 未完成下载任务
    public func getUnCompletedTasksCount() -> Int {
        guard let unfinishedTasks = getAllUncompletedTasks() else {
            return 0
        }
        
        return unfinishedTasks.count
    }
    
    /// 暂停所有任务
    public func suspendAllTasks() {
        guard let unfinishedTasks = getAllUncompletedTasks() else {
            return
        }
        
        for task in unfinishedTasks {
            task.suspendDownloadTask()
        }
    }
    
    /// 开始所有任务
    public func startAllTasks() {
        guard let unfinishedTasks = getAllUncompletedTasks() else {
            return
        }
        
        switch TZNetworkManager.currentNetworkType() {
        case .wifi:
            for task in unfinishedTasks {
                task.startDownloadTask()
            }
        case .wwan:
            if let isAllow = UserDefaults.standard.value(forKey: "allowDownloadingWith4G") as? Bool, isAllow {
                for task in unfinishedTasks {
                    task.startDownloadTask()
                }
            } else {
                suspendAllTasksByCellularNetwork()
            }
        default:
            cancelAllTasksByNetworkError()
        }
    }
    
    /// 删除所有未完成任务
    public func deleteAllUncompletedTasks() {
        guard let tasks = uncompletedTasks, tasks.count > 0 else {
            return
        }
        for task in tasks {
            removeTask(task: task)
        }
    }
}

// MARK: - Public funcs for other components
// MARK: - WI-FI与蜂窝网切换的逻辑

public extension TaskManager {
    
    /// 由于移动网络下不允许下载,暂停所有正在下载以及正在等待的任务
    func suspendAllTasksByCellularNetwork() {
        guard let unfinishedTasks = getAllUncompletedTasks() else {
            return
        }
        
        for task in unfinishedTasks {
            if task.downloadState != .pause {
                (task as? DownloadTaskInfo)?.cancelTaskByCellularNetwork()
            }
        }
    }
    
    
    /// 开启所有非手动暂停的任务
    ///
    /// - Parameter firstTask: 如果是需要首先开始某个任务,就传递该任务对象.
    func startAllTasksThatSuspendedByCellularNetwork(firstTask: FileDownloadTaskProtocol?) {
        guard let unfinishedTasks = getAllUncompletedTasks() else {
            return
        }
        firstTask?.startDownloadTask()
        for task in unfinishedTasks {
            if task.downloadState != .pause {
                if firstTask == nil || !firstTask!.isEqualTo(task) {
                    (task as? DownloadTaskInfo)?.startDownloadTask()
                }
            }
        }
    }
    
}

// MARK: - Public funcs in ther component

extension TaskManager {
    
    /// 当有任务下载完成后,要从当前未完成任务数组中移除这些已完成任务.
    func removeCompletedTask(_ task: FileDownloadTaskProtocol) {
        if task is TaskWrapperInfo {
            let wrapper = task as! TaskWrapperInfo
            if uncompletedTasks != nil && uncompletedTasks!.count >= 0 { // 先在未完成任务中查找，如果查找到，那就要从任务管理器中删除该组任务
                let index = uncompletedTasks!.index { (obj) -> Bool in
                    let aWrapper = obj as? TaskWrapperInfo
                    if aWrapper == nil {
                        return false
                    }
                    return wrapper.isEqualTo(aWrapper!)
                }
                if index != nil {
                    // 如果找到，从未完成任务数组中删除
                    uncompletedTasks!.remove(at: index!)
                }
            }
        }
    }
    
}

// MARK: - Private funcs

private extension TaskManager {
    
    private func addANewTask(_ task: FileDownloadTaskProtocol) {
        if uncompletedTasks == nil {
            uncompletedTasks = [FileDownloadTaskProtocol]()
        }
        uncompletedTasks?.insert(task, at: 0)
    }
    
    /// 根据url查询任务
    ///
    /// - Parameter urlStr: 下载地址
    /// - Returns: 如果找到下载任务，就返回，否则返回nil
    private func getTask(by urlStr: String) -> DownloadTaskInfo? {
        guard let taskArr = uncompletedTasks , taskArr.count > 0 else {
            return nil
        }
        for task in taskArr {
            if task.sourceUrlStr == urlStr {
                return task as? DownloadTaskInfo
            }
        }
        return nil
    }
    
    
    /// 根据wrapperID获取wrapper
    ///
    /// - Parameter wrapperID: 目录ID
    /// - Returns: 若找到，返回目录对象，否则返回nil
    private func getWrapper(by wrapperID: Int64) -> TaskWrapperInfo? {
        guard let tasks = uncompletedTasks, tasks.count > 0 else {
            return nil
        }
        let wrappers = tasks.filter { (obj) -> Bool in
            return obj is TaskWrapperInfo
        }
        guard let array = wrappers as? [TaskWrapperInfo], array.count > 0 else {
            return nil
        }
        for wrapper in array {
            if wrapper.wrapperID == wrapperID {
                return wrapper
            }
        }
        return nil
    }
    
    private func initializeTasksFromCoreData() {
        let wrappers = TZTaskWrapper.fetchAllUncompletedWrappers(nil) // 包含了已经完成的子任务
        let tasksWithoutWrapper = TZDownloadTask.fetchAllUncompletedTasksWithoutWrapper(nil)
        if wrappers == nil && tasksWithoutWrapper == nil {
            return
        }
        let models = sort(wrappers, tasks: tasksWithoutWrapper, byCreateDate: true)
        
        guard let taskModels = models, taskModels.count > 0 else {
            return
        }
        uncompletedTasks = [FileDownloadTaskProtocol]()
        for task in taskModels {
            if task is TZTaskWrapper {
                if let wrapperInfo = generateTaskWrapperInfo(by: task as! TZTaskWrapper, isCompleted: false) {
                    wrapperInfo.removeCompletedSubTasks()
                    if wrapperInfo.subTasks != nil && wrapperInfo.subTasks!.count > 0 {
                        uncompletedTasks!.append(wrapperInfo)
                    }
                } else {
                    (task as! TZTaskWrapper).deleteTaskWrapper()
                }
            } else {
                let taskInfo = DownloadTaskInfo(task as! TZDownloadTask)
                uncompletedTasks!.append(taskInfo)
            }
        }
    }
    
    /// 对两个有序列表进行排序，在这里是按照TZTaskWrapper和TZDownloadTask的创建日期或者下载完成日期进行降序排序
    ///
    /// - Parameters:
    ///   - wrappers: 包含下载任务的目录集合
    ///   - task: 没有父目录的下载任务集合
    ///   - byCreateDate: 是否是用创建日期降序排序（true：使用创建日期，false：使用完成日期）
    /// - Returns: 排序后的结果集合
    private func sort(_ wrappers: [TZTaskWrapper]?, tasks: [TZDownloadTask]?, byCreateDate: Bool) -> [NSManagedObject]? {
        if wrappers == nil || tasks == nil {
            return wrappers == nil ? tasks : wrappers
        }
        if wrappers!.count == 0 || tasks!.count == 0 {
            return wrappers!.count == 0 ? tasks!: wrappers!
        }
        var newArray = [NSManagedObject]()
        var newWrappers = wrappers!
        var newTasks = tasks!
        while newWrappers.count != 0 && newTasks.count != 0 {
            let lastWrapper = newWrappers.last!
            let findedFlag = getArraysSortIndex(lastWrapper, tasks: newTasks, byCreateDate: byCreateDate)
            if findedFlag == -1 {
                newArray.insert(lastWrapper, at: 0)
                newWrappers.removeLast()
            } else if findedFlag == 0 {
                newArray.insert(contentsOf: newTasks, at: 0)
                newArray.insert(contentsOf: newWrappers, at: 0)
                newWrappers.removeAll()
                newTasks.removeAll()
                break
            } else {
                let arr = newTasks.suffix(from: findedFlag)
                newArray.insert(contentsOf: Array(arr), at: 0)
                newArray.insert(lastWrapper, at: 0)
                newWrappers.removeLast()
                newTasks.removeSubrange(findedFlag ..< newTasks.count)
            }
        }
        let remainArr: [NSManagedObject] = newWrappers.count == 0 ? newTasks : newWrappers
        newArray.insert(contentsOf: remainArr, at: 0)
        return newArray
    }
    
    /// 对两个有序数组，获取数组a的最后一个元素与数组b比较，第一个为降序或相等的b的数组下标i
    ///
    /// - Parameters:
    ///   - lastWrapper: wrapper数组中最后一个元素
    ///   - tasks: 被比较的tasks数组
    ///   - byCreateDate: 是否是按照创建日期排序
    /// - Returns: 找到的index
    private func getArraysSortIndex(_ lastWrapper: TZTaskWrapper, tasks: [TZDownloadTask], byCreateDate: Bool) -> Int {
        for i in 0 ..< tasks.count {
            let task = tasks[i]
            if byCreateDate {
                if lastWrapper.createDate!.compare(task.createDate! as Date) == .orderedAscending {
                    return i
                }
            } else {
                if lastWrapper.completeDate!.compare(task.completeDate! as Date) == .orderedAscending {
                    return i
                }
            }
        }
        return -1
    }
    
    
    /// 根据TZTaskWrapper model生成TaskWrapperInfo
    ///
    /// - Parameter wrapperModel: coredata中查询出来的model
    /// - Parameter isCompleted: false：子任务按照createdate排序，true：子任务按照completedDate排序
    /// - Returns: 如果该目录没有子任务，返回nil，否则返回目录对象
    private func generateTaskWrapperInfo(by wrapperModel: TZTaskWrapper, isCompleted: Bool) -> TaskWrapperInfo? {
        guard var subTasks = wrapperModel.subTasks?.allObjects as? [TZDownloadTask], subTasks.count > 0 else {
            return nil
        }
        subTasks = subTasks.sorted(by: { (obj1, obj2) -> Bool in
            if isCompleted {
                return obj1.completeDate!.compare(obj2.completeDate! as Date) == .orderedAscending
            } else {
                return obj1.createDate!.compare(obj2.createDate! as Date) == .orderedAscending
            }
        })
        wrapperModel.subTasks = NSSet(array: subTasks)
        let wrapperInfo = TaskWrapperInfo(wrapperModel)
        return wrapperInfo
    }
    
    private func folderSize(at path: String) -> Int64 {
        let manager = FileManager.default
        if !manager.fileExists(atPath: path, isDirectory: nil) {
            return 0
        }
        var totalSize: Int64 = 0
        if let childFiles = manager.subpaths(atPath: path) {
            for fileName in childFiles {
                let isDirectory = UnsafeMutablePointer<ObjCBool>.allocate(capacity: 1)
                let filePath = "\(path)/\(fileName)"
                var size: Int64 = 0
                if manager.fileExists(atPath: filePath, isDirectory: isDirectory) {
                    if isDirectory.pointee.boolValue {
                        size = folderSize(at: filePath)
                    } else {
                        size = fileSize(at: filePath)
                    }
                    totalSize += size
                }
            }
        }
        return totalSize
        
    }
    
    /// 获取单个文件的文件大小
    ///
    /// - Parameter path: 文件路径
    /// - Returns: 文件大小
    private func fileSize(at path: String) -> Int64 {
        let manager = FileManager.default
        if manager.fileExists(atPath: path) {
            do {
                let size = try manager.attributesOfItem(atPath: path)
                return size[FileAttributeKey.size] as! Int64
            } catch {
                return 0
            }
        }
        return 0
    }
    
    /// 监听网络状态的变化
    
    @objc private func didNetworkingStatusChanged() {
        switch TZNetworkManager.currentNetworkType() {
        case .wifi:
            startAllTasksThatSuspendedByCellularNetwork(firstTask: nil)
        case .wwan:
            didBecameCellularNetwork()
        default: // 默认都做无网络处理
            cancelAllTasksByNetworkError()
        }
    }
    
    /// 网络故障下,让所有非手动暂停的任务取消,并抛出网络故障异常
    private func cancelAllTasksByNetworkError() {
        guard let unfinishedTasks = getAllUncompletedTasks() else {
            return
        }
        
        for task in unfinishedTasks {
            if task.downloadState == .downloading || task.downloadState == .waitting || task.downloadState == .failed {
                (task as? DownloadTaskInfo)?.cancelTaskByNetworkError()
            }
        }
    }
    
    
    /// 当网络状态变为移动蜂窝网后,需要先判断是否允许该请款下继续下载,否则会停掉所有下载任务
    private func didBecameCellularNetwork() {
        if let isAllow = UserDefaults.standard.value(forKey: "allowDownloadingWith4G") as? Bool, isAllow {
            startAllTasksThatSuspendedByCellularNetwork(firstTask: nil)
        } else {
            suspendAllTasksByCellularNetwork()
        }
    }
    
}

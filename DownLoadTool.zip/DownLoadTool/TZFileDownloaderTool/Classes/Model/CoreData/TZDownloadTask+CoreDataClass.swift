//
//  TZDownloadTask+CoreDataClass.swift
//  DownloadDemo
//
//  Created by TyroneZhang on 2018/6/29.
//  Copyright © 2018 TyroneZhang. All rights reserved.
//
//

import Foundation
import CoreData

@objc(TZDownloadTask)
public class TZDownloadTask: NSManagedObject {
    
    // MARK: - Public funcs
    
    // MARK: - 增
    
    /// 向数据库插入一条任务记录(会先从所有任务当中查询一遍，看是否有对应url的任务，如果没有，才会创建)
    ///
    /// - Parameters:
    ///   - taskID: 任务ID
    ///   - fileType: 任务文件类型
    ///   - taskName: 任务名称
    ///   - urlStr: 下载地址
    ///   - previewPath: 预览图地址
    /// - Returns: 返回新创建的或者通过url找到的已经存在的任务
    class func insertANewTask(_ taskID: Int64, fileType: FileType, taskName: String?, urlStr: String, previewPath: String?) -> TZDownloadTask {
        if let task = fetchTask(by: urlStr) {
           return task
        }
        let task = NSEntityDescription.insertNewObject(forEntityName: "TZDownloadTask", into: DownloadCoreDataHelper.shared.managedObjectContext) as! TZDownloadTask
        // 创建日期
        let date = Date.getCurrentDeviceDate()
        task.createDate = date as NSDate
        task.taskID = taskID
        task.taskName = taskName
        task.fileURLStr = urlStr
        task.previewPath = previewPath
        task.fileType = fileType.rawValue
        task.downloadState = DownloadState.waitting.rawValue
        task.bytesExpectToReceive = 0
        task.totalBytesReceived = 0
        DownloadCoreDataHelper.shared.saveContext()
        
        return task
    }
    
    // MARK: - 删
    
    // 删除一条记录
    func deleteTask() {
        if wrapper != nil {
            wrapper!.removeSubTasks([self])
        } else {
            DownloadCoreDataHelper.shared.managedObjectContext.delete(self)
            DownloadCoreDataHelper.shared.saveContext()
        }
    }
    
    // MARK: - 查
    
    /// 查询所有任务（不管什么状态，也不管有没有目录，并且按照创建日期降序排序）
    ///
    /// - Parameter fileType: 若不传文件类型,默认会查询所有下载任务
    /// - Returns: 下载任务集合
    class func fetchAllTasks(_ fileType: FileType?) -> [TZDownloadTask]? {
        var predicate: NSPredicate?
        if fileType != nil {
            predicate = NSPredicate(format: "fileType == %d", fileType!.rawValue)
        }
        let dateDescriptor = NSSortDescriptor(key: "createDate", ascending: false)
        return fetchDownloadTasks(predicate, sortDescriptors: [dateDescriptor])
    }
    
    /// 查询所有无目录的任务，并且按照创建日期降序排序
    ///
    /// - Parameter fileType: 若不传文件类型,默认会查询所有下载任务
    /// - Returns: 所有无目录的任务集合
    class func fetchAllTasksWithoutWrapper(_ fileType: FileType?) -> [TZDownloadTask]? {
        var predicate: NSPredicate?
        if fileType != nil {
            predicate = NSPredicate(format: "wrapper == nil && fileType == %d", fileType!.rawValue)
        } else {
            predicate = NSPredicate(format: "wrapper == nil", "")
        }
        let dateDescriptor = NSSortDescriptor(key: "createDate", ascending: false)
        return fetchDownloadTasks(predicate, sortDescriptors: [dateDescriptor])
    }
    
    /// 查询所有未完成任务（不管有没有目录，并且按照创建日期降序排序）
    ///
    /// - Parameter fileType: 若不传文件类型,默认会查询所有下载任务
    /// - Returns: 未完成任务集合
    class func fetchAllUncompletedTasks(_ fileType: FileType?) -> [TZDownloadTask]? {
        var predicate: NSPredicate?
        if predicate != nil {
            predicate = NSPredicate(format: "downloadState != %d && fileType == %d", (DownloadState.completed.rawValue), fileType!.rawValue)
        } else {
            predicate = NSPredicate(format: "downloadState != %d", (DownloadState.completed.rawValue))
        }
        
        let dateDescriptor = NSSortDescriptor(key: "createDate", ascending: false)
        return fetchDownloadTasks(predicate, sortDescriptors: [dateDescriptor])
    }
    
    /// 查询所有无目录且未完成的任务，并且按照创建日期降序排序
    ///
    /// - Parameter fileType: 若不传文件类型,默认会查询所有下载任务
    /// - Returns: 无目录且未完成任务集合
    class func fetchAllUncompletedTasksWithoutWrapper(_ fileType: FileType?) -> [TZDownloadTask]? {
        var predicate: NSPredicate?
        if predicate != nil {
            predicate = NSPredicate(format: "wrapper == nil && downloadState != %d && fileType == %d", (DownloadState.completed.rawValue), fileType!.rawValue)
        } else {
            predicate = NSPredicate(format: "wrapper == nil && downloadState != %d", (DownloadState.completed.rawValue))
        }
        let dateDescriptor = NSSortDescriptor(key: "createDate", ascending: false)
        return fetchDownloadTasks(predicate, sortDescriptors: [dateDescriptor])
    }
    
    /// 查询所有已完成的任务(不管有没有目录,并且按照完成日期降序排序)
    ///
    /// - Parameter fileType: 若不传文件类型,默认会查询所有下载任务
    /// - Returns: 无目录且已完成任务集合
    class func fetchAllCompletedTasks(_ fileType: FileType?) -> [TZDownloadTask]? {
        var predicate: NSPredicate?
        if predicate != nil {
            predicate = NSPredicate(format: "downloadState == %d && fileType == %d", (DownloadState.completed.rawValue), fileType!.rawValue)
        } else {
            predicate = NSPredicate(format: "downloadState == %d", (DownloadState.completed.rawValue))
        }
        let dateDescriptor = NSSortDescriptor(key: "completeDate", ascending: false)
        return fetchDownloadTasks(predicate, sortDescriptors: [dateDescriptor])
    }
    
    
    /// 查询所有无目录且已完成的任务，并且按照完成日期降序排序
    ///
    /// - Parameter fileType: 若不传文件类型,默认会查询所有下载任务
    /// - Returns: 无目录且已完成任务集合
    class func fetchAllCompletedTasksWithoutWrapper(_ fileType: FileType?) -> [TZDownloadTask]? {
        var predicate: NSPredicate?
        if predicate != nil {
            predicate = NSPredicate(format: "wrapper == nil && downloadState == %d && fileType == %d", (DownloadState.completed.rawValue), fileType!.rawValue)
        } else {
            predicate = NSPredicate(format: "wrapper == nil && downloadState == %d", (DownloadState.completed.rawValue))
        }
        let dateDescriptor = NSSortDescriptor(key: "completeDate", ascending: false)
        return fetchDownloadTasks(predicate, sortDescriptors: [dateDescriptor])
    }
    
    // MARK: - 改
    
    /// 将修改放到使用者的地方去，我们只提供一个保存当前数据库的方法
    func saveUpdatedContent() {
        DownloadCoreDataHelper.shared.saveContext()
    }

    // MARK: - Private funcs
    
    
    /// 根据下载地址查询该条记录是否存在
    ///
    /// - Parameter urlStr: 下载地址
    /// - Returns: 如果没找到，返回nil，否则返回找到的对象
    private class func fetchTask(by urlStr: String) -> TZDownloadTask? {
        let predicate = NSPredicate(format: "fileURLStr == %@", urlStr)
        let results = fetchDownloadTasks(predicate, sortDescriptors: nil)
        guard let tasks = results, tasks.count > 0 else {
            return nil
        }
        return tasks.first
    }
    
    /// 根据筛选条件以及排序规则获取下载任务集合
    ///
    /// - Parameters:
    ///   - predicate: 筛选条件，若为空，查询所有下载任务
    ///   - sortDescriptors: 排序规则，若为空，则不排序
    /// - Returns: 下载任务数组
    class private func fetchDownloadTasks(_ predicate: NSPredicate?, sortDescriptors: [NSSortDescriptor]?) -> [TZDownloadTask]? {
        let fetchRequest = NSFetchRequest<TZDownloadTask>(entityName: "TZDownloadTask")
        fetchRequest.predicate = predicate
        fetchRequest.sortDescriptors = sortDescriptors
        do {
            let fetchedObjects:[AnyObject]? = try DownloadCoreDataHelper.shared.managedObjectContext.fetch(fetchRequest)
            if let tasks = fetchedObjects as? [TZDownloadTask], tasks.count > 0 {
                return tasks
            }
        } catch {
            fatalError("fetch error \(error)")
        }
        return nil
    }
}

extension Date {
    static func getCurrentDeviceDate() -> Date {
        let dateNow = Date()
        let timeZone = TimeZone.current
        let interval = timeZone.secondsFromGMT(for: dateNow)
        let systemDate = dateNow.addingTimeInterval(TimeInterval(interval))
        return systemDate
    }
}

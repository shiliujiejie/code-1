//
//  TZDownloadTask+CoreDataProperties.swift
//  DownloadDemo
//
//  Created by TyroneZhang on 2018/6/29.
//  Copyright © 2018 TyroneZhang. All rights reserved.
//
//

import Foundation
import CoreData


extension TZDownloadTask {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<TZDownloadTask> {
        return NSFetchRequest<TZDownloadTask>(entityName: "TZDownloadTask")
    }

    /// 任务id，即服务器文件主键，与服务器对应
    @NSManaged public var taskID: Int64
    /// 任务名
    @NSManaged public var taskName: String?
    /// 下载文件路径
    @NSManaged public var fileURLStr: String?
    /// 父目录
    @NSManaged public var wrapper: TZTaskWrapper?
    /// 临时缓存文件存储路径
    @NSManaged public var cachePath: String?
    /// 完整文件存储路径
    @NSManaged public var storeDestinationPath: String?
    /// 任务下载完成日期
    @NSManaged public var completeDate: NSDate?
    /// 任务创建日期
    @NSManaged public var createDate: NSDate?
    /// 下载状态
    @NSManaged public var downloadState: Int32
    /// 预览图
    @NSManaged public var previewPath: String?
    /// 文件总大小(bytes)
    @NSManaged public var bytesExpectToReceive: Int64
    /// 已下载文件数据大小(bytes)
    @NSManaged public var totalBytesReceived: Int64
    /// 文件后缀
    @NSManaged public var fileExtension: String?
    /// 文件名
    @NSManaged public var fileName: String?
    /// 文件类型（0:视频，1:音频）
    @NSManaged public var fileType: Int32

}

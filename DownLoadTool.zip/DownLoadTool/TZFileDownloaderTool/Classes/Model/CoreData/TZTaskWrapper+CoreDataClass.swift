//
//  TZTaskWrapper+CoreDataClass.swift
//  DownloadDemo
//
//  Created by TyroneZhang on 2018/6/27.
//  Copyright © 2018 TyroneZhang. All rights reserved.
//
//

import Foundation
import CoreData

@objc(TZTaskWrapper)
public class TZTaskWrapper: NSManagedObject {
    
    // MARK: Public funcs
    
    // MARK: - 增
    
    /// 通过属性，插入一个目录，并且返回（自动会查询是否已经存在，如果存在就不会创建一条新的记录）
    ///
    /// - Parameters:
    ///   - name: 目录名称
    ///   - wrapperID: 目录ID
    ///   - fileType: 目录类型
    ///   - previewPath: 预览图
    ///   - subTasks: 子任务
    /// - Returns: 返回创建的或者已经找到的wrapper
    class func insertTaskWrapper(_ name: String, wrapperID: Int64, fileType: FileType, previewPath: String?, subTasks: NSSet?) -> TZTaskWrapper {
        if let wrapper = fetchWrapper(by: wrapperID, fileType: fileType) {
            return wrapper
        }
        let wrapper = NSEntityDescription.insertNewObject(forEntityName: "TZTaskWrapper", into: DownloadCoreDataHelper.shared.managedObjectContext) as! TZTaskWrapper
        wrapper.name = name
        wrapper.wrapperID = wrapperID
        wrapper.subTasks = subTasks
        wrapper.previewPath = previewPath
        wrapper.fileType = fileType.rawValue
        wrapper.createDate = Date.getCurrentDeviceDate() as NSDate
        return wrapper
    }
    
    // MARK: - 删
    
    
    /// 删除目录以及该目录下的所有子任务(慎用)
    func deleteTaskWrapper() {
        DownloadCoreDataHelper.shared.managedObjectContext.delete(self)
        DownloadCoreDataHelper.shared.saveContext()
    }
    
    
    /// 删除目录中的部分子任务（同时该子任务也会从数据库中删除），如果删除后该目录没有子任务了，那将会从数据库中删除该目录
    ///
    /// - Parameter willRemovedSubTasks: 将要被删除的子任务
    func removeSubTasks(_ willRemovedSubTasks: [TZDownloadTask]) {
        guard let allTasks = subTasks?.allObjects as? [TZDownloadTask] , allTasks.count > 0 else {
            deleteTaskWrapper()
            return
        }
        removeFromSubTasks(NSSet(array: willRemovedSubTasks))
        for task in willRemovedSubTasks {
            DownloadCoreDataHelper.shared.managedObjectContext.delete(task)
        }
        DownloadCoreDataHelper.shared.saveContext()
        if subTasks == nil || subTasks!.count == 0 {
            deleteTaskWrapper()
        }
        changeWrapperCompleteDate()
    }
    
    // MARK: - 查

    /// 按照目录类型,查询对应的目录（包含所有状态，并且按照创建日期降序排序）
    ///
    /// - Parameter fileType: 如不传递该参数,默认会查询出所有类型的目录
    /// - Returns: 查询到的目录数组
    class func fetchAllWrappers(_ fileType: FileType?) -> [TZTaskWrapper]? {
        let dateSortDescriptor = NSSortDescriptor(key: "createDate", ascending: false)
        var predicate: NSPredicate?
        if fileType != nil {
            predicate = NSPredicate(format: "fileType == %d", fileType!.rawValue)
        }
        return fetchWrappers(predicate, sortDescriptors: [dateSortDescriptor])
    }
    
    /// 查询所有包含未完成子任务的目录
    ///
    /// - Parameter fileType: 如不传递该参数,默认会查询出所有类型的目录
    /// - Returns: 查询到的目录数组
    class func fetchAllUncompletedWrappers(_ fileType: FileType?) -> [TZTaskWrapper]? {
        guard let wrappers = fetchAllWrappers(fileType) else {
            return nil
        }
        var uncompletedWrappers = [TZTaskWrapper]()
        for wrapper in wrappers {
            if let subTasks = wrapper.subTasks?.allObjects as? [TZDownloadTask] {
                for subTask in subTasks {
                    if subTask.downloadState != DownloadState.completed.rawValue {
                        uncompletedWrappers.append(wrapper)
                        break
                    }
                }
            }
        }
        if uncompletedWrappers.count == 0 {
            return nil
        }
        return uncompletedWrappers
    }
    
    /// 查询所有包含已完成子任务的目录(按照完成日期,降序排序)
    ///
    /// - Parameter fileType: 如不传递该参数,默认会查询出所有类型的目录
    /// - Returns: 查询到的目录数组
    class func fetchAllCompletedWrappers(_ fileType: FileType?) -> [TZTaskWrapper]? {
        var predicate: NSPredicate?
        if fileType == nil {
            predicate = NSPredicate(format: "completeDate != nil", "")
        } else {
            predicate = NSPredicate(format: "completeDate != nil && fileType == %d", fileType!.rawValue)
        }
        let dateSortDescriptor = NSSortDescriptor(key: "completeDate", ascending: false)
        return fetchWrappers(predicate, sortDescriptors: [dateSortDescriptor])
    }
    
    // MARK: - 改
    
    func saveUpdatedWrapperInfo() {
        DownloadCoreDataHelper.shared.saveContext()
    }
    
    // MARK: - Private funcs
    
    /// 根据目录ID查询该条记录是否存在
    ///
    /// - Parameter wrapperID: 目录ID
    /// - Returns: 如果没找到，返回nil，否则返回找到的对象
    private class func fetchWrapper(by wrapperID: Int64, fileType: FileType) -> TZTaskWrapper? {
        guard let wrappers = fetchAllWrappers(fileType), wrappers.count > 0 else {
            return nil
        }
        let index = wrappers.index { (obj) -> Bool in
            return obj.wrapperID == wrapperID
        }
        if index != nil {
            return wrappers[index!]
        }
        return nil
    }
    
    /// 根据筛选条件以及排序规则获取下载一级目录集合
    ///
    /// - Parameters:
    ///   - predicate: 筛选条件，若为空，查询所有下载任务
    ///   - sortDescriptors: 排序规则，若为空，则不排序
    /// - Returns: 下载任务数组
    private class func fetchWrappers(_ predicate: NSPredicate?, sortDescriptors: [NSSortDescriptor]?) -> [TZTaskWrapper]? {
        let fetchRequest = NSFetchRequest<TZTaskWrapper>(entityName: "TZTaskWrapper")
        fetchRequest.predicate = predicate
        fetchRequest.sortDescriptors = sortDescriptors
        do {
            let fetchedObjects:[AnyObject]? = try DownloadCoreDataHelper.shared.managedObjectContext.fetch(fetchRequest)
            if let wrappers = fetchedObjects as? [TZTaskWrapper], wrappers.count > 0 {
                return wrappers
            }
        } catch {
            fatalError("fetch error \(error)")
        }
        return nil
    }
    
    
    /// 将目录的完成日期改为最近的子任务的完成日期，如果没有完成的子任务，那么就将目录的完成日期置为nil
    private func changeWrapperCompleteDate() {
        guard let allTasks = subTasks?.allObjects as? [TZDownloadTask] , allTasks.count > 0 else {
            deleteTaskWrapper()
            return
        }
        let completedTasks = allTasks.filter { (subTask) -> Bool in
            subTask.completeDate != nil
        }
        if completedTasks.count == 0 {
            completeDate = nil
        } else {
            let sortedTasks = completedTasks.sorted { (task1, task2) -> Bool in
                return task1.completeDate!.compare(task2.completeDate! as Date) == .orderedDescending
            }
            completeDate = sortedTasks.first!.completeDate
        }
        DownloadCoreDataHelper.shared.saveContext()
    }

}

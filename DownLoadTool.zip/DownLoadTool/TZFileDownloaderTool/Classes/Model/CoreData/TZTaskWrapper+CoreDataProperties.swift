//
//  TZTaskWrapper+CoreDataProperties.swift
//  DownloadDemo
//
//  Created by TyroneZhang on 2018/6/27.
//  Copyright © 2018 TyroneZhang. All rights reserved.
//
//

import Foundation
import CoreData


extension TZTaskWrapper {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<TZTaskWrapper> {
        return NSFetchRequest<TZTaskWrapper>(entityName: "TZTaskWrapper")
    }

    /// 任何一个子任务完成日期（当有子任务完成后，就将该值修改为子任务的完成日期）
    @NSManaged public var completeDate: NSDate?
    /// 创建日期
    @NSManaged public var createDate: NSDate?
    /// 名称
    @NSManaged public var name: String?
    /// 预览图路径
    @NSManaged public var previewPath: String?
    /// 与服务器对应的ID
    @NSManaged public var wrapperID: Int64
    /// 子任务
    @NSManaged public var subTasks: NSSet?
    /// 目录所包含的文件类型
    @NSManaged public var fileType: Int32

}

// MARK: Generated accessors for subTasks
extension TZTaskWrapper {

    @objc(addSubTasksObject:)
    @NSManaged public func addToSubTasks(_ value: TZDownloadTask)

    @objc(removeSubTasksObject:)
    @NSManaged public func removeFromSubTasks(_ value: TZDownloadTask)

    @objc(addSubTasks:)
    @NSManaged public func addToSubTasks(_ values: NSSet)

    @objc(removeSubTasks:)
    @NSManaged public func removeFromSubTasks(_ values: NSSet)

}

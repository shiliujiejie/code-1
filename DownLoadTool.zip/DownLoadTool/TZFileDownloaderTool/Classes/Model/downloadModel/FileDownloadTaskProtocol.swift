//
//  FileDownloadTaskProtocol.swift
//  DownloadDemo
//
//  Created by TyroneZhang on 2018/6/25.
//  Copyright © 2018 TyroneZhang. All rights reserved.
//

import Foundation

public struct FileDownloadDataResponse {
    public var bytesReceived: Int64 = 0
    public var totalBytesReceived: Int64 = 0
    public var bytesExpectToReceive: Int64 = 0
    public var progress: Float = 0
}

public protocol eeee: NSObjectProtocol {
    
}

public protocol FileDownloadTaskProtocol {
    
    /// 判断是否包含子目录，若不包含，则代表其只是一个独立的下载任务
    var hasSubTasks: Bool {get}
    /// 下载源
    var sourceUrlStr: String? {get}
    /// 任务名称
    var taskName: String? {get}
    /// 预览图路径
    var previewPath: String? {get}
    /// 下载状态
    var downloadState: DownloadState {get}
    /// 当前下载大小
    var bytesReceived: Int64 {get}
    /// 已下载大小
    var totalBytesReceived: Int64 {get}
    /// 需要下载的总大小
    var bytesExpectToReceive: Int64 {get}
    /// 下载进度
    var downloadProgress: Float {get}
    /// 下载速度
    var speed: Int64 {get}
    /// 同时支持delegate方式
    var delegate: FileDownloadTaskDelegate? {get set}
    /// 错误情况下的错误类型
    var downloadErrorType: DownloadBrokenErrorType {get}
    
    /// 网速实时回调(bytes/s)
    var downloadSpeed:((Int64) -> Void)? {get set}
    /// 数据实时回调
    var dataResponse: ((FileDownloadDataResponse) -> Void)?  {get set}
    /// 暂停
    var suspendHandler: (() -> Void)?  {get set}
    /// 意外中断
    var brokenHandler: ((_ error: DownloadBrokenErrorType) -> Void)?  {get set}
    /// 下载完成
    var completeHandler: (() -> Void)?  {get set}
    
    /// 开始下载任务
    func startDownloadTask()
    /// 暂停下载任务
    func suspendDownloadTask()
    /// 对比相等(如果是目录，对比的就是目录ID，如果是下载任务，对比的就是url)
    func isEqualTo(_ task: FileDownloadTaskProtocol) -> Bool
    /// 移除delegate
    func removeDelegateFromTask(_ delegate: FileDownloadTaskDelegate)
}


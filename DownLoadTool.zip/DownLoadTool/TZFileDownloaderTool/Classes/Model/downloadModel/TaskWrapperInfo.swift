//
//  TaskWrapperInfo.swift
//  DownloadDemo
//
//  Created by TyroneZhang on 2018/6/25.
//  Copyright © 2018 TyroneZhang. All rights reserved.
//

import Foundation

open class TaskWrapperInfo: FileDownloadTaskProtocol {
    /// 每初始化一次就自增1
    static var kHashValue: Int = 0
    
    /// 定时取网速
    fileprivate var calculateDownloadSpeedTimer: Timer?
    fileprivate let hValue = TaskWrapperInfo.kHashValue + 1
    /// 该目录下所有的子下载任务
    public private(set) var subTasks: [DownloadTaskInfo]?
    private(set) var wrapperModel: TZTaskWrapper?
    /// 判断是否包含子目录，若不包含，则代表其只是一个独立的下载任务
    public private(set) var hasSubTasks: Bool = true
    public private(set) var wrapperID: Int64 = 0
    public private(set) var sourceUrlStr: String?
    public private(set) var taskName: String?
    public private(set) var previewPath: String?
    // 默认wrapper都是downloading状态
    public private(set) var downloadState: DownloadState = .downloading
    public private(set) var bytesReceived: Int64 = 0
    public private(set) var totalBytesReceived: Int64 = 0
    public private(set) var bytesExpectToReceive: Int64 = 0
    public private(set) var downloadProgress: Float = 0
    public private(set) var downloadErrorType: DownloadBrokenErrorType = .unknown
    public private(set) var speed: Int64 = 0 {
        didSet(value) {
            downloadSpeed?(speed)
            delegate?.fileDownloadTask(self, downloadSpeedChanged: speed)
        }
    }
    public weak var delegate: FileDownloadTaskDelegate?
    public var downloadSpeed:((Int64) -> Void)?
    public var dataResponse: ((FileDownloadDataResponse) -> Void)?
    public var suspendHandler: (() -> Void)?
    public var brokenHandler: ((_ error: DownloadBrokenErrorType) -> Void)?
    public var completeHandler:(() -> Void)?
    
    deinit {
        delegate = nil
        stopCalculateDownloadSpeed()
    }
    
    private init() {}
    
    
    /// 创建一个下载目录
    ///
    /// - Parameters:
    ///   - taskName: 目录名称
    ///   - wrapperID: 与服务器对应的目录ID
    ///   - previewPath: 预览图路径
    ///   - subTasks: 该目录下的子任务
    init(_ taskName: String,
         wrapperID: Int64,
         fileType: FileType,
         previewPath: String?,
         subTasks: [DownloadTaskInfo]) {
        self.taskName = taskName
        self.wrapperID = wrapperID
        self.previewPath = previewPath
        self.wrapperModel = TZTaskWrapper.insertTaskWrapper(taskName, wrapperID: wrapperID, fileType: fileType, previewPath: previewPath, subTasks: nil)
        self.addNewTasks(subTasks)
    }
    
    init(_ wrapperModel: TZTaskWrapper) {
        self.taskName = wrapperModel.name
        self.wrapperID = wrapperModel.wrapperID
        self.previewPath = wrapperModel.previewPath
        var isCompleted = true
        if let subTaskModels = wrapperModel.subTasks?.allObjects as? [TZDownloadTask], subTaskModels.count > 0 {
            self.subTasks = [DownloadTaskInfo]()
            for task in subTaskModels {
                let taskInfo = DownloadTaskInfo(task)
                taskInfo.delegate = self
                self.subTasks!.append(taskInfo)
                self.totalBytesReceived += task.totalBytesReceived
                self.bytesExpectToReceive += task.bytesExpectToReceive
                isCompleted = task.downloadState == DownloadState.completed.rawValue
            }
        }
        if isCompleted {
            downloadState = .completed
        }
        self.wrapperModel = wrapperModel
    }
    
    // MARK: - Public funcs

    
    /// wrapper中暂时不提供这个方法
    public func startDownloadTask() {
//        guard let tasks = subTasks, tasks.count > 0 else {
//            return
//        }
//        for task in tasks {
//            task.startDownloadTask()
//        }
    }
    
    /// wrapper中暂时不提供这个方法
    public func suspendDownloadTask() {
//        guard let tasks = subTasks, tasks.count > 0 else {
//            return
//        }
//        for task in tasks {
//            task.suspendDownloadTask()
//        }
    }
    
    /// 移除delegate
    public func removeDelegateFromTask(_ delegate: FileDownloadTaskDelegate) {
        self.delegate = nil
    }
    
    /// 针对目录的判断相等（wrapperID相等 && wrapper下的所有subtasks数量相等 && subtasks里每一个task都相等）
    ///
    /// - Parameter task: 判断相等的目录
    /// - Returns: true：相等，false：不相等
    public func isEqualTo(_ task: FileDownloadTaskProtocol) -> Bool {
        guard let wrapper = task as? TaskWrapperInfo else {
            return false
        }
        if wrapperID != wrapper.wrapperID {
            return false
        }
        if subTasks?.count != wrapper.subTasks?.count {
            return false
        }
        if subTasks == nil {
            return true
        }
        for subTask in subTasks! {
            var result = false
            for task in wrapper.subTasks! {
                if subTask.isEqualTo(task) {
                    result = true
                    break
                }
            }
            if result == false {
                return false
            }
        }
        return true
    }
    
    /// 从该目录中批量删除子任务，如果删除后该目录没有子任务了，那将会删除该目录
    public func deleteSubTasks(_ tasks: [DownloadTaskInfo]) {
        guard let _ = subTasks, tasks.count > 0 else {
            return
        }
        
        for i in 0 ..< tasks.count {
            if subTasks!.count == 0 {
                break
            }
            let task = tasks[i]
            task.deleteDownloadTask()
            let index = subTasks!.index { (obj) -> Bool in
                return obj.isEqualTo(task)
            }
            if index != nil {
                subTasks!.remove(at: index!)
            }
        }
        
        if subTasks!.count == 0 {
            stopCalculateDownloadSpeed()
        } else {
            didSubTasksGetResponse() // 删除过后,更新数据
        }
    }
    
    /// 在wrapper的subtask数组的前面增加一些子任务，如果子任务已经存在，将不会重复插入
    ///
    /// - Parameter tasks: 需要增加的一些子任务
    func addNewTasks(_ tasks: [DownloadTaskInfo]) {
        if subTasks == nil {
            subTasks = [DownloadTaskInfo]()
        }
        for task in tasks {
            let exist = subTasks!.contains { (obj) -> Bool in
                return obj.sourceUrlStr == task.sourceUrlStr
            }
            if !exist {
                task.delegate = self
                subTasks!.insert(task, at: 0)
                bytesExpectToReceive += task.bytesExpectToReceive
                totalBytesReceived += task.totalBytesReceived
                if let taskModel = task.taskModel {
                    wrapperModel?.addToSubTasks(taskModel)
                }
            }
        }
    }
    
    
    /// 从子任务中移除未完成的任务
    func removeUncompletedSubTasks() {
        guard let tasks = subTasks, tasks.count > 0 else {
            return
        }
        let completedSubTasks = tasks.filter { (obj) -> Bool in
            return obj.taskModel?.completeDate != nil
        }
        downloadState = .completed
        subTasks = completedSubTasks
        downloadState = .completed
        var aTotalBytesReceived: Int64 = 0
        var aBytesExpectToReceive: Int64 = 0
        for task in completedSubTasks {
            aTotalBytesReceived += task.totalBytesReceived
            aBytesExpectToReceive += task.bytesExpectToReceive
        }
        totalBytesReceived = aTotalBytesReceived
        bytesExpectToReceive = aBytesExpectToReceive
    }
    
    /// 从子任务中移除已完成的任务
    func removeCompletedSubTasks() {
        guard let tasks = subTasks, tasks.count > 0 else {
            return
        }
        let uncompletedSubTasks = tasks.filter { (obj) -> Bool in
            return obj.taskModel?.completeDate == nil
        }
        downloadState = .downloading
        self.subTasks = uncompletedSubTasks
        var aTotalBytesReceived: Int64 = 0
        var aBytesExpectToReceive: Int64 = 0
        for task in uncompletedSubTasks {
            aTotalBytesReceived += task.totalBytesReceived
            aBytesExpectToReceive += task.bytesExpectToReceive
        }
        totalBytesReceived = aTotalBytesReceived
        bytesExpectToReceive = aBytesExpectToReceive
    }
    
    func isContain(_ subTask: DownloadTaskInfo) -> Bool {
        guard let tasks = subTasks ,tasks.count > 0 else {
            return false
        }
        for task in tasks {
            if task.isEqualTo(subTask) {
                return true
            }
        }
        return false
    }
    
    // MARK: - Private funcs
    
    private func startCalculateDownloadSpeed() {
        guard let tasks = subTasks, tasks.count > 0 else {
            stopCalculateDownloadSpeed()
            return
        }
        if calculateDownloadSpeedTimer != nil {
            return
        }
        calculateDownloadSpeedTimer = Timer.scheduledTimer(timeInterval: DownloadTaskInfo.kCalculateDownloadSpeedTimeInterval, target: self, selector: #selector(TaskWrapperInfo.calculateDownloadSpeedTimerCallback), userInfo: nil, repeats: true)
    }
    
    private func stopCalculateDownloadSpeed() {
        calculateDownloadSpeedTimer?.invalidate()
        calculateDownloadSpeedTimer = nil
        speed = 0
    }
    
    @objc private func calculateDownloadSpeedTimerCallback() {
        guard let tasks = subTasks, tasks.count > 0 else {
            speed = 0
            return
        }
        var downloadSpeed: Int64 = 0
        for task in tasks {
            downloadSpeed += task.speed
        }
        speed = downloadSpeed
    }
    
    fileprivate func didSubTaskDownloadStateChanged(by task: DownloadTaskInfo) {
        guard let tasks = subTasks, tasks.count > 0 else {
            stopCalculateDownloadSpeed()
            return
        }
        if task.downloadState == .completed {
            let index = subTasks!.index { (obj) -> Bool in
                return task.sourceUrlStr == obj.sourceUrlStr
            }
            if index != nil {
                subTasks!.remove(at: index!)
            }
            didSubTasksGetResponse()
        }
        let downloadingTasks = tasks.filter { (obj) -> Bool in
            return obj.downloadState == DownloadState.downloading
        }
        if downloadingTasks.count > 0 {
            downloadState = .downloading
            delegate?.fileDownloadTaskDidStarted(self)
        } else {
            stopCalculateDownloadSpeed()
            let completedTasks = tasks.filter { (obj) -> Bool in
                return obj.downloadState == DownloadState.completed
            }
            if completedTasks.count == tasks.count {
                downloadState = .completed
                completeHandler?()
                delegate?.fileDownloadTaskDidCompleted(self)
                TaskManager.shared.removeCompletedTask(self)
            }
        }
    }
    
    fileprivate func didSubTasksGetResponse() {
        guard let tasks = subTasks, tasks.count > 0 else {
            stopCalculateDownloadSpeed()
            return
        }
        var totalBytesReceived: Int64 = 0
        var bytesExpectToReceive: Int64 = 0
        for task in tasks {
            totalBytesReceived += task.totalBytesReceived
            bytesExpectToReceive += task.bytesExpectToReceive
        }
        self.totalBytesReceived = totalBytesReceived
        self.bytesExpectToReceive = bytesExpectToReceive
        let value = Float(totalBytesReceived) / Float(bytesExpectToReceive)
        downloadProgress = value
        let newResponse = FileDownloadDataResponse(bytesReceived: 0, totalBytesReceived: totalBytesReceived, bytesExpectToReceive: bytesExpectToReceive, progress: value)
        
        dataResponse?(newResponse)
        delegate?.fileDownloadTask(self, didGetResponse: newResponse)
    }
    
}

// MARK: - FileDownloadTaskDelegate

extension TaskWrapperInfo: FileDownloadTaskDelegate {
    
    public func fileDownloadTaskDidWaitOnLine(_ task: FileDownloadTaskProtocol) {
    }
    

    public func fileDownloadTaskDidStarted(_ task: FileDownloadTaskProtocol) {
        downloadState = .downloading
        DispatchQueue.main.async { [weak self] in
            self?.startCalculateDownloadSpeed()
        }
    }
    
    public func fileDownloadTask(_ task: FileDownloadTaskProtocol, downloadSpeedChanged speed: Int64) {}
    
    public func fileDownloadTask(_ task: FileDownloadTaskProtocol, didGetResponse response: FileDownloadDataResponse) {
        guard let tasks = subTasks, tasks.count > 0 else {
            stopCalculateDownloadSpeed()
            return
        }
        OperationQueue.main.addOperation { [weak self] in
            guard let strongSelf = self else {
                return
            }
            strongSelf.didSubTasksGetResponse()
        }
    }
    
    public func fileDownloadTaskDidSuspended(_ task: FileDownloadTaskProtocol) {
        didSubTaskDownloadStateChanged(by: task as! DownloadTaskInfo)
    }
    
    public func fileDownloadTask(_ task: FileDownloadTaskProtocol, beenBrokenWith errorType: DownloadBrokenErrorType) {
        didSubTaskDownloadStateChanged(by: task as! DownloadTaskInfo)
    }
    
    public func fileDownloadTaskDidCompleted(_ task: FileDownloadTaskProtocol) {
        wrapperModel?.completeDate = (task as! DownloadTaskInfo).taskModel!.completeDate!
        wrapperModel?.saveUpdatedWrapperInfo()
        didSubTaskDownloadStateChanged(by: task as! DownloadTaskInfo)
        delegate?.wrapperDownloadTask(self, subTaskFinised: task)
    }
    
    public func delegateHashvalue() -> Int {
        return self.hValue
    }
    
}

//
//  FileDownloadTaskDelegate.swift
//  DownloadDemo
//
//  Created by TyroneZhang on 2018/6/27.
//  Copyright © 2018 TyroneZhang. All rights reserved.
//

import Foundation

public protocol FileDownloadTaskDelegate: class {
    
    /// 开始等待
    func fileDownloadTaskDidWaitOnLine(_ task: FileDownloadTaskProtocol)
    /// 开始下载
    func fileDownloadTaskDidStarted(_ task: FileDownloadTaskProtocol)
    /// 网速实时回调(bytes/s)
    func fileDownloadTask(_ task: FileDownloadTaskProtocol, downloadSpeedChanged speed: Int64)
    /// 数据实时回调
    func fileDownloadTask(_ task: FileDownloadTaskProtocol, didGetResponse response: FileDownloadDataResponse)
    /// 暂停
    func fileDownloadTaskDidSuspended(_ task: FileDownloadTaskProtocol)
    /// 意外中断
    func fileDownloadTask(_ task: FileDownloadTaskProtocol, beenBrokenWith errorType: DownloadBrokenErrorType)
    /// 下载完成
    func fileDownloadTaskDidCompleted(_ task: FileDownloadTaskProtocol)
    /// 获取哈希值，判断相等
    func delegateHashvalue() -> Int
    
    // optional
    
    /// 该目录下载任务中有子任务下载完成了
    func wrapperDownloadTask(_ wrapper: FileDownloadTaskProtocol, subTaskFinised subTask: FileDownloadTaskProtocol)
}

public extension FileDownloadTaskDelegate {
    func wrapperDownloadTask(_ wrapper: FileDownloadTaskProtocol, subTaskFinised subTask: FileDownloadTaskProtocol) {}
}


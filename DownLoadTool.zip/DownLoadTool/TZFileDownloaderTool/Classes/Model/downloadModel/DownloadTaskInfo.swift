//
//  DownloadTaskInfo.swift
//  DownloadDemo
//
//  Created by TyroneZhang on 2018/6/25.
//  Copyright © 2018 TyroneZhang. All rights reserved.
//

import Foundation

struct MultDelegates {
    weak var delegate: FileDownloadTaskDelegate?
}

open class DownloadTaskInfo: FileDownloadTaskProtocol {
    
    static let kCalculateDataTimeInterval = 0.5
    static let kCalculateDownloadSpeedTimeInterval = 2.0
    static let kDataArraySize = 5 // (2 / 0.5) + 1
    
    /// 记录每次下载数据量的数组，为计算网速做准备
    fileprivate var dataCountArr: [Int64]?
    /// 定时计算已下载数据量，更新dataCountArr
    fileprivate var calculateDataTimer: Timer?
    /// 定时取网速
    fileprivate var calculateDownloadSpeedTimer: Timer?
    /// 存取delegate数组
    fileprivate var delegates: [MultDelegates]?
    private(set) var taskModel: TZDownloadTask?
    /// 目录ID
    var wrapperID: Int64?
    /// 判断是否包含子目录，若不包含，则代表其只是一个独立的下载任务
    public private(set) var hasSubTasks: Bool = false
    public private(set) var taskID: Int64 = 0
    public private(set) var sourceUrlStr: String?
    public private(set) var taskName: String?
    public private(set) var previewPath: String?
    public private(set) var downloadState: DownloadState = .waitting
    public private(set) var bytesReceived: Int64 = 0
    public private(set) var totalBytesReceived: Int64 = 0
    public private(set) var bytesExpectToReceive: Int64 = 0
    public private(set) var downloadProgress: Float = 0
    public private(set) var downloadErrorType: DownloadBrokenErrorType = .unknown
    public var downloadSpeed:((Int64) -> Void)?
    public var dataResponse: ((FileDownloadDataResponse) -> Void)?
    public var suspendHandler: (() -> Void)?
    public var brokenHandler: ((_ error: DownloadBrokenErrorType) -> Void)?
    public var completeHandler:(() -> Void)?
    
    static let destDirectoryURL: URL = {
        let urls = FileManager.default.urls(for: FileManager.SearchPathDirectory.documentDirectory, in: FileManager.SearchPathDomainMask.userDomainMask)
        var  document = urls[0]
        return document.appendingPathComponent("Download")
    }()
    public private(set) var speed: Int64 = 0 {
        didSet(value) {
            downloadSpeed?(speed)
            if delegates != nil {
                for multDele in delegates! {
                    multDele.delegate?.fileDownloadTask(self, downloadSpeedChanged: speed)
                }
            }
        }
    }
    public weak var delegate: FileDownloadTaskDelegate? {
        get {
            return nil
        }
        set {
            if newValue == nil {
                return
            }
            if delegates == nil {
                delegates = [MultDelegates]()
                delegates?.append(MultDelegates(delegate: newValue))
            } else {
                let index = delegates!.index { (obj) -> Bool in
                    if obj.delegate == nil {
                        return false
                    }
                    return obj.delegate?.delegateHashvalue() == newValue!.delegateHashvalue()
                }
                if index == nil {
                    delegates!.append(MultDelegates(delegate: newValue))
                }
            }
        }
    }
    
    deinit {
        stopCalculateDownloadSpeed()
        delegates?.removeAll()
    }
    
    private init() {}
    
    
    /// 初始化一个下载任务
    ///
    /// - Parameters:
    ///   - title: 任务名称
    ///   - downloadSource: 下载链接
    ///   - taskID: 与服务器对应的ID
    ///   - previewPath: 预览图
    ///   - wrapperID: 如果有目录，就传递目录的ID
    init(_ taskName: String,
         downloadSource: String,
         taskID: Int64,
         fileType: FileType,
         previewPath: String?,
         wrapperID: Int64?) {
        self.taskName = taskName
        self.sourceUrlStr = downloadSource
        self.taskID = taskID
        self.previewPath = previewPath
        self.taskModel = TZDownloadTask.insertANewTask(taskID, fileType: fileType, taskName: taskName, urlStr: downloadSource, previewPath: previewPath)
        self.downloadState = DownloadState(rawValue: taskModel!.downloadState)!
    }
    
    init(_ taskModle: TZDownloadTask) {
        self.sourceUrlStr = taskModle.fileURLStr
        self.taskName = taskModle.taskName
        self.wrapperID = taskModle.wrapper?.wrapperID
        self.previewPath = taskModle.previewPath
        self.taskID = taskModle.taskID
        self.totalBytesReceived = taskModle.totalBytesReceived
        self.bytesExpectToReceive = taskModle.bytesExpectToReceive
        if bytesExpectToReceive != 0 {
            self.downloadProgress = Float(totalBytesReceived) / Float(bytesExpectToReceive)
        }
        self.downloadState = DownloadState(rawValue: taskModle.downloadState)!
        self.taskModel = taskModle
    }
    
}

// MARK: - Public funcs for other components

public extension DownloadTaskInfo {
    
    public func startDownloadTask() {
        if sourceUrlStr == nil {
            return
        }
        if downloadState == .completed {
            return
        }
        if downloadState == .waitting {
            if TZFileDownloader.shared.getTask(by: sourceUrlStr!) != nil {
                return
            }
        }
        if downloadState == .downloading {
            if TZFileDownloader.shared.getTask(by: sourceUrlStr!) != nil {
                return
            }
        }
        guard let task = TZFileDownloader.shared.addDownloadTask(sourceUrlStr!, resumePath: taskModel?.cachePath) else {
            return
        }
        /// 从等待状态变为激活下载状态
        task.didBecomeActiveState = { [weak self] in
            guard let strongSelf = self else {
                return
            }
            print("\(strongSelf.taskName!) ===== downloading")
            strongSelf.downloadState = .downloading
            strongSelf.taskModel?.downloadState = DownloadState.downloading.rawValue
            strongSelf.taskModel?.saveUpdatedContent()
            if strongSelf.delegates != nil {
                for multDele in strongSelf.delegates! {
                    multDele.delegate?.fileDownloadTaskDidStarted(strongSelf)
                }
            }
            DispatchQueue.main.async {
                if self?.downloadState == .downloading {
                    self?.startCalculateDownloadSpeed()
                }
            }
        }
        task.didCreateDownloadingCacheFile = { [weak self] (resumePath) in
            self?.taskModel?.cachePath = resumePath
            self?.taskModel?.saveUpdatedContent()
        }
        task.brokenHandler = { [weak self] (errorType) in
            guard let strongSelf = self else {
                return
            }
            strongSelf.stopCalculateDownloadSpeed()
            strongSelf.downloadErrorType = errorType
            strongSelf.downloadState = errorType == .cancel ? .pause : .failed
            strongSelf.taskModel?.bytesExpectToReceive = strongSelf.bytesExpectToReceive
            strongSelf.taskModel?.totalBytesReceived = strongSelf.totalBytesReceived
            strongSelf.taskModel?.downloadState = strongSelf.downloadState.rawValue
            strongSelf.taskModel?.saveUpdatedContent()
            
            strongSelf.brokenHandler?(errorType)
            if strongSelf.delegates != nil {
                for multDele in strongSelf.delegates! {
                    multDele.delegate?.fileDownloadTask(strongSelf, beenBrokenWith: errorType)
                }
            }
        }
        task.dataResponse = { [weak self] (bytesReceived, totalBytesReceived, bytesExpectToReceive) in
            guard let strongSelf = self else {
                return
            }
            strongSelf.bytesReceived = bytesReceived
            strongSelf.totalBytesReceived = totalBytesReceived
            strongSelf.bytesExpectToReceive = bytesExpectToReceive
            
            let value = Float(totalBytesReceived) / Float(bytesExpectToReceive)
            strongSelf.downloadProgress = value
            let response = FileDownloadDataResponse(bytesReceived: bytesReceived, totalBytesReceived: totalBytesReceived, bytesExpectToReceive: bytesExpectToReceive, progress: value)
            strongSelf.dataResponse?(response)
            if strongSelf.delegates != nil {
                for multDele in strongSelf.delegates! {
                    multDele.delegate?.fileDownloadTask(strongSelf, didGetResponse: response)
                }
            }
        }
        task.completeHandler = { [weak self] (tmpPath, suggestName, suggestType) in
            guard let strongSelf = self else {
                return
            }
            strongSelf.stopCalculateDownloadSpeed()
            var tmpUrl = URL(fileURLWithPath: tmpPath)
            if suggestName != nil {
                let arr = suggestName!.components(separatedBy: "/")
                if arr.count > 0 {
                    tmpUrl.appendPathExtension(".\(arr.last!)")
                } else {
                    if suggestType != nil {
                        let arr = suggestType!.components(separatedBy: "/")
                        if arr.count > 0 {
                            tmpUrl.appendPathExtension(".\(arr.last!)")
                        }
                    }
                }
            }
            let fileName = tmpUrl.lastPathComponent
            strongSelf.taskModel?.fileName = fileName
            let destURL = DownloadTaskInfo.destDirectoryURL.appendingPathComponent(fileName)
            let fileManager = FileManager.default
            if fileManager.fileExists(atPath: destURL.path) {
                try! fileManager.removeItem(at: destURL)
            } else {
                if !fileManager.fileExists(atPath: DownloadTaskInfo.destDirectoryURL.absoluteString, isDirectory: nil) {
                    try? fileManager.createDirectory(at: DownloadTaskInfo.destDirectoryURL, withIntermediateDirectories: true, attributes: nil)
                }
            }
            do {
                try fileManager.moveItem(at: URL(fileURLWithPath: tmpPath), to: destURL)
                strongSelf.taskModel?.storeDestinationPath = fileName //  存储相对路径
                strongSelf.encryptFile(suggestedName: fileName)
            } catch {
                print("下载完成,但是存储失败!!!")
            }
            
        }
        
        downloadState = task.state
        taskModel?.downloadState = DownloadState.waitting.rawValue
        if delegates != nil {
            for multDele in delegates! {
                multDele.delegate?.fileDownloadTaskDidWaitOnLine(self)
            }
        }
    }
    
    
    /// 暂停任务
    public func suspendDownloadTask() {
        if sourceUrlStr == nil {
            return
        }
        stopCalculateDownloadSpeed()
        TZFileDownloader.shared.suspendDownload(sourceUrlStr!)
        
        downloadErrorType = .cancel
        downloadState = .pause
        taskModel?.bytesExpectToReceive = bytesExpectToReceive
        taskModel?.downloadState = downloadState.rawValue
        taskModel?.saveUpdatedContent()
        
        brokenHandler?(downloadErrorType)
        if delegates != nil {
            for multDele in delegates! {
                multDele.delegate?.fileDownloadTask(self, beenBrokenWith: downloadErrorType)
            }
        }
        
    }
    
    /// 针对下载任务判断是否相等（url相等 && taskID相等）
    ///
    /// - Parameter task: 相比较的下载任务对象
    /// - Returns: true：相等，false：不相等
    public func isEqualTo(_ task: FileDownloadTaskProtocol) -> Bool {
        guard let aTask = task as? DownloadTaskInfo else {
            return false
        }
        return taskID == aTask.taskID && sourceUrlStr == aTask.sourceUrlStr
    }
    
    
    /// 获取已完成它任务的文件存储路径
    ///
    /// - Returns: 文件路径
    public func getCompletedSourcePath() -> String? {
        if downloadState != .completed {
            return nil
        }
        guard let path = taskModel?.storeDestinationPath else {
            return nil
        }
        let destURL = DownloadTaskInfo.destDirectoryURL.appendingPathComponent(path)
        return destURL.path
    }
    
    /// 移除delegate
    public func removeDelegateFromTask(_ delegate: FileDownloadTaskDelegate) {
        if delegates == nil {
            return
        }
        let index = delegates!.index { (del) -> Bool in
            if del.delegate != nil {
                return delegate.delegateHashvalue() == del.delegate!.delegateHashvalue()
            }
            return false
        }
        if index != nil {
            delegates!.remove(at: index!)
        }
    }
    
}

// MARK: - Public funcs in the components

extension DownloadTaskInfo {
    
    /// 删除任务
    func deleteDownloadTask() {
        if sourceUrlStr == nil {
            return
        }
        delegates?.removeAll()
        stopCalculateDownloadSpeed()
        TZFileDownloader.shared.deleteDownload(sourceUrlStr!, resumePath: taskModel?.cachePath)
        removeDownedFile()
        taskModel?.deleteTask()
        taskModel = nil
    }
    
    
    /// 由于不支持移动网络下下载,主动取消任务
    func cancelTaskByCellularNetwork() {
        if sourceUrlStr == nil {
            return
        }
        stopCalculateDownloadSpeed()
        TZFileDownloader.shared.cancelAllTasksByCellularNetwork()
        downloadErrorType = .canceledByCellularNetwork
        downloadState = .failed
        taskModel?.bytesExpectToReceive = bytesExpectToReceive
        taskModel?.downloadState = downloadState.rawValue
        taskModel?.saveUpdatedContent()
        
        brokenHandler?(downloadErrorType)
        if delegates != nil {
            for multDele in delegates! {
                multDele.delegate?.fileDownloadTask(self, beenBrokenWith: downloadErrorType)
            }
        }
        
    }
    
    func cancelTaskByNetworkError() {
        if sourceUrlStr == nil {
            return
        }
        stopCalculateDownloadSpeed()
        TZFileDownloader.shared.cancelAllTasksByNetworkError()
        downloadErrorType = .networkError
        downloadState = .failed
        taskModel?.bytesExpectToReceive = bytesExpectToReceive
        taskModel?.downloadState = downloadState.rawValue
        taskModel?.saveUpdatedContent()
        
        brokenHandler?(downloadErrorType)
        if delegates != nil {
            for multDele in delegates! {
                multDele.delegate?.fileDownloadTask(self, beenBrokenWith: downloadErrorType)
            }
        }
    }
    
}

// MARK: - Private funcs

private extension DownloadTaskInfo {
    
    private func startCalculateDownloadSpeed() {
        stopCalculateDownloadSpeed()
        calculateDataTimer = Timer.scheduledTimer(timeInterval: DownloadTaskInfo.kCalculateDataTimeInterval, target: self, selector: #selector(DownloadTaskInfo.calculateDataTimerCallback), userInfo: nil, repeats: true)
        calculateDownloadSpeedTimer = Timer.scheduledTimer(timeInterval: DownloadTaskInfo.kCalculateDownloadSpeedTimeInterval, target: self, selector: #selector(DownloadTaskInfo.calculateDownloadSpeedTimerCallback), userInfo: nil, repeats: true)
    }
    
    private func stopCalculateDownloadSpeed() {
        calculateDataTimer?.invalidate()
        calculateDataTimer = nil
        calculateDownloadSpeedTimer?.invalidate()
        calculateDownloadSpeedTimer = nil
        dataCountArr?.removeAll()
    }
    
    @objc private func calculateDataTimerCallback() {
        if dataCountArr == nil {
            dataCountArr = []
        }
        if dataCountArr!.count == 0 {
            dataCountArr!.append(totalBytesReceived)
            return
        }
        let changeBytes = totalBytesReceived - dataCountArr![0]
        if dataCountArr!.count == DownloadTaskInfo.kDataArraySize {
            dataCountArr!.remove(at: 1)
        }
        dataCountArr!.append(changeBytes)
        dataCountArr![0] = totalBytesReceived
    }
    
    @objc private func calculateDownloadSpeedTimerCallback() {
        if taskModel == nil {
            stopCalculateDownloadSpeed()
        }
        guard let array = dataCountArr else {
            self.speed = 0
            return
        }
        if array.count == 1 {
            self.speed = array[0]
            return
        }
        var totalChanged: Int64 = 0
        let totalTime = Double(array.count - 1) * 0.5
        for i in 1 ..< array.count {
            totalChanged += array[i]
        }
        let averageSpeed = Double(totalChanged) / totalTime
        print("==========tt===== \(totalChanged)======\(totalTime)")
        self.speed = Int64(averageSpeed)
    }
    
    private func generateCacheFileName() -> String {
        return "\(sourceUrlStr!.hashValue)_\(taskID)"
    }
    
    private func removeDownedFile() {
        if let suggestedName = self.taskModel?.fileName {
            let destURL = DownloadTaskInfo.destDirectoryURL.appendingPathComponent(suggestedName)
            let fileManager = FileManager.default
            if fileManager.fileExists(atPath: destURL.path) {
                try? fileManager.removeItem(at: destURL)
            }
        }
    }
    
    /// 加密文件
    ///
    /// - Parameter suggestedName: 源文件存储的名字
    private func encryptFile(suggestedName: String) {
        downloadState = .completed
        taskModel?.bytesExpectToReceive = bytesExpectToReceive
        taskModel?.totalBytesReceived = bytesExpectToReceive
        downloadProgress = 1
        taskModel?.downloadState = downloadState.rawValue
        taskModel?.completeDate = Date.getCurrentDeviceDate() as NSDate
        taskModel?.saveUpdatedContent()
        completeHandler?()
        if delegates != nil {
            for multDele in delegates! {
                multDele.delegate?.fileDownloadTaskDidCompleted(self)
            }
        }
    }
}


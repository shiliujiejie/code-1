//
//  ViewController.swift
//  DownloadDemo
//
//  Created by TyroneZhang on 2018/6/20.
//  Copyright © 2018 TyroneZhang. All rights reserved.
//

import UIKit
import TZFileDownloaderTool

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var startOrPauseBtn: UIButton!
    @IBOutlet weak var capacity: UILabel!
    
    fileprivate var taskArray: [FileDownloadTaskProtocol]?
    //使用这个pod私有库编译不通过,报错“Command failed due to signal: Abort trap: 6”,不知道为什么
    fileprivate var wrapper: TaskWrapperInfo?
    // 下一级的子任务界面删除数据后，需要在父界面更新UI
    var didDeleteSubTasksHandler: (() -> Void)?
    
    deinit {
        print("ViewController release")
    }
    
    
    /// 带目录的任务进入其子任务界面,使用此初始化方法
    ///
    /// - Parameter wrapper: 目录
    /// - Returns: ViewController
    class func `init`(_ wrapper: TaskWrapperInfo) -> ViewController {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        vc.wrapper = wrapper
        vc.taskArray = vc.wrapper?.subTasks

        if var subTasks = vc.taskArray {
            for i in 0 ..< subTasks.count {
                subTasks[i].delegate = vc
            }
        }
        return vc
    }

    class func `init`(_ tasks: [FileDownloadTaskProtocol]) -> ViewController {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        var newTasks = tasks
        for i in 0 ..< newTasks.count {
            newTasks[i].delegate = vc
        }
        vc.taskArray = newTasks
        return vc
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.tableFooterView = UIView(frame: CGRect.zero)
        updateStartAllPauseButtonTitle()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
 
    @IBAction func didClickControllAllTasks(_ sender: Any) {
        startOrPauseBtn.isSelected = startOrPauseBtn.isSelected
        if startOrPauseBtn.isSelected {
            TaskManager.shared.suspendAllTasks()
        } else {
            TaskManager.shared.startAllTasks()
        }
    }

}

// MARK: - Private funcs

private extension ViewController {
    
    func alertDonwloadingWithCellularNetwork(_ task: FileDownloadTaskProtocol) {
        let alert = UIAlertController(title: nil, message: "您当前正处于流量环境下,若继续下载,可能会产生高额的流量费?", preferredStyle: UIAlertControllerStyle.alert)
        let cancelAction = UIAlertAction(title: "取消下载", style: UIAlertActionStyle.cancel, handler: { (action) in
            UserDefaults.standard.setValue(false, forKey: "allowDownloadingWith4G")
        })
        let confirmAction = UIAlertAction(title: "继续下载", style: UIAlertActionStyle.default) { (action) in
            UserDefaults.standard.setValue(true, forKey: "allowDownloadingWith4G")
            TaskManager.shared.startAllTasksThatSuspendedByCellularNetwork(firstTask: task)
        }
        alert.addAction(cancelAction)
        alert.addAction(confirmAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    func showNetworkError() {
        let alert = UIAlertController(title: "网络故障", message: "亲,您没连网呢!", preferredStyle: UIAlertControllerStyle.alert)
        let cancelAction = UIAlertAction(title: "确定", style: UIAlertActionStyle.cancel, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
        })
        alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    func updateStartAllPauseButtonTitle() {
        if taskArray == nil || taskArray!.count == 0 {
            startOrPauseBtn.isHidden = true
            return
        }
        startOrPauseBtn.isHidden = false
        var isAllInDownloading = true
        for task in taskArray! {
            if task.downloadState != .downloading && task.downloadState != .waitting {
                isAllInDownloading = false
                break
            }
        }
        startOrPauseBtn.isSelected = isAllInDownloading
    }
    
}

// MARK: - UITableViewDelegate, UITableViewDataSource

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if taskArray == nil {
            return 0
        }
        return taskArray!.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TaskTableViewCell
        let task = taskArray![indexPath.row]
        cell.taskName.text = task.taskName
        switch task.downloadState {
        case .waitting:
            cell.downloadSpeedLabel.isHidden = false
            cell.downloadSpeedLabel.text = "waitting..."
            cell.sizeLabel.isHidden = true
            cell.progress.progress = task.downloadProgress
        case .downloading:
            cell.downloadSpeedLabel.isHidden = false
            cell.downloadSpeedLabel.text = "0k/s"
            cell.sizeLabel.isHidden = false
            cell.sizeLabel.text = "\(task.totalBytesReceived)Bytes/\(task.bytesExpectToReceive)Bytes"
            cell.progress.progress = task.downloadProgress
        case .pause:
            cell.downloadSpeedLabel.isHidden = false
            cell.downloadSpeedLabel.text = "paused"
            cell.sizeLabel.isHidden = false
            cell.sizeLabel.text = "\(task.totalBytesReceived)Bytes/\(task.bytesExpectToReceive)Bytes"
            cell.progress.progress = task.downloadProgress
        case .completed:
            cell.downloadSpeedLabel.isHidden = false
            cell.downloadSpeedLabel.text = "completed"
            cell.sizeLabel.isHidden = false
            cell.sizeLabel.text = "\(task.totalBytesReceived)Bytes"
            cell.progress.progress = task.downloadProgress
        case .failed:
            cell.downloadSpeedLabel.isHidden = false
            if task.downloadErrorType == .canceledByCellularNetwork {
                cell.downloadSpeedLabel.text = "移动网络下已经暂停"
            } else if task.downloadErrorType == .networkError {
                cell.downloadSpeedLabel.text = "未连接网络"
            } else {
                cell.downloadSpeedLabel.text = "failed"
            }
            cell.sizeLabel.isHidden = false
            cell.sizeLabel.text = "\(task.totalBytesReceived)Bytes/\(task.bytesExpectToReceive)Bytes"
            cell.progress.progress = task.downloadProgress
        }

        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 77
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let task = taskArray![indexPath.row]
        
        if !task.hasSubTasks {
            switch task.downloadState {
            case .waitting:
                task.suspendDownloadTask()
            case .downloading:
                task.suspendDownloadTask()
            case .failed, .pause:
                if task.downloadErrorType == .canceledByCellularNetwork {
                    alertDonwloadingWithCellularNetwork(task)
                } else if task.downloadErrorType == .networkError {
                    showNetworkError()
                } else {
                    task.startDownloadTask()
                }
            case .completed:
                print("already completed!!!")
                if let path = (task as! DownloadTaskInfo).getCompletedSourcePath() {
                    print(path)
                }
            }
            updateStartAllPauseButtonTitle()
        } else  {
            let vc = ViewController.init(task as! TaskWrapperInfo)
            vc.didDeleteSubTasksHandler = { [weak self] in
                let wrapper = task as! TaskWrapperInfo
                if wrapper.subTasks == nil || wrapper.subTasks!.count == 0 {
                    let index = self?.taskArray?.index(where: { (obj) -> Bool in
                        obj.isEqualTo(wrapper)
                    })
                    if index != nil {
                        self?.taskArray?.remove(at: index!)
                        tableView.reloadData()
                    }
                }
            }
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
        return UITableViewCellEditingStyle.delete
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if indexPath.row >= taskArray!.count {
            return
        }
        if editingStyle == .delete {
            let task = taskArray![indexPath.row]
            taskArray!.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .middle)
            TaskManager.shared.removeTask(task: task)
            if wrapper != nil {
                wrapper!.deleteSubTasks([task as! DownloadTaskInfo])
            }
            didDeleteSubTasksHandler?()
        }
        updateStartAllPauseButtonTitle()
    }
    
}

// MARK: FileDownloadInfoDelegate

extension ViewController: FileDownloadTaskDelegate {
    
    func fileDownloadTaskDidWaitOnLine(_ task: FileDownloadTaskProtocol) {
        OperationQueue.main.addOperation { [weak self] in
            guard let index = self?.getTaskIndex(by: task) else {
                return
            }
            guard let _ = self?.tableView?.cellForRow(at: IndexPath(row: index, section: 0)) as? TaskTableViewCell else {
                return
            }
            self?.tableView?.reloadRows(at: [IndexPath(row: index, section: 0)], with: .none)
            self?.updateStartAllPauseButtonTitle()
        }
    }
    
    // 开始下载
    func fileDownloadTaskDidStarted(_ task: FileDownloadTaskProtocol) {
        OperationQueue.main.addOperation { [weak self] in
            guard let index = self?.getTaskIndex(by: task) else {
                return
            }
            guard let _ = self?.tableView?.cellForRow(at: IndexPath(row: index, section: 0)) as? TaskTableViewCell else {
                return
            }
            self?.tableView?.reloadRows(at: [IndexPath(row: index, section: 0)], with: .none)
            self?.updateStartAllPauseButtonTitle()
        }
    }
    
    /// 网速实时回调(bytes/s)
    func fileDownloadTask(_ task: FileDownloadTaskProtocol, downloadSpeedChanged speed: Int64) {
        OperationQueue.main.addOperation { [weak self] in
            guard let index = self?.getTaskIndex(by: task) else {
                return
            }
            guard let cell = self?.tableView?.cellForRow(at: IndexPath(row: index, section: 0)) as? TaskTableViewCell else {
                return
            }
            cell.downloadSpeedLabel?.text = self?.getTransformedDownloadSpeed(speed)
        }
    }
    
    /// 数据实时回调
    func fileDownloadTask(_ task: FileDownloadTaskProtocol, didGetResponse response: FileDownloadDataResponse) {
        OperationQueue.main.addOperation { [weak self] in
            guard let index = self?.getTaskIndex(by: task) else {
                return
            }
            guard let cell = self?.tableView?.cellForRow(at: IndexPath(row: index, section: 0)) as? TaskTableViewCell else {
                return
            }
            cell.sizeLabel?.text = "\(response.totalBytesReceived)Bytes/\(response.bytesExpectToReceive)Bytes"
            cell.progress?.progress = response.progress
        }
    }
    
    /// 暂停
    func fileDownloadTaskDidSuspended(_ task: FileDownloadTaskProtocol) {
        OperationQueue.main.addOperation { [weak self] in
            guard let index = self?.getTaskIndex(by: task) else {
                return
            }
            guard let _ = self?.tableView?.cellForRow(at: IndexPath(row: index, section: 0)) as? TaskTableViewCell else {
                return
            }
            self?.tableView?.reloadRows(at: [IndexPath(row: index, section: 0)], with: .none)
            self?.updateStartAllPauseButtonTitle()
        }
    }
    
    /// 意外中断
    func fileDownloadTask(_ task: FileDownloadTaskProtocol, beenBrokenWith errorType: DownloadBrokenErrorType) {
        OperationQueue.main.addOperation { [weak self] in
            guard let index = self?.getTaskIndex(by: task) else {
                return
            }
            guard let _ = self?.tableView?.cellForRow(at: IndexPath(row: index, section: 0)) as? TaskTableViewCell else {
                return
            }
            self?.tableView?.reloadRows(at: [IndexPath(row: index, section: 0)], with: .none)
            self?.updateStartAllPauseButtonTitle()
        }
    }
    
    /// 下载完成
    func fileDownloadTaskDidCompleted(_ task: FileDownloadTaskProtocol) {
        OperationQueue.main.addOperation { [weak self] in
            guard let index = self?.getTaskIndex(by: task) else {
                return
            }
            self?.taskArray?.remove(at: index)
            self?.tableView?.deleteRows(at: [IndexPath(row: index, section: 0)], with: UITableViewRowAnimation.middle)
            self?.updateStartAllPauseButtonTitle()
        }
    }
    
    func delegateHashvalue() -> Int {
        return self.hashValue
    }
    
    private func getTransformedDownloadSpeed(_ bytesSpeed: Int64) -> String {
        if bytesSpeed < 1024 {
            return "\(bytesSpeed)bytes/s"
        }
        if bytesSpeed > 1024 && bytesSpeed < 1048576 {
            let speed = bytesSpeed / Int64(1024)
            return "\(speed)kb/s"
        } else {
            let speed = Double(bytesSpeed) / Double(1048576)
            let speedStr = String(format: "%.2f", speed)
            return "\(speedStr)M/s"
        }
    }
    
    private func getTaskIndex(by task: FileDownloadTaskProtocol) -> Int? {
        guard let array = taskArray else {
            return nil
        }
        let index = array.index { (obj) -> Bool in
            return task.isEqualTo(obj)
        }
        return index
    }
    
}

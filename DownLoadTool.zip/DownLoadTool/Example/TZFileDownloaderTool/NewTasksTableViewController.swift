//
//  NewTasksTableViewController.swift
//  DownloadDemo
//
//  Created by TyroneZhang on 2018/7/3.
//  Copyright © 2018 TyroneZhang. All rights reserved.
//

import UIKit
import TZFileDownloaderTool
import TZNetworking

class NewTasksTableViewController: UITableViewController {
    
    @IBOutlet weak var confirmBtn: UIBarButtonItem!
    private let tasks: [DownloadTask] = [
        DownloadTask(taskID: 2, fileType: .video, taskName: "QQ", downloadUrlStr: "http://dldir1.qq.com/qqfile/QQforMac/QQ_V6.4.0.dmg", previewPath: nil),
        DownloadTask(taskID: 5, fileType: .video, taskName: "QQMusic", downloadUrlStr: "http://gdown.baidu.com/data/wisegame/96a5775969f07fd5/QQyinle_850.apk", previewPath: nil),
        DownloadTask(taskID: 7, fileType: .video, taskName: "CleanMac", downloadUrlStr: "http://dl.hkcleanmymac.com/CleanMyMacChinese.dmg", previewPath: nil),
        
        DownloadTask(taskID: 1, fileType: .video, taskName: "iOS Programming Guide dsflkasdflkasjdlfkjalsdkfjakldsjfladksjflkdsjaflkjfl", downloadUrlStr: "https://developer.apple.com/library/ios/documentation/iphone/conceptual/iphoneosprogrammingguide/iphoneappprogrammingguide.pdf", previewPath: nil),
        DownloadTask(taskID: 3, fileType: .video, taskName: "iPhone User Guide", downloadUrlStr: "http://192.168.28.217/iphone_user_guide.pdf", previewPath: nil),
        
        DownloadTask(taskID: 4, fileType: .video, taskName: "Old Boy", downloadUrlStr: "http://192.168.28.217/3.mp4", previewPath: nil),
        DownloadTask(taskID: 6, fileType: .video, taskName: "iTunes", downloadUrlStr: "https://secure-appldnld.apple.com/itunes12/091-81932-20180529-DAFCC9F2-5F77-11E8-B1FB-4E9A897FD268/iTunes12.7.5.dmg", previewPath: nil),
        DownloadTask(taskID: 8, fileType: .video, taskName: "error iTunes", downloadUrlStr: "https://192.168.1.1/", previewPath: nil),
        DownloadTask(taskID: 9, fileType: .video, taskName: "测试数据sts", downloadUrlStr: "http://192.168.28.88:18081/userApp/oss/auth?key=4.mp4", previewPath: nil),
        DownloadTask(taskID: 9, fileType: .video, taskName: "大文件", downloadUrlStr: "http://192.168.28.217/1532331686466.mp4", previewPath: nil)
        
    ]
    private var selectedIndexPath: [IndexPath]?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        
        TaskManager.shared.checkExist(by: tasks)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    private func showNetworkError() {
        let alert = UIAlertController(title: "网络故障", message: "亲,您没连网呢!", preferredStyle: UIAlertControllerStyle.alert)
        let cancelAction = UIAlertAction(title: "确定", style: UIAlertActionStyle.cancel, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
        })
        alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func backBtnBeenClicked(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func configBtnBeenClicked(_ sender: Any) {
        if selectedIndexPath == nil || selectedIndexPath!.count == 0 {
            return
        }
        if !TZNetworkingConfigurationManager.shareInstance.isReachable {
            showNetworkError()
            return
        }
        
        let sortedArr = selectedIndexPath!.sorted { (index1, index2) -> Bool in
            return index1.row < index2.row
        }
        
        print("you have added \(sortedArr.count) download tasks!")
        
        for indexPath in sortedArr {
            
            switch indexPath.row {
            case 0:
                let wrapper = TaskWrapper(wrapperID: 1, fileType: .video, wrapperName: "QQ & QQMusic & cleanMac", previewPath: nil)
                let _ = TaskManager.shared.createWrapper(wrapper, with: [tasks[indexPath.row]])
            case 1:
                let wrapper = TaskWrapper(wrapperID: 1, fileType: .video, wrapperName: "QQ & QQMusic & cleanMac", previewPath: nil)
                let _ = TaskManager.shared.createWrapper(wrapper, with: [tasks[indexPath.row]])
            case 2:
                let wrapper = TaskWrapper(wrapperID: 1, fileType: .video, wrapperName: "QQ & QQMusic & cleanMac", previewPath: nil)
                let _ = TaskManager.shared.createWrapper(wrapper, with: [tasks[indexPath.row]])
            case 3:
                let wrapper = TaskWrapper(wrapperID: 2, fileType: .video, wrapperName: "About iOS", previewPath: nil)
                let _ = TaskManager.shared.createWrapper(wrapper, with: [tasks[indexPath.row]])
            case 4:
                let wrapper = TaskWrapper(wrapperID: 2, fileType: .video, wrapperName: "About iOS", previewPath: nil)
                let _ = TaskManager.shared.createWrapper(wrapper, with: [tasks[indexPath.row]])
            case 5:
                let _ = TaskManager.shared.createTask(tasks[indexPath.row])
            case 6:
                let _ = TaskManager.shared.createTask(tasks[indexPath.row])
            case 7:
                let _ = TaskManager.shared.createTask(tasks[indexPath.row])
            case 8,9:
                let _ = TaskManager.shared.createTask(tasks[indexPath.row])
            default: break
            }

        }
        
        if TZNetworkManager.currentNetworkType() == .wwan {
            TaskManager.shared.suspendAllTasksByCellularNetwork()
            if let isAllow = UserDefaults.standard.value(forKey: "allowDownloadingWith4G") as? Bool, isAllow {
                alertDonwloadingWithCellularNetwork()
            } else {
                alertForbidCellularNetwork()
            }
        } else {
            dismiss(animated: true, completion: nil)
        }
    }
    
    private func alertForbidCellularNetwork() {
        let alert = UIAlertController(title: nil, message: "当前运营商网络下已为您暂停下载,如仍需下载请在“设置”中更改", preferredStyle: UIAlertControllerStyle.alert)
        let cancelAction = UIAlertAction(title: "仅WIFI下载", style: UIAlertActionStyle.cancel, handler: { [weak self] (action) in
            UserDefaults.standard.setValue(true, forKey: "allowDownloadingWith4G")
            alert.dismiss(animated: true, completion: nil)
            self?.dismiss(animated: true, completion: nil)
        })
        let confirmAction = UIAlertAction(title: "更改设置", style: UIAlertActionStyle.default) {[weak self] (action) in
            alert.dismiss(animated: true, completion: nil)
            self?.dismiss(animated: true, completion: nil)
        }
        alert.addAction(cancelAction)
        alert.addAction(confirmAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    private func alertDonwloadingWithCellularNetwork() {
        let alert = UIAlertController(title: nil, message: "您已设置允许运营商网络下下载视频,可能产生超额流量费,是否继续下载?", preferredStyle: UIAlertControllerStyle.alert)
        let cancelAction = UIAlertAction(title: "更改设置", style: UIAlertActionStyle.cancel, handler: { [weak self] (action) in
            alert.dismiss(animated: true, completion: nil)
            self?.dismiss(animated: true, completion: nil)
        })
        let confirmAction = UIAlertAction(title: "继续下载", style: UIAlertActionStyle.default) { [weak self] (action) in
            UserDefaults.standard.setValue(true, forKey: "allowDownloadingWith4G")
            TaskManager.shared.startAllTasksThatSuspendedByCellularNetwork(firstTask: nil)
            alert.dismiss(animated: true, completion: nil)
            self?.dismiss(animated: true, completion: nil)
        }
        alert.addAction(cancelAction)
        alert.addAction(confirmAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return tasks.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! NewTaskTableViewCell
        
        let result = tasks[indexPath.row]
        let task = tasks[indexPath.row]
        cell.taskName.text = task.taskName
        if result.isExist {
            cell.taskName.textColor = UIColor.darkGray
            cell.taskState.isHidden = false
            switch result.downloadState! {
            case .completed:
                cell.taskState.text = "已下载"
            case .waitting:
                cell.taskState.text = "等待下载中"
            case .downloading:
                cell.taskState.text = "下载中"
            case .pause:
                cell.taskState.text = "暂停中"
            case .failed:
                cell.taskState.text = "下载失败"
            }
        } else {
            cell.taskName.textColor = UIColor(red: 49 / 255.0, green: 145 / 255.0, blue: 1, alpha: 1)
            cell.taskState.isHidden = true
        }
        if selectedIndexPath != nil && selectedIndexPath!.contains(indexPath) {
            cell.accessoryType = .checkmark
        } else {
            cell.accessoryType = .none
        }
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }

    
    override func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
        if !tasks[indexPath.row].isExist {
            return indexPath
        }
        return nil
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let cell = tableView.cellForRow(at: indexPath)
        if selectedIndexPath == nil {
            selectedIndexPath = [IndexPath]()
        }
        if selectedIndexPath!.contains(indexPath) {
            let index = selectedIndexPath!.index { (element) -> Bool in
                return element == indexPath
            }
            selectedIndexPath!.remove(at: index!)
            cell!.accessoryType = .none
        } else {
            selectedIndexPath!.append(indexPath)
            cell!.accessoryType = .checkmark
        }
    }

}

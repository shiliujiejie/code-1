//
//  RootViewController.swift
//  DownloadDemo
//
//  Created by TyroneZhang on 2018/6/28.
//  Copyright © 2018 TyroneZhang. All rights reserved.
//

import UIKit
import TZFileDownloaderTool
import TZNetworking

class RootViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var sizeLabel: UILabel!
    @IBOutlet weak var wwanBtn: UIBarButtonItem!
    fileprivate var taskArray: [FileDownloadTaskProtocol]?
    fileprivate var focusedTask: FileDownloadTaskProtocol?
    fileprivate var uncompletedTasksCount: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.isHidden = true
        button.isHidden = true
        
        tableView.tableFooterView = UIView(frame: CGRect.zero)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        updateSizeLabel()
        updateDataSource()
        updateWwanBtnTitle()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    private func updateWwanBtnTitle() {
        if let isAllow = UserDefaults.standard.value(forKey: "allowDownloadingWith4G") as? Bool, isAllow {
            wwanBtn.title = "allowWwan"
        } else {
            wwanBtn.title = "NoWwan"
        }
    }
    
    @IBAction func switchWwan(_ sender: Any) {
        if let isAllow = UserDefaults.standard.value(forKey: "allowDownloadingWith4G") as? Bool, isAllow {
            UserDefaults.standard.setValue(false, forKey: "allowDownloadingWith4G")
            if TZNetworkManager.currentNetworkType() == .wwan {
                TaskManager.shared.suspendAllTasksByCellularNetwork()
            }
        } else {
            UserDefaults.standard.setValue(true, forKey: "allowDownloadingWith4G")
            if TZNetworkManager.currentNetworkType() != .notReachable {
                TaskManager.shared.startAllTasksThatSuspendedByCellularNetwork(firstTask: nil)
            }
        }
        updateWwanBtnTitle()
    }
    
    fileprivate func updateDataSource() {
        updateWwanBtnTitle()
        uncompletedTasksCount = TaskManager.shared.getUnCompletedTasksCount()
        taskArray = TaskManager.shared.getAllCompletedTasks()
        focusedTask?.removeDelegateFromTask(self)
        focusedTask = TaskManager.shared.getFocusedDownloadTask()
        focusedTask?.delegate = self
        DispatchQueue.main.async { [unowned self] in
            if self.uncompletedTasksCount == 0 && (self.taskArray == nil || self.taskArray!.count == 0) {
                self.button.isHidden = false
                self.tableView.isHidden = true
            } else {
                self.button.isHidden = true
                self.tableView.isHidden = false
            }
            self.tableView.reloadData()
        }
    }
    
    fileprivate func updateSizeLabel() {
        let mutableAttributedStr = NSMutableAttributedString(string: "已使用 ", attributes: [NSAttributedStringKey.foregroundColor : UIColor.black, NSAttributedStringKey.font: UIFont.systemFont(ofSize: 10)])
        let usedSpaceStr = String(format: "%.2fG", TaskManager.shared.getUsedDiskSized())
        let availabelStr = String(format: "%.2fG", TaskManager.shared.getAvailableSize())
        mutableAttributedStr.append(NSAttributedString(string: usedSpaceStr, attributes: [NSAttributedStringKey.foregroundColor : UIColor(red: 49 / 255.0, green: 145 / 255.0, blue: 1, alpha: 1), NSAttributedStringKey.font: UIFont.systemFont(ofSize: 10)]))
        mutableAttributedStr.append(NSAttributedString(string: ", 可用空间 ", attributes: [NSAttributedStringKey.foregroundColor : UIColor.black, NSAttributedStringKey.font: UIFont.systemFont(ofSize: 10)]))
        mutableAttributedStr.append(NSAttributedString(string: availabelStr, attributes: [NSAttributedStringKey.foregroundColor : UIColor(red: 49 / 255.0, green: 145 / 255.0, blue: 1, alpha: 1), NSAttributedStringKey.font: UIFont.systemFont(ofSize: 10)]))
        sizeLabel.attributedText = mutableAttributedStr
    }
    
}

// MARK: - UITableViewDelegate, UITableViewDataSource

extension RootViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return uncompletedTasksCount == 0 ? 0 : 1
        } else {
            return taskArray == nil ? 0 : taskArray!.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TaskTableViewCell
        let task = indexPath.section == 0 ? focusedTask! : taskArray![indexPath.row]
        cell.taskName.text = task.taskName
        switch task.downloadState {
        case .waitting:
            cell.downloadSpeedLabel.isHidden = false
            cell.downloadSpeedLabel.text = "waitting..."
            cell.sizeLabel.isHidden = true
            cell.progress.progress = 0
        case .downloading:
            cell.downloadSpeedLabel.isHidden = false
            cell.sizeLabel.isHidden = false
            cell.sizeLabel.text = "\(task.totalBytesReceived)Bytes/\(task.bytesExpectToReceive)Bytes"
            cell.progress.progress = task.downloadProgress
        case .pause:
            cell.downloadSpeedLabel.isHidden = false
            cell.downloadSpeedLabel.text = "paused"
            cell.sizeLabel.isHidden = false
            cell.sizeLabel.text = "\(task.totalBytesReceived)Bytes/\(task.bytesExpectToReceive)Bytes"
            cell.progress.progress = task.downloadProgress
        case .completed:
            cell.downloadSpeedLabel.isHidden = false
            cell.downloadSpeedLabel.text = "completed"
            cell.sizeLabel.isHidden = false
            cell.sizeLabel.text = "\(task.totalBytesReceived)Bytes"
            cell.progress.progress = task.downloadProgress
        case .failed:
            cell.downloadSpeedLabel.isHidden = false
            cell.downloadSpeedLabel.text = "failed"
            cell.sizeLabel.isHidden = false
            cell.sizeLabel.text = "\(task.totalBytesReceived)Bytes/\(task.bytesExpectToReceive)Bytes"
            cell.progress.progress = task.downloadProgress
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 77
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 {
            return uncompletedTasksCount == 0 ? 0 : 40
        } else {
            if taskArray == nil || taskArray!.count == 0 {
                return 0
            }
            return 40
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == 0 {
            if uncompletedTasksCount != 0 {
                let view = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 40))
                let label = UILabel()
                label.font = UIFont.systemFont(ofSize: 14)
                label.text = "下载中\(uncompletedTasksCount)个"
                label.textColor = UIColor.darkGray
                view.addSubview(label)
                label.frame = CGRect(x: 15, y: 0, width: 100, height: 40)
                return view
            }
        } else {
            if taskArray != nil && taskArray!.count > 0 {
                let view = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 40))
                let label = UILabel()
                label.font = UIFont.systemFont(ofSize: 14)
                label.text = "已完成"
                label.textColor = UIColor.darkGray
                view.addSubview(label)
                label.frame = CGRect(x: 15, y: 0, width: 100, height: 40)
                return view
            }
        }
        return nil
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if indexPath.section == 0 {
            guard let uncompletedTasks = TaskManager.shared.getAllUncompletedTasks(), uncompletedTasks.count > 0 else {
                return
            }
            let vc = ViewController.init(uncompletedTasks)
            vc.didDeleteSubTasksHandler = { [weak self] in
                self?.updateDataSource()
                self?.updateSizeLabel()
            }
            navigationController?.pushViewController(vc, animated: true)
        } else {
            let task = taskArray![indexPath.row]
            if task is DownloadTaskInfo {
                switch task.downloadState {
                case .waitting:
                    task.startDownloadTask()
                case .downloading:
                    task.suspendDownloadTask()
                case .pause:
                    task.startDownloadTask()
                case .failed:
                    task.startDownloadTask()
                case .completed:
                    print("already completed!!!")
                }
            } else if task is TaskWrapperInfo {
                let vc = ViewController.init(task as! TaskWrapperInfo)
                navigationController?.pushViewController(vc, animated: true)
            }
        }
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
        return UITableViewCellEditingStyle.delete
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            if indexPath.section == 0 {
                TaskManager.shared.deleteAllUncompletedTasks()
            } else {
                let task = taskArray![indexPath.row]
                taskArray!.remove(at: indexPath.row)
                tableView.deleteRows(at: [indexPath], with: .middle)
                TaskManager.shared.removeTask(task: task)
            }
            updateDataSource()
            updateSizeLabel()
        }
    }
    
}

extension RootViewController: FileDownloadTaskDelegate {
    
    func fileDownloadTaskDidWaitOnLine(_ task: FileDownloadTaskProtocol) {
    }
    
    
    func fileDownloadTaskDidStarted(_ task: FileDownloadTaskProtocol) {}
    
    func fileDownloadTask(_ task: FileDownloadTaskProtocol, downloadSpeedChanged speed: Int64) {
        OperationQueue.main.addOperation { [weak self] in
            guard let cell = self?.tableView?.cellForRow(at: IndexPath(row: 0, section: 0)) as? TaskTableViewCell else {
                return
            }
            cell.downloadSpeedLabel?.text = self?.getTransformedDownloadSpeed(speed)
        }
    }
    
    func fileDownloadTask(_ task: FileDownloadTaskProtocol, didGetResponse response: FileDownloadDataResponse) {
        OperationQueue.main.addOperation { [weak self] in
            guard let cell = self?.tableView?.cellForRow(at: IndexPath(row: 0, section: 0)) as? TaskTableViewCell else {
                return
            }
            cell.sizeLabel?.text = "\(response.totalBytesReceived)Bytes/\(response.bytesExpectToReceive)Bytes"
            cell.progress?.progress = response.progress
        }
    }
    
    func fileDownloadTaskDidSuspended(_ task: FileDownloadTaskProtocol) {
        updateDataSource()
        updateSizeLabel()
    }
    
    func fileDownloadTask(_ task: FileDownloadTaskProtocol, beenBrokenWith errorType: DownloadBrokenErrorType) {
        updateDataSource()
        updateSizeLabel()
    }
    
    func fileDownloadTaskDidCompleted(_ task: FileDownloadTaskProtocol) {
        updateDataSource()
        updateSizeLabel()
    }
    
    func delegateHashvalue() -> Int {
        return self.hashValue
    }
    
    private func getTransformedDownloadSpeed(_ bytesSpeed: Int64) -> String {
        if bytesSpeed < 1024 {
            return "\(bytesSpeed)bytes/s"
        }
        if bytesSpeed > 1024 && bytesSpeed < 1048576 {
            let speed = bytesSpeed / Int64(1024)
            return "\(speed)kb/s"
        } else {
            let speed = Double(bytesSpeed) / Double(1048576)
            let speedStr = String(format: "%.2f", speed)
            return "\(speedStr)M/s"
        }
    }
    
}

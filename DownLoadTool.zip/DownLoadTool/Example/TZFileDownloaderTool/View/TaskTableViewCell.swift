//
//  TaskTableViewCell.swift
//  DownloadDemo
//
//  Created by TyroneZhang on 2018/6/20.
//  Copyright © 2018 TyroneZhang. All rights reserved.
//

import UIKit

class TaskTableViewCell: UITableViewCell {
    
    @IBOutlet weak var taskName: UILabel!
    @IBOutlet weak var downloadSpeedLabel: UILabel!
    @IBOutlet weak var progress: UIProgressView!
    @IBOutlet weak var sizeLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

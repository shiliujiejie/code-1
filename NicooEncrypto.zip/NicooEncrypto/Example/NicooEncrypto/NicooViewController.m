//
//  NicooViewController.m
//  NicooEncrypto
//
//  Created by 504672006@qq.com on 11/15/2018.
//  Copyright (c) 2018 504672006@qq.com. All rights reserved.
//

#import "NicooViewController.h"
#import "NSString+Encrypto.h"

@interface NicooViewController ()
@property (weak, nonatomic) IBOutlet UILabel *textLable;

@end

@implementation NicooViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSString * string = @"yang xin";
    NSString * key = @"yangqian";
    NSString * aesstr = [string AES128EncryptStringWithKey: key];
    NSLog(@"AES128Encrypt ==== %@",aesstr);
    NSString * newstring = [aesstr AES128DecryptStringWithKey: key];
    NSLog(@"AES128Decrypt ==== %@",newstring);
    
    
    NSString * md5string = [string md5String];
    NSLog(@"md5String ==== %@", md5string);
    
    NSString * sha384String = [string sha384String];
    NSLog(@"sha384String ==== %@",sha384String);
    
    NSString * desString = [string DESEncryptStringWithKey: key];
    NSLog(@"desString ==== %@", desString);
    NSString * desDString = [desString DESDecryptStringWithKey: key];
    NSLog(@"oldString ==== %@", desDString);
    _textLable.text = [NSString stringWithFormat:@" 原字符串:%@\n key:%@\n AES128Encrypt: %@\n md5String: %@\n sha384String:%@\n DesString:%@\n ",string, key, aesstr, md5string, sha384String, desString];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

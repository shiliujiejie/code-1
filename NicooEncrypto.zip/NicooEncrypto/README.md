# NicooEncrypto

[![CI Status](https://img.shields.io/travis/504672006@qq.com/NicooEncrypto.svg?style=flat)](https://travis-ci.org/504672006@qq.com/NicooEncrypto)
[![Version](https://img.shields.io/cocoapods/v/NicooEncrypto.svg?style=flat)](https://cocoapods.org/pods/NicooEncrypto)
[![License](https://img.shields.io/cocoapods/l/NicooEncrypto.svg?style=flat)](https://cocoapods.org/pods/NicooEncrypto)
[![Platform](https://img.shields.io/cocoapods/p/NicooEncrypto.svg?style=flat)](https://cocoapods.org/pods/NicooEncrypto)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

NicooEncrypto is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'NicooEncrypto'
```

## Author

504672006@qq.com, yangxin@tzpt.com

## License

NicooEncrypto is available under the MIT license. See the LICENSE file for more info.

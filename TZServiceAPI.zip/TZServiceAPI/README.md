# TZServiceAPI

[![CI Status](https://img.shields.io/travis/504672006@qq.com/TZServiceAPI.svg?style=flat)](https://travis-ci.org/504672006@qq.com/TZServiceAPI)
[![Version](https://img.shields.io/cocoapods/v/TZServiceAPI.svg?style=flat)](https://cocoapods.org/pods/TZServiceAPI)
[![License](https://img.shields.io/cocoapods/l/TZServiceAPI.svg?style=flat)](https://cocoapods.org/pods/TZServiceAPI)
[![Platform](https://img.shields.io/cocoapods/p/TZServiceAPI.svg?style=flat)](https://cocoapods.org/pods/TZServiceAPI)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

TZServiceAPI is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'TZServiceAPI'
```

## Author

504672006@qq.com, yangxin@tzpt.com

## License

TZServiceAPI is available under the MIT license. See the LICENSE file for more info.

//
//  ViewController.swift
//  TZServiceAPI
//
//  Created by 504672006@qq.com on 05/29/2018.
//  Copyright (c) 2018 504672006@qq.com. All rights reserved.
//

import UIKit
import TZNetworking

class ViewController: UIViewController {
    fileprivate let cellReuseIdentifer = "BookTableViewCell"
    var booksRequestId = 0
    fileprivate var bookList: BookList?
    lazy fileprivate var hotBooksAPI: BooksHotListAPI = {
        let api = BooksHotListAPI()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    lazy fileprivate var tableView: UITableView = {
        let tableView = UITableView()
        var cellCalss: AnyClass = UITableViewCell.classForCoder()
        tableView.register(cellCalss, forCellReuseIdentifier: self.cellReuseIdentifer)
        tableView.tableFooterView = UIView(frame: CGRect.zero)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorColor = UIColor.groupTableViewBackground

        return tableView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addSubview(tableView)
        layoutPageSubViews()
        booksRequestId =  hotBooksAPI.loadData()
        
    }
    private func layoutPageSubViews() {
        tableView.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
    }
    func requestFail(error: String?, manager: TZBaseAPIManager?){
        print(manager?.errorMessage)
    }
    func requestSuccess(_ aBookList: BookList?) {
         bookList = aBookList
         print("bookList  = \(bookList)")
        if let books = bookList?.books, books.count > 0 {
            tableView.reloadData()
        } else {
         
        }
        
    }


}
extension ViewController: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let books = bookList?.books else {
            return 0
        }
        return  books.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 131.0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellReuseIdentifer, for: indexPath)
        if let book = bookList?.books?[indexPath.row] {
            cell.textLabel?.text = String(format: "%@", book.bookName ?? "")
        }
       
       return cell
    }
}
extension ViewController: TZAPIManagerParamSourceDelegate,TZAPIManagerCallbackDelegate {
    func paramsForAPI(_ manager: TZBaseAPIManager) -> [String : Any]? {
        return nil
    }
    
    func managerCallAPISuccess(_ manager: TZBaseAPIManager) {
        let list = manager.fetchJSONData(BookReformer()) as? BookList
        if manager == hotBooksAPI {
            self.requestSuccess(list)
        }
    }
    
    func managerCallAPIFailed(_ manager: TZBaseAPIManager) {
        if manager == hotBooksAPI {
           self.requestFail(error: manager.errorMessage, manager: manager)
        }
    }
}


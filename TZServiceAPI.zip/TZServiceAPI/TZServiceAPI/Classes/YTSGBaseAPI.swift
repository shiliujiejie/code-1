//
//  YTSGBaseAPI.swift
//  CloudLibrary
//
//  Created by TyroneZhang on 10/04/2018.
//  Copyright © 2018 TZPT. All rights reserved.
//

import UIKit
import TZNetworking
import CLMacroDefine

/**
 整个app网络请求的base类，用于做一些公共处理
 
 - superclass: TZBaseAPIManager
 - classdesign: none
 - author: TyroneZhang
 */
open class YTSGBaseAPI: TZBaseAPIManager, TZAPIManagerProtocol, TZAPIManagerValidatorDelegate, TZAPIManagerInterceptorProtocol {
    
    public override init() {
        super.init()
        interceptor = self
        validator = self
    }
    
    // MAKR: - TZAPIManagerProtocol
    
   open func methodName() -> String {
        return ""
    }
    
   open func serviceType() -> String {
        return ConstValue.kYTSGService
    }
    
   open func requestType() -> TZAPIManagerRequestType {
        return .get
    }
    
   open func shouldCache() -> Bool {
        return false
    }
    
   open func reform(_ params: [String: Any]?) -> [String: Any]? {
        return params
    }
    
   open func parameterEncodingType() -> TZAPIManagerParameterEncodeing {
        return .json
    }
    
    // MARK: - TZAPIManagerValidatorDelegate
    
    // 在这里验证参数是否错误，并且给出具体的错误原因
   open func manager(_ manager: TZBaseAPIManager, isCorrectWithParams params: [String: Any]?) -> Bool {
        return true
    }
    
   open func manager(_ manager: TZBaseAPIManager, isCorrectWithCallbackData data: [String: Any]?) -> Bool {
        if (data?["status"] as? NSNumber)?.intValue == 200 {
            return true
        }
        return false
    }
    
    // MARK: - TZAPIManagerInterceptorProtocol
    
   open func manager(_ manager: TZBaseAPIManager, beforePerformSuccess response: TZURLResponse) -> Bool {
        return true
    }
   open func manager(_ manager: TZBaseAPIManager, afterPerformSuccess response: TZURLResponse) {}
    
    // 在这里根据错误类型，给errorMessage赋值
   open func manager(_ manager: TZBaseAPIManager, beforePerformFail response: TZURLResponse?) -> Bool {
        if manager.errorType == .noNetwork {
            self.errorMessage = CLAlertMessages.kNetworkErrorMessage
        } else if manager.errorType == .defaultError {
            self.errorMessage = CLAlertMessages.kNetworkErrorMessage
        } else if manager.errorType == .timeout {
            self.errorMessage = CLAlertMessages.kNetworkErrorMessage
        }
        return true
    }
   open func manager(_ manager: TZBaseAPIManager, afterPerformFail response: TZURLResponse?) {}
    
   open func manager(_ manager: TZBaseAPIManager, shouldCallAPI params: [String: Any]?) -> Bool {
        return true
    }
   open func manager(_ manager: TZBaseAPIManager, afterCallAPI params: [String: Any]?) {}
    
}



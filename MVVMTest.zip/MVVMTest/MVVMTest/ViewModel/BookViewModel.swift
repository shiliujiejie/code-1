//
//  BookViewModel.swift
//  MVVMTest
//
//  Created by 小星星 on 2018/10/15.
//  Copyright © 2018年 yangxin. All rights reserved.
//

import UIKit

/// 处理tableView列表 Modules

class MainViewModel: NSObject {
    
    /// 区对应的模块
    enum SectionType {
        case module
        case library
        case book
        case ebook
        case infomation
        case activity
    }
    
    private(set) var sectionCount: Int = 0
    private(set) lazy var sectionItems: [AnyObject] = {
        let sections = [AnyObject]()
        return sections
    }()

    /// 用于区分该分区的数据类型，和cell类型
    var sectionType: SectionType = SectionType.module

    /// 模拟网络请求，这里应该还有失败，成功的回调，失败的回调 （成功回调只需要回调  booksCount，有特殊需要可以回调 books ）
    func loadData(success: ((_ bookCount: Int) -> Void), faild: ((_ errorCode: Int) -> Void)) {
        var bookItems = [BookModel]()
        var libItems = [LibraryModel]()
        for i in 0 ..< 6 {
            let model = BookModel(bookName: "bookName + \(i)", bookImage: "book", bookDes: "MVVM是Model-View-ViewModel的简写，是由MVP（Model-View-Presenter）模式与WPF结合的应用方式时发展演变过来的一种新型架构框架。Model 用来获取数据并建立实体模型和基本的业务逻辑", bookWritter: "yang", readCount: i * 1000)
           
            bookItems.append(model)
        }
        
        for k in 0 ..< 7 {
            let model = LibraryModel.init(libraryName: "libName +\(k)", libraryImage: "library", hotCout: k * 200, address: "地址: 天府\(k)街")
            libItems.append(model)
        }
        if bookItems.count > 0 {
            sectionItems.append(bookItems as AnyObject)
        }
        if libItems.count > 0 {
            sectionItems.append(libItems as AnyObject)
        }
        
        sectionCount = sectionItems.count
        success(sectionCount)
        faild(1005)
    }
    
    func reloadData(success: ((_ bookCount: Int) ->Void), faild: ((_ errorCode: Int) -> Void)) {
        sectionItems.removeAll()
        loadData(success: { (count) in
            success(count)
        }) { (errorcode) in
            faild(errorcode)
        }
    }
    
    /// 获取每个区显示多少数据
    func getRowCountWith(section: Int) -> Int {
        if sectionItems[section].count > 0 {
            return sectionItems[section].count
        }
        return 0
    }
    
    /// 用于判断展示哪种cell
    func getSectionType(section: Int) -> SectionType {
        if sectionItems.count > section {
            if sectionItems[section] is [BookModel] {
                return .book
            }
            if sectionItems[section] is [LibraryModel] {
                return .library
            }
        }
        return sectionType
    }
    
}

// MARK: - 处理BookCell上的数据展示

extension MainViewModel {
    
    func bookCellConfig(_ indexPath: IndexPath) -> BookModel? {
        if sectionItems[indexPath.section] is [BookModel] && (sectionItems[indexPath.section] as! [BookModel]).count > indexPath.row {
            let bookModel = (sectionItems[indexPath.section] as! [BookModel])[indexPath.row]
            return bookModel
        }
        return nil
    }
    
    func getBookName(index: IndexPath) -> String {
        guard let book = bookCellConfig(index) else { return "" }
        return book.bookName ?? ""
    }
    
    func getBookImage(index: IndexPath) -> String {
        guard let book = bookCellConfig(index) else { return "" }
        return book.bookImage ?? ""
    }
    
    func getBookDes(index: IndexPath) -> String {
        guard let book = bookCellConfig(index) else { return "" }
        return book.bookDes ?? ""
    }
    
    func getBookWritter(index: IndexPath) -> String {
        guard let book = bookCellConfig(index) else { return "" }
        return book.bookWritter ?? ""
    }
    
    func getBookReadCount(index: IndexPath) -> String {
        guard let book = bookCellConfig(index) else { return "" }
        return book.readCount >= 1000 ? String(format: "%.2f万", Float(book.readCount) / 10000.0) : String(format: "%d", book.readCount)
    }
    
}

// MARK: - 处理LibraryCell上的数据展示

extension MainViewModel {
    
    func libCellConfig(_ indexPath: IndexPath) -> LibraryModel? {
        if sectionItems[indexPath.section] is [LibraryModel] && (sectionItems[indexPath.section] as! [LibraryModel]).count > indexPath.row {
            let libraryModel = (sectionItems[indexPath.section] as! [LibraryModel])[indexPath.row]
            return libraryModel
        }
        return nil
    }
    
    func getLibraryName(index: IndexPath) -> String {
        guard let lib = libCellConfig(index) else { return "" }
        return lib.libraryName ?? ""
    }
    
    func getLibraryImage(index: IndexPath) -> String {
        guard let lib = libCellConfig(index) else { return "" }
        return lib.libraryImage ?? ""
    }
    
    func getLibraryHotCount(index: IndexPath) -> String {
        guard let lib = libCellConfig(index) else { return "" }
        return lib.hotCout >= 1000 ?  String(format: "%.2f万", Float(lib.hotCout) / 10000.0) : String(format: "%d", lib.hotCout)
    }
    
    func getLibraryAddress(index: IndexPath) -> String {
        guard let lib = libCellConfig(index) else { return "" }
        return  lib.address ?? ""
    }
    
}

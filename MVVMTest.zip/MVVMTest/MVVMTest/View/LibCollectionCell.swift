//
//  LibCollectionCell.swift
//  MVVMTest
//
//  Created by 小星星 on 2018/10/16.
//  Copyright © 2018年 yangxin. All rights reserved.
//

import UIKit

class LibCollectionCell: UICollectionViewCell {

    @IBOutlet weak var libImage: UIImageView!
    @IBOutlet weak var libName: UILabel!
    @IBOutlet weak var libHotCount: UILabel!
    @IBOutlet weak var libAddress: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = UIColor.groupTableViewBackground
    }

}

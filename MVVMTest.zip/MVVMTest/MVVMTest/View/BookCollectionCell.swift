//
//  BookCollectionCell.swift
//  MVVMTest
//
//  Created by 小星星 on 2018/10/16.
//  Copyright © 2018年 yangxin. All rights reserved.
//

import UIKit

class BookCollectionCell: UICollectionViewCell {

    
    @IBOutlet weak var bookImage: UIImageView!
    
    @IBOutlet weak var bookName: UILabel!
    @IBOutlet weak var bookWritter: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
         self.backgroundColor = UIColor.yellow
    }

}

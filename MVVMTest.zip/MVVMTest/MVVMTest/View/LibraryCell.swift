//
//  LibraryCell.swift
//  MVVMTest
//
//  Created by 小星星 on 2018/10/15.
//  Copyright © 2018年 yangxin. All rights reserved.
//

import UIKit

class LibraryCell: UITableViewCell {

    @IBOutlet weak var hotCount: UILabel!
    @IBOutlet weak var address: UILabel!
    @IBOutlet weak var libHotCount: NSLayoutConstraint!
    @IBOutlet weak var libName: UILabel!
    @IBOutlet weak var libraryImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

//
//  ViewController.swift
//  MVVMTest
//
//  Created by 小星星 on 2018/10/15.
//  Copyright © 2018年 yangxin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    static let cellId = "CustomCell"
    static let libCellId =  "LibraryCell"
   
    private lazy var tableView: UITableView = {
        let table = UITableView(frame: self.view.bounds, style: .plain)
        table.register(UINib.init(nibName: "CustomCell", bundle: Bundle.main), forCellReuseIdentifier: ViewController.cellId)
        table.register(UINib.init(nibName: "LibraryCell", bundle: Bundle.main), forCellReuseIdentifier: ViewController.libCellId)
        table.delegate = self
        table.dataSource = self
        return table
    }()
    private var viewModel = MainViewModel()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(tableView)
        loadData()
    }
    
    func loadData() {
        viewModel.loadData(success: { [weak self] (count) in
            self?.tableView.reloadData()
        }, faild: { (errorCode) in
            print("失败，展示失败的UI")
        })
    }
    


}


// MARK: - UITableViewDelegate,UITableViewDataSource

extension ViewController: UITableViewDelegate,UITableViewDataSource {
    
     /// 所有的布局都要根据 ViewModel 获取到的数据来决定
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let sectionType = viewModel.getSectionType(section: indexPath.section)
        if sectionType == .book {
            return 150
        } else if sectionType == .library {
            return 100
        }
        return 0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return viewModel.sectionItems.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.getRowCountWith(section: section)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = cellForRow(with: indexPath)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let collectionVc = CollectionController()
        navigationController?.pushViewController(collectionVc, animated: true)
    }
    
    
}

// MARK: - 配置cell上的数据

extension ViewController {
    
    func cellForRow(with indexPath: IndexPath) -> UITableViewCell {
        
        let sectionType = viewModel.getSectionType(section: indexPath.section)
        if sectionType == .book {
            let cell = tableView.dequeueReusableCell(withIdentifier: ViewController.cellId, for: indexPath) as! CustomCell
            cell.bookName.text = viewModel.getBookName(index: indexPath)
            cell.bookImage.image = UIImage(named: viewModel.getBookImage(index: indexPath))
            cell.bookDesc.text = viewModel.getBookDes(index: indexPath)
            cell.writter.text = viewModel.getBookWritter(index: indexPath)
            cell.readCount.text = viewModel.getBookReadCount(index: indexPath)
            return cell
        } else if sectionType == .library {
            let cell = tableView.dequeueReusableCell(withIdentifier: ViewController.libCellId, for: indexPath) as! LibraryCell
            cell.libName.text = viewModel.getLibraryName(index: indexPath)
            cell.libraryImage.image = UIImage(named: viewModel.getLibraryImage(index: indexPath))
            cell.hotCount.text = viewModel.getLibraryHotCount(index: indexPath)
            cell.address.text = viewModel.getLibraryAddress(index: indexPath)
            return cell
        }
        return UITableViewCell()
    }
    
   
}

//
//  BookModel.swift
//  MVVMTest
//
//  Created by 小星星 on 2018/10/15.
//  Copyright © 2018年 yangxin. All rights reserved.
//

import Foundation

struct BookModel {
    var bookName: String?
    var bookImage: String?
    var bookDes: String?
    var bookWritter: String?
    var readCount: Int = 0
}

struct LibraryModel {
    var libraryName: String?
    var libraryImage: String?
    var hotCout: Int = 0
    var address: String?
}

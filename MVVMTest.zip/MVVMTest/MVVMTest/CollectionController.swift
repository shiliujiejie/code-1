//
//  CollectionController.swift
//  MVVMTest
//
//  Created by 小星星 on 2018/10/16.
//  Copyright © 2018年 yangxin. All rights reserved.
//

import UIKit

class CollectionController: UIViewController {
    
    static let bookCellId = "BookCollectionCell"
    static let libCellId = "LibCollectionCell"
    /// item之间的最小间隙
    static let interitemSpacing: CGFloat = 20.0
    static let bookItemWidth: CGFloat = (UIScreen.main.bounds.size.width - 52)/3 - interitemSpacing/2
    static let bookItemHieght: CGFloat = bookItemWidth + 70
    /// BookItem 的size，与item之间的最小间隙关联
    static let itemBookSize = CGSize(width: bookItemWidth, height: bookItemHieght)
    static let itemLibSize = CGSize(width: UIScreen.main.bounds.size.width , height: 100)
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        let collection = UICollectionView.init(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.backgroundColor = UIColor.white
        collection.register(UINib(nibName: "BookCollectionCell", bundle: Bundle.main), forCellWithReuseIdentifier: CollectionController.bookCellId)
         collection.register(UINib(nibName: "LibCollectionCell", bundle: Bundle.main), forCellWithReuseIdentifier: CollectionController.libCellId)
        return collection
    }()
    
    var viewModel: MainViewModel = MainViewModel()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        view.addSubview(collectionView)
        loadData()
    }
    
    func loadData() {
       
        viewModel.loadData(success: { [weak self] (count) in
            guard let strongSelf = self else { return }
            strongSelf.collectionView.reloadData()
        }) { (errorCode) in
          print("ettorCode == \(errorCode)")
        }
    }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource

extension CollectionController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return viewModel.sectionCount
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.getRowCountWith(section: section)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cellForRow(with: indexPath)
        return cell
    }
    
    /// 配置cell
    func cellForRow(with indexPath: IndexPath) -> UICollectionViewCell {
        let sectionType = viewModel.getSectionType(section: indexPath.section)
        
        if sectionType == .book {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CollectionController.bookCellId, for: indexPath) as! BookCollectionCell
            cell.bookName.text = viewModel.getBookName(index: indexPath)
            cell.bookImage.image = UIImage(named: viewModel.getBookImage(index: indexPath))
            cell.bookWritter.text = viewModel.getBookWritter(index: indexPath)
            return cell
        } else if sectionType == .library {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CollectionController.libCellId, for: indexPath) as! LibCollectionCell
            cell.libName.text = viewModel.getLibraryName(index: indexPath)
            cell.libImage.image = UIImage(named: viewModel.getLibraryImage(index: indexPath))
            cell.libHotCount.text = viewModel.getLibraryHotCount(index: indexPath)
            cell.libAddress.text = viewModel.getLibraryAddress(index: indexPath)
            return cell
        }
        return UICollectionViewCell()
    }
    
    
}

// MARK: - UICollectionViewDelegateFlowLayout

extension CollectionController: UICollectionViewDelegateFlowLayout {
    
    /// 所有的布局都要根据 ViewModel 获取到的数据来决定
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let sectionType = viewModel.getSectionType(section: indexPath.section)
        if sectionType == .book {
            return CollectionController.itemBookSize
        } else if sectionType == .library {
            return CollectionController.itemLibSize
        }
       
        return CGSize(width: 0, height:0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
        let sectionType = viewModel.getSectionType(section: section)
        
        if sectionType == .book {
            return UIEdgeInsets.init(top: 0, left: 16, bottom: 0, right:16)
        } else if sectionType == .library {
            return UIEdgeInsets.zero
        }
        return UIEdgeInsets.zero
       
    }
    
    /// 垂直最小间距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        
        let sectionType = viewModel.getSectionType(section: section)
        
        if sectionType == .book {
            return 15
        } else if sectionType == .library {
            return 5
        }
        return 0
    }
    
    /// 水平最小间距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        // 当然这里也是可以根据数据类型来判断
        return CollectionController.interitemSpacing
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize(width: UIScreen.main.bounds.size.width, height: 40)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        return CGSize(width: UIScreen.main.bounds.size.width, height: 0)
    }
    
    
}

//
//  AppDelegate.swift
//  XSVideo
//
//  Created by pro5 on 2018/11/26.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import NicooPlayer
import NicooNetwork

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    /// 公共域名请求
    private lazy var appProdApi: XSVideoProdAPI = {
        let prodApi = XSVideoProdAPI()
        prodApi.delegate = self
        prodApi.paramSource = self
        return prodApi
    }()

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // 配置服务（这一步必须先执行， 请求都需要先有服务）
        findServer()  
        // 请求可用域名
        loadAppProdUrl()
        // 查询本地下载任务
        DownLoadMannager.share().checkDownLoadingTaskCount()
      
        return true
    }

    //  整个项目支持竖屏，播放页面需要横屏，导入播放器头文件，添加下面方法：
    func application(_ application: UIApplication, supportedInterfaceOrientationsFor window: UIWindow?)
        -> UIInterfaceOrientationMask {
            guard let num = NicooPlayerOrietation(rawValue: orientationSupport.rawValue) else {
                return [.portrait]
            }
            return num.getOrientSupports()           // 这里的支持方向，做了组件化的朋友，实际项目中可以考虑用路由去播放器内拿，
    }
    
    /// 程序进入后台，存储当前下载的信息
    func applicationWillResignActive(_ application: UIApplication) {
        if DownLoadMannager.share().videoDownloadModels.count > 0 {
            DownLoadMannager.share().saveDownloadTaskToLocal()
        }
    }
    
    /// 启动野广告
    func addAdvertisement(_ url: String) {
        let _ = AdvertisementView(frame: nil, duration: 5, delay: 0, adUrl: url, isHiddenSkipBtn: false, isIgnoreCache: false, placeholderImage: nil) { (isClickDetail) in
            print(isClickDetail)
        }
    }
    
    /// service 配置
    private func findServer() {
        NicooServiceFactory.shareInstance.dataSource = self
    }
    
    /// 请求公共域名
    private func loadAppProdUrl() {
        let _ = appProdApi.loadData()
    }

}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension AppDelegate: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is XSVideoProdAPI {
            if let keyWindow = UIApplication.shared.keyWindow {
                XSProgressHUD.showCustomAnimation(msg: nil, onView: keyWindow, imageNames: nil, bgColor: nil, animated: false)
            }
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        if manager is XSVideoProdAPI {
            if let keyWindow = UIApplication.shared.keyWindow { XSProgressHUD.hide(for: keyWindow, animated: false)}
            if let prodstring = manager.fetchJSONData(AppProdReformer()) as? String {
                ProdValue.prod().kProdUrlBase = (prodstring.isEmpty || ConstValue.isDevServer) ? ConstValue.kCLBaseUrlString : prodstring
            } else {
                ProdValue.prod().kProdUrlBase = ConstValue.kCLBaseUrlString
            }
            window?.rootViewController = XSTabBarController()
            // 第一次进入的新用户不弹广告, 没有缓存过广告图片不展示
            if !UserDefaults.standard.bool(forKey: UserDefaults.knewUserSatisfiedShow) { return }
            if let adDataUrl = UserDefaults.standard.string(forKey: UserDefaults.kAdDataUrl), !adDataUrl.isEmpty {
                // 开屏广告
                addAdvertisement(adDataUrl)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        if manager is XSVideoProdAPI {
            ProdValue.prod().kProdUrlBase = ConstValue.kCLBaseUrlString
            window?.rootViewController = XSTabBarController()
        }
    }
    
}

// MARK: - NicooServiceFactoryProtocol
extension AppDelegate: NicooServiceFactoryProtocol {
    
    /// 自定义的服务
    ///
    /// - Returns: 自定义的服务名
    func servicesKindsOfServiceFactory() -> [String : String] {
        return [ConstValue.kXSVideoService: "XSVideoService", ConstValue.kAppProdService: "AppProdService"]
    }
    
    /// 自定义的服务所在的命名空间 （如果自定义的服务是组件，命名空间就为 服务组件名）
    ///
    /// - Parameter service: 服务名
    /// - Returns: m命名空间
    func namespaceForService(_ service: String) -> String? {
        switch service {
        case ConstValue.kXSVideoService, ConstValue.kAppProdService:
            return "XSVideo"   // 这里两个服务都在主工程 （如果服务 跟随组件模块， 则需要传入组件所在的命名空间名）
        default:
            return nil
        }
    }
}

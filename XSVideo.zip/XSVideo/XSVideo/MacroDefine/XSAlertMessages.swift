//
//  XSAlertMessages.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/28.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation

/// 全局错误提示
public struct XSAlertMessages {
    // MARK: - 全局
    public static let kConvertTasksOrNot = UIViewController.localStr("kConvertOrNot")
    public static let kNetworkErrorMessage = UIViewController.localStr("kNetworkFailAlertMsg")
    public static let kHaveBeenCollectyedMsg = UIViewController.localStr("kHaveBeenCollected")

    public static let kNotAvailTokenAlertMsg = UIViewController.localStr("kNotAvailTokenAlertMsg")
    /* 相机 */
    public static let kAllowCamera = UIViewController.localStr("kAllowCamera")
    /* 相册 */
    public static let kAllowPhoto = UIViewController.localStr("kNotAvailTokenAlertMsg")
  
    public static let kVideoPlayNetworkMessage = UIViewController.localStr("kVideoPlayNetworkMessage")
    
    public static let kNotSearchHistory = UIViewController.localStr("kNotSearchHistory")
    
}

//
//  MacroDefine.swift
//  XSVideo
//
//  Created by pro5 on 2018/11/26.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation
import UIKit

// MARK: - AppKey
public enum APPKeys {
    /// WeChat APPid
    public static let kWeChatAppId = ""
    /// 支付宝appid
    public static let kAlipayAppId = ""
    /// QQ appid
    public static let kQQAppId = ""
    /// 高的地图appid
    public static let kAMAppKey = ""
    /// 友盟
    public static let kUMengAppKey = ""
    public static let kUMengChannelId = ""
    /// sina
    public static let kSinaAppkey = ""
    public static let kSinaAppSecurity = ""
}

// MARK: ------  域名单利 （用于访问APP中所有的数据APi）
public class ProdValue {
    static private let prodValue: ProdValue = ProdValue()
    class func prod() -> ProdValue {
        return prodValue
    }
    public var kProdUrlBase: String?
}

// MARK: - 全局静态常量
public struct ConstValue {
    
    /// 本appurlscheme
    public static let kAppScheme = "xsvideo"
    
    // MARK: ------  屏幕各个模块的 宽高
    public static let kScreenHeight = UIScreen.main.bounds.size.height
    public static let kScreenWdith = UIScreen.main.bounds.size.width
    public static let kStatusBarHeight = UIApplication.shared.statusBarFrame.size.height
    public static let kNavigationBarHeight = CGFloat(44.0)
    
    // MARK: ------  App 主体颜色
    public static let kAppDefaultColor = UIColor(red: 73/255.0, green: 114/255.0, blue: 255/255.0, alpha: 1)
    public static let kAppDefaultTitleColor = UIColor(red: 63/255.0, green: 103/255.0, blue: 255/255.0, alpha: 1)
    public static let kAppScoreTitleColor = UIColor(red: 255/255.0, green: 105/255.0, blue: 27/255.0, alpha: 1)
    public static let kDefaultTableSeparatorColor = UIColor.groupTableViewBackground
    public static let kDefaultFontName = "PingFangSC-Light"
    
    
    // MARK: ------  apAddress 域名（默认）
    /// app 网页下载地址
    public static let kAppDownLoadLoadUrl = "http://api.asblab.com"
    /// App BaseLoad Data Url （app 获取数据url）
    public static let kCLBaseUrlString = "http://api.asblab.com"
    /// App Produrl (此Url仅用于请求有效域名)
    public static let kXSBaseProdUrl = "http://public.asbpro.com"
    /// 是否是测试服务器
    public static let isDevServer = false

    // 测试域名
    //  "http://video-dev.xsstxt.com"
    // 正式域名
    //  "http://api.asblab.com"
    // 测试IP地址   "http://192.168.137.223:50007"
    // 正式服IP地址  http://45.77.108.246:50003

    // image base url  (app返回的是全地址， 无需)
    public static let kImageURL = "" // 图片
    
    // MARK: ------  ServiceIdentifier （服务Key）
    /// app 数据接口服务名 （正式服）
    public static let kXSVideoService = "XSVideoService"
    /// 域名请求服务名  （域名服）
    public static let kAppProdService = "AppProdService"
    /// 测试服 名
    public static let kTestService = "kTestService"
    
    // MARK: ------ 本地数据库名： db name
     /// 本地数据库名称
    public static let kXSVideoLocalDBName = "XSVideoLocal.db"
   
    // MARK: ------ 本地数据库表名称
     /// 观看历史记录本地数据库
    public static let kVideoWatchedListTable = "VideoWatchedListTable"
     /// 下载进度记录本地数据表
    public static let kVideoDownLoadListTable = "VideoDownLoadListTable"
    
    // MARK: ------ 占位图片
    /// 竖屏展位图
    public static let kVerticalPHImage = UIImage(named: "placeholderV")
    /// 横屏展位图
    public static let kHorizontalPHImage = UIImage(named: "placeholderH")
    /// 默认头像
    public static let kDefaultHeader = UIImage(named: "defaultHeader")
    /// 圆形展位图
    public static let kTopicTypeHolder = UIImage(named: "starHeaderPh")
    
    // MARK: ------ 接口数据加密开关 + 密钥
    /// 是否对接口加密的  开关
    public static let kIsEncryptoApi = true
    /// 接口数据加密解密Key
    public static let kApiEncryptKey = "JBsU#qfNrsF*gIgR"
    /// 图片解密key
    public static let kImageDataDecryptKey = "wPK8CxWaOwPuVzgs"
    
    // MARK: ------ Loading Image
    public static let loadImageNames = ["loading_1","loading_2","loading_3","loading_4","loading_5","loading_6","loading_7","loading_8","loading_9","loading_10","loading_11","loading_12"]
    
    // MARK: ------ Refresh Image
    public static let refreshImageNames = ["refreshing_1","refreshing_2","refreshing_3","refreshing_4","refreshing_5","refreshing_6","refreshing_7","refreshing_8"]
    
}

// MARK: ------ 观看历史本地数据库表 参数名
public struct WatchedVideoListParams {
    public static let kVideoId = "videoId"
    public static let kVideoCover_Path = "Cover_Path"
    public static let kVideoName = "videoName"
    public static let kVideoIntrol = "videoIntrol"
    public static let kVideoWatchedPoint = "watchPoint"
}

// MARK: - Notificaiton name
public extension Notification.Name {
    /// 登录成功的通知
    static let kUserLoginSuccessfully = Notification.Name("kUserLoginSuccessfully")
    /// 在切换定位信息后，需要某些地方收到通知，并重新获取数据
    static let kLocationHaveSwitchedNotification = Notification.Name("locationHaveSwitchedNotification")
    /// 账户信息变动的通知
    static let kUserBasicalInformationChanged = Notification.Name("kUserBasicalInformationChanged")
    /// 用户别踢下线或者token失效的回调
    static let kUserBeenKickedOutNotification = Notification.Name("kUserBeenKickedOutNotification")
}

// MARK: - UserDefaults Key
public extension UserDefaults {
    
    /// 是否是首次进入APP
    static let kIsNotFirstIn = "IsFirstIn"
    ///  当日是否已经领过观影奖励 bool 类型
    static let kSatisfyKey = "Satisfy"
    ///  当日累加观影时长 Int
    static let kWatchedTime = "TimeLogin"
    ///  最后一次观影的日期 String
    static let kLastTimeDay = "LastTimeDay"
    ///  [String: Any]类型  存放单日观影时长， 当日时间，
    static let kSatisfyInfo = "SatisfyInfo"
    ///  上一个用户的用户名
    static let kUserAcountPhone = "AcountPhone"
    /// 上一个 登录的用户token
    static let kUserToken = "UserLastToken"
    ///  上一个登录用户的邀请码
    static let kUserInviteCode = "UserInviteCode"
    /// 搜索历史 (数组，长度为9)
    static let kSearchHistory = "SearchHistoryList"
    
    /// APP安装包地址
    static let kAppDownLoadUrl = "AppDownLoadUrl"
    /// App分享地址（）
    static let kAppShareUrl = "AppShareUrl"
    /// 是否提示过新用户奖励
    static let knewUserSatisfiedShow = "IsSatisfyAlertShow"
    /// 广告数据是否有
    static let kAdDataUrl = "AdDataUrl"
    /// 下载列表的IdS
    static let kDownloadIds = "DownloadIds"
}


// log
public func DLog(_ item: Any, _ file: String = #file,  _ line: Int = #line, _ function: String = #function) {
    #if DEBUG
    print(file + ":\(line):" + function, item)
    #endif
}

//
//  SpecialActorInfoApi.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/19.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation

class SpecialActorInfoApi: XSVideoBaseAPI {
    
    static let kActor_Id = "actor_id"
    
    static let kUrlValue = "/api/video/special/actor/info"
    static let kMethodValue = "GET"
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/video/special/actor/info"
    }
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func shouldCache() -> Bool {
        return true
    }
    
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [SpecialActorInfoApi.kUrl: SpecialActorInfoApi.kUrlValue,
                                        SpecialActorInfoApi.kMethod: SpecialActorInfoApi.kMethodValue]
        allParams[SpecialActorInfoApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
}

//
//  SpecialTypeListApi.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/14.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

// 查询专题类型分类列表 Api
class SpecialTypeListApi: XSVideoBaseAPI {
    
    static let kPageNumber = "page" // 当前页数
    static let kPageCount = "limit" // 每页数据数
    static let kDefaultCount = 16
    
    static let kUrlValue = "/api/video/special/type/list"
    static let kMethodValue = "GET"
    
    fileprivate var pageNumber: Int = 1
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/video/special/type/list"
    }
    
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    
    override func shouldCache() -> Bool {
        return true
    }
    
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [SpecialTypeListApi.kUrl: SpecialTypeListApi.kUrlValue,
                                        SpecialTypeListApi.kMethod: SpecialTypeListApi.kMethodValue]
        allParams[SpecialTypeListApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        self.pageNumber += 1
        return true
    }
    
}

//
//  SpecialVideoInfoApi.swift
//  XSVideo
//
//  Created by pro5 on 2019/2/13.
//  Copyright © 2019年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// 专题详情
class SpecialVideoInfoApi: XSVideoBaseAPI {
    
    static let kUrlValue = "/api/video/special/info"
    static let kMethodValue = "GET"
    
    // 分页参数
    static let kPageNumber = "page"
    static let kPageCount = "limit"
    static let kDefaultCount = 15
    
    static let kSpecial_id = "special_id"
    
    private var pageNumber: Int = 1
    // MARK: - Public method
    
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/video/special/info"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [SpecialVideoInfoApi.kUrl: SpecialVideoInfoApi.kUrlValue,
                                        SpecialVideoInfoApi.kMethod: SpecialVideoInfoApi.kMethodValue]
        /// 分页参数
        var newParams: [String: Any] = [SpecialVideoInfoApi.kPageNumber: pageNumber,
                                        SpecialVideoInfoApi.kPageCount: SpecialVideoInfoApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        allParams[SpecialVideoInfoApi.kParams] = newParams
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : newParams)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        self.pageNumber += 1
        return true
    }
}

//
//  SpecialTopicReformer.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/14.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// 专题数据解析器
class SpecialTopicReformer: NSObject {
    
    /// 专题明星列表
    private func reformTopicStarsDatas(_ data: Data?) -> Any? {
        if let actorList = try? decode(response: data, of: ObjectResponse<TopicStarListModel>.self)?.result {
            return actorList
        }
        return nil
    }
    /// 专题演员详情
    private func reformTopicActorInfoDatas(_ data: Data?) -> Any? {
        if let actorInfo = try? decode(response: data, of: ObjectResponse<TopicActorInfoModel>.self)?.result {
            return actorInfo
        }
        return nil
    }
    /// 专题类型列表
    private func reformTopicTypesDatas(_ data: Data?) -> Any? {
        if let typeList = try? decode(response: data, of: ObjectResponse<TopicTypeListModel>.self)?.result {
            return typeList
        }
        return nil
    }
    
    /// 专题视频集列表
    private func reformTopicVideoListDatas(_ data: Data?) -> Any? {
        if let typeList = try? decode(response: data, of: ObjectResponse<TopicVideoListModel>.self)?.result {
            return typeList
        }
        return nil
    }
    
    /// 专题详情视频集列表
    private func reformTopicDetailVideoListDatas(_ data: Data?) -> Any? {
        if let typeList = try? decode(response: data, of: ObjectResponse<VideoListModel>.self)?.result {
            return typeList
        }
        return nil
    }
  
}

extension SpecialTopicReformer: NicooAPIManagerDataReformProtocol {
    
    func manager(_ manager: NicooBaseAPIManager, reformData jsonData: Data?) -> Any? {
        if manager is SpecialActorListApi {
            return reformTopicStarsDatas(jsonData)
        }
        if manager is SpecialTypeListApi {
            return reformTopicTypesDatas(jsonData)
        }
        if manager is SpecialActorInfoApi {
            return reformTopicActorInfoDatas(jsonData)
        }
        if manager is SpecialVideoListApi {
            return reformTopicVideoListDatas(jsonData)
        }
        if manager is SpecialVideoInfoApi {
            return reformTopicDetailVideoListDatas(jsonData)
        }
    
        return nil
    }
}

//
//  SpecialVideoListApi.swift
//  XSVideo
//
//  Created by pro5 on 2019/2/13.
//  Copyright © 2019年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// 专题列表
class SpecialVideoListApi: XSVideoBaseAPI {
    
    static let kUrlValue = "/api/video/special/list"
    static let kMethodValue = "GET"
    
    // 分页参数
    static let kPageNumber = "page"
    static let kPageCount = "limit"
    static let kDefaultCount = 15
    
    private var pageNumber: Int = 1
    // MARK: - Public method
    
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/video/special/list"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [SpecialVideoListApi.kUrl: SpecialVideoListApi.kUrlValue,
                                        SpecialVideoListApi.kMethod: SpecialVideoListApi.kMethodValue]
        /// 分页参数
        var newParams: [String: Any] = [SpecialVideoListApi.kPageNumber: pageNumber,
                                        SpecialVideoListApi.kPageCount: SpecialVideoListApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        allParams[SpecialVideoListApi.kParams] = newParams
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : newParams)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        self.pageNumber += 1
        return true
    }
}

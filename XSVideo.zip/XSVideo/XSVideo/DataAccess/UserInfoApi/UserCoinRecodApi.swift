//
//  UserCoinRecodApi.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/26.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// 用户金币明细
class UserCoinRecordApi: XSVideoBaseAPI {
    
    static let kUrlValue = "/api/user/coins/history/list"
    static let kMethodValue = "GET"
    
    // 分页参数
    static let kPageNumber = "page"
    static let kPageCount = "limit"
    static let kDefaultCount = 10
    
    private var pageNumber: Int = 1
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/user/coins/history/list"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [UserCoinRecordApi.kUrl: UserCoinRecordApi.kUrlValue,
                                        UserCoinRecordApi.kMethod: UserCoinRecordApi.kMethodValue]
        /// 分页参数
        var newParams: [String: Any] = [UserCoinRecordApi.kPageNumber: pageNumber,
                                        UserCoinRecordApi.kPageCount: UserCoinRecordApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        allParams[UserCoinRecordApi.kParams] = newParams
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : newParams)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        self.pageNumber += 1
        return true
    }
}




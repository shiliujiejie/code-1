//
//  VideoCateTypeListApi.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/11.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// 选择分类ItemS API
class VideoCateTypeListApi: XSVideoBaseAPI {
    
    static let kGlobal_type = "global_type"
    
    static let kUrlValue = "/api/video/dict"
    static let kMethodValue = "GET"
  
    // MARK: - Public method
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/video/dict"
    }
    
    override func shouldCache() -> Bool {
        return true
    }
    

    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [VideoCateTypeListApi.kUrl: VideoCateTypeListApi.kUrlValue,
                                        VideoCateTypeListApi.kMethod: VideoCateTypeListApi.kMethodValue]
        allParams[VideoCateTypeListApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
    
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
//        self.pageNumber += 1
        return true
    }
    
}

//
//  GlobalTypeReformer.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/11.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import NicooNetwork

/// 数据解析器
class GlobalTypeReformer: NSObject {

    /// 主页顶部类型列表Api
    private func reformMainTypeListDatas(_ data: Data?) -> Any? {
        if let typeList = try? decode(response: data, of: ObjectResponse<[GlobalType]>.self)?.result {
            return typeList
        }
        return nil
    }
    /// 分类页面分类小标列表Api
    private func reformVideoCateTypeDatas(_ data: Data?) -> Any? {
        if let typeList = try? decode(response: data, of: ObjectResponse<CateListModel>.self)?.result {
            return typeList
        }
        return nil
    }
    
}

extension GlobalTypeReformer: NicooAPIManagerDataReformProtocol {
    
    func manager(_ manager: NicooBaseAPIManager, reformData jsonData: Data?) -> Any? {
        if manager is GlobalTypeApi {
            return reformMainTypeListDatas(jsonData)
        }
        if manager is VideoCateTypeListApi {
            return reformVideoCateTypeDatas(jsonData)
        }
        return nil
    }
}

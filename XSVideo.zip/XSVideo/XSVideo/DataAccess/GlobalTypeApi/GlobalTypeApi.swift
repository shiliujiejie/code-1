//
//  GlobalTypeApi.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/11.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import NicooNetwork

/// 首页顶部分类item 
class GlobalTypeApi: XSVideoBaseAPI {
    
    
    /// 固定参数
    static let kUrlValue = "/api/video/globaltype"
    static let kMethodValue = "GET"

    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/video/globaltype"
    }
    
    override func shouldCache() -> Bool {
        return true
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [GlobalTypeApi.kUrl: GlobalTypeApi.kUrlValue,
                                        GlobalTypeApi.kMethod: GlobalTypeApi.kMethodValue]

        allParams[GlobalTypeApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
    
}



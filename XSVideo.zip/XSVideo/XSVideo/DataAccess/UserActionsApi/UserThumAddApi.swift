//
//  UserThumAddApi.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/5.
//  Copyright © 2019年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork


/// 用户 点👍 或者 点👎
class UserThumAddApi: XSVideoBaseAPI {
    
    static let kAction = "action"  //好评:recommend   差评: negative
    static let kVideo_id = "video_id"
    static let kStatus = "status"
    
    static let kRecommend = "recommend" // 点👍传他
    static let kNegative  = "negative"  // 点👎传他
    
    static let kUrlValue = "/api/video/user/appraise/add"
    static let kMethodValue = "POST"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/video/user/appraise/add"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func requestType() -> NicooAPIManagerRequestType {
        return ConstValue.kIsEncryptoApi ? super.requestType() : .post
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [UserThumAddApi.kUrl: UserThumAddApi.kUrlValue,
                                        UserThumAddApi.kMethod: UserThumAddApi.kMethodValue]
        allParams[UserThumAddApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
    
}

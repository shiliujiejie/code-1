//
//  UserConvertReformer.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/20.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

class UserConvertReformer: NSObject {
    /// 兑换列表
    private func reformConvertListDatas(_ data: Data?) -> Any? {
        if let convertList = try? decode(response: data, of: ObjectResponse<[ConvertModel]>.self)?.result {
            return convertList
        }
        return nil
    }
    
}

extension UserConvertReformer: NicooAPIManagerDataReformProtocol {
    
    func manager(_ manager: NicooBaseAPIManager, reformData jsonData: Data?) -> Any? {
        if manager is UserConvertListApi {
            return reformConvertListDatas(jsonData)
        }
        return nil
    }
}

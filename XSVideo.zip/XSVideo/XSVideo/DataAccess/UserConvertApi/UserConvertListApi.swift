//
//  UserConvertListApi.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/20.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// 用户兑换任务列表Api
class UserConvertListApi: XSVideoBaseAPI {
    
    static let kUrlValue = "/api/user/convert/list"
    static let kMethodValue = "GET"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/user/convert/list"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [UserConvertListApi.kUrl: UserConvertListApi.kUrlValue,
                                        UserConvertListApi.kMethod: UserConvertListApi.kMethodValue]
        //        var newParams: [String: Any] = [VideoListApi.kPageNumber: pageNumber,
        //                                        VideoListApi.kPageCount: VideoListApi.kDefaultCount]
        //        if params != nil {
        //            for (key, value) in params! {
        //                newParams[key] = value
        //            }
        //        }
        allParams[UserConvertListApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
}



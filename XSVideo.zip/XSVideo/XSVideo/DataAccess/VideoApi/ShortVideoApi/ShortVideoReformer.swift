//
//  ShortVideoReformer.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/26.
//  Copyright © 2019年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// 数据解析器
class ShortVideoReformer: NSObject {
    
    /// 短视频 头部分类列表
    private func reformShortVideoTypeListDatas(_ data: Data?) -> Any? {
        if let typeList = try? decode(response: data, of: ObjectResponse<[ShortVideoTypeModel]>.self)?.result {
            return typeList
        }
        return nil
    }
    /// 短视频列表
    private func reformShortVideoListDatas(_ data: Data?) -> Any? {
        if let shortList = try? decode(response: data, of: ObjectResponse<ShortVideoListModel>.self)?.result {
            return shortList
        }
        return nil
    }
    /// 短视频详情
    private func reformShortVideoInfoDatas(_ data: Data?) -> Any? {
        if let shortInfo = try? decode(response: data, of: ObjectResponse<ShortVideoListModel>.self)?.result {
            return shortInfo
        }
        return nil
    }
    
}

extension ShortVideoReformer: NicooAPIManagerDataReformProtocol {
    
    func manager(_ manager: NicooBaseAPIManager, reformData jsonData: Data?) -> Any? {
        
        if manager is ShortVideoTypeListApi {
            return reformShortVideoTypeListDatas(jsonData)
        }
        if manager is ShortVideoListApi || manager is ShortReconmentApi {
            return reformShortVideoListDatas(jsonData)
        }
        if manager is ShortVideoInfoApi {
            return reformShortVideoInfoDatas(jsonData)
        }
        return nil
    }
}

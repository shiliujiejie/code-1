//
//  ShortVideoTypeListApi.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/26.
//  Copyright © 2019年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// 短视频 头部 类型列表api
class ShortVideoTypeListApi: XSVideoBaseAPI {
    
    /// 固定参数
    static let kUrlValue = "/api/video/short/type"
    static let kMethodValue = "GET"
    
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/video/short/type"
    }
    
    override func shouldCache() -> Bool {
        return true
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [ShortVideoTypeListApi.kUrl: ShortVideoTypeListApi.kUrlValue,
                                        ShortVideoTypeListApi.kMethod: ShortVideoTypeListApi.kMethodValue]
        
        allParams[ShortVideoTypeListApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
}

//
//  ShortVideoInfoApi.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/27.
//  Copyright © 2019年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// 查询短视频详情
class ShortVideoInfoApi: XSVideoBaseAPI {
    
    static let kVideo_Id = "video_id"
    
    static let kUrlValue = "/api/video/short/info"
    static let kMethodValue = "GET"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/video/short/info"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [ShortVideoInfoApi.kUrl: ShortVideoInfoApi.kUrlValue,
                                        ShortVideoInfoApi.kMethod: ShortVideoInfoApi.kMethodValue]
        allParams[ShortVideoInfoApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
}

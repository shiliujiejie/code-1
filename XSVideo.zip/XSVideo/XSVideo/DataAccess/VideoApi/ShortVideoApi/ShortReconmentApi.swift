//
//  ShortReconmentApi.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/26.
//  Copyright © 2019年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

// 查询短视频 推荐列表Api
class ShortReconmentApi: XSVideoBaseAPI {
    
    static let kUrlValue = "/api/video/short/guesslike"
    static let kMethodValue = "GET"
    
    // 短视频ID
    static let kVideoId = "video_id"
  
    // 分页参数
    static let kPageNumber = "page"
    static let kPageCount = "limit"
    static let kDefaultCount = 15
    
    private var pageNumber: Int = 1
    // MARK: - Public method
    
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/video/short/guesslike"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [ShortReconmentApi.kUrl: ShortReconmentApi.kUrlValue,
                                        ShortReconmentApi.kMethod: ShortReconmentApi.kMethodValue]
        /// 分页参数
        var newParams: [String: Any] = [ShortReconmentApi.kPageNumber: pageNumber,
                                        ShortReconmentApi.kPageCount: ShortReconmentApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        allParams[ShortReconmentApi.kParams] = newParams
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : newParams)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        self.pageNumber += 1
        return true
    }
    
}

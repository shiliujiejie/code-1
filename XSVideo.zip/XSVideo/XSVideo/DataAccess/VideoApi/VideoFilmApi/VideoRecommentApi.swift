//
//  VideoRecommentApi.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/13.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation

// 首页视频推荐列表
class VideoRecommentApi: XSVideoBaseAPI {
    
    static let kUrlValue = "/api/video/index/recommend"
    static let kMethodValue = "GET"
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/video/index/recommend"
    }
    
    override func shouldCache() -> Bool {
        return true
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [VideoRecommentApi.kUrl: VideoRecommentApi.kUrlValue,
                                        VideoRecommentApi.kMethod: VideoRecommentApi.kMethodValue]
        allParams[GlobalTypeApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
}

// 首页视频分类查询列表
class VideoMainListApi: XSVideoBaseAPI {
    
    static let kGlobal_type = "global_type"
    
    static let kUrlValue = "/api/video/index/globaltype"
    static let kMethodValue = "GET"
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/video/index/globaltype"
    }
    override func shouldCache() -> Bool {
        return true
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [VideoMainListApi.kUrl: VideoMainListApi.kUrlValue,
                                        VideoMainListApi.kMethod: VideoMainListApi.kMethodValue]
        allParams[GlobalTypeApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
}

//
//  VideoCommentListApi.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/14.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// 查询视频评论列表Api
class VideoCommentListApi: XSVideoBaseAPI {
    
    static let kVideo_Id = "video_id"
    
    static let kUrlValue = "/api/video/comment/lists"
    static let kMethodValue = "GET"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/video/comment/lists"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [VideoCommentListApi.kUrl: VideoCommentListApi.kUrlValue,
                                        VideoCommentListApi.kMethod: VideoCommentListApi.kMethodValue]
        allParams[VideoCommentListApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
    
}


/// 视频评论Api  （用户发评论）
class VideoCommentApi: XSVideoBaseAPI {
    
    static let kVideo_Id = "video_id"
    static let kGlobal_type = "global_type"
    static let kContent = "content"
    
    static let kUrlValue = "/api/video/user/comment/add"
    static let kMethodValue = "POST"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/video/user/comment/add"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func requestType() -> NicooAPIManagerRequestType {
        return ConstValue.kIsEncryptoApi ?  super.requestType() : .post
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [VideoCommentApi.kUrl: VideoCommentApi.kUrlValue,
                                        VideoCommentApi.kMethod: VideoCommentApi.kMethodValue]
        allParams[VideoCommentApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
}

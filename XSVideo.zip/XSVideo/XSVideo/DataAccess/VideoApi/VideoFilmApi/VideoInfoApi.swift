//
//  VideoInfoApi.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/13.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation

/// 查询视频详情
class VideoInfoApi: XSVideoBaseAPI {
    
    static let kVideo_Id = "video_id"
    
    static let kUrlValue = "/api/video/info"
    static let kMethodValue = "GET"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/video/info"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [VideoInfoApi.kUrl: VideoInfoApi.kUrlValue,
                                        VideoInfoApi.kMethod: VideoInfoApi.kMethodValue]
        allParams[VideoInfoApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
}

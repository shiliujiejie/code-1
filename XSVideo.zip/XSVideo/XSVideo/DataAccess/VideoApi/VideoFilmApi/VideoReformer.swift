//
//  VideoReformer.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/12.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// 数据解析器
class VideoReformer: NSObject {
    
    /// 首页推荐、分类视频 列表
    private func reformVideoModulesDatas(_ data: Data?) -> Any? {
        if let videoModules = try? decode(response: data, of: ObjectResponse<VideoModulesListModel>.self)?.result {
            return videoModules
        }
        return nil
    }
    
    /// 分类页面视频列表
    private func reformVideoListDatas(_ data: Data?) -> Any? {
        if let videoList = try? decode(response: data, of: ObjectResponse<VideoListModel>.self)?.result {
            return videoList
        }
        return nil
    }
    /// 视频详情页
    private func reformVideoInfoDatas(_ data: Data?) -> Any? {
        if let videoDetail = try? decode(response: data, of: ObjectResponse<VideoDetailModel>.self)?.result {
            return videoDetail
        }
        return nil
    }
    
    /// 首页模块更多
    private func reformVideoModuleMoreDatas(_ data: Data?) -> Any? {
        if let videoModuleMore = try? decode(response: data, of: ObjectResponse<VideoListModel>.self)?.result {
            return videoModuleMore
        }
        return nil
    }
  
    /// 猜你喜欢
    private func reformVideoGuessFavorDatas(_ data: Data?) -> Any? {
        if let videoGuessFavor = try? decode(response: data, of: ObjectResponse<VideoListModel>.self)?.result {
            return videoGuessFavor
        }
        return nil
    }
    
    /// 视频评论列表
    private func reformVideoCommentListDatas(_ data: Data?) -> Any? {
        if let videoCommentList = try? decode(response: data, of: ObjectResponse<VideoCommentListModel>.self)?.result {
            return videoCommentList
        }
        return nil
    }
    /// 点赞数据
    private func reformVideoThumDatas(_ data: Data?) -> Any? {
        if let thumResultModel = try? decode(response: data, of: ObjectResponse<VideoThumResultModel>.self)?.result {
            return thumResultModel
        }
        return nil
    }
    
}

extension VideoReformer: NicooAPIManagerDataReformProtocol {
    
    func manager(_ manager: NicooBaseAPIManager, reformData jsonData: Data?) -> Any? {
        
        if manager is VideoListApi || manager is UserFavorListApi || manager is UserWatchedListApi {
            return reformVideoListDatas(jsonData)
        }
        
        if manager is VideoModuleListApi {
            return reformVideoModulesDatas(jsonData)
        }
        
        if manager is VideoInfoApi {
            return reformVideoInfoDatas(jsonData)
        }
       
        if  manager is VideoModuleMoreApi {
            return reformVideoModuleMoreDatas(jsonData)
        }
        if manager is GuessFavorApi {
            return reformVideoGuessFavorDatas(jsonData)
        }
        if manager is VideoCommentListApi {
            return reformVideoCommentListDatas(jsonData)
        }
        if manager is UserThumAddApi {
            return reformVideoThumDatas(jsonData)
        }
        return nil
    }
}

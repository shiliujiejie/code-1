//
//  GuessFavorApi.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/14.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 视频详情页面“猜你喜欢”
class GuessFavorApi: XSVideoBaseAPI {
    
    static let kVideo_id = "video_id"
    
    static let kUrlValue = "/api/video/guess/like"
    static let kMethodValue = "GET"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/video/guess/like"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [GuessFavorApi.kUrl: GuessFavorApi.kUrlValue,
                                        GuessFavorApi.kMethod: GuessFavorApi.kMethodValue]
        allParams[GuessFavorApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
}

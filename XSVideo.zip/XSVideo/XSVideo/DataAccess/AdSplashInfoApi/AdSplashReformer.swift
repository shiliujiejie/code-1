//
//  AdSplashReformer.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/16.
//  Copyright © 2019年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// App闪屏广告解析
class AdSplashReformer: NSObject {
    
    /// AdSplashInfoApi
    private func reformAdSplashInfoDatas(_ data: Data?) -> Any? {
        guard let response = data else { return nil }
        if let info = try? decode(response: response, of: ObjectResponse<AdSplashModel>.self)?.result {
            return info
        }
        return nil
    }
    
}

// MARK: - NicooAPIManagerDataReformProtocol
extension AdSplashReformer: NicooAPIManagerDataReformProtocol {
    
    func manager(_ manager: NicooBaseAPIManager, reformData jsonData: Data?) -> Any? {
        if manager is AdSplashInfoApi {
            return reformAdSplashInfoDatas(jsonData)
        }
        return nil
    }
}

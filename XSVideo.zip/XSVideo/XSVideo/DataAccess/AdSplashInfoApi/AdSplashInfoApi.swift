//
//  AdSplashInfoApi.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/16.
//  Copyright © 2019年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// 开屏广告信息Api
class AdSplashInfoApi: XSVideoBaseAPI {
    
    static let kUrlValue = "/api/video/startup"
    static let kMethodValue = "GET"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return  ConstValue.kIsEncryptoApi ? super.methodName() : "api/video/startup"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [AdSplashInfoApi.kUrl: AdSplashInfoApi.kUrlValue,
                                        AdSplashInfoApi.kMethod: AdSplashInfoApi.kMethodValue]
        allParams[AdSplashInfoApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
    
}


//
//  WatchVideoSatisfyApi.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/19.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// 观看影片奖励  30分钟, a观影30分钟时调用  (这里的30分钟是真实的30分钟，非拖进度条)
/// 计算方式： 进入视频详情页, 点击播放，记录 time1， 用户离开x播放页面， 或APP进入后台， 记录 time2， time2 - time1 = 有效观影时间，
/// 当有效观影时间累加到30分钟， 给出提示，让用户点领取，调用此接口

class WatchVideoSatisfyApi: XSVideoBaseAPI {
    
    static let kUrlValue = "/api/user/task/lookvideosatisfy"
    static let kMethodValue = "GET"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/user/task/lookvideosatisfy"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func requestType() -> NicooAPIManagerRequestType {
        return super.requestType()
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [WatchVideoSatisfyApi.kUrl: WatchVideoSatisfyApi.kUrlValue,
                                        WatchVideoSatisfyApi.kMethod: WatchVideoSatisfyApi.kMethodValue]
        allParams[WatchVideoSatisfyApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
}

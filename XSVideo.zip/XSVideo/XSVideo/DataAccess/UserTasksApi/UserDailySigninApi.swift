//
//  UserDailySigninApi.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/19.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation

/// 用户每日签到Api,已签到显示 已签到状态

class UserDailySigninApi: XSVideoBaseAPI {
    
    static let kUrlValue = "/api/user/task/dailysignin"
    static let kMethodValue = "GET"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/user/task/dailysignin"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [UserDailySigninApi.kUrl: UserDailySigninApi.kUrlValue,
                                        UserDailySigninApi.kMethod: UserDailySigninApi.kMethodValue]
        allParams[UserDailySigninApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
   
}


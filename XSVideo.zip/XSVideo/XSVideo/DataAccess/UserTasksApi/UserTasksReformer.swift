//
//  UserTasksReformer.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/20.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import NicooNetwork

/// 任务，兑换数据解析器
class UserTasksReformer: NSObject {

    /// 任务列表
    private func reformTaskListDatas(_ data: Data?) -> Any? {
        if let taskList = try? decode(response: data, of: ObjectResponse<[TaskModel]>.self)?.result {
            return taskList
        }
        return nil
    }
    
}

extension UserTasksReformer: NicooAPIManagerDataReformProtocol {
    
    func manager(_ manager: NicooBaseAPIManager, reformData jsonData: Data?) -> Any? {
        
        if manager is UserTaskListApi {
            return reformTaskListDatas(jsonData)
        }
        return nil
    }
}

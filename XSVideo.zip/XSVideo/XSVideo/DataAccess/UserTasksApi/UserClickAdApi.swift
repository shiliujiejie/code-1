//
//  UserClickAdApi.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/5.
//  Copyright © 2019年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// 用户点击广告调用， 如果用户未登录，提示用户，登陆后查看广告，可以领奖励？
class UserClickAdApi: XSVideoBaseAPI {
    
    static let kUrlValue = "/api/user/task/clickad"
    static let kMethodValue = "GET"
    static let kAd_id = "ad_id"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/user/task/clickad"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [UserClickAdApi.kUrl: UserClickAdApi.kUrlValue,
                                        UserClickAdApi.kMethod: UserClickAdApi.kMethodValue]
        allParams[UserClickAdApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
    
}

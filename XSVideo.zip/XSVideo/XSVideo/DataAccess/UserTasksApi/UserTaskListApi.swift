//
//  UserTaskListApi.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/20.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation

/// 用户任务列表Api
class UserTaskListApi: XSVideoBaseAPI {
    
    static let kUrlValue = "/api/user/task/list"
    static let kMethodValue = "GET"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/user/task/list"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [UserTaskListApi.kUrl: UserTaskListApi.kUrlValue,
                                        UserTaskListApi.kMethod: UserTaskListApi.kMethodValue]
        allParams[UserTaskListApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
}

//
//  VideoListPagerView.swift
//  XSVideo
//
//  Created by pro5 on 2018/11/29.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import SnapKit

/// fsPagerView 的父视图
class VideoListPagerView: UIView {
    
    static let bannerCellId = "bannerCellId"
    static let bookCellId = "BookCollectionCell"
    
    /// 滚动方式
    enum TransType {
        case kCrossFading
        case kZoomOut
        case kDepth
        case kLinear
        case kOverlap
        case kFerrisWheel
        case kCoverFlow
        case kCubic
        
        fileprivate func getTransType() ->FSPagerViewTransformerType {
            switch self {
            case .kCrossFading:
                return .crossFading
            case .kZoomOut:
                return .zoomOut
            case .kDepth:
                return .depth
            case .kLinear:
                return .linear
            case .kOverlap:
                return .overlap
            case .kFerrisWheel:
                return .ferrisWheel
            case .kCoverFlow:
                return .coverFlow
            case .kCubic:
                return .cubic
            }
        }
    }
    /// cell的样式
    enum PagerStype {
        case bannerPage
        case overlapPage
        case scrollPage
    }
    
    private lazy var fsPagerView: FSPagerView = {
        let pagerView = FSPagerView(frame: self.bounds)
        pagerView.delegate = self
        pagerView.dataSource = self //self.bounds.width * self.itemSizeScale
        pagerView.itemSize = CGSize(width: 80, height: self.bounds.height * self.itemSizeScale)
        pagerView.interitemSpacing = self.interitemSpacing
        
        if self.pagerStype == .bannerPage {
            pagerView.register(FSPagerViewCell.classForCoder(), forCellWithReuseIdentifier: VideoListPagerView.bannerCellId)
        } else if self.pagerStype == .overlapPage || self.pagerStype == .scrollPage {

            pagerView.register(VideoThridItemCell.classForCoder(), forCellWithReuseIdentifier: VideoThridItemCell.cellId)
        } else {
            pagerView.register(FSPagerViewCell.classForCoder(), forCellWithReuseIdentifier: VideoListPagerView.bannerCellId)
        }
        return pagerView
    }()
    private lazy var fsPagerControl: FSPageControl = {
        let pagerControl = FSPageControl(frame: CGRect(x: self.bounds.width - 100, y: self.bounds.height-25, width: 100, height: 25))
        pagerControl.contentHorizontalAlignment = .right
        pagerControl.contentInsets = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 20)
        return pagerControl
        
    }()
    private lazy var backgroundImageView: UIImageView = {
        let bgImageView = UIImageView(frame: self.bounds)
        return bgImageView
    }()
    /// 是否显示 PageControl
    private var isShowPageControl: Bool = false
    
    /// 当前第几个
    var currentIndex: Int = 0 {
        didSet {
            fsPagerView.currentIndex = currentIndex
        }
    }
    /// 滑动灵敏度 数值代表格数 0 表示随意
    var decelerationCount: UInt = 1 {
        didSet {
            fsPagerView.decelerationDistance = decelerationCount
        }
    }
    /// 背景图片
    var backgroundImage = UIImage(named: "") {
        didSet {
            if backgroundImage != nil {
                self.backgroundImageView.image = backgroundImage!
                self.insertSubview(self.backgroundImageView, at: 0)
            }
        }
    }
    /// 是否循环
    var isInfinite: Bool = true {
        didSet {
            self.fsPagerView.isInfinite = isInfinite
        }
    }
    /// 切换时间
    var slidingIntervals: CGFloat = 3 {
        didSet {
            self.fsPagerView.automaticSlidingInterval = slidingIntervals
        }
    }
    /// 比例
    var itemSizeScale: CGFloat = 1.0 {
        didSet {
            self.fsPagerView.itemSize = CGSize(width: self.bounds.width * itemSizeScale, height: self.bounds.height * itemSizeScale)
        }
    }
    /// itemSize
    var itemSize: CGSize = CGSize.zero {
        didSet {
            self.fsPagerView.itemSize = itemSize
        }
    }
    /// Item间的水平间距
    var interitemSpacing: CGFloat = 1.0 {
        didSet {
             self.fsPagerView.interitemSpacing = interitemSpacing
        }
    }
    /// 是否显示
    var isShownDesLable: Bool = false {
        didSet {
            self.fsPagerView.reloadData()
        }
    }
    /// 设置图片
    var imageNames: [String] = [""] {
        didSet {
            self.fsPagerControl.numberOfPages = imageNames.count
            self.fsPagerView.reloadData()
        }
    }
    var titleMsgs: [String] = [] {
        didSet {
            self.fsPagerView.reloadData()
        }
    }
    /// 转换动画类型
    var transType: TransType = .kCrossFading {
        didSet {
            let type = transType.getTransType()
            self.fsPagerView.transformer = FSPagerViewTransformer(type: type)
            switch type {
            case .crossFading, .zoomOut, .depth:
                self.fsPagerView.itemSize = .zero // 'Zero' means fill the size of parent
            case .linear, .overlap:
                self.fsPagerView.itemSize = CGSize(width: self.fsPagerView.frame.size.height * 5/7, height: self.fsPagerView.frame.size.height)
           
            case .ferrisWheel, .invertedFerrisWheel:
                self.fsPagerView.itemSize = CGSize(width: 180, height: 140)
            case .coverFlow:
                self.fsPagerView.itemSize = CGSize(width: 220, height: 170)
                if self.imageNames.count > 1 {
                   self.fsPagerView.currentIndex = 1
                }
            case .cubic:
                let transform = CGAffineTransform(scaleX: 0.9, y: 0.9)
                self.fsPagerView.itemSize = self.fsPagerView.frame.size.applying(transform)
            }
        }
    }
    var pagerStype: PagerStype = .bannerPage
    
    var itemClickHandler: ((Int) -> Void)?
 
    init(frame: CGRect, pagerStype: PagerStype) {
        super.init(frame: frame)
        self.pagerStype = pagerStype
        addSubview(fsPagerView)
        if pagerStype == .bannerPage {
            addSubview(fsPagerControl)
            isShowPageControl = true
        } else {
            isShowPageControl = false
        }
       
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

// MARK: - FSPagerViewDelegate, FSPagerViewDataSource
extension VideoListPagerView: FSPagerViewDelegate, FSPagerViewDataSource {
    
    // DataSource
    func numberOfItems(in pagerView: FSPagerView) -> Int {
        return self.imageNames.count
    }
    
    func pagerView(_ pagerView: FSPagerView, cellForItemAt index: Int) -> FSPagerViewCell {
        if pagerStype == .bannerPage {
            let cell = pagerView.dequeueReusableCell(withReuseIdentifier: VideoListPagerView.bannerCellId, at: index)
            cell.imageView?.kfSetHorizontalImageWithUrl(imageNames[index])
            cell.imageView?.contentMode = .scaleAspectFill
            cell.imageView?.clipsToBounds = true
            if titleMsgs.count > index {
                cell.textLabel?.text = titleMsgs[index]
                cell.textLabel?.font = UIFont.systemFont(ofSize: 15)
            }
            return cell
        }
         else {
            let cell = pagerView.dequeueReusableCell(withReuseIdentifier: VideoListPagerView.bannerCellId, at: index)
            cell.imageView?.image = UIImage(named: self.imageNames[index])
            cell.imageView?.contentMode = .scaleAspectFill
            cell.imageView?.clipsToBounds = true
            if titleMsgs.count > index {
                cell.textLabel?.text = titleMsgs[index]
                cell.textLabel?.textAlignment = .center
            }
             return cell
        }
    }
    
    // Delegate
    func pagerView(_ pagerView: FSPagerView, didSelectItemAt index: Int) {
        pagerView.deselectItem(at: index, animated: true)
        pagerView.scrollToItem(at: index, animated: true)
        if isShowPageControl {
            self.fsPagerControl.currentPage = index
        }
        self.itemClickHandler?(index)
    }
    
    func pagerViewDidScroll(_ pagerView: FSPagerView) {
        if isShowPageControl {
            guard self.fsPagerControl.currentPage != pagerView.currentIndex else {
                return
            }
            // Or Use KVO with property "currentIndex"
            self.fsPagerControl.currentPage = pagerView.currentIndex
        }
    }
    
}

// MARK: - Layout
extension VideoListPagerView {
    
    private func layoutPagerView() {
        fsPagerView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    private func layoutPagerControl() {
        fsPagerControl.snp.makeConstraints { (make) in
            make.trailing.bottom.equalToSuperview()
        }
    }
}

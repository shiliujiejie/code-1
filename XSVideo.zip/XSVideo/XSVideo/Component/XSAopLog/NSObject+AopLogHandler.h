//
//  NSObject+AopLogHandler.h
//  XSVideo
//
//  Created by pro5 on 2019/1/9.
//  Copyright © 2019年 pro5. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSObject (AopLogHandler)
+ (void)pageHandleLog:(NSDictionary *)pageJson isEnter:(BOOL)isEnter;
@end

NS_ASSUME_NONNULL_END

//
//  NSObject+AopLogHandler.m
//  XSVideo
//
//  Created by pro5 on 2019/1/9.
//  Copyright © 2019年 pro5. All rights reserved.
//

#import "NSObject+AopLogHandler.h"

@implementation NSObject (AopLogHandler)

+ (void)pageHandleLog:(NSDictionary *)pageJson isEnter:(BOOL)isEnter {
    if (isEnter) {
        NSMutableDictionary * pageD = [pageJson mutableCopy];
        [pageD setObject:[self getTime] forKey: @"startTime"];
        NSMutableArray * array = [NSMutableArray arrayWithArray:[[NSUserDefaults standardUserDefaults]  objectForKey:@"pageView"]];
        if (array != nil) {
            [array addObject:pageD];
            [[NSUserDefaults standardUserDefaults] setObject:array forKey:@"pageView"];
        } else {
            NSMutableArray * pageViews = [NSMutableArray arrayWithCapacity:1000];
            [pageViews addObject:pageD];
            [[NSUserDefaults standardUserDefaults] setObject:pageViews forKey:@"pageView"];
        }
        NSLog(@"pages--上报------1111----------->>>>>>>>>>>>> = %@",pageD);
    } else {
        NSMutableArray * pages = [NSMutableArray arrayWithArray:[[NSUserDefaults standardUserDefaults]  objectForKey:@"pageView"]];
        if (pages != nil && pages.count > 0) {
            NSMutableDictionary * lastOne = [NSMutableDictionary dictionaryWithDictionary:[pages lastObject]];
            [lastOne setObject:[self getTime] forKey:@"endTime"];
            [pages removeLastObject];
            [pages addObject:lastOne];
            [[NSUserDefaults standardUserDefaults] setObject:pages forKey:@"pageView"];
        }
        NSLog(@"pages--上报-------2222----------<<<<<<<<< = %@",pages);
    }
    
}

+ (NSString *)getTime {
    NSDate * now = [NSDate date];
    NSDateFormatter * fot = [[NSDateFormatter alloc]init];
    fot.dateFormat = @"yyyy-MM-dd HH-mm-ss";
    NSString * dateStr = [fot stringFromDate:now];
    return dateStr;
}
@end

//
//  XSTabBarController.swift
//  XSVideo
//
//  Created by pro5 on 2018/11/26.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class XSTabBarController: UITabBarController {
    
    public var isFirstIn: Bool = false
    /// 第一次进入APP展示引导页
    private lazy var guideView: GuidePageView = {
        let imageGifArray = ["","","","", ""]
        let guideView = GuidePageView(images: imageGifArray, loginRegistCompletion: {
            DLog("登录/注册")
        }) {
            DLog("点击了跳过或者别的")
        }
        return guideView
    }()
    
    private let homeViewController: VideoMainViewController = {
        let viewController = VideoMainViewController()
        viewController.tabBarItem.title = localStr("kMainModule")
        viewController.tabBarItem.image = UIImage(named: "mainTabbarBar_N")
        var selectImage = UIImage(named: "mainTabbarBar")
        selectImage = selectImage?.withRenderingMode(.alwaysOriginal)
        viewController.tabBarItem.selectedImage = selectImage
        viewController.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: ConstValue.kAppDefaultTitleColor], for: .selected)
        return viewController
    }()
    
    private let shortVideoMainController: ShortVideoMainController = {
        let viewController = ShortVideoMainController()
        viewController.tabBarItem.title = localStr("kHotShortVideoTitle")
        viewController.tabBarItem.image = UIImage(named: "shortVideoIcon_N")
        var selectImage = UIImage(named: "shortVideoIcon")
        selectImage = selectImage?.withRenderingMode(.alwaysOriginal)
        viewController.tabBarItem.selectedImage = selectImage
        viewController.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: ConstValue.kAppDefaultTitleColor], for: .selected)
        return viewController
    }()
    
    private let specialTopicViewController: SpecialTopicMainController = {
        let viewController = SpecialTopicMainController()
        viewController.tabBarItem.title = localStr("kSpecialTopic")
        viewController.tabBarItem.image = UIImage(named: "specialTabbar_N")
        var selectImage = UIImage(named: "specialTabbar")
        selectImage = selectImage?.withRenderingMode(.alwaysOriginal)
        viewController.tabBarItem.selectedImage = selectImage
        viewController.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: ConstValue.kAppDefaultTitleColor], for: .selected)
        return viewController
    }()
    
    private let taskViewController: UserTaskCenterController = {
        let viewController = UserTaskCenterController()
        viewController.tabBarItem.title = localStr("kTaskModule")
        viewController.tabBarItem.image = UIImage(named: "taskTabbar_N")
        var selectImage = UIImage(named: "taskTabar")
        selectImage = selectImage?.withRenderingMode(.alwaysOriginal)
        viewController.tabBarItem.selectedImage = selectImage
        viewController.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: ConstValue.kAppDefaultTitleColor], for: .selected)
        return viewController
    }()
    
    private let acountViewController: AcountMainViewController = {
        let viewController = AcountMainViewController()
        viewController.tabBarItem.title = localStr("kUserCenter")
        viewController.tabBarItem.image = UIImage(named: "acountTabbar_N")
        var selectImage = UIImage(named: "acountTabbar")
        selectImage = selectImage?.withRenderingMode(.alwaysOriginal)
        viewController.tabBarItem.selectedImage = selectImage
        viewController.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: ConstValue.kAppDefaultTitleColor], for: .selected)
        return viewController
    }()
   
    override func viewDidLoad() {
        super.viewDidLoad()
        let homeNav = XSNavigationController(rootViewController: homeViewController)
        let shortVideoNav = XSNavigationController(rootViewController: shortVideoMainController)
        let specialTopicNav = XSNavigationController(rootViewController: specialTopicViewController)
        let taskNav = XSNavigationController(rootViewController: taskViewController)
        let acountNav = XSNavigationController(rootViewController: acountViewController)
        viewControllers = [homeNav, shortVideoNav, specialTopicNav, taskNav ,acountNav]
//        tabBar.isTranslucent = false
//        tabBar.tintColor = UIColor(red: 138 / 255.0, green: 99.0 / 255.0, blue: 61 / 255.0, alpha: 0.1)
//
//        tabBar.barTintColor = UIColor(red: 238 / 255.0, green: 238.0 / 255.0, blue: 238 / 255.0, alpha: 0.1)
//        tabBar.backgroundImage = UIImage.imageFromColor(UIColor(red: 0, green: 0, blue: 0, alpha: 0), frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: tabBar.bounds.height))
//        tabBar.shadowImage = UIImage.imageFromColor(UIColor(red: 0, green: 0, blue: 0, alpha: 0), frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: tabBar.bounds.height))
//
        if isFirstIn {
            view.addSubview(guideView)
        }
    }
   
}

//
//  UIControl+Aspects.h
//  XSVideo
//
//  Created by pro5 on 2019/1/8.
//  Copyright © 2019年 pro5. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIControl (Aspects)

@end

NS_ASSUME_NONNULL_END




//
//  UIViewController+Aspects.m
//  XSVideo
//
//  Created by pro5 on 2018/11/26.
//  Copyright © 2018年 pro5. All rights reserved.
//

#import "UIViewController+Aspects.h"
#import <objc/runtime.h>
#import "NSObject+AopLogHandler.h"

/**
 用于做一些公共的事情
 */

@implementation UIViewController (Aspects)

+ (void)load {
    [super load];
    Method oc_viewDidLoadMethod = class_getInstanceMethod([UIViewController class], @selector(viewDidLoad));
    Method xs_viewDidLoadMethod = class_getInstanceMethod([UIViewController class], @selector(xs_viewDidLoad));
    method_exchangeImplementations(oc_viewDidLoadMethod, xs_viewDidLoadMethod);
    
    Method oc_viewWillAppearMethod = class_getInstanceMethod([UIViewController class], @selector(viewDidAppear:));
    Method xs_viewWillAppearMethod = class_getInstanceMethod([UIViewController class], @selector(xs_viewDidAppear:));
    method_exchangeImplementations(oc_viewWillAppearMethod, xs_viewWillAppearMethod);
    
    Method oc_viewDidAppearMethod = class_getInstanceMethod([UIViewController class], @selector(viewWillDisappear:));
    Method xs_viewDidAppearMethod = class_getInstanceMethod([UIViewController class], @selector(xs_viewWillDisappear:));
    method_exchangeImplementations(oc_viewDidAppearMethod, xs_viewDidAppearMethod);
}

- (void)xs_viewDidLoad {
    if (self.navigationController.viewControllers.count > 1) {
        UIBarButtonItem *backItem = [[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStylePlain target:self action:@selector(xs_backButtonBeenClicked)];
        backItem.image = [UIImage imageNamed:@"navBackDefault"];
        UIBarButtonItem * space = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
        space.width = -5;
        self.navigationItem.leftBarButtonItems = @[space,backItem];
    }
//    UIViewController * VC = self.navigationController.visibleViewController;
//
//    NSInteger index = [self.navigationController.viewControllers indexOfObject:VC];
//    UIViewController * lastController = nil;
//    if (index > 0) {
//        lastController = self.navigationController.viewControllers[index - 1];
//    }
//    NSLog(@"last viewController- Appear ==== %@",[[NSStringFromClass(lastController.class) componentsSeparatedByString:@"."] lastObject]);
}

- (void)xs_viewDidAppear:(BOOL)animated {
//    NSString * currentController = [[NSStringFromClass(self.class) componentsSeparatedByString:@"."] lastObject];
//    if ([self viewControllerIgnore: currentController]) {
//        return;
//    }
//    NSDictionary *configDict = [self dictionaryFromUserStatisticsConfigPlist];
//    NSDictionary *pageDic = configDict[@"Pages"][currentController];
//    NSLog(@"current_viewWillAppear Dic = %@", pageDic);
//
//    if (pageDic != nil) {
//        [NSObject pageHandleLog:pageDic isEnter:YES];
//    }
}
- (void)xs_viewWillDisappear:(BOOL)animated {
//    NSString * currentController = [[NSStringFromClass(self.class) componentsSeparatedByString:@"."] lastObject];
//    if ([self viewControllerIgnore: currentController]) {
//        return;
//    }
//    NSDictionary *configDict = [self dictionaryFromUserStatisticsConfigPlist];
//    NSDictionary *pageDic = configDict[@"Pages"][currentController];
//    NSLog(@"currentviewDidDisappear Dic = %@", pageDic);
//    
//    if (pageDic != nil) {
//       [NSObject pageHandleLog:pageDic isEnter:NO];
//    }
}

- (NSDictionary *)dictionaryFromUserStatisticsConfigPlist
{
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"UserStatisticsPage" ofType:@"plist"];
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:filePath];
    return dic;
}

- (BOOL)viewControllerIgnore:(NSString *)className {
    NSString *screenName = NSStringFromClass([self class]);
    if ([screenName isEqualToString:@"SFBrowserRemoteViewController"] ||
        [screenName isEqualToString:@"SFSafariViewController"] ||
        [screenName isEqualToString:@"UIAlertController"] ||
        [screenName isEqualToString:@"UIInputWindowController"] ||
        [screenName isEqualToString:@"UINavigationController"] ||
        [screenName isEqualToString:@"UIKeyboardCandidateGridCollectionViewController"] ||
        [screenName isEqualToString:@"UICompatibilityInputViewController"] ||
        [screenName isEqualToString:@"UIApplicationRotationFollowingController"] ||
        [screenName isEqualToString:@"UIApplicationRotationFollowingControllerNoTouches"] ||
        [screenName isEqualToString:@"UIViewController"]
        ) {
        return YES;
    }
    if ([className isEqualToString:(@"XSTabBarController")] ||
        [className isEqualToString:(@"XSNavigationController")] ||
        [className isEqualToString:(@"VideoTypePageController")]) {
        return YES;
    }
    return NO;
}

- (void)xs_backButtonBeenClicked {
    [self.navigationController popViewControllerAnimated:true];
}

@end

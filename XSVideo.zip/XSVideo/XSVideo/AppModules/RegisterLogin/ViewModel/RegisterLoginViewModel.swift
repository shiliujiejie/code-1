//
//  ReginsterLoginViewModel.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/17.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import NicooNetwork

class RegisterLoginViewModel: NSObject {
    
    private lazy var loginApi: UserLoginApi = {
        let api = UserLoginApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var registerApi: UserRegisterApi = {
        let api = UserRegisterApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var sendCodeApi: SendCodeApi = {
        let api = SendCodeApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var changePswApi: UserResetPswApi = {
        let api = UserResetPswApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var deviceRegisterApi: DeviceRegisterApi = {
        let api = DeviceRegisterApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    /// 参数
    var paramsRegister: [String: Any]?
    var paramsLogin: [String: Any]?
    var paramsSendCode: [String: Any]?
    var paramsChangePsw: [String: Any]?
    /// 注册接口回调
    var loadRegisterApiSuccess:(() ->Void)?
    var loadRegisterApiFail:((_ msg: String) ->Void)?
    /// 登录接口回调
    var loadLoginApiSuccess:(() ->Void)?
    var loadLoginApiFail:((_ msg: String) ->Void)?
    /// 发送验证码接口回掉
    var loadSendCodeApiSuccess:(() ->Void)?
    var loadSendCodeApiFail:((_ msg: String) ->Void)?
    /// 修改密码接口回调
    var loadChangePswApiSuccess:(() ->Void)?
    var loadChangePswApiFail:((_ msg: String) ->Void)?
    
    /// 注册成功
    var loadDeviceRegisterSuccess:(() ->Void)?
    var loadDeviceRegisterFail:(() -> Void)?
    
    var codeModel: CodeModel?
    

    /// 注册
    func reginsterUser(_ params: [String: Any]) {
        paramsRegister = params
        let _ = registerApi.loadData()
    }
    
    /// 登录
    func loginUser(_ params: [String: Any]) {
        paramsLogin = params
        let _ = loginApi.loadData()
    }
    
    /// 发送验证码
    func sendCode(_ params: [String: Any]) {
        paramsSendCode = params
        let _ = sendCodeApi.loadData()
    }
    
    /// 设备注册
    func registerDevice() {
        let _ = deviceRegisterApi.loadData()
    }
    
    /// 修改密码
    func changePsw(_ params: [String: Any]) {
        paramsChangePsw = params
        let _ = changePswApi.loadData()
    }
    
}

// MARK: - PUBLIC FUNCS
extension RegisterLoginViewModel {
    
    func getCodeModel() -> CodeModel {
        if codeModel != nil {
            return codeModel!
        }
        return CodeModel()
    }
}

// MARK: - Privite Funcs
 private extension RegisterLoginViewModel {
    
    func loginSuccess(_ model: LoginInfoModel) {
        DLog("userNickName ---\(model.user?.name ?? "")")
        if model.user != nil {
            UserModel.share().api_token = model.user!.api_token
            UserModel.share().name = model.user!.name
            UserModel.share().email = model.user!.email
            UserModel.share().cover_path = model.user!.cover_path
            UserModel.share().id = model.user!.id
            UserModel.share().created_at = model.user!.created_at
            UserModel.share().isLogin = true
            UserModel.share().isRealUser = true
        }
        loadLoginApiSuccess?()
    }
    
    func sendCodeSuccess(_ model: CodeModel) {
        codeModel = model
        loadSendCodeApiSuccess?()
    }
    
    func deviceRegisterSuccess(_ model: UserInfoModel) {
        UserModel.share().api_token = model.api_token
        UserModel.share().coins = model.coins ?? 0
        UserModel.share().id = model.id ?? 0
        UserModel.share().mobile = model.mobile
        UserModel.share().cover_path = model.cover_path
        UserModel.share().name = model.name
        UserModel.share().email = model.email
        UserModel.share().empirical = model.empirical ?? 0
        UserModel.share().created_at = model.created_at
        UserModel.share().lv_title = model.lv_title
        UserModel.share().updated_at = model.updated_at
        UserModel.share().view_count_daily_total = model.view_count_daily_total ?? 0
        UserModel.share().view_count_daily_use = model.view_count_daily_use ?? 0
        UserModel.share().view_count = model.view_count ?? 0
        UserModel.share().invite_code = model.invite_code
        UserModel.share().remain_count = model.remain_count ?? 0
        
        UserModel.share().type = model.type
        UserModel.share().isRealUser = model.type == 0
        UserModel.share().isLogin = true
        UserDefaults.standard.set(model.api_token, forKey: UserDefaults.kUserToken)
        UserDefaults.standard.set(model.invite_code, forKey: UserDefaults.kUserInviteCode)
        loadDeviceRegisterSuccess?()
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension RegisterLoginViewModel: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is UserLoginApi {
           return paramsLogin
        }
        if manager is UserRegisterApi {
            return paramsRegister
        }
        if manager is SendCodeApi {
            return paramsSendCode
        }
        if manager is DeviceRegisterApi {
            return [DeviceRegisterApi.kDevice_code: UIDevice.current.getIdfv()]
        }
        if manager is UserResetPswApi {
            return paramsChangePsw
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        if manager is UserLoginApi {
            DLog("UserLoginApi --- success")
            if let model = manager.fetchJSONData(UserReformer()) as? LoginInfoModel {
                loginSuccess(model)
            }
        }
        if manager is UserRegisterApi {
            DLog("RegisterApi --- success")
            loadRegisterApiSuccess?()
        }
        if manager is SendCodeApi {
            DLog("SendCodeApi --- success")
            if let model = manager.fetchJSONData(LoginRegisterReformer()) as? CodeModel {
                sendCodeSuccess(model)
            }
        }
        if manager is UserResetPswApi {
            DLog("UserResetPswApi --- success")
            loadChangePswApiSuccess?()
        }
        if manager is DeviceRegisterApi {
            if let model = manager.fetchJSONData(LoginRegisterReformer()) as? UserInfoModel {
                deviceRegisterSuccess(model)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        if manager is UserLoginApi {
            loadLoginApiFail?(manager.errorMessage)
        }
        if manager is UserRegisterApi {
            loadRegisterApiFail?(manager.errorMessage)
        }
        if manager is SendCodeApi {
            loadSendCodeApiFail?(manager.errorMessage)
        }
        if manager is UserResetPswApi {
            loadChangePswApiFail?(manager.errorMessage)
        }
        if manager is DeviceRegisterApi {
            loadDeviceRegisterFail?()
        }
           
    }
}

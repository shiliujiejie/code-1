//
//  VideoCategoryViewModel.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/4.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import NicooNetwork

class VideoCategoryViewModel: NSObject {

    /// item之间的最小间隙 (这些size应该放入ViewModel)
    static let interitemSpacing: CGFloat = 5
    /// 一排 3个 排版
    static let thirdItemWidth: CGFloat = (UIScreen.main.bounds.size.width - 20)/3
    static let thirdItemHieght: CGFloat = thirdItemWidth * 1.4 + 55
    /// 一排 2个 排版
    static let doubleItemWidth: CGFloat = (UIScreen.main.bounds.size.width - 15)/2
    static let doubleItemHeight: CGFloat = doubleItemWidth * 9/16 + 50
    /// 广告 排版
    static let advertisingItemWith: CGFloat = ConstValue.kScreenWdith - 10
    static let advertisingItemHeight: CGFloat =  200
    /// 每个区的数据类型
    enum SectionType {
        case advertisement       // 广告
        case video      // 视频  3 * 1
        case doubleItemVideo     // 视频  2 * 1
    }
    /// 分区数
    private(set) var sectionCount: Int = 1
    /// 数据源
    private(set) lazy var sectionItems: [AnyObject] = {
        let sections = [AnyObject]()
        return sections
    }()
    /// 视频列表APi
    private lazy var videoListApi: VideoListApi = {
        let api = VideoListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    /// 用于区分该分区的数据类型，和cell类型
    var sectionType: SectionType = SectionType.video
    /// 类型ID
    var globalType: String?
    /// 选中的tips参数
    var tipsParams: [String: Any]?
    /// 数据model
    var videoListModel: VideoListModel?
    var videoModelList = [VideoModel]()
    var currentPage: Int = 0
    /// 是否是下拉刷新操作
    var isRefreshOperation = false
    var successCallBack:((Bool) ->Void)?
    var loadDataFailCallbackHnadler:((_ emptyData: Bool, _ currentPage: Int) ->Void)?
    var loadPageDataSuccess:((_ fullPage: Bool, _ firstPage: Bool) -> Void)?
    
    
    convenience init(globalType: String) {
        self.init()
        self.globalType = globalType
    }
    
    func loadData() {
         let _  = videoListApi.loadData()
    }
    
    func loadNextPage() {
        let _ = videoListApi.loadNextPage()
    }
    
    private func requestSuccess(_ listModel: VideoListModel) {
        self.videoListModel = listModel
        if let list = listModel.data, let pageNumber = listModel.current_page, list.count > 0 {
            currentPage = pageNumber   // 记录下来当前请求的页数
            if pageNumber == 1 {
                videoModelList = list
                if list.count >= VideoListApi.kDefaultCount {  // 表示可能还有数据
                    loadPageDataSuccess?(true, true)                 // 第一页请求成功，可能还有第二页数据
                } else {
                    loadPageDataSuccess?(false, true)                // 第一页请求成功，没有第二页数据
                }
                isRefreshOperation = true
            } else {
                videoModelList.append(contentsOf: list)
                if list.count >= VideoListApi.kDefaultCount {     // 表示可能还有数据
                    loadPageDataSuccess?(true, false)
                } else {
                    loadPageDataSuccess?(false, false)
                }
            }
        }
        successCallBack?(true)
    }
    
}

// MARK: - 数据加载 构造
extension VideoCategoryViewModel {
    
    func getVideoList() ->[VideoModel] {
        return videoModelList
    }
   
    func getVideoModel(_ row: Int) -> VideoModel {
        if videoModelList.count > row { // 防止数组越界
            let videoModel = videoModelList[row]
            return videoModel
        }
        return VideoModel()
    }
}


// MARK: - 根据数据配置页面 pubulic
extension VideoCategoryViewModel {
    
    /// 获取每个区显示多少数据
    func getRowCountWith() -> Int {
        return videoModelList.count
    }
    
    /// 获取该区显示得是哪种类型的数据，从而选择使用哪种cell， 哪种布局方式
    func getSectionType(section: Int) -> SectionType {
        if sectionItems.count > section {
            if sectionItems[section] is [VideoModel] {
                return .video
            }
            if sectionItems[section] is [AdvertisingModel] {
                return .advertisement
            }
        }
        return sectionType
    }
    
    /// 获取Item大小
    func getItemSize(sectionType: SectionType) -> CGSize? {
        if sectionType == .video {
            return CGSize(width: VideoCategoryViewModel.thirdItemWidth, height: VideoCategoryViewModel.thirdItemHieght)
        } else if sectionType == .advertisement {
            return  CGSize(width: VideoCategoryViewModel.advertisingItemWith, height: VideoCategoryViewModel.advertisingItemHeight)
        } else if sectionType == .doubleItemVideo {
            return CGSize(width: VideoCategoryViewModel.doubleItemWidth, height: VideoCategoryViewModel.doubleItemHeight)
        }
        return CGSize.zero
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension VideoCategoryViewModel: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is VideoListApi {
            if var params = tipsParams {
                params[VideoListApi.kGlobal_type] = self.globalType ?? ""
                return params
            } else {
                return [VideoListApi.kGlobal_type: globalType ?? ""]
            }
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        if manager is VideoListApi {
            if let videoList = manager.fetchJSONData(VideoReformer()) as? VideoListModel {
                requestSuccess(videoList)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        loadDataFailCallbackHnadler?(false, currentPage)
    }
}

//
//  AdvertisingCollectionCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/5.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class AdvertisingCollectionCell: UICollectionViewCell {

    static let cellId = "AdvertisingCollectionCell"
    
    @IBOutlet weak var advertisingImage: UIImageView!
    @IBOutlet weak var advertisingDesLable: UILabel!
    @IBOutlet weak var advertisingNameLable: UILabel!
    @IBOutlet weak var tipsLable: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        tipsLable.layer.cornerRadius = 3
        tipsLable.layer.borderColor = UIColor.white.cgColor
        tipsLable.layer.borderWidth = 0.8
        tipsLable.text = "广告"
        tipsLable.layer.masksToBounds = true
        advertisingImage.layer.cornerRadius = 3
        advertisingImage.layer.masksToBounds = true
    }

}

//
//  VideoCategoryListView.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/4.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import NicooNetwork

class VideoCategoryListView: UIView {
    
    static let titleViewBaseTag = 4399
    
    private var titles: [[String]] = {
       let title = [["全部类型"],["全部地区"],["全部年限"],["全部分类", "最近更新", "最多喜欢", "人气排行"]]
        return title
    }()
    /// 分类选择APi
    private lazy var videoCateTypeApi: VideoCateTypeListApi = {
        let api = VideoCateTypeListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private var defuatTitles: [String] = {
        let titles = [UIViewController.localStr("kAllCateTitle"), UIViewController.localStr("kRecenttimeUpdate"), UIViewController.localStr("kMostLikely"), UIViewController.localStr("kPopularRank")]
        return titles
    }()
    var selfHieght: CGFloat = 65.0
    // 类型区分
    var global_type: String?
    /// item点击回调
    var itemClickHandler:(([String: Any]) -> Void)?

    private var cateLsModel: CateListModel?

    init(frame: CGRect, type: String) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        global_type = type
        let _ = videoCateTypeApi.loadData()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func createTitleViews(_ allTitles: [[String]]) {
        for i in 0 ..< titles.count {
            if let titleView = FSSegmentTitleView(frame: CGRect(x: 10, y: 20 + i * 45, width: Int(self.bounds.width - 10), height: 30), titles: titles[i], delegate: self , indicatorType: FSIndicatorTypeEqualTitle) {
                titleView.indicatorColor = UIColor.clear
                titleView.titleSelectColor = ConstValue.kAppDefaultColor
                titleView.tag = VideoCategoryListView.titleViewBaseTag + i
              //  titleView.selectedBgImage = UIImage.imageFromColor(ConstValue.kAppDefaultColor, frame: CGRect(x: 0, y: 0, width: 50, height: 30))
                self.addSubview(titleView)
            }
        }
    }
    
    ///处理数据
    private func requestDataSuccess() {
        guard let cateList = self.cateLsModel else { return }
        var typeListTitles = [String]()
        var dictListTitles = [String]()
        var epochListTitles = [String]()
        if let typeList = cateList.type, typeList.count > 0 {
            for k in 0..<typeList.count {
                let model = typeList[k]
                typeListTitles.append(model.name ?? "")
            }
            let defaultTips = VideoTipsModel(key: "0", name: UIViewController.localStr("kAllKindsTitle"))
            typeListTitles.insert(defaultTips.name!, at: 0)
            self.cateLsModel?.type?.insert(defaultTips, at: 0)
        }
        if let dictList = cateList.dist, dictList.count > 0 {
            for k in 0..<dictList.count {
                let model = dictList[k]
                dictListTitles.append(model.name ?? "")
            }
            let defaultTips = VideoTipsModel(key: "0", name: UIViewController.localStr("kAllEpochTitle"))
            dictListTitles.insert(defaultTips.name!, at: 0)
            self.cateLsModel?.dist?.insert(defaultTips, at: 0)
        }
        if let epochList = cateList.epoch, epochList.count > 0 {
            for k in 0..<epochList.count {
                let model = epochList[k]
                epochListTitles.append(model.name ?? "")
            }
            let defaultTips = VideoTipsModel(key: "0", name: UIViewController.localStr("kAllYearTitle"))
            epochListTitles.insert(defaultTips.name!, at: 0)
            self.cateLsModel?.epoch?.insert(defaultTips, at: 0)
        }
        let allTitles = [typeListTitles, dictListTitles, epochListTitles]
        titles = allTitles
        titles.append(defuatTitles)
        createTitleViews(titles)
    }
    
}

// MARK: - FSSegmentTitleViewDelegate
extension VideoCategoryListView: FSSegmentTitleViewDelegate {
    
    func fsSegmentTitleView(_ titleView: FSSegmentTitleView!, start startIndex: Int, end endIndex: Int) {
        /// 选中的tips参数
        var tipsParams = [VideoListApi.kType_id: "0", VideoListApi.kDist_id: "0", VideoListApi.kEpoch_id : "0"]
        let titleViewIndex = titleView.tag - VideoCategoryListView.titleViewBaseTag
        if titleViewIndex == 0 {
            guard let typeModelList = self.cateLsModel?.type else { return }
            let model = typeModelList[endIndex]
            tipsParams[VideoListApi.kType_id] = model.key ?? "0"
        }
        if titleViewIndex == 1 {
            guard let distModelList = self.cateLsModel?.dist else { return }
            let model = distModelList[endIndex]
            tipsParams[VideoListApi.kDist_id] = model.key ?? "0"
        }
        if titleViewIndex == 2 {
            guard let epochModelList = self.cateLsModel?.epoch else { return }
            let model = epochModelList[endIndex]
            tipsParams[VideoListApi.kEpoch_id] = model.key ?? "0"
        }
        if titleViewIndex == 3 {
            let key = ["",VideoListApi.kCreated_at,VideoListApi.kPlay_count_real,VideoListApi.kExponent_bd][endIndex]
            let value = ["",VideoListApi.kDefaultCreat_at, VideoListApi.kDefaultPlay_count_real,VideoListApi.kDefaultExponent_bd][endIndex]
            if endIndex != 0 {
               tipsParams[key] = value
            }
        }
        itemClickHandler?(tipsParams)
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension VideoCategoryListView: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
         var parameters = [String: Any]()
        parameters[VideoCateTypeListApi.kGlobal_type] = global_type ?? "film"
        return parameters
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        let cateListModel = manager.fetchJSONData(GlobalTypeReformer()) as? CateListModel
        cateLsModel = cateListModel
        requestDataSuccess()
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        
        
    }
}

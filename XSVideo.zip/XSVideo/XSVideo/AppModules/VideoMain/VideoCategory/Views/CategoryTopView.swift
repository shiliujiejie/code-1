//
//  CategoryTopView.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/5.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 分类头部展示选中的 类型
class CategoryTopView: UIView {

    private lazy var showButton: UIButton = {
        let button = UIButton(type: .custom)
        button.addTarget(self, action: #selector(showButtonClick(_:)), for: .touchUpInside)
        button.setTitleColor(UIColor(red: 60/255.0, green: 179/255.0, blue: 79/255.0, alpha: 1), for: .normal)
        button.setTitle(UIViewController.localStr("kAllCateTitle"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        button.backgroundColor = UIColor.clear
        button.layer.borderColor = UIColor.groupTableViewBackground.cgColor
        button.layer.borderWidth = 0.5
        return button
    }()
    lazy var categoryListView: VideoCategoryListView = {
        let cateView = VideoCategoryListView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: categoryListViewHeight), type: global_type ?? "")
        cateView.backgroundColor = UIColor.white
        return cateView
    }()
    var categoryListViewHeight: CGFloat = 0
    // 类型区分
    var global_type: String?
    var clickHandler:(() -> Void)?
    var itemClickHandler:(([String: Any]) -> Void)?
    
    init(frame: CGRect, type: String) {
        super.init(frame: frame)
        backgroundColor = UIColor.white
        global_type = type
        addSubview(showButton)
        layoutShowButton()    
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    @objc func showButtonClick(_ sender: UIButton) {
        clickHandler?()
        self.bounds = CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: categoryListViewHeight + 40)
        self.snp.updateConstraints { (make) in
            make.height.equalTo(categoryListViewHeight + 40)
        }
        if !subviews.contains(categoryListView) {
            insertSubview(categoryListView, belowSubview: showButton)
            addItemClickHandler()
            layoutCategoryListView()
        }
    }
    
    private func addItemClickHandler() {
        categoryListView.itemClickHandler = { [weak self] (parmas) in
            self?.itemClickHandler?(parmas)
        }
    }
}

// MARK: - Layout
private extension CategoryTopView {
    
    func layoutPageSubviews() {
        layoutShowButton()
    }
    
    func layoutShowButton() {
        showButton.snp.makeConstraints { (make) in
            make.top.leading.trailing.equalToSuperview()
            make.height.equalTo(40)
        }
    }
    
    func layoutCategoryListView() {
        categoryListView.snp.makeConstraints { (make) in
            make.top.equalTo(showButton.snp.bottom).offset(-10)
            make.leading.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
    }
}

//
//  SingleCategoryController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/10.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import NicooNetwork
import MJRefresh

/// 单个类别的视频列表
class SingleCategoryController: UIViewController {
    
    static let footerViewId = "footViewId"
    
    private let layout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = SpecialTopicViewModel.videoItemSize
        layout.minimumLineSpacing = 15   // 垂直最小间距
        layout.minimumInteritemSpacing = 5.0 // 水平最小间距
        layout.sectionInset = UIEdgeInsets(top: 10, left: 5, bottom: 10, right: 5)
        return layout
    }()
    private lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.backgroundColor = UIColor.white
        collection.showsVerticalScrollIndicator = false
        collection.register(VideoThridItemCell.classForCoder(), forCellWithReuseIdentifier: VideoThridItemCell.cellId)
        collection.register(UINib(nibName: "AdvertisingCollectionCell", bundle: Bundle.main), forCellWithReuseIdentifier: AdvertisingCollectionCell.cellId)
        collection.register(UICollectionReusableView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: SingleCategoryController.footerViewId)
        collection.mj_header = refreshView
        return collection
    }()
    private lazy var videoModulsApi: VideoModuleMoreApi = {
        let api = VideoModuleMoreApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var videoLsApi: VideoListApi = {
        let api = VideoListApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        return MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
    }()
    lazy private var refreshView: MJRefreshGifHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshGifHeader(refreshingBlock: {
            weakSelf?.isRefreshOperation = true
            weakSelf?.loadData()
        })
        var gifImages = [UIImage]()
        for string in ConstValue.refreshImageNames {
            gifImages.append(UIImage(named: string)!)
        }
        mjRefreshHeader?.setImages(gifImages, for: .refreshing)
        mjRefreshHeader?.setImages(gifImages, for: .idle)
        return mjRefreshHeader!
    }()
    
    /// 是否是下拉刷新操作
    private var isRefreshOperation = false
    var parmas: [String: Any]?
    var navTitle: String?
    var isSpecialTopic = false
    
    var videoList = [VideoModel]()
    
    /// 处理导航栏
    var navHidenCallBackHandler:((_ isAnimated: Bool) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        title = navTitle
        view.addSubview(collectionView)
        layoutPageSubviews()
        loadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navHidenCallBackHandler?(true)
    }
    
    func loadData() {
        NicooErrorView.removeErrorMeesageFrom(self.view)
        if !isRefreshOperation {
            XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        } else {
            isRefreshOperation = false
        }
        if isSpecialTopic {
            let _ = videoLsApi.loadData()
        } else {
            let _ = videoModulsApi.loadData()
        }
        
    }
    
    func loadNextPage() {
        if isSpecialTopic {
            let _ = videoLsApi.loadNextPage()
        } else {
            let _ = videoModulsApi.loadNextPage()
        }
    }
  
}

// MARK: - Private - Funcs
private extension SingleCategoryController {
    
    private func requestSuccess(_ model: VideoListModel) {
        NicooErrorView.removeErrorMeesageFrom(self.view)
        collectionView.mj_footer?.endRefreshing()
        collectionView.mj_header?.endRefreshing()
        loadMoreView.isHidden = true
        if let list = model.data, let pageNumber = model.current_page, list.count > 0 {
            if pageNumber == 1 {
                videoList = list
                if list.count >= VideoListApi.kDefaultCount { // 表示可能还有数据
                    collectionView.mj_footer = loadMoreView
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
                isRefreshOperation = true
            } else {
                videoList.append(contentsOf: list)
                if list.count >= VideoListApi.kDefaultCount { // 表示可能还有数据
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
            }
            collectionView.reloadData()
        } else {
            NicooErrorView.showErrorMessage(.noData, on: view, topMargin: 50, clickHandler: nil)
        }
    }
    
    private func requestFail(_ manager: NicooBaseAPIManager) {
        if !isRefreshOperation {
            NicooErrorView.showErrorMessage(.noNetwork, on: view) { [weak self] in
                self?.loadData()
            }
        } 
    }
}
    

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension SingleCategoryController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return videoList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cellForRow(with: indexPath)
        return cell
    }
    
    /// 配置cell
    func cellForRow(with indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: VideoThridItemCell.cellId, for: indexPath) as! VideoThridItemCell
        let videoModel = videoList[indexPath.row]
        cell.videoNameLable.text = videoModel.title ?? ""
        cell.videoImageView.kfSetVerticalImageWithUrl(videoModel.cover_path)
        if let introl = videoModel.intro, !introl.isEmpty {
            cell.videoIntroLable.text = introl
        } else {
            cell.videoIntroLable.text = localStr("kNotIntrolMsg")
        }
        if videoModel.score != nil &&  !videoModel.score!.isEmpty {
            cell.pointLable.isHidden = false
            cell.pointLable.attributedText = TextSpaceManager.configScoreString(allString: String(format: "%@", videoModel.score!))
        } else {
            cell.pointLable.isHidden = true
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let videoDetail = VideoDetailViewController()
        let videoModel = videoList[indexPath.row]
        videoDetail.videoId = videoModel.id
        navigationController?.pushViewController(videoDetail, animated: true)
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension SingleCategoryController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is VideoModuleMoreApi || manager is VideoListApi  {
             return parmas
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is VideoModuleMoreApi || manager is VideoListApi {
            if let videoList = manager.fetchJSONData(VideoReformer()) as? VideoListModel {
                requestSuccess(videoList)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is VideoModuleMoreApi || manager is VideoListApi {
            requestFail(manager)
        }
        
    }
}

// MARK: - Layout
private extension SingleCategoryController {
    
    func layoutPageSubviews() {
        layoutCollectionView()
    }
    
    func layoutCollectionView() {
        collectionView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalTo(0)
            }
        }
    }
}

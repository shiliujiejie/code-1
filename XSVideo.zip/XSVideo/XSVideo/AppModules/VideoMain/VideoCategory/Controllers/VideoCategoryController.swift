//
//  VideoCategoryController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/4.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import MJRefresh

/// 视频选择分类页面
class VideoCategoryController: UIViewController {
    
    static let thridVideoCellId = "BookCollectionCell"
    static let doubleCellId = "doubleCell"
    static let footerViewId = "footViewId"
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.backgroundColor = UIColor.white
        collection.showsVerticalScrollIndicator = false
        collection.register(VideoThridItemCell.classForCoder(), forCellWithReuseIdentifier: VideoThridItemCell.cellId)
        collection.register(UINib(nibName: "VideoDoubleCollectionCell", bundle: Bundle.main), forCellWithReuseIdentifier: VideoCategoryController.doubleCellId)
        collection.register(UINib(nibName: "AdvertisingCollectionCell", bundle: Bundle.main), forCellWithReuseIdentifier: AdvertisingCollectionCell.cellId)
        collection.register(UICollectionReusableView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: VideoCategoryController.footerViewId)
        collection.mj_header = refreshView
        return collection
    }()
    
    private lazy var categoryListView: VideoCategoryListView = {
        let cateView = VideoCategoryListView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 45 * 4  + 20), type: typeKeyModel?.key ?? "")
        return cateView
    }()
    private lazy var categoryTopView: CategoryTopView = {
        let topView = CategoryTopView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 40), type: typeKeyModel?.key ?? "")
        topView.categoryListViewHeight = categoryListView.bounds.size.height
        topView.alpha = 0.0
        return topView
    }()
    /// 右上角搜索按钮
    private lazy var searchBarButton: UIBarButtonItem = {
        let item = UIBarButtonItem(barButtonSystemItem: .search, target: self, action: #selector(searchBarButtonBeenClicked))
        item.tintColor = ConstValue.kAppDefaultTitleColor
        return item
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        return MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
    }()
    lazy private var refreshView: MJRefreshGifHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshGifHeader(refreshingBlock: {
            weakSelf?.viewModel.isRefreshOperation = true
            weakSelf?.loadData()
        })
        var gifImages = [UIImage]()
        for string in ConstValue.refreshImageNames {
            gifImages.append(UIImage(named: string)!)
        }
        mjRefreshHeader?.setImages(gifImages, for: .refreshing)
        mjRefreshHeader?.setImages(gifImages, for: .idle)
        return mjRefreshHeader!
    }()
    var typeKeyModel: GlobalType?
    private lazy var viewModel: VideoCategoryViewModel = {
        let model = VideoCategoryViewModel(globalType: typeKeyModel?.key ?? "")
        addLoadDataSuccessCallBack(model)
        return model
    }()
    
    /// 处理导航栏
    var navHidenCallBackHandler:((_ isAnimated: Bool) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = typeKeyModel?.name ?? "" // 这个可能也要去viewmodel 内根据数据类型取
        navigationItem.rightBarButtonItem = searchBarButton
        view.backgroundColor = UIColor.white
        view.addSubview(categoryListView)
        view.addSubview(collectionView)
        view.addSubview(categoryTopView)
        layoutPageSubviews()
        addTipsItemClickHandler()
        loadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: false)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navHidenCallBackHandler?(true)
    }
    
    @objc private func searchBarButtonBeenClicked() {
        let searchVC = SearchController()
        let nav = XSNavigationController(rootViewController: searchVC)
        present(nav, animated: true, completion: nil)
    }
    
    func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        if !viewModel.isRefreshOperation { // 非下拉操作
              XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        } else {
            viewModel.isRefreshOperation = false
        }
        viewModel.loadData()
    }
    
    func loadNextPage() {
        viewModel.loadNextPage()
    }
    
    private func addTipsItemClickHandler() {
        categoryListView.itemClickHandler = { [weak self] (parmas) in
            guard let strongSelf = self else { return }
            strongSelf.viewModel.tipsParams = parmas
            strongSelf.viewModel.videoModelList.removeAll()
            strongSelf.viewModel.isRefreshOperation = false
            strongSelf.loadData()
        }
        categoryTopView.itemClickHandler = { [weak self] (parmas) in
            guard let strongSelf = self else { return }
            strongSelf.viewModel.tipsParams = parmas
            strongSelf.viewModel.videoModelList.removeAll()
            strongSelf.viewModel.isRefreshOperation = false
            strongSelf.loadData()
        }
    
    }
    
    private func endRefresh() {
        collectionView.mj_footer?.endRefreshing()
        collectionView.mj_header?.endRefreshing()
        XSProgressHUD.hide(for: view, animated: false)
    }
    
    /// 网络请求回调
    private func addLoadDataSuccessCallBack(_ viewModel: VideoCategoryViewModel) {
        
        viewModel.successCallBack = { [weak self] (success) in
            guard let strongSelf = self else { return }
            if strongSelf.viewModel.videoModelList.count == 0 {
                NicooErrorView.showErrorMessage(.noData, on: strongSelf.view, topMargin: 200, clickHandler: nil)
            }
            strongSelf.endRefresh()
            strongSelf.collectionView.reloadData()
        }
        viewModel.loadDataFailCallbackHnadler = { [weak self] (emptyData,currentPage) in
            guard let strongSelf = self else { return }
            strongSelf.endRefresh()
            if currentPage == 0 {
                NicooErrorView.showErrorMessage(.noNetwork, on: strongSelf.view, topMargin: 200 ,clickHandler: {
                    if !emptyData {
                        strongSelf.loadData()
                    }
                })
            }
        }
        viewModel.loadPageDataSuccess = { [weak self] (isFullPage, isFirstPage) in
            guard let strongSelf = self else { return }
            if isFullPage {
                strongSelf.loadMoreView.isHidden = false
                if isFirstPage {
                    strongSelf.collectionView.mj_footer = strongSelf.loadMoreView
                }
            } else {
                strongSelf.loadMoreView.isHidden = true
            }
        }
    }

}


// MARK: - UICollectionViewDelegate, UICollectionViewDataSource

extension VideoCategoryController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return viewModel.sectionCount
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.getRowCountWith()
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cellForRow(with: indexPath)
        return cell
    }
    
    /// 配置cell
    func cellForRow(with indexPath: IndexPath) -> UICollectionViewCell {
        let sectionType = viewModel.getSectionType(section: indexPath.section)
        if sectionType == .video {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: VideoThridItemCell.cellId, for: indexPath) as! VideoThridItemCell
            let model = viewModel.getVideoModel(indexPath.row)
            cell.videoNameLable.text = model.title ?? ""
            cell.videoImageView.kfSetVerticalImageWithUrl(model.cover_path)
            if let introl = model.intro, !introl.isEmpty {
                cell.videoIntroLable.text = introl
            } else {
                cell.videoIntroLable.text = localStr("kNotIntrolMsg")
            }
            if model.score != nil &&  !model.score!.isEmpty {
                cell.pointLable.isHidden = false
                cell.pointLable.attributedText = TextSpaceManager.configScoreString(allString: String(format: "%@", model.score!))
            } else {
                cell.pointLable.isHidden = true
            }
            return cell
        }
        if sectionType == .doubleItemVideo {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: VideoCategoryController.doubleCellId, for: indexPath) as! VideoDoubleCollectionCell
            cell.videoName.text = "name"
            cell.VideoImage.image = UIImage(named: "videoHpic\(indexPath.row + 1).jpg")
            cell.VideoDes.text = "阿汤哥全程开挂模式。"
            return cell
        }
      if sectionType == .advertisement {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: AdvertisingCollectionCell.cellId, for: indexPath) as! AdvertisingCollectionCell
        cell.advertisingDesLable.text = "阿汤哥全程开挂模式。"
        cell.advertisingImage.image = UIImage(named: "7.jpg")
        cell.advertisingNameLable.text = "广告"
        return cell
    }
        return UICollectionViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        let model = viewModel.getVideoModel(indexPath.row)
        let videoDetail = VideoDetailViewController()
        videoDetail.videoId = model.id
        navigationController?.pushViewController(videoDetail, animated: true)
    }
}

// MARK: - UICollectionViewDelegateFlowLayout

extension VideoCategoryController: UICollectionViewDelegateFlowLayout {
    
    /// 所有的布局都要根据 ViewModel 获取到的数据来决定
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let sectionType = viewModel.getSectionType(section: indexPath.section)
        if let itemSize = viewModel.getItemSize(sectionType: sectionType) {
            return itemSize
        }
        return .zero
    }
    
    /// 边距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 5)
        
    }
    
    /// 垂直最小间距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }
    
    /// 水平最小间距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        // 当然这里也是可以根据数据类型来判断
        return VideoCategoryViewModel.interitemSpacing
    }
    
    /// sectionHeader高度
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return .zero
    }
    
    /// sectionFooter 高度
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        return CGSize(width: UIScreen.main.bounds.size.width, height: 10)
    }
    
}

// MARK: - UIScrollViewDelegate
extension VideoCategoryController: UIScrollViewDelegate {
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let yOffset = scrollView.contentOffset.y
        let topMargin = yOffset * 0.4
        if yOffset > 10  {
            if topMargin <= categoryListView.bounds.height {
                categoryListView.snp.remakeConstraints { (make) in
                    make.top.equalTo(-topMargin)
                    make.leading.trailing.equalToSuperview()
                    make.height.equalTo(45 * 4 + 30)
                }
                if topMargin >= categoryListView.bounds.height - 40 {
                    categoryTopView.alpha = 1/40 * (topMargin - categoryTopView.bounds.height + 40)
                } else {
                    categoryTopView.alpha = 0.0
                }
            } else {
                categoryTopView.alpha = 1.0
            }
            if categoryTopView.bounds.size.height > 40 {
                categoryTopView.bounds = CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 40)
                categoryTopView.snp.updateConstraints { (make) in
                    make.height.equalTo(40)
                }
                for view in categoryTopView.subviews {
                    if view is VideoCategoryListView {
                        view.removeFromSuperview()
                    }
                }
            }
        } else {
            categoryTopView.alpha = 0.0
            categoryListView.snp.remakeConstraints { (make) in
                make.top.equalTo(0)
                make.leading.trailing.equalToSuperview()
                make.height.equalTo(45 * 4 + 30)
            }
        }
    }
 
}

// MARK: - Layout
private extension VideoCategoryController {
    
    func layoutPageSubviews() {
        layoutCategoryView()
        layoutCollectionView()
        layoutCategoryTopView()
    }
    
    func layoutCategoryView() {
        categoryListView.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(45 * 4 + 30)
        }
    }
    
    func layoutCategoryTopView() {
        categoryTopView.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(40)
        }
    }
    
    func layoutCollectionView() {
        collectionView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(categoryListView.snp.bottom)
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalTo(0)
            }
        }
    }
    
}


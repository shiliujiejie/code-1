//
//  AdvertisingModel.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/5.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation

/// 广告model
struct AdvertisingModel: Codable {
    var id: Int?
    var key: String?
    var global_type: String?
    var type: CarouselType?
    var title: String?
    var remark: String?
    var cover_path: String?
    var redirect_url: String?
    var sort: Int?
    var video_id: Int?
}

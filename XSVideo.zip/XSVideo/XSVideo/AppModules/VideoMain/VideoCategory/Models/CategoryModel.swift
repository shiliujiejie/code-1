//
//  CategoryModel.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/12.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation


struct CateListModel: Codable {
    var type: [VideoTipsModel]?
    var dist: [VideoTipsModel]?
    var epoch: [VideoTipsModel]?
}


struct VideoTipsModel: Codable {
    var key: String?
    var name: String?
}

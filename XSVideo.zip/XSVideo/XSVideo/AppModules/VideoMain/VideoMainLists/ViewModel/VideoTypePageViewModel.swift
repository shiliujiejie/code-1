//
//  BookViewModel.swift
//  MVVMTest
//
//  Created by 小星星 on 2018/10/15.
//  Copyright © 2018年 yangxin. All rights reserved.
//

import UIKit
import NicooNetwork

/// viewModel做三件事 ： 1.请求数据。 2.根据数据来决定V的布局（比如某一个区没有数据，该区不显示）3.向V提供需要的数据结构。

class VideoTypePageViewModel: NSObject {
    
    /// item之间的最小间隙 (这些size应该放入ViewModel)
    static let interitemSpacing: CGFloat = 5
    static let bookItemWidth: CGFloat = (UIScreen.main.bounds.size.width - 20)/3
    static let bookItemHieght: CGFloat = bookItemWidth * 1.4 + 55
    static let doubleItemWidth: CGFloat = (UIScreen.main.bounds.size.width - 15)/2
    static let doubleItemHeight: CGFloat = doubleItemWidth * 9/16 + 50
    /// BookItem 的size，与item之间的最小间隙关联
    static let itemThridSize = CGSize(width: bookItemWidth, height: bookItemHieght)
    static let itemOverlapSize = CGSize(width: ConstValue.kScreenWdith , height: ConstValue.kScreenWdith*3/8 + 55)
    static let itemScrollSize = CGSize(width: ConstValue.kScreenWdith , height: (ConstValue.kScreenWdith - 10)/2)
    static let itemDoubleSize = CGSize(width: doubleItemWidth , height: doubleItemHeight)
    static let itemScroll_V_Size = CGSize(width: ConstValue.kScreenWdith, height: ThirdStyleScrollCell.itemHieght + 40)
    /// 广告 排版
    static let itemAdvertiseSize = CGSize(width: ConstValue.kScreenWdith - 10, height: (ConstValue.kScreenWdith - 10) * 7/16 + 70)

    
    /// 区对应的模块
    enum SectionType {
        case adCarouse     // 轮播
        case thirdItems    // 九宫格视频
        case doubleItems   // 四宫格视频
        case scroll_H      // 横向滚动视频
        case scroll_V      // 竖向滚动
        case advertise     // 广告
    }
    
    enum GlobalType {
        case recomment  // 推荐（包含以下任意类型）
        case film       // 电影
        case teleplay   // 电视剧
        case cartoon    // 动漫
        case variety    // 综艺
    }
   
    private(set) var sectionCount: Int = 0
    private(set) lazy var sectionItems: [AnyObject] = {
        let sections = [AnyObject]()
        return sections
    }()
    private lazy var reconmentApi: VideoRecommentApi = {
        let api = VideoRecommentApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var videoMainListApi: VideoMainListApi = {
        let api = VideoMainListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    
    private lazy var videoModulesApi: VideoModuleListApi = {
        let api = VideoModuleListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    
    
    /// 区分视频类型
    var globalType: String? = "recommend" {
        didSet {
            if globalType == "recommend" {
                globalVideoType = .recomment
            }
            if globalType == "film" {
                globalVideoType = .film
            }
            if globalType == "teleplay" {
                globalVideoType = .teleplay
            }
            if globalType == "cartoon" {
                globalVideoType = .cartoon
            }
            if globalType == "variety" {
                globalVideoType = .variety
            }
        }
    }
    /// 是否是下拉刷新操作
    var isRefreshOperation = false
    var recommentModel: VideoRecommentModel?
    
    var modulesListModels = [VideoModulesModel]()
    var modulesList = [VideoModulesModel]()
    
    
    /// 用于区分该分区的数据类型，和cell类型
    var sectionType: SectionType = SectionType.adCarouse
    var globalVideoType: GlobalType = GlobalType.recomment
    
    /// 无数据
    var showNodataCallBackHandler:(() ->Void)?
    var loadModulesDatasSuccessHandler:((_ moreData: Bool) -> Void)?
    var loadModulesDatasFailHandler:(() -> Void)?
    
    var changeMoreDataHandler:((_ section: Int) -> Void)?
    
    
    func loadData() {
        let _ = videoModulesApi.loadData()
    }
    
    func loadNextPage() {
        let _ = videoModulesApi.loadNextPage()
    }
    
    func requestModulesListSuccess(_ listModel: VideoModulesListModel) {
        
        if let list = listModel.data, let pageNumber = listModel.current_page {
            if pageNumber == 1 {
                modulesList = list
                modulesListModels = list
                if list.count == 0 {
                    // 显示无数据
                    showNodataCallBackHandler?()
                }
                if list.count >= VideoModuleListApi.kDefaultCount {  // 表示可能还有数据
                   loadModulesDatasSuccessHandler?(true)                // 第一页请求成功，可能还有第二页数据
                } else {
                   loadModulesDatasSuccessHandler?(false)                // 第一页请求成功，没有第二页数据
                }
                isRefreshOperation = true
            } else {
                modulesList.append(contentsOf: list)
                modulesListModels.append(contentsOf: list)
                if list.count >= VideoModuleListApi.kDefaultCount {     // 表示可能还有数据
                    loadModulesDatasSuccessHandler?(true)
                } else {
                    // 隐藏加载更多View
                    loadModulesDatasSuccessHandler?(false)
                }
            }
        }
    }
    
    func requestModulesListFail() {
        if !isRefreshOperation  { // 不是刷新请求失败
            // 显示NodataView
            showNodataCallBackHandler?()
        }
        // 回调失败
        loadModulesDatasFailHandler?()
    }
    
    func changeSomeData(_ section: Int) {
        if modulesList.count > section {
            let modellist = self.modulesListModels
            var moduleModel = modellist[section]
            if moduleModel.client_limit == nil ||  moduleModel.client_limit == 0 { return }
            if moduleModel.currentPage  == nil {
                moduleModel.currentPage = 1
            }
            // 视频
            if moduleModel.client_module == Module_Type.video {
                // 非滚动列表
                if moduleModel.client_style == Module_Style.thridItems || moduleModel.client_style == Module_Style.doubleItems {
                    if let list = moduleModel.m_video_data, list.count > moduleModel.client_limit! {
                        let pageCount = list.count/moduleModel.client_limit! + (list.count%moduleModel.client_limit! > 0 ? 1 : 0)
                        if pageCount <= 1 { return }
                        if moduleModel.currentPage! < pageCount {
                            moduleModel.currentPage = moduleModel.currentPage! + 1
                        } else {
                              moduleModel.currentPage = 1
                        }
                        let startIndex = (moduleModel.currentPage! - 1) * moduleModel.client_limit!
                        var arr = [VideoModel]()
                        if pageCount == list.count/moduleModel.client_limit! { //能整除
                            let aa = list[startIndex ..< pageCount * moduleModel.client_limit!]
                            arr.append(contentsOf: aa)
                            moduleModel.m_video_data = arr
                        }
                        modulesList[section].m_video_data = moduleModel.m_video_data
                        modulesListModels[section].currentPage = moduleModel.currentPage!
                        changeMoreDataHandler?(section)
                    }
                }
            }
            
        }
    }
  
}

// MARK: - 处理tableView列表 Modules

extension VideoTypePageViewModel {
    
    /// 获取ItemsCount
    func getModuleRowCount(section: Int) -> Int {
        if modulesList.count > section { // 防止数组越界
            let model = modulesList[section]
            // 轮播图
            if model.client_module == Module_Type.banner {
                return 1
            }
            // 视频
            if model.client_module == Module_Type.video {
                if model.client_style == Module_Style.scrollItems_H || model.client_style == Module_Style.scrollItems_V { // 滚动列表
                    return 1
                }
                if model.client_style == Module_Style.thridItems || model.client_style == Module_Style.doubleItems {
                    let count = model.m_video_data?.count ?? 0
                    let limit = model.client_limit ?? 0
                    return count >= limit ? limit : count
                }
            }
            // 广告
            if model.client_module == Module_Type.advertise {
                return model.m_ad_data?.count ?? 0
            }
        }
        return 0
    }
    
    /// 获取模块类型
    func getModulesSectionType(section: Int) -> SectionType {
        if modulesList.count > section {
            let model = modulesList[section]
            // 轮播图
            if model.client_module == Module_Type.banner {
                return .adCarouse
            }
            // 视频
            if model.client_module == Module_Type.video {
                if model.client_style == Module_Style.scrollItems_H { // 横向滚动列表
                    return .scroll_H
                } else if model.client_style == Module_Style.thridItems {
                    return .thirdItems
                } else if model.client_style == Module_Style.doubleItems {
                    return .doubleItems
                } else if model.client_style == Module_Style.scrollItems_V {
                    return .scroll_V
                } else {
                    return .thirdItems
                }
            }
            // 广告
            if model.client_module == Module_Type.advertise {
                return .advertise
            }
        }
        return sectionType
    }
    
    /// 获取区头size
    func getModuleHeaderHeight(section: Int) -> CGSize {
        if modulesList.count > section { // 防止数组越界
            let model = modulesList[section]
            // 轮播图
            if model.client_module == Module_Type.banner {
                return CGSize.zero
            }
            // 视频
            if model.client_module == Module_Type.video {
               return CGSize(width: ConstValue.kScreenWdith, height: 50)
            }
            // 广告
            if model.client_module == Module_Type.advertise {
                return CGSize.zero
            }
        }
        return CGSize.zero
    }
    
    /// 获取区脚size
    func getModuleFooterHieght(section: Int) -> CGSize {
        if modulesList.count > section { // 防止数组越界
            let model = modulesList[section]
            // 轮播图
            if model.client_module == Module_Type.banner {
                return CGSize.zero
            }
            // 视频
            if model.client_module == Module_Type.video {
                if model.client_style == Module_Style.doubleItems || model.client_style == Module_Style.thridItems {
                    return CGSize(width: ConstValue.kScreenWdith, height: 50)
                } else {
                    return CGSize.zero
                }
            }
            // 广告
            if model.client_module == Module_Type.advertise {
                return CGSize.zero
            }
        }
        return CGSize.zero
    }
    
    /// 获取Item大小
    func getModuleItemSize(section: Int) -> CGSize? {
        let sectionType = getModulesSectionType(section: section)
        if sectionType == .thirdItems {
            return VideoTypePageViewModel.itemThridSize
        } else if sectionType == .scroll_V {
            return VideoTypePageViewModel.itemScroll_V_Size
        } else if sectionType == .scroll_H {
            return VideoTypePageViewModel.itemOverlapSize
        } else if sectionType == .adCarouse {
            return VideoTypePageViewModel.itemScrollSize
        } else if sectionType == .doubleItems {
            return VideoTypePageViewModel.itemDoubleSize
        } else if sectionType == .advertise {
            return VideoTypePageViewModel.itemAdvertiseSize
        }
        return CGSize.zero
    }
//    // 页面不同获取的title icon 不一样
//    func getTitleIconImage() -> UIImage? {
//      
//        if globalVideoType == .recomment {
//
//        }
//
//    }
    
    
}

// MARK: - 处理Cell上的数据展
extension VideoTypePageViewModel {
    
    /// 获取模块对象
    func getModuleModel(section: Int) ->VideoModulesModel {
        if modulesList.count > section { // 防止数组越界
            return modulesList[section]
        }
        return VideoModulesModel()
    }
    /// 获取轮播图图片地址
    func getBannerImageStrings(_ section: Int) -> [String]? {
        var bannerImages = [String]()
        if let banners = getModuleBannerModels(section: section), banners.count > 0 {
            for banner in banners {
                bannerImages.append(banner.cover_path ?? "")
            }
        }
        return bannerImages
    }
    /// 获取轮播图标题
    func getBannerTitles(_ section: Int) -> [String]? {
        var bannerTitles = [String]()
        if let banners = getModuleBannerModels(section: section), banners.count > 0 {
            for banner in banners {
                bannerTitles.append(banner.title ?? "")
            }
        }
        return bannerTitles
    }
    /// 获取baner列表 （轮播图调用）
    func getModuleBannerModels(section: Int) -> [AdCarousel]? {
        if modulesList.count > section { // 防止数组越界
            let model = modulesList[section]
            return model.m_banner_data
        }
        return nil
    }
    /// 获取baner Model （轮播图调用）
    func getModuleBannerModel(indexPath: IndexPath) -> AdCarousel? {
        if modulesList.count > indexPath.section {
            let moduleModel = modulesList[indexPath.section]
            if let bannerModelList = moduleModel.m_banner_data, bannerModelList.count > indexPath.row {
                return bannerModelList[indexPath.row]
            }
        }
        return nil
    }
    /// 获取视频对象（四宫格 和九宫格调用）
    func getModuleVideoModel(indexPath: IndexPath) -> VideoModel? {
        if modulesList.count > indexPath.section {
            let moduleModel = modulesList[indexPath.section]
            if let videoModelList = moduleModel.m_video_data, videoModelList.count > indexPath.row {
                return videoModelList[indexPath.row]
            }
        }
        return nil
    }
    /// 获取视频列表 （滚动视频  调用）
    func getModuleVideoScrollModel(section: Int) -> [VideoModel]? {
        if modulesList.count > section { // 防止数组越界
            let model = modulesList[section]
            return model.m_video_data
        }
        return nil
    }
    /// 获取广告对象（四宫格 和九宫格调用）
    func getModuleAdvertiseModel(indexPath: IndexPath) -> AdvertisingModel? {
        if modulesList.count > indexPath.section {
            let moduleModel = modulesList[indexPath.section]
            if let advertisList = moduleModel.m_ad_data, advertisList.count > indexPath.row {
                return advertisList[indexPath.row]
            }
        }
        return nil
    }
    /// 获取广告列表
    func getModuleAdvertiseList(_ section: Int) -> [AdvertisingModel]? {
        if modulesList.count > section { // 防止数组越界
            let model = modulesList[section]
            return model.m_ad_data
        }
        return nil
    }
 
}


// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension VideoTypePageViewModel: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
  
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is VideoModuleListApi {
            return [VideoMainListApi.kGlobal_type: globalType ?? ""]
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        if let videoModuleListModel = manager.fetchJSONData(VideoReformer()) as? VideoModulesListModel {
            requestModulesListSuccess(videoModuleListModel)
        }
    }

    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        if manager is VideoModuleListApi {
            requestModulesListFail()
        }
    }
}





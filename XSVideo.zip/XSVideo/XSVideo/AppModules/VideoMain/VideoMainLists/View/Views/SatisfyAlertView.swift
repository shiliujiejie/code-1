//
//  SatisfyAlertView.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/29.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 新手奖励提示
class SatisfyAlertView: UIView {
    
    static let xibId = "SatisfyAlertView"

    @IBOutlet weak var alertContainer: UIView!
    @IBOutlet weak var barImageView: UIImageView!
    @IBOutlet weak var okButton: UIButton!
    @IBOutlet weak var cancleButton: UIButton!
    @IBOutlet weak var titleLable: UILabel!
    @IBOutlet weak var infoMsgLable: UILabel!
    
    var okButtonClickHandler:(() ->Void)?
    var cancleButtonClickHandler:(() ->Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = UIColor(white: 0.1, alpha: 0.2)
        alertContainer.layer.cornerRadius = 10
        alertContainer.layer.masksToBounds = true
        okButton.setTitle(UIViewController.localStr("kConvertNow"), for: .normal)
        cancleButton.setTitle(UIViewController.localStr("kLetMeLookSomthing"), for: .normal)
        titleLable.text = UIViewController.localStr("kNewUserSatisfyTitle")
        infoMsgLable.text = UIViewController.localStr("kNewUserSatisfyInfoMsg")
    }
    
    @IBAction func okButtonClick(_ sender: Any) {
        okButtonClickHandler?()
    }
    
    @IBAction func cancleButtonClick(_ sender: UIButton) {
        cancleButtonClickHandler?()
    }
}

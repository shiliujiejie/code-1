//
//  DefualtReusableView.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/3.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// DefautReusableView  做collectionView 的区头
class DefautReusableView: UICollectionReusableView {
    
    static let identifier = "DefautReusableView"
    private var titleView: UIView = {
        let contentView = UIView()
        return contentView
    }()
    var titleLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.darkText
        lable.font = UIFont.boldSystemFont(ofSize: 16)
        return lable
    }()
    var titleImage: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    let moreButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "groupMore"), for: .normal)
        button.setTitle(UIViewController.localStr("kMore"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        button.setTitleColor(UIColor.darkText, for: .normal)
        button.imagePosition(at: .right, space: 25)
        button.addTarget(self, action: #selector(moreButtonClick), for: .touchUpInside)
        return button
    }()
    var hideMoreButton = false {
        didSet {
            if hideMoreButton {
                moreButton.isHidden = true
            } else {
                moreButton.isHidden = false
            }
        }
    }
    var hideTitleIcon = false {
        didSet {
            if hideTitleIcon {
                titleImage.snp.updateConstraints { (make) in
                    make.width.equalTo(0)
                }
                titleImage.isHidden = true
            } else {
                titleImage.snp.updateConstraints { (make) in
                    make.width.equalTo(25)
                }
                titleImage.isHidden = false
            }
        }
    }
   
    var moreClickHandler:(() -> Void)?
    
    override init(frame: CGRect) {
        super.init(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 50))
        initialize()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initialize()
    }
    
    private func initialize() {
        addSubview(titleView)
        titleView.addSubview(titleImage)
        titleView.addSubview(titleLable)
        titleView.addSubview(moreButton)
        layoutViews()
    }
    
    @objc private func moreButtonClick() {
        moreClickHandler?()
    }
    
   
}

// MARK: - layout
private extension DefautReusableView {
    
    func layoutViews() {
        layoutContentView()
        layoutTitleImage()
        layoutTitleLable()
        layoutMoreBtn()
    }
    func layoutContentView() {
        titleView.snp.makeConstraints {
            $0.edges.equalToSuperview()
        }
    }
    func layoutTitleImage() {
        titleImage.snp.makeConstraints {
            $0.top.equalTo(10)
            $0.bottom.equalToSuperview().offset(-10)
            $0.leading.equalTo(14)
            $0.width.equalTo(25)
        }
    }
    func layoutTitleLable() {
        titleLable.snp.makeConstraints {
            $0.top.equalTo(0)
            $0.bottom.equalToSuperview()
            $0.leading.equalTo(titleImage.snp.trailing).offset(10)
            $0.trailing.equalTo(60)
        }
    }
    func layoutMoreBtn() {
        moreButton.snp.makeConstraints { (make) in
            make.trailing.equalTo(-20)
            make.centerY.equalToSuperview()
            make.width.equalTo(50)
            make.height.equalTo(40)
        }
    }
}

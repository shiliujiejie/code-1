//
//  ModuleFooterReusableView.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/14.
//  Copyright © 2019年 pro5. All rights reserved.
//

import UIKit

class ModuleFooterReusableView: UICollectionReusableView {
    
    static let identifier = "ModuleFooterReusableView"

    let moreButton: UIButton = {
        let button = UIButton(type: .custom)
       // button.setImage(UIImage(named: "groupMore"), for: .normal)
        button.setTitle(UIViewController.localStr("kMore"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        button.setTitleColor(UIColor.darkGray, for: .normal)
        button.backgroundColor = UIColor.groupTableViewBackground
        button.layer.cornerRadius = 8
        button.layer.masksToBounds = true
       // button.imagePosition(at: .right, space: 25)
        button.addTarget(self, action: #selector(moreButtonClick), for: .touchUpInside)
        return button
    }()
    let changeButton: UIButton = {
        let button = UIButton(type: .custom)
       // button.setImage(UIImage(named: "groupMore"), for: .normal)
        button.setTitle(UIViewController.localStr("kChange"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        button.setTitleColor(UIColor.darkGray, for: .normal)
       // button.imagePosition(at: .right, space: 25)
        button.backgroundColor = UIColor.groupTableViewBackground
        button.layer.cornerRadius = 8
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(changeSomeButtonClick), for: .touchUpInside)
        return button
    }()
  
    var moreClickHandler:(() -> Void)?
    var changeClickHnadler:(() -> Void)?
    
    override init(frame: CGRect) {
        super.init(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 50))
        initialize()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initialize()
    }
    
    private func initialize() {
        addSubview(moreButton)
        addSubview(changeButton)
        layoutViews()
    }
    
    @objc private func moreButtonClick() {
        moreClickHandler?()
    }
    @objc private func changeSomeButtonClick() {
        changeClickHnadler?()
    }
    
    
}

// MARK: - layout
private extension ModuleFooterReusableView {
    
    func layoutViews() {
        layoutMoreBtn()
        layoutChangeButton()
    }
    
    func layoutMoreBtn() {
        moreButton.snp.makeConstraints { (make) in
            make.leading.equalTo(10)
            make.trailing.equalTo(self.snp.centerX).offset(-10)
            make.centerY.equalToSuperview()
            make.height.equalTo(40)
        }
    }
    
    func layoutChangeButton() {
        changeButton.snp.makeConstraints { (make) in
            make.trailing.equalTo(-10)
            make.centerY.equalToSuperview()
            make.leading.equalTo(moreButton.snp.trailing).offset(20)
            make.height.equalTo(40)
        }
    }
}

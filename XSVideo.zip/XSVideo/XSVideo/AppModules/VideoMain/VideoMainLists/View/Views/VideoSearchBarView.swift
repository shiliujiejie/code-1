//
//  VideoSearchBarView.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/3.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 搜索栏
class VideoSearchBarView: UIView {
    
    private let searchView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.groupTableViewBackground
        view.layer.cornerRadius = 16
        view.layer.masksToBounds = true
        return view
    }()
    let searchLable: UILabel = {
      let lable = UILabel()
        lable.textAlignment = .center
        lable.font = UIFont.systemFont(ofSize: 14)
        lable.textColor = UIColor.darkGray
        lable.text = UIViewController.localStr("kMainSearchPlaceholder")
        return lable
    }()
    private let searchIcon: UIImageView = {
        let image = UIImageView()
        image.contentMode = .scaleAspectFit
        image.image = UIImage(named: "searchIcon")
        image.isUserInteractionEnabled = true
        return image
    }()
    private lazy var searchButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitleColor(UIColor.darkText, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        button.addTarget(self, action: #selector(searchButtonClick), for: .touchUpInside)
        return button
    }()
    private lazy var historyWatchButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "mainHisWatch"), for: .normal)
        button.addTarget(self, action: #selector(historyButtonClick), for: .touchUpInside)
        return button
    }()
    private lazy var collectButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "ColleMainStar"), for: .normal)
        button.addTarget(self, action: #selector(collectedButtonClick), for: .touchUpInside)
        return button
    }()
    private let lineView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.groupTableViewBackground
        return view
    }()
    
    
    var itemButtonClickHandler:((_ index: Int) -> Void)?
    var searchButtonClickHandler:(() -> Void)?

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        searchView.addSubview(searchLable)
        searchView.addSubview(searchIcon)
        searchView.addSubview(searchButton)
        addSubview(searchView)
        addSubview(historyWatchButton)
        addSubview(collectButton)
        addSubview(lineView)
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    @objc func historyButtonClick() {
        itemButtonClickHandler?(0)
    }
    
    @objc func searchButtonClick() {
        searchButtonClickHandler?()
    }
    
    @objc func collectedButtonClick() {
        itemButtonClickHandler?(1)
    }
    
    
}

// MARK: - Layout
private extension VideoSearchBarView {
    
    func layoutPageSubviews() {
        layoutSearchView()
        layoutSearchIcon()
        layoutSearchLable()
        layoutSearchButton()
       
        layoutCollectButton()
        layoutHistroyButton()
        layoutLineView()
    }
    func layoutSearchView() {
        searchView.snp.makeConstraints { (make) in
            make.leading.equalTo(10)
            make.centerY.equalToSuperview()
            make.height.equalTo(32)
            make.trailing.equalTo(-120)
        }
    }
    func layoutSearchButton() {
        searchButton.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    func layoutSearchIcon() {
        searchIcon.snp.makeConstraints { (make) in
            make.trailing.equalTo(-25)
            make.centerY.equalToSuperview()
            make.width.height.equalTo(18)
        }
    }
    func layoutSearchLable() {
        searchLable.snp.makeConstraints { (make) in
            make.leading.top.bottom.equalToSuperview()
            make.trailing.equalTo(-50)
        }
    }
    func layoutHistroyButton() {
        historyWatchButton.snp.makeConstraints { (make) in
            make.trailing.equalTo(collectButton.snp.leading).offset(-10)
            make.centerY.equalToSuperview()
            make.width.height.equalTo(35)
        }
    }
    func layoutCollectButton() {
        collectButton.snp.makeConstraints { (make) in
            make.trailing.equalTo(-10)
            make.centerY.equalToSuperview()
            make.width.height.equalTo(38)
        }
    }
    func layoutLineView() {
        lineView.snp.makeConstraints { (make) in
            make.leading.trailing.bottom.equalToSuperview()
            make.height.equalTo(0.5)
        }
    }
    
    
}

//
//  ScrollVerItem_Cell.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/14.
//  Copyright © 2019年 pro5. All rights reserved.
//

import UIKit

/// 首页滑动，竖排的视屏  （带缩放）
class ScrollVerItem_Cell: UICollectionViewCell {
    
    static let cellId = "ScrollVerItem_Cell"
    
    var videoImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.layer.cornerRadius = 3
        imageView.contentMode = .scaleAspectFill
        imageView.layer.masksToBounds = true
        return imageView
    }()
    var videoNameLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 15)
        lable.textColor = UIColor.darkText
        lable.textAlignment = .left
        return lable
    }()
    var videoIntroLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 12)
        lable.textColor = UIColor.lightGray
        lable.textAlignment = .left
        return lable
    }()
    var pointLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.boldSystemFont(ofSize: 14)
        lable.textColor = ConstValue.kAppScoreTitleColor
        lable.textAlignment = .center
        return lable
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        addSubview(videoImageView)
        addSubview(videoNameLable)
        addSubview(pointLable)
        layoutPageSubviews()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}

private extension ScrollVerItem_Cell {
    
    func layoutPageSubviews() {
        layoutVideoImageView()
        layoutNameLable()
        layoutPointLable()
    }
    func layoutVideoImageView() {
        videoImageView.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ThirdStyleScrollCell.itemWidth * 7/5)
        }
    }
    func layoutNameLable() {
        videoNameLable.snp.makeConstraints { (make) in
            make.leading.equalTo(5)
            make.trailing.equalTo(-5)
            make.top.equalTo(videoImageView.snp.bottom).offset(5)
            make.height.equalTo(20)
        }
    }
    func layoutIntroLable() {
        videoIntroLable.snp.makeConstraints { (make) in
            make.leading.equalTo(5)
            make.trailing.equalTo(-5)
            make.top.equalTo(videoNameLable.snp.bottom).offset(5)
            make.height.equalTo(16)
        }
    }
    func layoutPointLable() {
        pointLable.snp.makeConstraints { (make) in
            make.trailing.equalTo(-8)
            make.bottom.equalTo(videoImageView.snp.bottom).offset(-5)
            make.height.equalTo(20)
            make.width.equalTo(30)
        }
    }
}

//
//  VideoDoubleCollectionCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/11/30.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 一排2个视频的 布局cell
class VideoDoubleCollectionCell: UICollectionViewCell {
    static let cellId = "VideoDoubleCollectionCell"

    @IBOutlet weak var VideoImage: UIImageView!
    @IBOutlet weak var VideoDes: UILabel!
    @IBOutlet weak var videoName: UILabel!
    @IBOutlet weak var pointLable: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        VideoImage.layer.cornerRadius = 3.0
        VideoImage.layer.masksToBounds = true
        contentView.backgroundColor = UIColor.white
        pointLable.textColor = ConstValue.kAppScoreTitleColor
    }

}

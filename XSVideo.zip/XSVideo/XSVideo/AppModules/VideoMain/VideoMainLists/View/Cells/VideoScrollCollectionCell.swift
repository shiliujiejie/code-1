//
//  VideoScrollCollectionCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/11/30.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 用于轮播的BannerCell
class VideoScrollCollectionCell: UICollectionViewCell {
    
    private lazy var scrollView: VideoListPagerView = {
        let headerView = VideoListPagerView(frame: CGRect(x: 0, y: 0, width: self.bounds.width, height: self.bounds.height), pagerStype: .bannerPage)
        // headerView.itemSizeScale = 0.8
        headerView.itemSize = CGSize(width: ConstValue.kScreenWdith - 10 , height: (ConstValue.kScreenWdith - 10)/2)
        headerView.isInfinite = true
        headerView.interitemSpacing = 5
        headerView.slidingIntervals = 4.0
        return headerView
    }()
    var scrollItemClickHandler:((_ index: Int) -> Void)?
    
    override init(frame: CGRect) {
        super.init(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: ConstValue.kScreenWdith/2))
        self.backgroundColor = UIColor.white
        contentView.addSubview(scrollView)
        layoutView()
        scrollView.itemClickHandler = { [weak self] (index) in
            self?.scrollItemClickHandler?(index)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func setImages(imageNames: [String]?) {
        if imageNames != nil && imageNames!.count > 0 {
            scrollView.imageNames = imageNames!
        }
    }
    
    func setTitles(titles: [String]!) {
        if titles != nil && titles!.count > 0 {
            scrollView.titleMsgs = titles!
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
    }
    
    override func layoutIfNeeded() {
        super.layoutIfNeeded()
    }
}

// MARK: - Layout
private extension VideoScrollCollectionCell {
    
    private func layoutView() {
        scrollView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
}


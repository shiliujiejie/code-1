//
//  Scroll_V_ItemCell.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/14.
//  Copyright © 2019年 pro5. All rights reserved.
//

import UIKit

/// 竖屏图片滚动的item Cell ，不带缩放（用于： 猜你喜欢， 历史播放记录）
class Scroll_V_ItemCell: UICollectionViewCell {
    
    static let cellId = "Scroll_V_ItemCell"
    
    var videoImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.layer.cornerRadius = 3
        imageView.contentMode = .scaleAspectFill
        imageView.layer.masksToBounds = true
        return imageView
    }()
    var videoNameLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 15)
        lable.textColor = UIColor.darkText
        lable.textAlignment = .left
        return lable
    }()
    var videoIntroLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 12)
        lable.textColor = UIColor.lightGray
        lable.textAlignment = .left
        return lable
    }()
    var pointLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.boldSystemFont(ofSize: 14)
        lable.textColor = ConstValue.kAppScoreTitleColor
        lable.textAlignment = .center
        return lable
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        addSubview(videoImageView)
        addSubview(videoNameLable)
        addSubview(videoIntroLable)
        addSubview(pointLable)
        layoutPageSubviews()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}

private extension Scroll_V_ItemCell {
    
    func layoutPageSubviews() {
        layoutVideoImageView()
        layoutNameLable()
        layoutIntroLable()
        layoutPointLable()
    }
    func layoutVideoImageView() {
        videoImageView.snp.makeConstraints { (make) in
            make.centerX.top.equalToSuperview()
            make.width.equalTo(180 * 5/7)
            make.height.equalTo(180)
        }
    }
    func layoutNameLable() {
        videoNameLable.snp.makeConstraints { (make) in
            make.leading.equalTo(5)
            make.trailing.equalTo(-5)
            make.top.equalTo(videoImageView.snp.bottom).offset(5)
            make.height.equalTo(20)
        }
    }
    func layoutIntroLable() {
        videoIntroLable.snp.makeConstraints { (make) in
            make.leading.equalTo(5)
            make.trailing.equalTo(-5)
            make.top.equalTo(videoNameLable.snp.bottom).offset(5)
            make.height.equalTo(16)
        }
    }
    func layoutPointLable() {
        pointLable.snp.makeConstraints { (make) in
            make.trailing.equalTo(-8)
            make.bottom.equalTo(videoImageView.snp.bottom).offset(-5)
            make.height.equalTo(20)
            make.width.equalTo(30)
        }
    }
}

//
//  DoubleStyleScrollCell.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/14.
//  Copyright © 2019年 pro5. All rights reserved.
//

import UIKit

/// 用于横屏图片的横向滚动，（不带缩放）
class DoubleStyleScrollCell: UICollectionViewCell {
    
    static let cellId = "DoubleStyleScrollCell"
    private let customLayout: CustomFlowSingleLayout = {
        let layout = CustomFlowSingleLayout()
        let width = ConstValue.kScreenWdith*2/3
        let height = ConstValue.kScreenWdith*3/8 + 55
        layout.itemSize = CGSize(width: width, height: height)
        return layout
    }()
    private lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: ConstValue.kScreenWdith*3/8 + 55), collectionViewLayout: customLayout)
        collection.backgroundColor = UIColor.white
        collection.showsHorizontalScrollIndicator = false
        collection.delegate = self
        collection.dataSource = self
        collection.register(UINib.init(nibName: "VideoDoubleCollectionCell", bundle: Bundle.main), forCellWithReuseIdentifier: VideoDoubleCollectionCell.cellId)
        return collection
    }()
    var dataModels: [VideoModel]?
    
    var itemClickHandler:((_ index: Int) -> Void)?
    
    
    override init(frame: CGRect) {
        super.init(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: ConstValue.kScreenWdith*3/8 + 55))
        self.backgroundColor = UIColor.white
        contentView.addSubview(collectionView)
        layoutCollection()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setModdels(_ models: [VideoModel]) {
        dataModels = models
        collectionView.reloadData()
    }
    
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension DoubleStyleScrollCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dataModels?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: VideoDoubleCollectionCell.cellId, for: indexPath) as! VideoDoubleCollectionCell
        if let model = dataModels?[indexPath.row] {
            cell.VideoImage.kfSetHorizontalImageWithUrl(model.cover_path)
            cell.videoName.text = model.title ?? ""
            if let introl = model.intro, !introl.isEmpty {
                cell.VideoDes.text = introl
            } else {
                cell.VideoDes.text = UIViewController.localStr("kNotIntrolMsg")
            }
            if model.score != nil &&  !model.score!.isEmpty {
                cell.pointLable.isHidden = false
                cell.pointLable.attributedText = TextSpaceManager.configScoreString(allString: String(format: "%@", model.score!))
            } else {
                cell.pointLable.isHidden = true
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        itemClickHandler?(indexPath.row)
    }
    
}

// MARK: - Layout
private extension DoubleStyleScrollCell {
    
    private func layoutCollection() {
        collectionView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(0)
            make.bottom.equalTo(-0)
        }
    }
    
}

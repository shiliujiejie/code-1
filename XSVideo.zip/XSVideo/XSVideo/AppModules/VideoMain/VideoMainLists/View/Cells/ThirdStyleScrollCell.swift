//
//  LibCollectionCell.swift
//  MVVMTest
//
//

import UIKit

/// 用于竖屏图片的横向滚动，（带缩放）
class ThirdStyleScrollCell: UICollectionViewCell {
    
    static let cellId = "ThirdStyleScrollCell"
    static let itemWidth = (ConstValue.kScreenWdith - 15)/2.7
    static let itemHieght = ThirdStyleScrollCell.itemWidth * 7/5 + 25
    
    private let customLayout: CustomFlowLayout = {
        let layout = CustomFlowLayout()
        layout.itemSize = CGSize(width: ThirdStyleScrollCell.itemWidth, height: ThirdStyleScrollCell.itemHieght)
        return layout
    }()
    private lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: ThirdStyleScrollCell.itemHieght + 40), collectionViewLayout: customLayout)
        collection.backgroundColor = UIColor.white
        collection.showsHorizontalScrollIndicator = false
        collection.delegate = self
        collection.dataSource = self
        collection.register(ScrollVerItem_Cell.classForCoder(), forCellWithReuseIdentifier: ScrollVerItem_Cell.cellId)
        return collection
    }()
    var dataModels: [VideoModel]?

    var itemClickHandler:((_ index: Int) -> Void)?
    
  
    override init(frame: CGRect) {
        super.init(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: ThirdStyleScrollCell.itemHieght + 40))
        self.backgroundColor = UIColor.white
        contentView.addSubview(collectionView)
        layoutCollection()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setModdels(_ models: [VideoModel]) {
        dataModels = models
        collectionView.reloadData()
    }
    
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension ThirdStyleScrollCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dataModels?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ScrollVerItem_Cell.cellId, for: indexPath) as! ScrollVerItem_Cell
        if let model = dataModels?[indexPath.row] {
            cell.videoImageView.kfSetVerticalImageWithUrl(model.cover_path)
            cell.videoNameLable.text = model.title ?? ""
            if model.score != nil &&  !model.score!.isEmpty {
                cell.pointLable.isHidden = false
                cell.pointLable.attributedText = TextSpaceManager.configScoreString(allString: String(format: "%@", model.score!))
            } else {
                cell.pointLable.isHidden = true
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        itemClickHandler?(indexPath.row)
    }
    
}

// MARK: - Layout
private extension ThirdStyleScrollCell {
    
    private func layoutCollection() {
        collectionView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(10)
            make.bottom.equalTo(-10)
        }
    }
    
}

//
//  VideoTypePageController.swift
//  XSVideo
//
//  Created by pro5 on 2018/11/29.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import SnapKit
import MJRefresh

/// 首页s推荐、电影、电视剧、综艺、动漫  分类VC
class VideoTypePageController: UIViewController {

    static let scrollCellId = "scrollCellId"
    static let footerViewId = "footViewId"
    /// item之间的最小间隙 (这些size应该放入ViewModel)
    static let interitemSpacing: CGFloat = 5
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        let collection = UICollectionView.init(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.backgroundColor = UIColor.white
        collection.showsVerticalScrollIndicator = false
        collection.mj_header = refreshView
        collection.mj_footer = loadMoreView
        collection.register(VideoThridItemCell.classForCoder(), forCellWithReuseIdentifier: VideoThridItemCell.cellId)
        collection.register(ThirdStyleScrollCell.classForCoder(), forCellWithReuseIdentifier: ThirdStyleScrollCell.cellId)
        collection.register(VideoScrollCollectionCell.classForCoder(), forCellWithReuseIdentifier: VideoTypePageController.scrollCellId)
        collection.register(UINib(nibName: "VideoDoubleCollectionCell", bundle: Bundle.main), forCellWithReuseIdentifier: VideoDoubleCollectionCell.cellId)
        collection.register(UINib(nibName: "AdvertisingCollectionCell", bundle: Bundle.main), forCellWithReuseIdentifier: AdvertisingCollectionCell.cellId)
        collection.register(DoubleStyleScrollCell.classForCoder(), forCellWithReuseIdentifier: DoubleStyleScrollCell.cellId)
        collection.register(DefautReusableView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: DefautReusableView.identifier)
        collection.register(ModuleFooterReusableView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: ModuleFooterReusableView.identifier)
        return collection
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        return MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
    }()
    lazy private var refreshView: MJRefreshGifHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshGifHeader(refreshingBlock: {
            weakSelf?.viewModel.isRefreshOperation = true
            weakSelf?.loadData()
        })
        var gifImages = [UIImage]()
        for string in ConstValue.refreshImageNames {
            gifImages.append(UIImage(named: string)!)
        }
        mjRefreshHeader?.setImages(gifImages, for: .refreshing)
        mjRefreshHeader?.setImages(gifImages, for: .idle)
        return mjRefreshHeader!
    }()
    /// 视频类型
    var globalType: String?
    /// ViewModel
    var viewModel: VideoTypePageViewModel = VideoTypePageViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        view.addSubview(collectionView)
        viewModel.globalType = self.globalType
        loadMoreView.isHidden = true
        layoutCollectionView()
        addViewModelCallBack()
        loadData()
    }
    // 数据请求
    func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        if !viewModel.isRefreshOperation {
            XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        } else {
            viewModel.isRefreshOperation = false
        }
        viewModel.loadData()
    }
    
    func loadNextPage() {
        viewModel.loadNextPage()
    }
    
    /// 添加请求回调
    func addViewModelCallBack() {
        viewModel.loadModulesDatasSuccessHandler = {[weak self] (moreData) in
            guard let strongSelf = self else { return }
            strongSelf.collectionView.mj_header.endRefreshing()
            strongSelf.collectionView.mj_footer.endRefreshing()
            if moreData {
                // 显示加载更多分页
                strongSelf.loadMoreView.isHidden = false
            } else {
                // 隐藏加载更多分页
                strongSelf.loadMoreView.isHidden = true
            }
            strongSelf.collectionView.mj_header.endRefreshing()
            NicooErrorView.removeErrorMeesageFrom(strongSelf.view)
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            strongSelf.collectionView.reloadData()    
        }
        viewModel.showNodataCallBackHandler = { [weak self] in
            guard let strongSelf = self else { return }
            NicooErrorView.showErrorMessage(.noNetwork, on: strongSelf.view, clickHandler: {
                strongSelf.loadData()
            })
        }
        viewModel.loadModulesDatasFailHandler = { [weak self] in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            strongSelf.collectionView.mj_header.endRefreshing()
            strongSelf.collectionView.mj_footer.endRefreshing()
            NicooErrorView.showErrorMessage(.noNetwork, on: strongSelf.view, clickHandler: {
                strongSelf.loadData()
            })
        }
        viewModel.changeMoreDataHandler = { [weak self] (section) in
            guard let strongSelf = self else { return }
            strongSelf.collectionView.reloadSections([section])
        }
    }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension VideoTypePageController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return viewModel.modulesList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.getModuleRowCount(section: section)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cellForRow(with: indexPath)
        return cell
    }
    
    /// 配置cell
    func cellForRow(with indexPath: IndexPath) -> UICollectionViewCell {
        let sectionType = viewModel.getModulesSectionType(section: indexPath.section)
        
        if sectionType == .thirdItems {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: VideoThridItemCell.cellId, for: indexPath) as! VideoThridItemCell
            if let videoModel = viewModel.getModuleVideoModel(indexPath: indexPath) {
                cell.videoNameLable.text = videoModel.title ?? ""
                cell.videoImageView.kfSetVerticalImageWithUrl(videoModel.cover_path)
                if let introl = videoModel.intro, !introl.isEmpty {
                    cell.videoIntroLable.text = introl
                } else {
                    cell.videoIntroLable.text = localStr("kNotIntrolMsg")
                }
                if videoModel.score != nil &&  !videoModel.score!.isEmpty {
                    cell.pointLable.isHidden = false
                    cell.pointLable.attributedText = TextSpaceManager.configScoreString(allString: String(format: "%@", videoModel.score!))
                } else {
                    cell.pointLable.isHidden = true
                }
                
            }
            return cell
        } else if sectionType == .doubleItems {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: VideoDoubleCollectionCell.cellId, for: indexPath) as! VideoDoubleCollectionCell
            if let videoModel = viewModel.getModuleVideoModel(indexPath: indexPath) {
                cell.videoName.text = videoModel.title ?? ""
                cell.VideoDes.text = videoModel.intro ?? localStr("kNotIntrolMsg")
                cell.VideoImage.kfSetHorizontalImageWithUrl(videoModel.cover_path)
                if videoModel.score != nil &&  !videoModel.score!.isEmpty {
                    cell.pointLable.isHidden = false
                    cell.pointLable.attributedText = TextSpaceManager.configScoreString(allString: String(format: "%@", videoModel.score!))
                } else {
                    cell.pointLable.isHidden = true
                }
            }
            return cell
        } else if sectionType == .scroll_V {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ThirdStyleScrollCell.cellId, for: indexPath) as! ThirdStyleScrollCell
            if let models = viewModel.getModuleVideoScrollModel(section: indexPath.section), models.count > 0 {
                 cell.setModdels(models)
                 cell.itemClickHandler = { [weak self] (index) in
                    let videoDetail = VideoDetailViewController()
                    videoDetail.videoId = models[index].id ?? 0
                    self?.navigationController?.pushViewController(videoDetail, animated: true)
                 }
            }
            return cell
        } else if sectionType == .scroll_H {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: DoubleStyleScrollCell.cellId, for: indexPath) as! DoubleStyleScrollCell
            if let models = viewModel.getModuleVideoScrollModel(section: indexPath.section), models.count > 0 {
                cell.setModdels(models)
                cell.itemClickHandler = { [weak self] (index) in
                    let videoDetail = VideoDetailViewController()
                    videoDetail.videoId = models[index].id ?? 0
                    self?.navigationController?.pushViewController(videoDetail, animated: true)
                }
            }
            return cell
        } else if sectionType == .advertise {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: AdvertisingCollectionCell.cellId, for: indexPath) as! AdvertisingCollectionCell
            if let adModel = viewModel.getModuleAdvertiseModel(indexPath: indexPath) {
                cell.advertisingImage.kfSetHorizontalImageWithUrl(adModel.cover_path)
                cell.advertisingNameLable.text = adModel.title ?? ""
                cell.advertisingDesLable.text = adModel.remark ?? ""
            }
            return cell
        } else if sectionType == .adCarouse {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: VideoTypePageController.scrollCellId, for: indexPath) as! VideoScrollCollectionCell
            cell.setImages(imageNames: viewModel.getBannerImageStrings(indexPath.section))
            cell.setTitles(titles: viewModel.getBannerTitles(indexPath.section))
            cell.scrollItemClickHandler = { [weak self] (index) in
                guard let strongSelf = self else { return }
                if let model = strongSelf.viewModel.getModuleBannerModel(indexPath: indexPath) {
                    if model.type == .kVideo { // 视频
                        let videoDetail = VideoDetailViewController()
                        videoDetail.videoId = model.video_id ?? 0
                        strongSelf.navigationController?.pushViewController(videoDetail, animated: true)
                    } else if model.type == .kLink { // 链接 ”LINK“
                        let adWebVc = AdvertWebController()
                        adWebVc.urlString = model.redirect_url
                        adWebVc.navTitle = model.title
                        strongSelf.navigationController?.pushViewController(adWebVc, animated: true)
                    }
                }
            }
            return cell
        }
        return UICollectionViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        let sectionType = viewModel.getModulesSectionType(section: indexPath.section)
        if sectionType == .thirdItems || sectionType == .doubleItems {
            if let model = viewModel.getModuleVideoModel(indexPath: indexPath) {
                let videoDetail = VideoDetailViewController()
                videoDetail.videoId = model.id ?? 0
                navigationController?.pushViewController(videoDetail, animated: true)
            }
        } else if sectionType == .advertise {
            if let model = viewModel.getModuleAdvertiseModel(indexPath: indexPath) {
                if model.type == .kVideo { // 视频
                    let videoDetail = VideoDetailViewController()
                    videoDetail.videoId = model.video_id ?? 0
                    navigationController?.pushViewController(videoDetail, animated: true)
                } else if model.type == .kLink { // 链接 ”LINK“
                    let adWebVc = AdvertWebController()
                    adWebVc.urlString = model.redirect_url
                    adWebVc.navTitle = model.title
                    adWebVc.ad_id = model.id ?? 0
                    adWebVc.navHidenCallBackHandler = { [weak self] (isAnimate) in
                        self?.parent?.isNavAnimated = isAnimate
                    }
                    navigationController?.pushViewController(adWebVc, animated: true)
                }
            }
        }
    }
    
}

// MARK: - UICollectionViewDelegateFlowLayout

extension VideoTypePageController: UICollectionViewDelegateFlowLayout {
    
    /// 所有的布局都要根据 ViewModel 获取到的数据来决定
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if let itemSize = viewModel.getModuleItemSize(section: indexPath.section) {
           return itemSize
        }
        return CGSize.zero
    }
    
    /// 边距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
        let sectionType = viewModel.getModulesSectionType(section: section)
        
        if sectionType == .thirdItems || sectionType == .doubleItems {
            return UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 5)
        }
        return UIEdgeInsets.zero
        
    }
    
    /// 垂直最小间距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        let sectionType = viewModel.getModulesSectionType(section: section)
        if sectionType == .thirdItems || sectionType == .doubleItems {
            return 15
        }
        return 0
    }
    
    /// 水平最小间距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        // 当然这里也是可以根据数据类型来判断
        return VideoTypePageController.interitemSpacing
    }
    
    /// sectionHeader高度
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return viewModel.getModuleHeaderHeight(section: section)
    }
    
    /// sectionFooter 高度
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        return viewModel.getModuleFooterHieght(section: section)
    }
    
    /// 区头 && 区脚 - View
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let sectionType = viewModel.getModulesSectionType(section: indexPath.section)
        /// 这里的赋值也应该放入ViewModel
        let model = viewModel.getModuleModel(section: indexPath.section)
        if kind == UICollectionView.elementKindSectionHeader { // header
            let view = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: DefautReusableView.identifier, for: indexPath) as! DefautReusableView
            view.backgroundColor = UIColor.white
            view.titleLable.text = model.title ?? ""
            view.titleImage.image = UIImage(named: "sudokuGroup")
            if sectionType == .doubleItems || sectionType == .thirdItems {
                view.hideMoreButton = true
            } else {
                view.hideMoreButton = false
            }
            view.moreClickHandler = { [weak self] in
                guard let strongSelf = self else { return }
                let singleModuleVC = SingleCategoryController()
                singleModuleVC.navTitle = model.title ?? ""
                singleModuleVC.isSpecialTopic = false
                singleModuleVC.parmas = [VideoModuleMoreApi.kModuleId: model.id ?? 0]
                singleModuleVC.navHidenCallBackHandler = { [weak self] (isAnimate) in
                    self?.parent?.isNavAnimated = isAnimate
                }
                strongSelf.navigationController?.pushViewController(singleModuleVC, animated: true)
            }
            return view
        } else { // footer
            let footer = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: ModuleFooterReusableView.identifier, for: indexPath) as! ModuleFooterReusableView
            footer.backgroundColor = UIColor.white
            footer.moreClickHandler = { [weak self] in
                guard let strongSelf = self else { return }
                let singleModuleVC = SingleCategoryController()
                singleModuleVC.navTitle = model.title ?? ""
                singleModuleVC.parmas = [VideoModuleMoreApi.kModuleId: model.id ?? 0]
                singleModuleVC.navHidenCallBackHandler = { [weak self] (isAnimate) in
                    self?.parent?.isNavAnimated = isAnimate
                }
                strongSelf.navigationController?.pushViewController(singleModuleVC, animated: true)
            }
            footer.changeClickHnadler = { [weak self] in
                self?.viewModel.changeSomeData(indexPath.section)
            }
            return footer
        }
    }
    
}

// MARK: - Layout
private extension VideoTypePageController {
    
    func layoutCollectionView() {
        let bottomMargin =  UIDevice.current.isiPhoneXSeriesDevices() ? 0 : -50
       // let bottomMargin =  (UIScreen.main.bounds.height >= 812.0) ? 0 : -50  // 测试这样写
        collectionView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalToSuperview().offset(VideoMainViewController.searchBarHeight)
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(bottomMargin)
            } else {
                make.bottom.equalTo(bottomMargin)
            }
        }
    }
}

//
//  VideoMainViewController.swift
//  XSVideo
//
//  Created by pro5 on 2018/11/26.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import SnapKit
import LTScrollView
import NicooNetwork

class VideoMainViewController: UIViewController {

    static let searchBarHeight: CGFloat = 45
    
    // MARK: - Private Var {
    private let glt_iphoneX = (UIScreen.main.bounds.height >= 812.0)
    private lazy var viewControllers: [UIViewController] = {
        var vcs = [UIViewController]()
        
        for i in 0..<self.titles.count {
            if let globalTypeModel = globalTypeList?[i] {
                let oneVc = VideoTypePageController()
                oneVc.globalType = globalTypeModel.key
                vcs.append(oneVc)
            }
        }
        return vcs
    }()
    private lazy var titles: [String] = {
        return [localStr("kRecomment"), localStr("kFilm"), localStr("kTVSerial"), localStr("kCatoon"), localStr("kVarietyShow")]
    }()
    /// 记录顶部选中的Index
    private var topIndex: Int = 0
    private lazy var layout: LTLayout = {
        let layout = LTLayout()
        layout.titleViewBgColor = UIColor.clear
        layout.titleColor = UIColor(r: 0.1, g: 0.1, b: 0.1)
        layout.titleSelectColor = ConstValue.kAppDefaultTitleColor
        layout.bottomLineColor = ConstValue.kAppDefaultTitleColor
        layout.showsHorizontalScrollIndicator = false
        layout.sliderHeight = 50
        layout.titleFont = UIFont.boldSystemFont(ofSize: 18)
        layout.isShowBounces = true
        layout.scale = 1.1
        layout.titleMargin = 25
        layout.lrMargin = 55
        return layout
    }()
    /// 顶部栏目切换控件
    private lazy var pageView: LTPageView = {
        let tabBarH = self.tabBarController?.tabBar.bounds.height ?? 0.0
        let Y: CGFloat = ConstValue.kStatusBarHeight //+ VideoMainViewController.searchBarHeight
        let H: CGFloat = glt_iphoneX ? (view.bounds.height - Y - tabBarH) : view.bounds.height - Y - tabBarH
        //let H: CGFloat = view.bounds.height - Y - tabBarH
        let pageView = LTPageView(frame: CGRect(x: 0, y: Y, width: view.bounds.width , height: H), currentViewController: self, viewControllers: viewControllers, titles: titles, layout: layout)
       // pageView.backgroundColor = UIColor.clear
        pageView.isClickScrollAnimation = true

        return pageView
    }()
    /// 搜索栏 控件
    private lazy var searchBarView: VideoSearchBarView = {
        let Y: CGFloat = ConstValue.kStatusBarHeight + 50
        let barView = VideoSearchBarView(frame: CGRect(x: 0, y: Y, width: ConstValue.kScreenWdith, height: VideoMainViewController.searchBarHeight))
        return barView
    }()
    private lazy var allCateButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "Allcate"), for: .normal)
        button.backgroundColor = UIColor.white
        button.addTarget(self, action: #selector(allCateButtonClick), for: .touchUpInside)
        button.isHidden = true
        return button
    }()
    private lazy var logolImage: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "mainLogoIcon"), for: .normal)
        button.backgroundColor = UIColor.white
        return button
    }()
    /// 登录挤掉线提示弹框
    private lazy var reloginAlter: VideoAlterView = {
        let alter = VideoAlterView(frame: view.bounds, itemButtonTitles: [localStr("kRelogin"), localStr("kCancle")], message: XSAlertMessages.kNotAvailTokenAlertMsg)
        return alter
    }()
    /// 最大分类请求
    private lazy var globalTypeAPI: GlobalTypeApi = {
        let api = GlobalTypeApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var updateAPI: AppUpdateApi = {
        let api = AppUpdateApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    /// 闪屏广告信息请求
    private lazy var adSplashApi: AdSplashInfoApi = {
        let adApi = AdSplashInfoApi()
        adApi.delegate = self
        adApi.paramSource = self
        return adApi
    }()
    private lazy var installApi: InstallApi = {
        let adApi = InstallApi()
        adApi.delegate = self
        adApi.paramSource = self
        return adApi
    }()
    private var globalTypeList: [GlobalType]?
    private let viewModel = RegisterLoginViewModel()
    private let userInfoViewModel = UserInfoViewModel()
    
    // MARK: -  Life cycle
    deinit {
        DLog("self --- relesse")
        NotificationCenter.default.removeObserver(self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        NotificationCenter.default.addObserver(self, selector: #selector(didUserBeenKickedOut), name: Notification.Name.kUserBeenKickedOutNotification, object: nil)
        loadUpdateInfo()
        loadData()
        // 设备号注册
        registerDevice()
        installApp()
        loadSplashAdInfo()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: isNavAnimated ? animated : false)
        isNavAnimated = false
        if !UserDefaults.standard.bool(forKey: UserDefaults.knewUserSatisfiedShow) {
            satisfyAlertShow()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
       // navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    /// 设备号注册
    private func registerDevice() {
        if let token = UserDefaults.standard.string(forKey: UserDefaults.kUserToken) {
            UserModel.share().api_token = token
            userInfoViewModel.loadUserInfo()
        } else {
            viewModel.registerDevice()
        }
    }
    /// 请求闪屏广告
    private func loadSplashAdInfo() {
        let _ = adSplashApi.loadData()
    }
    /// 告诉后台安装了
    private func installApp() {
        let _ = installApi.loadData()
    }
    
    // 掉线提醒
    @objc private func didUserBeenKickedOut() {
        DLog("didUserBeenKickedOut  ===== Main")
        LoginManager().logout(nil)
        showReloginAlter()
    }
    
    private func showReloginAlter() {
        reloginAlter.showInWindow()
        reloginAlter.itemButtonClick = { (index) in
            if index == 0 {
                 LoginManager().login(nil)
            }
        }
    }
    
    func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        let _ = globalTypeAPI.loadData()
    }
    
    /// 新手奖励提示框
    private func satisfyAlertShow() {
        guard let window = UIApplication.shared.keyWindow else { return }
        guard let satisfyAlert = Bundle.main.loadNibNamed("SatisfyAlertView", owner: nil, options: nil)?[0] as? SatisfyAlertView else { return }
        satisfyAlert.okButton.setTitle(UIViewController.localStr("kGoWatching"), for: .normal)
        satisfyAlert.cancleButton.setTitle(UIViewController.localStr("kLetMeLookSomthing"), for: .normal)
        satisfyAlert.titleLable.text = UIViewController.localStr("kNewUserSatisfyTitle")
        satisfyAlert.infoMsgLable.text = UIViewController.localStr("kNewUserSatisfyInfoMsg")
        satisfyAlert.frame = view.bounds
        window.addSubview(satisfyAlert)
        satisfyAlert.okButtonClickHandler = {
            UserDefaults.standard.set(true, forKey: UserDefaults.knewUserSatisfiedShow)
            satisfyAlert.removeFromSuperview()
        }
        satisfyAlert.cancleButtonClickHandler = {
            UserDefaults.standard.set(true, forKey: UserDefaults.knewUserSatisfiedShow)
            satisfyAlert.removeFromSuperview()
        }
    }
    
}

// MARK: - AppUpdateApi
private extension VideoMainViewController {
    
    func loadUpdateInfo() {
        let _ = updateAPI.loadData()
    }
    
    func loadUpdateInfoSuccess(_ model: AppVersionInfo) {
        guard let versionNew = model.version_code else { return }
        saveDownLoadUrlString(model.package_path)
        saveShareUrlString(model.share_url)
        guard let numVersionNew = versionNew.removeAllPoints() else { return }
        guard let numVersionCurrent = getCurrentAppVersion().removeAllPoints() else { return }
        if Int(numVersionNew) != nil && Int(numVersionCurrent) != nil && Int(numVersionNew)! > Int(numVersionCurrent)! {
            if model.force == ForceUpdate.forceUpdate {
                showDialog(title: model.title ?? "", message: model.remark ?? "", okTitle: localStr("kUpdateNow"), cancelTitle: nil, okHandler: { [weak self] in
                    self?.goAndUpdate(model.package_path)
                    }, cancelHandler: nil)
            } else {
                showDialog(title: model.title ?? "", message: model.remark ?? "", okTitle: localStr("kUpdateNow"), cancelTitle: localStr("kNotUpdateNow"), okHandler: { [weak self] in
                    self?.goAndUpdate(model.package_path)
                    }, cancelHandler: nil)
            }
        }
    }
    
    /// 保存下载地址
    func saveDownLoadUrlString(_ downloadUrl: String?) {
        if downloadUrl != nil && !downloadUrl!.isEmpty {
            UserDefaults.standard.set(downloadUrl!, forKey: UserDefaults.kAppDownLoadUrl)
        }
    }
    
    /// 保存分享地址
    func saveShareUrlString(_ shareUrl: String?) {
        if shareUrl != nil && !shareUrl!.isEmpty {
            UserDefaults.standard.set(shareUrl!, forKey: UserDefaults.kAppShareUrl)
        }
    }
    
    func getCurrentAppVersion() -> String {
        let filePath = Bundle.main.path(forResource: "Info", ofType: "plist")
        let dictionary = NSDictionary(contentsOfFile: filePath!)
        return dictionary!["CFBundleShortVersionString"] as! String
    }
    
    func goAndUpdate(_ downLoadUrl: String?) {
        if let urlstring = downLoadUrl {
            let downUrl = String(format: "%@", urlstring)
            if let url = URL(string: downUrl) {
                if UIApplication.shared.canOpenURL(url) {
                    UIApplication.shared.openURL(url)
                }
            }
        }
    }
}

// MARK: - Privite Funcs
private extension VideoMainViewController {
    
    func addSearchBarViewClickHandler() {
        searchBarView.itemButtonClickHandler = { [weak self]  (index) in
            let historyWatchVC = HistoryWatchListController()
            historyWatchVC.navHidenCallBackHandler = { [weak self] (isAnimate) in
                self?.isNavAnimated = isAnimate
            }
            if index == 0 {
                historyWatchVC.listType = .watchedList
                if UserModel.share().isLogin  {
                    self?.navigationController?.pushViewController(historyWatchVC, animated: true)
                    } else {
                    LoginManager().login { [weak self] in
                        self?.navigationController?.pushViewController(historyWatchVC, animated: true)
                    }
                }
            }else if index == 1 {
                historyWatchVC.listType = .collectedList
                if UserModel.share().isLogin && UserModel.share().isRealUser {
                    self?.navigationController?.pushViewController(historyWatchVC, animated: true)
                } else {
                    LoginManager().login { [weak self] in
                        self?.navigationController?.pushViewController(historyWatchVC, animated: true)
                    }
                }
            }
           
        }
        searchBarView.searchButtonClickHandler = { [weak self] in
            let searchVC = SearchController()
            let nav = XSNavigationController(rootViewController: searchVC)
            self?.present(nav, animated: true, completion: nil)
        }
    }
    
    @objc private func allCateButtonClick() {
        let videoCategoryVc = VideoCategoryController()
        videoCategoryVc.navHidenCallBackHandler = { [weak self] (isAnimate) in
            self?.isNavAnimated = isAnimate
        }
        if let typeModel = globalTypeList?[topIndex] {
            videoCategoryVc.typeKeyModel = typeModel
        }
        navigationController?.pushViewController(videoCategoryVc, animated: true)
    }
    
    func addTitlePageViewCallBack() {
        pageView.didSelectIndexBlock = { [weak self] (_, index) in
            DLog("pageView.didSelectIndexBlock ")
            self?.topIndex = index
            if let globleTypeModel = self?.globalTypeList?[index] {
                self?.allCateButton.isHidden = globleTypeModel.key == "recommend"
            }
        }
    }
    
    /// 请求失败
    func requestFail(error: String?, manager: NicooBaseAPIManager?) {
        let errorViewTopMargin: CGFloat = ConstValue.kStatusBarHeight + 50
        NicooErrorView.showErrorMessage(.noNetwork, on: view, topMargin: errorViewTopMargin) { [weak self] in
             self?.loadData()
        }
    }
    
    /// 请求成功
    func requestSuccess(_ typeList: [GlobalType]?) {
        NicooErrorView.removeErrorMeesageFrom(view)
        if typeList != nil && typeList!.count > 0 {
            globalTypeList = typeList
            var allTitles = [String]()
            for i in 0..<typeList!.count {
                let model = typeList![i]
                allTitles.append(model.name ?? "")
            }
            titles = allTitles
            view.addSubview(pageView)
            view.addSubview(allCateButton)
            view.addSubview(searchBarView)
            view.addSubview(logolImage)
            addSearchBarViewClickHandler()
            addTitlePageViewCallBack()
            layoutPageSubviews()
        }
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension VideoMainViewController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    /// 网络请求参数添加  （这里是追加动态参数， 固定参数可以直接在BooksHotListAPI中拼接）
    ///
    /// - Parameter manager: NicooBaseAPIManager
    /// - Returns: params: [String: Any]
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        if manager is AppUpdateApi {
            return [AppUpdateApi.kPlatform: AppUpdateApi.kDefaultPlatform]
        }
        if manager is InstallApi {
            return [InstallApi.kType: "I", InstallApi.kVersion_code: getCurrentAppVersion(), InstallApi.kAccept : InstallApi.kAcceptDefault]
        }
        return nil
    }
    
    /// 请求成功回调
    ///
    /// - Parameter manager: NicooBaseAPIManager
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is GlobalTypeApi {
            if let list = manager.fetchJSONData(GlobalTypeReformer()) as? [GlobalType] {
               requestSuccess(list)
            }
        }
        if manager is AppUpdateApi {
            if let versionInfo = manager.fetchJSONData(AppUpdateReformer()) as? AppVersionInfo {
                loadUpdateInfoSuccess(versionInfo)
            }
        }
        if manager is AdSplashInfoApi {
            if let adInfo = manager.fetchJSONData(AdSplashReformer()) as? AdSplashModel {
                guard let adPath = adInfo.ad_path else { return }
                if adPath.isEmpty { return }
                if let saveAdSplashUrl = UserDefaults.standard.string(forKey: UserDefaults.kAdDataUrl), saveAdSplashUrl == adPath {
                    return
                }
                if let url = URL(string: adPath) {
                    AdvertisementView.downLoadImageDataWith(url)
                }
            }
        }
    }
    
    /// 请求失败回调
    ///
    /// - Parameter manager: manager descriptionNicooBaseAPIManager
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is GlobalTypeApi {
            requestFail(error: manager.errorMessage, manager: manager)
        }
    }
}

// MARK: - Layout
private extension VideoMainViewController {
    
    func layoutPageSubviews () {
        layoutSearchBarView()
        layoutCateButton()
        layoutLogolImage()
    }
  
    func layoutSearchBarView() {
        searchBarView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(ConstValue.kStatusBarHeight + 50)
            make.height.equalTo(VideoMainViewController.searchBarHeight)
        }
    }
    
    func layoutCateButton() {
        allCateButton.snp.makeConstraints { (make) in
            make.trailing.equalTo(0)
            make.top.equalTo(pageView)
            make.width.equalTo(40)
            make.height.equalTo(50)
        }
    }
    
    func layoutLogolImage() {
        logolImage.snp.makeConstraints { (make) in
            make.leading.equalTo(8)
            make.centerY.equalTo(allCateButton)
            make.height.equalTo(35)
            make.width.equalTo(44)
        }
    }
    
}

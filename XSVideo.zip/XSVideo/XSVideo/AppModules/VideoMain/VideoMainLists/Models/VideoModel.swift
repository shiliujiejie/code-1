//
//  BookModel.swift
//  MVVMTest
//
//  Created by 小星星 on 2018/10/15.
//  Copyright © 2018年 yangxin. All rights reserved.
//

import Foundation

struct VideoListModel: Codable {
    var current_page: Int?
    var data: [VideoModel]?
}

/// 一行 3个 的视频Model
struct VideoModel: Codable {
    var id: Int?
    var title: String?
    var intro: String?
    var cover_path: String?
    var global_type: String?
    var play_count: Int?
    var play_count_real: Int?
    var exponent_bd: Int?
    var score: String?
    var epoch_id: String?
    var created_at: String?
    var label_status: Int? // 0 :正常 1: 热门 2：最新 3：推荐
    var director: String?
    var dist_label: String?
    var dist_id: Int?
    var author: [AuthorModel]?
    var video_resource: [VideoResource]?
    var type: [InfoTypeModel]?
    
}

/// 作者
struct AuthorModel: Codable {
    var id: Int?
    var video_id: Int?
    var global_type: String?
    var director: String?
    var actor: String?
    var actor_cover_path: String?
    var actor_id: Int?
    var actor_intro: String?
    var created_at: String?
    var actor_label: String?
}

/// 视频源Model
struct VideoResource: Codable {
    var id: Int?
    var video_id: Int?
    var global_type: String?
    var resource_id: Int?
    var play_series: String?
    var play_url_m3u8: String?
    var play_url_h5: String?
    var created_at: String?
}






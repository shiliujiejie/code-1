//
//  VideoTypeModel.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/12.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation

/// 首页头部最大分类类型model
struct GlobalType: Codable {
    var key: String?
    var name: String?
}


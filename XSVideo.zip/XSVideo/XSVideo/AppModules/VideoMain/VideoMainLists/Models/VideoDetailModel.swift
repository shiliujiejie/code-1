//
//  VideoDetailModel.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/13.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation

/// 是否点👍
enum Recommend: Int, Codable {
    case noThumUp = 0
    case thumUp = 1
    
    var isThumUp: Bool {
        switch self {
        case .thumUp:
            return true
        case .noThumUp:
            return false
        }
    }
}

/// 是否点👎
enum Negative: Int, Codable {
    case noNegative = 0
    case negative = 1
    
    var isNegative: Bool {
        switch self {
        case .negative:
            return true
        case .noNegative:
            return false
        }
    }
}

/// 是否收藏
enum Collected: Int, Codable {
    case noCollected = 0
    case collected = 1
    
    var isCollected: Bool {
        switch self {
        case .collected:
            return true
        case .noCollected:
            return false
        }
    }
}

/// 视频播放详情页面
struct VideoDetailModel: Codable {
    var id: Int?
    var title: String?
    var intro: String?
    var cover_path: String?
    var global_type: String?
    var play_count: Int?
    var play_count_real: Int?
    var exponent_bd: Int?
    var epoch_id: String?
    var created_at: String?
    var dist_label: String?
    var director: String?
    var label_status: Int? // 0 :正常 1: 热门 2：最新 3：推荐
    
    /// 是否收藏
    var user_collect: Collected?
    var user_negative: Negative?
    var user_recommend: Recommend?
    /// 评论
    var comment_sum: Int?
    /// 反点赞数
    var negative_sum: Int?
    /// 点赞数
    var recommend_sum: Int?
    var author: [AuthorModel]?
    var resource: [InfoResource]?
    var type: [InfoTypeModel]?
}

/// 视频源 Model
struct InfoResource: Codable {
    var id: Int?
    var title: String?
    var key: String?
    var sort: Int?
    var created_at: String?
    var video_list: [VideoResource]?
}

/// 视频详情，视频标签model
struct InfoTypeModel: Codable {
    var id: Int?
    var video_id: Int?
    var global_type: String?
    var type_id: Int?
    var type_label: String?
    var created_at: String?
}

//
//  VideoRecommentModel.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/13.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation

enum Module_Type: String, Codable {
    case banner = "m_banner"
    case video = "m_video"
    case advertise = "m_ad"
    case notType = ""
}

enum Module_Style: String, Codable {
    case thridItems = "s_video_sudoku_3"
    case doubleItems = "s_video_sudoku_2"
    case scrollItems_H = "s_video_gundong_heng"
    case scrollItems_V = "s_video_gundong_shu"
    case notStyle = ""
}

/// 视频首页模块 model
struct VideoModulesListModel: Codable {
    var current_page: Int?
    var data: [VideoModulesModel]?
}

/// 视频首页模块 model
struct VideoModulesModel: Codable {
    var id: Int?
    var global_type: String?
    var title: String?
    var module: String?
    var more_api: String?
    var more_params: String?
    var client_limit: Int?
    /// 判断是什么类型
    var client_module: Module_Type?
    /// 判断展示什么样式的UI
    var client_style: Module_Style?
    
    /// 轮播图 list
    var m_banner_data: [AdCarousel]?
    /// 视频 List
    var m_video_data: [VideoModel]?
    /// 广告list
    var m_ad_data: [AdvertisingModel]?
    
    /// 当前页
    var currentPage: Int? = 1
    
    ///Video page
    var video_PageData: [[VideoModel]]?
    
}

enum CarouselType: String, Codable {
    case kVideo = "VIDEO"
    case kLink = "LINK"
}

/// 轮播图Model
struct AdCarousel: Codable {
    var id: Int?
    var key: String?
    var global_type: String?
    var type: CarouselType?
    var title: String?
    var remark: String?
    var cover_path: String?
    var video_id: Int?
    var redirect_url: String?
    var created_at: String?
}



/*  已废弃 */
struct VideoRecommentModel: Codable {
    var ad_carousel: CarouselModel?
    var sudoku: SudokuModel?
    var rebo: ReboModel?
    var classics: ClassicsModel?
}

///轮播图列表
struct CarouselModel: Codable {
    var current_page: Int?
    var data: [AdCarousel]?
}

/// 九宫格视频列表
struct SudokuModel: Codable {
    var current_page: Int?
    var data: [VideoModel]?
}

/// 一排滑动的视屏列表
struct ReboModel: Codable {
    var current_page: Int?
    var data: [VideoModel]?
}

/// 九宫格视频列表 (经典推荐)
struct ClassicsModel: Codable {
    var current_page: Int?
    var data: [VideoModel]?
}



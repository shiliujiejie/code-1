//
//  VideoDetailViewModel.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/14.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// 视频详情ViewModel
class VideoDetailViewModel: NSObject {
    
    static let watchTaskTime: Int = 30
    
    private lazy var guessFavorApi: GuessFavorApi = {
        let api = GuessFavorApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var commentListApi: VideoCommentListApi = {
        let api = VideoCommentListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var commentAddApi: VideoCommentApi = {
        let api = VideoCommentApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var favorAddApi: UserFavorAddApi = {
        let api = UserFavorAddApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var favorCancleApi: UserFavorCancleApi = {
        let api = UserFavorCancleApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var thumbAddApi: UserThumAddApi = {
        let api = UserThumAddApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    /// 猜你喜欢回调
    var loadFavorDataSuccessHandler:(() -> Void)?
    var loadFavorDataFailHandler:((_ empty: Bool) -> Void)?
    /// 评论列表回调
    var loadCommentListDataSuccessHandler:(() -> Void)?
    var loadCommentListDataFailHandler:((_ empty: Bool) -> Void)?
    /// 用户添加评论回调
    var loadCommentApiSuccess:(() -> Void)?
    var loadCommentApiFail:(() -> Void)?
    /// 用户添加收藏回调
    var loadFavorAddApiSuccessHandler:(() -> Void)?
    var loadFavorAddApiFailHandler:((_ msg: String?) -> Void)?
    /// 用户取消收藏回调
    var loadFavorCancleApiSuccessHandler:(() -> Void)?
    var loadFavorCancleApiFailHandler:((_ msg: String?) -> Void)?
    /// 用户点👍或者点👎回调
    var loadUserThumApiSuccessHandler:((_ isThumUp: Bool) -> Void)?
    var loadUserThumApiFailHandler:((_ msg: String?) -> Void)?
    
    var videoId: Int? = 0
    var globalTypeString: String?
    var contentString: String?
    var thumString: String?
    var isThumUp: Int = 0
    var isThumDown: Int = 0
    /// 播放时间记录
    var playRecordTime: Float = 0.0
    
    var guessFavorModel: VideoListModel?
    var commentListModel: VideoCommentListModel?
    var thumResultModel: VideoThumResultModel?
    
    /// 获取猜你喜欢列表
    func loadGuessFavorApiData() {
        let _ = guessFavorApi.loadData()
    }
    // 获取评论列表
    func loadCommentListData() {
        let _ = commentListApi.loadData()
    }
    
    /// 用户对视频添加评论
    func loadCommentApiData(content: String, globalType: String) {
        contentString = content
        globalTypeString = globalType
        let _ = commentAddApi.loadData()
    }
    
    /// 视频添加收藏
    func loadFavorAddApiData(globalType: String) {
        globalTypeString = globalType
        let _ = favorAddApi.loadData()
    }
    
    /// 视频取消收藏
    func loadFavorCancleApiData() {
        let _ = favorCancleApi.loadData()
    }
    
    /// 用户点赞
    func loadUserThumAddApiData(_ thumString: String, statu: Int) {
        self.thumString = thumString
        isThumUp = statu
        let _ = thumbAddApi.loadData()
    }
  
    
}

// MARK: - 取猜你喜欢数据
extension VideoDetailViewModel {
    
    func loadFavorListDataSuccess(_ videoList: VideoListModel) {
        guessFavorModel = videoList
        if let list = videoList.data, list.count > 0 {
            loadFavorDataSuccessHandler?()
        } else {
            loadFavorDataFailHandler?(true)
        }
    }
    
    func getVideoModelList() -> [VideoModel]? {
        if let videlModelList = guessFavorModel?.data, videlModelList.count > 0 {
            return videlModelList
        }
        return nil
    }
    func getVideoModel(_ index: Int) -> VideoModel? {
        if let videlModelList = guessFavorModel?.data, videlModelList.count > index {
            return videlModelList[index]
        }
        return nil
    }
}

// MARK: - 取视频评论数据
extension VideoDetailViewModel {
    
    func loadVideoCommentListDataSuccess(_ videoCommentList: VideoCommentListModel) {
        commentListModel = videoCommentList
        if let list = videoCommentList.data, list.count > 0 {
            loadCommentListDataSuccessHandler?()
        } else {
            loadCommentListDataFailHandler?(true)
        }
    }
    
    func getCommentModelList() -> [VideoCommentModel]? {
        if let videoCommentLs = commentListModel?.data, videoCommentLs.count > 0 {
            return videoCommentLs
        }
        return nil
    }
    
    func getCommentModel(_ index: Int) -> VideoCommentModel? {
        if let videoCommentLs = commentListModel?.data, videoCommentLs.count > 0 {
            return videoCommentLs[index]
        }
        return nil
    }
}

// MARK: - 点赞点loW
extension VideoDetailViewModel {
    
    func loadThumDataSuccess(_ model: VideoThumResultModel) {
        thumResultModel = model
        loadUserThumApiSuccessHandler?(thumString == UserThumAddApi.kRecommend)
    }
    
    func getThumResultModel() -> VideoThumResultModel {
        if let model = thumResultModel {
            return model
        }
        return VideoThumResultModel()
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension VideoDetailViewModel: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        var params = [String: Any]()
        if manager is GuessFavorApi {
           params[GuessFavorApi.kVideo_id] = videoId
        }
        if manager is VideoCommentListApi {
             params[VideoCommentListApi.kVideo_Id] = videoId
        }
        if manager is VideoCommentApi {
            params[VideoCommentApi.kGlobal_type] = globalTypeString
            params[VideoCommentApi.kContent] = contentString
            params[VideoCommentApi.kVideo_Id] = videoId
        }
        if manager is UserFavorAddApi {
            params[UserFavorAddApi.kGlobal_type] = globalTypeString
            params[UserFavorAddApi.kVideo_id] = videoId
        }
        if manager is UserFavorCancleApi {
            params[UserFavorCancleApi.kVideo_ids] = [videoId]
        }
        if manager is UserThumAddApi {
            params[UserThumAddApi.kVideo_id] = videoId
            params[UserThumAddApi.kAction] = thumString
            params[UserThumAddApi.kStatus] = isThumUp
        }
        return params
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        if manager is GuessFavorApi {
            if let listModel = manager.fetchJSONData(VideoReformer()) as? VideoListModel {
                loadFavorListDataSuccess(listModel)
            }
        }
        if manager is VideoCommentListApi {
            if let commitList = manager.fetchJSONData(VideoReformer()) as? VideoCommentListModel {
                loadVideoCommentListDataSuccess(commitList)
            }
        }
        if manager is VideoCommentApi {
            loadCommentApiSuccess?()
        }
        if manager is UserFavorAddApi {
            loadFavorAddApiSuccessHandler?()
        }
        if manager is UserFavorCancleApi {
            loadFavorCancleApiSuccessHandler?()
        }
        if manager is UserThumAddApi {
            if let thumData = manager.fetchJSONData(VideoReformer()) as? VideoThumResultModel {
                loadThumDataSuccess(thumData)
            }
           // loadUserThumApiSuccessHandler?(thumString == UserThumAddApi.kRecommend)
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        if manager is GuessFavorApi {
            loadFavorDataFailHandler?(false)
        }
        if manager is VideoCommentListApi {
            loadCommentListDataFailHandler?(false)
        }
        if manager is VideoCommentApi {
            loadCommentApiFail?()
        }
        if manager is UserFavorAddApi {
            loadFavorAddApiFailHandler?(manager.errorMessage)
        }
        if manager is UserFavorCancleApi {
            loadFavorCancleApiFailHandler?(manager.errorMessage)
        }
        if manager is UserThumAddApi {
            loadUserThumApiFailHandler?(manager.errorMessage)
        }
    }
}


extension VideoDetailViewModel {
    
    /// 获取当日时间，并转换为字符串
    ///
    /// - Returns: 时间字符串 "yyyy-MM-dd" 格式
    func getCurrentDay()-> String {
        let now = Date()
        let dataFormater = DateFormatter()
        dataFormater.dateFormat = "yyyy-MM-dd"
        let nowDay = dataFormater.string(from: now)
        return nowDay
    }
    
    func getStartTime() -> String {
        let now = Date()
        let timeInterval = now.timeIntervalSince1970
        let timeStamp = Int64(timeInterval)
        DLog("当前时间的时间戳：\(timeStamp)")
        let dataFormater = DateFormatter()
        dataFormater.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let nowTime = dataFormater.string(from: now)
        return nowTime
    }
    
    /// 获取单次观影时间长度 单位： 分钟
    ///
    /// - Parameters:
    ///   - statTime: 开始时间
    ///   - endTime: 结束时间
    /// - Returns: 时间差 （分钟）
    func getWatchVideoTime(statTime: Date, endTime: Date) ->Int {
        let gregorian = Calendar.init(identifier: .gregorian)
        let utils: Set = [Calendar.Component.day, Calendar.Component.hour, Calendar.Component.minute]
        let reslut = gregorian.dateComponents(utils, from: statTime, to: endTime)
        DLog("reslut ===== \(reslut.day, reslut.hour,reslut.minute)")
        guard let dayCount = reslut.day, let hourCount = reslut.hour, let minute = reslut.minute else { return 0 }
        if dayCount < 0 || hourCount < 0 || minute < 0 { return 0 }
        return dayCount * 1440 + hourCount * 60 + minute
    }
}

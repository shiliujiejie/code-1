//
//  VideoCommentView.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/15.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 视频详情底部的评论弹框
class VideoCommentView: UIView {

    lazy var textInputView: UITextField = {
        let textView = UITextField()
        textView.borderStyle = .roundedRect
        textView.placeholder = UIViewController.localStr("kLetMeCommentPlaceHolder")
        textView.font = UIFont.systemFont(ofSize: 15)
        textView.leftView = UIImageView(image: UIImage(named: "FavorNomal"))
        textView.delegate = self
        textView.inputAccessoryView = commentInputView
        return textView
    }()
    lazy var commentInputView: CommentInputView = {
        let view = CommentInputView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 80))
        return view
    }()
    
    private lazy var shareItems:  UIView = {
        let view = UIView()
        return view
    }()
    private lazy var favorItems: UIView = {
        let view = UIView()
        return view
    }()
    private lazy var downloadItems: UIView = {
        let view = UIView()
        return view
    }()
    private lazy var shareLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 9)
        lable.textAlignment = .center
        lable.textColor = UIColor.darkGray
        lable.text = UIViewController.localStr("kShareTitle")
        return lable
    }()
    lazy var favorLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 9)
        lable.textAlignment = .center
        lable.textColor = UIColor.darkGray
        lable.text = UIViewController.localStr("kCollectedTitle")
        return lable
    }()
    lazy var downLoadLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 9)
        lable.textAlignment = .center
        lable.textColor = UIColor.darkGray
        lable.text = UIViewController.localStr("kDownloadedTitle")
        return lable
    }()
    private lazy var shareButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "commentShare"), for: .normal)
        button.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return button
    }()
    lazy var favorButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "vdetailCollect"), for: .normal)
        button.setImage(UIImage(named: "collectedhAVE"), for: .selected)
        button.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return button
    }()
    lazy var downloadButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "download"), for: .normal)
       // button.setImage(UIImage(named: "collectedhAVE"), for: .selected)
        button.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return button
    }()
    var sendCommentTextHandler:((_ commentText: String) -> Void)?
    var favorButtonClickHandler:(() -> Void)?
    var shareButtonClickHandler:(() -> Void)?
    var downloadButtonClickHandler:(() -> Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.white
        shareItems.addSubview(shareButton)
        shareItems.addSubview(shareLable)
        favorItems.addSubview(favorButton)
        favorItems.addSubview(favorLable)
        downloadItems.addSubview(downloadButton)
        downloadItems.addSubview(downLoadLable)
        addSubview(textInputView)
        addSubview(favorItems)
        addSubview(shareItems)
        addSubview(downloadItems)
        layoutPageSubviews()
        addCommentInputViewCallBackHandler()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func addCommentInputViewCallBackHandler() {
        commentInputView.keyBoardDownHandler = { [weak self] (text) in
            self?.textInputView.resignFirstResponder()
            self?.textInputView.text = text
            
        }
        commentInputView.sendButtonHandler = { [weak self]  (text) in
            self?.textInputView.resignFirstResponder()
            if text != nil && !text!.isEmpty {
                self?.sendCommentTextHandler?(text!)
            }
            self?.textInputView.text = nil
        }
    }
    
    @objc private func buttonClick(_ sender: UIButton) {
        if sender == self.favorButton {
            favorButtonClickHandler?()
        }
        if sender == self.shareButton {
            shareButtonClickHandler?()
        }
        if sender == self.downloadButton {
            downloadButtonClickHandler?()
        }
    }
    
}

// MARK: - UITextFieldDelegate
extension VideoCommentView: UITextFieldDelegate {
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        commentInputView.textInputView.becomeFirstResponder()
        return true
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
    }
}

// MARK: - Layout
private extension VideoCommentView {
    
    func layoutPageSubviews() {
        layoutDownloadItems()
        layoutFavorItems()
        layoutShareItems()
        layoutDownloadButton()
        layoutDownloadLable()
        layoutShareButton()
        layoutShareLable()
        layoutFavorButton()
        layoutFavorLable()
        
        layoutTextView()
    }
    
    func layoutTextView() {
        textInputView.snp.makeConstraints { (make) in
            make.leading.equalTo(10)
            make.top.equalTo(8)
            make.bottom.equalTo(-8)
            make.trailing.equalTo(shareItems.snp.leading).offset(-10)
        }
    }
    func layoutShareItems () {
        shareItems.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview()
            make.top.equalTo(5)
            make.trailing.equalTo(favorItems.snp.leading).offset(-5)
            make.width.equalTo(40)
        }
    }
    func layoutFavorItems () {
        favorItems.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview()
            make.top.equalTo(5)
            make.trailing.equalTo(downloadItems.snp.leading).offset(-5)
            make.width.equalTo(40)
        }
    }
    func layoutDownloadItems () {
        downloadItems.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview()
            make.top.equalTo(5)
            make.trailing.equalToSuperview().offset(-10)
            make.width.equalTo(40)
        }
    }
    
    func layoutFavorButton() {
        favorButton.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.trailing.equalTo(-5)
            make.leading.equalTo(5)
            make.height.equalTo(30)
        }
    }
    func layoutShareButton() {
        shareButton.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.trailing.equalTo(-5)
            make.leading.equalTo(5)
            make.height.equalTo(30)
        }
    }
    func layoutShareLable() {
        shareLable.snp.makeConstraints { (make) in
            make.top.equalTo(shareButton.snp.bottom)
            make.trailing.leading.equalTo(0)
            make.bottom.equalTo(-5)
        }
    }
    func layoutFavorLable() {
        favorLable.snp.makeConstraints { (make) in
            make.top.equalTo(shareButton.snp.bottom)
            make.trailing.leading.equalTo(0)
            make.bottom.equalTo(-5)
        }
    }
    func layoutDownloadButton() {
        downloadButton.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.trailing.equalTo(-5)
            make.leading.equalTo(5)
            make.height.equalTo(30)
        }
    }
    func layoutDownloadLable() {
        downLoadLable.snp.makeConstraints { (make) in
            make.top.equalTo(downloadButton.snp.bottom)
            make.trailing.leading.equalTo(0)
            make.bottom.equalTo(-5)
        }
    }
    
}

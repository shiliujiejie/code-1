//
//  VideoDetailSectionHeaderView.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/7.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 视频详情 - 区头View
class VideoDetailSectionHeaderView: UIView {
    
    private let moreButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "groupMore"), for: .normal)
        return button
    }()
    
    private lazy var fakeMoreButton: UIButton = {
        let button = UIButton(type: .custom)
        button.addTarget(self, action: #selector(moreButtonClick), for: .touchUpInside)
        return button
    }()
    let moreInfoLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.darkGray
        lable.textAlignment = .right
        lable.font = UIFont.systemFont(ofSize: 12)
        return lable
    }()
    let titleLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.darkText
        lable.font = UIFont.boldSystemFont(ofSize: 16)
        return lable
    }()
    
    var moreButtonHiden: Bool = false {
        didSet {
            moreInfoLable.isHidden = moreButtonHiden
            moreButton.isHidden = moreButtonHiden
            fakeMoreButton.isHidden = moreButtonHiden
        }
    }
    
    var moreButtonClickHandler:(() -> Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(titleLable)
        addSubview(moreButton)
        addSubview(moreInfoLable)
        addSubview(fakeMoreButton)
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func moreButtonClick() {
        moreButtonClickHandler?()
    }
    
}

// MARK: - Layout
private extension VideoDetailSectionHeaderView {
    func layoutPageSubviews() {
        layoutTitleLable()
        layoutMoreButton()
        layoutMoreLable()
        layoutFakeMoreButton()
    }
    
    func layoutTitleLable() {
        titleLable.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.leading.equalTo(10)
        }
    }
    
    func layoutMoreButton() {
        moreButton.snp.makeConstraints { (make) in
            make.trailing.equalTo(-10)
            make.centerY.equalToSuperview()
            make.width.equalTo(20)
            make.height.equalTo(25)
        }
    }
    
    func layoutMoreLable() {
        moreInfoLable.snp.makeConstraints { (make) in
            make.trailing.equalTo(moreButton.snp.leading).offset(-10)
            make.centerY.equalToSuperview()
        }
    }
    
    func layoutFakeMoreButton() {
        fakeMoreButton.snp.makeConstraints { (make) in
            make.trailing.equalTo(moreButton.snp.trailing)
            make.top.bottom.equalToSuperview()
            make.width.equalTo(120)
        }
    }
}

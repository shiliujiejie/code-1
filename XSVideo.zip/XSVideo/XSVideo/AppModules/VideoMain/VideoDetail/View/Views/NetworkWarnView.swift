//
//  NetworkWarnView.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/24.
//  Copyright © 2019年 pro5. All rights reserved.
//

import UIKit

/// 网络提示
class NetworkWarnView: UIView {
    let msgLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 15)
        lable.textAlignment = .center
        lable.textColor = UIColor.white
        lable.numberOfLines = 2
        lable.text = "当前为非wifi网络，是否继续播放？"
        return lable
    }()
    private lazy var keepPlayingButton: UIButton = {
        let button = UIButton(type: .custom)
        button.backgroundColor = UIColor.red
        button.layer.cornerRadius = 20
        button.layer.masksToBounds = true
        button.setTitle("继续播放", for: .normal)
        button.addTarget(self, action: #selector(keepPlaying), for: .touchUpInside)
        return button
    }()
    var keepPlayingCallBackHandler:(() -> Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor(white: 0, alpha: 0.9)
        addSubview(msgLable)
        addSubview(keepPlayingButton)
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func keepPlaying() {
        keepPlayingCallBackHandler?()
    }

}

// MARK: - Layout
private extension NetworkWarnView {
    
    func layoutPageSubviews() {
        layoutMsgLable()
        layoutKeepPlayingButton()
    }
    
    func layoutMsgLable() {
        msgLable.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.height.equalTo(60)
            make.bottom.equalTo(self.snp.centerY)
        }
    }
    
    func layoutKeepPlayingButton() {
        keepPlayingButton.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.width.equalTo(130)
            make.height.equalTo(40)
            make.top.equalTo(self.snp.centerY).offset(15)
        }
    }
}

//
//  VideoInfoMsgCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/7.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 视频详情页  视频信息栏 cell
class VideoInfoMsgCell: UITableViewCell {

    @IBOutlet weak var hotImageView: UIImageView!
    @IBOutlet weak var videoNameLable: UILabel!
    @IBOutlet weak var introduceButton: UIButton!
    @IBOutlet weak var hotMsgLable: UILabel!
    @IBOutlet weak var fromLable: UILabel!
    @IBOutlet weak var fadeBackButton: UIButton!
    @IBOutlet weak var shareButton: UIButton!
    
    @IBOutlet weak var shareLable: UILabel!
    @IBOutlet weak var fadeBackLable: UILabel!
    @IBOutlet weak var hotCommentBtn: UIButton!
    @IBOutlet weak var thumUpBtn: UIButton!
    @IBOutlet weak var thumDownBtn: UIButton!
    var hotImageHiden = true {
        didSet {
            hotImageView.isHidden = hotImageHiden
            if hotImageHiden {
                hotImageView.snp.updateConstraints { (make) in
                    make.width.equalTo(0)
                }
            } else {
                hotImageView.snp.updateConstraints { (make) in
                    make.width.equalTo(20)
                }
            }
        }
    }
    
    var introduceBtnClickHandler:(() -> Void)?
    var thumUpBtnClickHandler:((_ isThumUp: Bool) -> Void)?
    var thumDownBtnClickHandler:((_ isThumUp: Bool) -> Void)?
    var fadeOrShareButtonClickHandler:((_ index:Int) -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        introduceButton.imagePosition(at: .right, space: 10)
        fadeBackLable.text = UIViewController.localStr("kFadeBackTitle")
        shareLable.text = UIViewController.localStr("kShareTitle")
        introduceButton.setTitle(UIViewController.localStr("kIntrol"), for: .normal)
    }

    @IBAction func fadeBackBtnClick(_ sender: Any) {
        fadeOrShareButtonClickHandler?(1)
    }
    
    @IBAction func shareBtnClick(_ sender: Any) {
        fadeOrShareButtonClickHandler?(2)
    }
    
    @IBAction func introduceBtnClick(_ sender: Any) {
        introduceBtnClickHandler?()
    }

    @IBAction func thumUpBtnClick(_ sender: UIButton) {
        thumUpBtnClickHandler?(sender.isSelected)
    }
    
    @IBAction func thumDownBtnClick(_ sender: UIButton) {
        thumDownBtnClickHandler?(sender.isSelected)
    }
}

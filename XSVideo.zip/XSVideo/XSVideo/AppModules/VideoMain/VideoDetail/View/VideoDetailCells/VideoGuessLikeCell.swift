//
//  VideoGuessLikeCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/7.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class VideoGuessLikeCell: UITableViewCell {

    static let cellId = "VideoGuessLikeCell"
    
    private let customLayout: CustomFlowSingleLayout = {
        let layout = CustomFlowSingleLayout()
        layout.itemSize = CGSize(width: 180 * 5/7, height: 210)
        return layout
    }()
    private lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 210), collectionViewLayout: customLayout)
        collection.backgroundColor = UIColor.white
        collection.showsHorizontalScrollIndicator = false
        collection.delegate = self
        collection.dataSource = self
        collection.register(Scroll_V_ItemCell.classForCoder(), forCellWithReuseIdentifier: Scroll_V_ItemCell.cellId)
        return collection
    }()
    var videoList: [VideoModel]?
    var itemClickHandler:((_ index: Int) -> Void)?
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.backgroundColor = UIColor.white
        contentView.addSubview(collectionView)
        layoutCollection()
        customLayout.minimumLineSpacing = 5
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setModels(_ videoList: [VideoModel]?) {
        self.videoList = videoList
        collectionView.reloadData()
    }
    
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension VideoGuessLikeCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return videoList?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: Scroll_V_ItemCell.cellId, for: indexPath) as! Scroll_V_ItemCell
        if let videoModel = videoList?[indexPath.row] {
            cell.videoImageView.kfSetVerticalImageWithUrl(videoModel.cover_path)
            cell.videoNameLable.text = videoModel.title ?? ""
            if videoModel.score != nil &&  !videoModel.score!.isEmpty {
                cell.pointLable.isHidden = false
                cell.pointLable.attributedText = TextSpaceManager.configScoreString(allString: String(format: "%@", videoModel.score!))
            } else {
                cell.pointLable.isHidden = true
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        itemClickHandler?(indexPath.row)
    }
    
}

// MARK: - Layout
private extension VideoGuessLikeCell {
    
    private func layoutCollection() {
        collectionView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
}

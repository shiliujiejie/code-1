//
//  CollectChoseCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/7.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit



/// 用于区分视频类型，显示不同宽度的item
enum VideoType {
    case videoTVSerial       // 连续剧
    case videoVarietyShow    // 综艺节目
    case videoTips        // 视屏标签
}

/// 选集cell
class CollectChoseCell: UITableViewCell {
    
    private let customLayout: CustomFlowSingleLayout = {
        let layout = CustomFlowSingleLayout()
        layout.itemSize = CGSize(width: 100, height: 50)
        return layout
    }()
    private lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 50), collectionViewLayout: customLayout)
        collection.backgroundColor = UIColor.white
        collection.showsHorizontalScrollIndicator = false
        collection.delegate = self
        collection.dataSource = self
        collection.register(UINib(nibName: "CollectChoseItemCell", bundle: Bundle.main), forCellWithReuseIdentifier: CollectChoseItemCell.cellId)
        return collection
    }()
    
    private var index: IndexPath = IndexPath.init(row: 0, section: 0)
    
    var videoType: VideoType = .videoTVSerial {
        didSet {
            if videoType == .videoTVSerial {
                customLayout.itemSize = CGSize(width: 100, height: 50)
            } else if videoType == .videoVarietyShow {
                customLayout.itemSize = CGSize(width: 120, height: 50)
            } else if videoType == .videoTips {
                customLayout.itemSize = CGSize(width: 50, height: 25)
            }
            collectionView.reloadData()
        }
    }
    var itemClickHandler:((_ index: Int) -> Void)?
    var videoResources: [VideoResource]?
    var resourceItems = [VideoResItem]()
    // 记录当前的index
    var currentIndex = 0
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.backgroundColor = UIColor.white
        contentView.addSubview(collectionView)
        layoutCollection()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setResource(_ resources: [VideoResource], _ currentIndex: Int) {
        videoResources = resources
        collectionView.reloadData()
        resourceItems.removeAll()
        self.currentIndex = currentIndex
        for i in 0..<resources.count {
            let videoItem = VideoResItem(selected: i == currentIndex ? true : false, index: i, videoModel: resources[i])
            resourceItems.append(videoItem)
        }
        collectionView.reloadData()
        collectionView.scrollToItem(at: IndexPath(row: currentIndex, section: 0), at: UICollectionView.ScrollPosition.centeredHorizontally, animated: false)
    }
    
    /// 切换当前正在播放的视频（换集， 换清晰度，非切源）
    private func changeCurrentVideo(_ index: Int) {
        if videoResources?[index] != nil {
            itemClickHandler?(index)
        }
    }
    
}
extension CollectChoseCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return resourceItems.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CollectChoseItemCell.cellId, for: indexPath) as! CollectChoseItemCell
        if resourceItems.count > indexPath.row {
            let resModel = resourceItems[indexPath.row]
            cell.itemLable.text = resModel.videoModel?.play_series ?? ""
            cell.itemLable.textColor =  resModel.selected ? ConstValue.kAppDefaultTitleColor : UIColor.darkText
           // cell.itemLable.backgroundColor = resModel.selected ? ConstValue.kAppDefaultColor : UIColor.groupTableViewBackground
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        if indexPath.row != currentIndex { // f点击  非当前正在播放  集
            changeCurrentVideo(indexPath.row)
        }
        resourceItems[currentIndex].selected = false
        resourceItems[indexPath.row].selected = true
        currentIndex = indexPath.row
        collectionView.reloadData()
    }
    
    
}

// MARK: - Layout
private extension CollectChoseCell {
    
    private func layoutCollection() {
        collectionView.snp.makeConstraints { (make) in
            make.top.equalTo(0)
            make.center.equalToSuperview()
            make.leading.trailing.equalToSuperview()
            make.height.equalTo(50)
        }
    }
    
}

//
//  VideoInfoTypeTipsCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/13.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit


/// 视频详情页面的视频标签列表
class VideoInfoTypeTipsCell: UITableViewCell {

    static let cellId = "VideoInfoTypeTipsCell"
    
    private let customLayout: CustomFlowSingleLayout = {
        let layout = CustomFlowSingleLayout()
        layout.itemSize = CGSize(width: 65, height: 25)
        return layout
    }()
    private lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 50), collectionViewLayout: customLayout)
        collection.backgroundColor = UIColor.white
        collection.showsHorizontalScrollIndicator = false
        collection.delegate = self
        collection.dataSource = self
        collection.register(UINib(nibName: "CollectChoseItemCell", bundle: Bundle.main), forCellWithReuseIdentifier: CollectChoseItemCell.cellId)
        return collection
    }()
    var infoTypeTips: [InfoTypeModel]?
   
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.backgroundColor = UIColor.white
        contentView.addSubview(collectionView)
        layoutCollection()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setTips(_ tips: [InfoTypeModel]) {
        infoTypeTips = tips
        collectionView.reloadData()
    }
    
}


extension VideoInfoTypeTipsCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return infoTypeTips?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CollectChoseItemCell.cellId, for: indexPath) as! CollectChoseItemCell
        if let tipsModels = infoTypeTips, tipsModels.count > indexPath.row {
            let tipsModel = tipsModels[indexPath.row]
            if tipsModel.type_label != nil && !tipsModel.type_label!.isEmpty {
                cell.itemLable.text = tipsModel.type_label!
            } else {
                cell.itemLable.text = UIViewController.localStr("kNotCategoryMsg")
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
       
    }
    
}



// MARK: - Layout
private extension VideoInfoTypeTipsCell {
    
    private func layoutCollection() {
        collectionView.snp.makeConstraints { (make) in
            make.top.equalTo(10)
            make.center.equalToSuperview()
            make.leading.trailing.equalToSuperview()
            make.height.equalTo(50)
        }
    }
    
}

//
//  VideoResourceCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/13.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

struct SourceItem {
    var selected: Bool = false
    var index: Int = 0
    var resourcesModel: InfoResource?
}

/// 选视屏源
class VideoResourceCell: UITableViewCell {
    
    static let cellId = "VideoResourceCell"
    static let collectCellId = "CollectChoseCell"
    
    private let customLayout: CustomFlowSingleLayout = {
        let layout = CustomFlowSingleLayout()
        layout.itemSize = CGSize(width: 100, height: 50)
        return layout
    }()
    private lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 50), collectionViewLayout: customLayout)
        collection.backgroundColor = UIColor.white
        collection.showsHorizontalScrollIndicator = false
        collection.delegate = self
        collection.dataSource = self
        collection.register(UINib(nibName: "CollectChoseItemCell", bundle: Bundle.main), forCellWithReuseIdentifier: CollectChoseItemCell.cellId)
        return collection
    }()
    var itemClickHandler:((_ res: InfoResource, _ currentIndex: Int) -> Void)?
    
    var infoResource: [InfoResource]?
    var resourceItems = [SourceItem]()
    // 记录当前的index
    var currentIndex = 0
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.backgroundColor = UIColor.white
        contentView.addSubview(collectionView)
        layoutCollection()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    /// 配置数据源
    func setResource(_ resource: [InfoResource], _ resIndex: Int) {
        infoResource = resource
        resourceItems.removeAll()
        currentIndex = resIndex
        for i in 0..<resource.count {
            let sourceItem = SourceItem(selected: i == resIndex ? true : false, index: i, resourcesModel: resource[i])
            resourceItems.append(sourceItem)
        }
        collectionView.reloadData()
        collectionView.scrollToItem(at: IndexPath(row: resIndex, section: 0), at: UICollectionView.ScrollPosition.centeredHorizontally, animated: false)
    }
    
    /// 切换源
    private func changeCurrentResource(_ index: Int) {
        if let resourceModel = infoResource?[index] {
            itemClickHandler?(resourceModel, index)
        }
    }
}


extension VideoResourceCell: UICollectionViewDelegate, UICollectionViewDataSource {
        
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return resourceItems.count
        }
        
        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CollectChoseItemCell.cellId, for: indexPath) as! CollectChoseItemCell
            if resourceItems.count > indexPath.row {
                let resModel = resourceItems[indexPath.row]
                cell.itemLable.text = resModel.resourcesModel?.title ?? ""
                cell.itemLable.textColor = resModel.selected ? ConstValue.kAppDefaultTitleColor : UIColor.darkText
            }
            return cell
        }
        
        func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
            collectionView.deselectItem(at: indexPath, animated: true)
            if indexPath.row != currentIndex { // 点击 非当前的已经在播放的源
                // 切换源
                changeCurrentResource(indexPath.row)
            }
            resourceItems[currentIndex].selected = false
            resourceItems[indexPath.row].selected = true
            currentIndex = indexPath.row
            collectionView.reloadData()
        }
   
}
    


// MARK: - Layout
private extension VideoResourceCell {
    
    private func layoutCollection() {
        collectionView.snp.makeConstraints { (make) in
            make.top.equalTo(10)
            make.center.equalToSuperview()
            make.leading.trailing.equalToSuperview()
            make.height.equalTo(50)
        }
    }
    
}

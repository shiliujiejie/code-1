//
//  CollectChoseItemCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/7.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class CollectChoseItemCell: UICollectionViewCell {

    static let cellId = "CollectChoseItemCell"
    
    @IBOutlet weak var itemLable: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        itemLable.layer.cornerRadius = 10
        itemLable.layer.masksToBounds = true
    }
    
}

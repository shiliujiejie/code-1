//
//  AdvertisingCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/7.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 视频详情页 广告
class AdvertisingCell: UITableViewCell {
    
    private let advImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.isUserInteractionEnabled = true
        imageView.image = UIImage(named: "5.jpg")
        return imageView
    }()
    
    private let advLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.white
        lable.font = UIFont.systemFont(ofSize: 15)
        lable.text = "广告"
        return lable
    }()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.addSubview(advImageView)
        contentView.addSubview(advLable)
        layoutpageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}


// MARK: - Layout
private extension AdvertisingCell {
    
    func layoutpageSubviews() {
        layoutAdvImage()
        layoutAdvLable()
    }
    
    func layoutAdvImage() {
        advImageView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    func layoutAdvLable() {
        advLable.snp.makeConstraints { (make) in
            make.trailing.equalTo(-15)
            make.bottom.equalTo(-15)
            make.height.equalTo(20)
        }
    }
    
}

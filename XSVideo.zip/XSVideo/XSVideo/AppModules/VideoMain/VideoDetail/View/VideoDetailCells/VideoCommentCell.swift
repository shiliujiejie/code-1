//
//  VideoCommentCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/7.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 视频详情页 - 视频评论Cell
class VideoCommentCell: UITableViewCell {

    
    @IBOutlet weak var hotCommentButton: UIButton!
    @IBOutlet weak var thumUp: UIButton!
    
    @IBOutlet weak var thumDown: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

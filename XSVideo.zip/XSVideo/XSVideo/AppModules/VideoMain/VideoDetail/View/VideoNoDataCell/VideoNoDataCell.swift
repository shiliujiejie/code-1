//
//  VideoNoDataCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/14.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class VideoNoDataCell: UITableViewCell {

    static let cellId = "VideoNoDataCell"
    
    @IBOutlet weak var noDatamMsgLable: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        noDatamMsgLable.text = UIViewController.localStr("kNotDataMsg")
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func noDataClick(_ sender: UIButton) {
        
    }
}

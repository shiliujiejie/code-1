//
//  VideoIntroduceListCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/7.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 视频简介 信息列表 cell
class VideoIntroduceListCell: UITableViewCell {

    let playCountLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 14)
        lable.textColor = UIColor.darkGray
        return lable
    }()
    let cateLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 14)
        lable.textColor = UIColor.darkGray
        return lable
    }()
    let directorLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 14)
        lable.textColor = UIColor.darkGray
        return lable
    }()
    let actorsLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 14)
        lable.textColor = UIColor.darkGray
        lable.numberOfLines = 0
        return lable
    }()
    let lineView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.groupTableViewBackground
        return view
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.addSubview(playCountLable)
        contentView.addSubview(cateLable)
        contentView.addSubview(directorLable)
        contentView.addSubview(actorsLable)
        contentView.addSubview(lineView)
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

// MARK: - Layout
private extension VideoIntroduceListCell {
    
    func layoutPageSubviews() {
        layoutPlayCountLable()
        layoutCateLable()
        layoutDirectorLable()
        layoutLineView()
        layoutActorsLable()
        
    }
    
    func layoutPlayCountLable() {
        playCountLable.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalTo(5)
            make.trailing.equalTo(-15)
            make.height.equalTo(20)
        }
    }
    
    func layoutCateLable() {
        cateLable.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(playCountLable.snp.bottom).offset(10)
            make.height.equalTo(20)
        }
    }
    
    func layoutDirectorLable() {
        directorLable.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(cateLable.snp.bottom).offset(10)
            make.height.equalTo(20)
        }
    }
    
    func layoutActorsLable() {
        actorsLable.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(directorLable.snp.bottom).offset(10)
            make.bottom.equalTo(lineView.snp.top).offset(-10)
        }
    }
    
    func layoutLineView() {
        lineView.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.bottom.equalToSuperview()
            make.height.equalTo(0.6)
        }
    }
}

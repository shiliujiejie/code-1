//
//  VideoIntroTextCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/7.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class VideoIntroTextCell: UITableViewCell {

    @IBOutlet weak var introlTitleLable: UILabel!
    @IBOutlet weak var introduceTextLable: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        introlTitleLable.text = UIViewController.localStr("kIntrol")
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setIntroduceText(text: String) {
        let attString = TextSpaceManager.getAttributeStringWithString(text, lineSpace: 6)
        introduceTextLable.attributedText = attString
    }
    
}


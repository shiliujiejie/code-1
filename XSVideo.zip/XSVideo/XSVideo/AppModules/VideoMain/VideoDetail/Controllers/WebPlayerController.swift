//
//  WebPlayerController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/15.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import WebKit

class WebPlayerController: UIViewController {

    private lazy var wkConfig: WKWebViewConfiguration = {
        let config = WKWebViewConfiguration()
        return config
    }()
    private let webPlayerBgView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.darkText
        return view
    }()
    private lazy var webView: WKWebView = {
        let webView = WKWebView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: ConstValue.kScreenWdith * 9/16), configuration: wkConfig)
        webView.navigationDelegate = self
        webView.scrollView.showsHorizontalScrollIndicator = false
        return webView
    }()
    private lazy var introVC: VideoIntroduceController = {
        let introlVC = VideoIntroduceController()
        introlVC.closeButton.isHidden = true
        introlVC.videoModel = self.videoModel
        return introlVC
    }()
    /// 处理导航栏
    var navHidenCallBackHandler:((_ isAnimated: Bool) -> Void)?
    
    var videoUrl: String?
    var videoModel: VideoDetailModel?
    
    deinit {
        print("vc is deinit")    // 出站的时候，这里没走，说明当前控制器没有被释放调，存在内存泄漏
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(webView)
        view.backgroundColor = UIColor.white
        let url = URL(string: videoUrl ?? "")
        webView.load(URLRequest(url: url ?? URL(string: String(format: "%@/share", ConstValue.kAppDownLoadLoadUrl))!))
        view.addSubview(introVC.view)
        addChild(introVC)
        layoutPageSubviews()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: false)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navHidenCallBackHandler?(true)
    }
    

}

extension WebPlayerController: WKNavigationDelegate {
    
    // 决定导航的动作，通常用于处理跨域的链接能否导航。
    // WebKit对跨域进行了安全检查限制，不允许跨域，因此我们要对不能跨域的链接单独处理。
    // 但是，对于Safari是允许跨域的，不用这么处理。
    // 这个是决定是否Request
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        decisionHandler(.allow)
    }
    
    // 开始接收响应
    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        decisionHandler(.allow)
    }
    
    //用于授权验证的API，与AFN、UIWebView的授权验证API是一样的
    func webView(_ webView: WKWebView, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        completionHandler(.performDefaultHandling ,nil)
    }
    
    // 开始加载数据
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        webView.isHidden = false
        // self.indicatorView.startAnimating()
    }
    
    // 当main frame接收到服务重定向时调用
    func webView(_ webView: WKWebView, didReceiveServerRedirectForProvisionalNavigation navigation: WKNavigation!) {
        // 接收到服务器跳转请求之后调用
    }
    
    // 当内容开始返回时调用
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
//        webView.evaluateJavaScript("document.body.offsetHeight") { [weak self] (result, error) in
//            if let strongSelf = self {
//                if let webheight = result as? CGFloat {
//                    print("网页高度= \(webheight)")
//                }
//            }
//        }
    }
    
    //当main frame导航完成时，会回调
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        
//        webView.evaluateJavaScript("document.body.offsetHeight") { [weak self] (result, error) in
//           
//        }
    }
    
    // 当web content处理完成时，会回调
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        
    }
    
    // 当main frame开始加载数据失败时，会回调
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        
    }
    
    // 当main frame最后下载数据失败时，会回调
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        
    }
}


// MARK: - Layout
private extension WebPlayerController {
    
    func layoutPageSubviews() {
        layoutWebView()
        layoutIntrolView()
    }
    
    func layoutWebView() {
        webView.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo( ConstValue.kScreenWdith * 9/16)
        }
    }
    
    func layoutIntrolView() {
        introVC.view.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(webView.snp.bottom).offset(1)
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalToSuperview()
            }
        }
    }
}

//
//  VideoIntroduceController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/7.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 视频简介 控制器
class VideoIntroduceController: UIViewController {

    static let videoInfoCellId = "VideoInfoListCell"
    static let VideoIntroTextCellId = "VideoIntroTextCell"
    
    private lazy var tableView: UITableView = {
        let table = UITableView(frame: view.bounds, style: .plain)
        table.allowsSelection = false
        table.delegate = self
        table.dataSource = self
        table.separatorStyle = .none
        table.showsHorizontalScrollIndicator = false
        table.tableFooterView = UIView(frame: CGRect.zero)
        table.register(VideoIntroduceListCell.classForCoder(), forCellReuseIdentifier: VideoIntroduceController.videoInfoCellId)
        table.register(UINib(nibName: "VideoIntroTextCell", bundle: Bundle.main), forCellReuseIdentifier: VideoIntroduceController.VideoIntroTextCellId)
        return table
    }()
    lazy var closeButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "borrowFailed"), for: .normal)
        button.frame = CGRect(x: ConstValue.kScreenWdith - 50, y: 5, width: 40, height: 40)
        button.addTarget(self, action: #selector(closeButtonClick), for: .touchUpInside)
        return button
    }()
    private lazy var tableHeaderView: UIView = {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 50))
        view.backgroundColor = UIColor.white
        view.layer.borderColor = UIColor.groupTableViewBackground.cgColor
        view.layer.borderWidth = 0.5
        return view
    }()
    lazy var headerLable: UILabel = {
        let titleLable = UILabel(frame: CGRect(x: 15, y: 0, width: ConstValue.kScreenWdith - 100, height: 50))
        titleLable.textColor = UIColor.darkText
        titleLable.font = UIFont.boldSystemFont(ofSize: 16)
        return titleLable
    }()
    
    var videoModel: VideoDetailModel?
    
    var closeButtonClickHandler:(() -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        tableHeaderView.addSubview(headerLable)
        tableHeaderView.addSubview(closeButton)
        view.addSubview(tableHeaderView)
        view.addSubview(tableView)
        layoutPageSubviews()
        setModelInfo()
    }
    
    func setModelInfo() {
        if videoModel != nil {
            headerLable.text = videoModel!.title ?? localStr("kUnknownTime")
        }
    }
    
    func getActorsLableText() -> String? {
        var actorsString: String = localStr("kAcotrTitle")
        if let actors = videoModel?.author, actors.count > 0 {
            for actor in actors {
                if actor.actor_label != nil {
                    let string = String(format: "%@  ", actor.actor_label!)
                    actorsString = String(format: "%@ %@", actorsString, string)
                }
            }
            return actorsString
        }
        return nil
    }
    
    func getTipsType() -> String? {
        var typeString: String = localStr("kCategoryTitle")
        if let types = videoModel?.type, types.count > 0 {
            for typeModel in types {
                if typeModel.type_label != nil {
                    let string = String(format: "%@  ", typeModel.type_label!)
                    typeString = String(format: "%@ %@", typeString, string)
                }
            }
            return typeString
        }
        return nil
    }
    
    @objc private func closeButtonClick() {
        closeButtonClickHandler?()
    }

}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension VideoIntroduceController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 120.0
        return tableView.rowHeight
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: VideoIntroduceController.videoInfoCellId, for: indexPath) as! VideoIntroduceListCell
            if videoModel != nil {
                cell.playCountLable.text = "\(localStr("kPlayCountTitle")) \(getStringWithNumber(videoModel?.play_count ?? 0))"
                cell.cateLable.text = (getTipsType() ?? localStr("kCategroyNotTitle"))! as String
                cell.directorLable.text = "\(localStr("kDiretorTitle")) \(videoModel!.director ?? localStr("kNot"))"
                cell.actorsLable.text = (getActorsLableText() ?? localStr("kActorsNotTitle"))! as String
                cell.actorsLable.attributedText = TextSpaceManager.getAttributeStringWithString(cell.actorsLable.text!, lineSpace: 7)
            }
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: VideoIntroduceController.VideoIntroTextCellId, for: indexPath) as! VideoIntroTextCell
            if self.videoModel != nil {
                cell.setIntroduceText(text: videoModel?.intro ?? localStr("kNotIntrolMsg"))
            }
            return cell
        }
    }
    
}

// MARK: - Layout
private extension VideoIntroduceController {
    
    func layoutPageSubviews() {
        layoutHeaderView()
        layoutTableView()
    }
    func layoutHeaderView() {
        tableHeaderView.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(50)
        }
    }
    
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            make.top.equalTo(tableHeaderView.snp.bottom)
            make.leading.trailing.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalToSuperview()
            }
        }
    }
}

//
//  VarietyShowCollectController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/8.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 综艺节目 选集 vc
class VarietyShowCollectController: UIViewController {
    
    private lazy var closeButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "borrowFailed"), for: .normal)
        button.frame = CGRect(x: ConstValue.kScreenWdith - 50, y: 5, width: 40, height: 40)
        button.addTarget(self, action: #selector(closeButtonClick), for: .touchUpInside)
        return button
    }()
    private lazy var tableHeaderView: UIView = {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 50))
        view.backgroundColor = UIColor.white
        view.layer.borderColor = UIColor.groupTableViewBackground.cgColor
        view.layer.borderWidth = 0.5
        return view
    }()
    private let collectionLayout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: (ConstValue.kScreenWdith - 50)/2, height: 50)
        layout.sectionInset = UIEdgeInsets(top: 10, left: 15, bottom: 10, right: 15)
        layout.minimumLineSpacing = 20
        layout.minimumInteritemSpacing = 15
        return layout
    }()
    private lazy var collectionView: UICollectionView = {
        let collection = UICollectionView.init(frame: self.view.bounds, collectionViewLayout: collectionLayout)
        collection.delegate = self
        collection.dataSource = self
        collection.backgroundColor = UIColor.white
        collection.showsVerticalScrollIndicator = false
        collection.register(UINib(nibName: "CollectChoseItemCell", bundle: Bundle.main), forCellWithReuseIdentifier: CollectChoseItemCell.cellId)
        return collection
    }()
    lazy var headerLable: UILabel = {
        let titleLable = UILabel(frame: CGRect(x: 15, y: 0, width: ConstValue.kScreenWdith - 100, height: 50))
        titleLable.textColor = UIColor.darkText
        titleLable.font = UIFont.boldSystemFont(ofSize: 16)
        return titleLable
    }()
    lazy var headerRightLable: UILabel = {
        let titleLable = UILabel(frame: CGRect(x: 15, y: 0, width: ConstValue.kScreenWdith - 100, height: 50))
        titleLable.textColor = UIColor.lightGray
        titleLable.textAlignment = .left
        titleLable.font = UIFont.boldSystemFont(ofSize: 14)
        titleLable.text = ""
        return titleLable
    }()
    var resources: InfoResource?
    var itemsModels = [VideoResItem]()
    var itemClickHandler:((_ index: Int) -> Void)?
    var closeButtonClickHandler:(() -> Void)?
    // 记录当前的index
    var currentIndex: Int? = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        tableHeaderView.addSubview(headerLable)
        tableHeaderView.addSubview(closeButton)
        tableHeaderView.addSubview(headerRightLable)
        view.addSubview(tableHeaderView)
       // view.addSubview(categoryTitleView)
        view.addSubview(collectionView)
        layoutPageSubviews()
        setCollectCount()
        fixDataModel()
    }
    
    @objc private func closeButtonClick() {
        closeButtonClickHandler?()
    }
  
    private func fixDataModel() {
        itemsModels.removeAll()
        if let resourceItems = resources?.video_list , resourceItems.count > 0 {
            for i in 0..<resourceItems.count {
                let videoItem = VideoResItem(selected: i == currentIndex ? true : false, index: i, videoModel: resourceItems[i])
                itemsModels.append(videoItem)
            }
            collectionView.reloadData()
        }
    }
    
    func setCollectCount() {
        if let videoList = resources?.video_list, videoList.count > 0 {
            headerRightLable.isHidden = false
            headerRightLable.text = "\(localStr("kAll"))\(videoList.count)\(localStr("kVerity"))"
        } else {
            headerRightLable.isHidden = true
        }
    }
    
    /// 切换当前正在播放的视频（换集， 换清晰度，非切源）
    private func changeCurrentVideo(_ index: Int) {
        if itemsModels.count > index {
            itemClickHandler?(index)
        }
    }
}


// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension VarietyShowCollectController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return itemsModels.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CollectChoseItemCell.cellId, for: indexPath) as! CollectChoseItemCell
        if itemsModels.count > indexPath.row {
            let resModel = itemsModels[indexPath.row]
            cell.itemLable.text = resModel.videoModel?.play_series ?? ""
            cell.itemLable.numberOfLines = 2
            cell.itemLable.textColor = resModel.selected ? UIColor.white : UIColor.darkText
            cell.itemLable.backgroundColor = resModel.selected ? ConstValue.kAppDefaultColor : UIColor.groupTableViewBackground
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        // 选中状态需要在数据源上做
        if indexPath.row != currentIndex { // f点击  非当前正在播放  集
            changeCurrentVideo(indexPath.row)
        }
        itemsModels[currentIndex!].selected = false
        itemsModels[indexPath.row].selected = true
        currentIndex = indexPath.row
        collectionView.reloadData()
    }
    
}

// MARK: - Layout
private extension VarietyShowCollectController {
    
    func layoutPageSubviews() {
        layoutHeaderView()
        layoutHeaderTitleLable()
        layoutRightLable()
        layoutCloseBtn()
      //  layoutCategoryView()
        layoutCollectionView()
    }
    
    func layoutHeaderView() {
        tableHeaderView.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(50)
        }
    }
    
    func layoutHeaderTitleLable() {
        headerLable.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.centerY.equalToSuperview()
        }
    }
    
    func layoutCloseBtn() {
        closeButton.snp.makeConstraints { (make) in
            make.trailing.equalTo(-15)
            make.centerY.equalToSuperview()
            make.height.width.equalTo(40)
        }
    }
    
    func layoutRightLable() {
        headerRightLable.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.centerY.equalToSuperview()
        }
    }
    
//    func layoutCategoryView() {
//        categoryTitleView.snp.makeConstraints { (make) in
//            make.leading.trailing.equalToSuperview()
//            make.top.equalTo(tableHeaderView.snp.bottom)
//            make.height.equalTo(50)
//        }
//    }
    
    func layoutCollectionView() {
        collectionView.snp.makeConstraints { (make) in
            make.top.equalTo(tableHeaderView.snp.bottom)
            make.leading.trailing.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalToSuperview()
            }
        }
    }
}

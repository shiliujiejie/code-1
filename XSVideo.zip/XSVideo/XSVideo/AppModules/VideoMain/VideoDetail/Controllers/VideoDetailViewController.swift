//
//  VideoDetailViewController.swift
//  XSVideo
//
//  Created by pro5 on 2018/11/27.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import SnapKit
import NicooPlayer
import NicooNetwork
import AVFoundation
import NicooM3u8Downloader

/// 播放页面，视频详情页
class VideoDetailViewController: UIViewController {
    
    static let advertisingCellId = "AdvertisingCell"
    static let videoInfoMsgCellId = "VideoInfoMsgCell"
    static let videoCommentCellId = "VideoCommentCell"
    static let collectChoseCellId = "CollectChoseCell"
    
    /// 这里重写系统方法，为了让 StatusBar 跟随播放器的操作栏一起 隐藏或显示，且在全屏播放时， StatusBar 样式变为 lightContent
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    private lazy var tableView: UITableView = {
        let table = UITableView(frame: view.bounds, style: .plain)
        table.showsVerticalScrollIndicator = false
        table.showsHorizontalScrollIndicator = false
        table.separatorStyle = .none
        table.allowsSelection = false
        table.delegate = self
        table.dataSource = self
        table.tableFooterView = UIView(frame: CGRect.zero)
        table.register(AdvertisingCell.classForCoder(), forCellReuseIdentifier: VideoDetailViewController.advertisingCellId)
        table.register(UINib(nibName: "VideoInfoMsgCell", bundle: Bundle.main), forCellReuseIdentifier: VideoDetailViewController.videoInfoMsgCellId)
        table.register(UINib(nibName: "VideoNoDataCell", bundle: Bundle.main), forCellReuseIdentifier: VideoNoDataCell.cellId)
        table.register(UINib(nibName: "VideoCommentCell", bundle: Bundle.main), forCellReuseIdentifier: VideoDetailViewController.videoCommentCellId)
        table.register(UINib(nibName: "VideoComListCell", bundle: Bundle.main), forCellReuseIdentifier: VideoComListCell.cellId)
        table.register(CollectChoseCell.classForCoder(), forCellReuseIdentifier: VideoDetailViewController.collectChoseCellId)
        table.register(VideoResourceCell.classForCoder(), forCellReuseIdentifier: VideoResourceCell.cellId)
        table.register(VideoInfoTypeTipsCell.classForCoder(), forCellReuseIdentifier: VideoInfoTypeTipsCell.cellId)
        table.register(VideoGuessLikeCell.classForCoder(), forCellReuseIdentifier: VideoGuessLikeCell.cellId)
        return table
    }()
    private lazy var backButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "navBackWhite"), for: .normal)
        button.backgroundColor = UIColor(white: 0.0, alpha: 0.2)
        button.layer.cornerRadius = 15
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(backButtonClick), for: .touchUpInside)
        return button
    }()
    private let statuBarView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.black
        return view
    }()
    private lazy var playerBgView: UIImageView = {
        let view = UIImageView(frame: CGRect(x: 0.0, y: 0.0, width: ConstValue.kScreenWdith, height: ConstValue.kScreenWdith * 9/16))
        view.isUserInteractionEnabled = true
        view.backgroundColor = UIColor.black
        let url = URL(string: videoModel?.cover_path ?? "")
        view.kf.setImage(with: url)
        return view
    }()
    private lazy var networkWarningView: NetworkWarnView = {
        let view = NetworkWarnView(frame: CGRect(x: 0.0, y: 0.0, width: ConstValue.kScreenWdith, height: ConstValue.kScreenWdith * 9/16))
        view.isHidden = true
        return view
    }()
    private lazy var videoCommentView: VideoCommentView = {
        let view = VideoCommentView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 50))
        return view
    }()
    private lazy var playerView: NicooPlayerView = {
        let player = NicooPlayerView(frame: playerBgView.bounds, bothSidesTimelable: true)
        player.videoLayerGravity = .resizeAspect
        player.videoNameShowOnlyFullScreen = true
        player.delegate = self
        player.customViewDelegate = self
        return player
    }()
    private lazy var videoDetailAPI: VideoInfoApi = {
        let api = VideoInfoApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    // 本次是否允许过非wifi 播放
    private var allowWannaPlay: Bool = false
    var viewModel = VideoDetailViewModel()
    let taskViewModel = TasksViewModel()
    var videoModel: VideoDetailModel?
    var videoResourceList: [InfoResource]?
    var videoId: Int?
    /// 当前播放的源
    var currentPalyResource: InfoResource?
    ///当前正在播放源在源数组的index
    var currentResIndex: Int = 0
    
    /// 当前正在播放的视频资源Id
    var currentPlayResId: Int?
    /// 当前播放的视频在当前源中的Index
    var currentVideoIndex: Int = 0
    
    deinit {
        DLog("视图控制器被释放了11")
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc private func backButtonClick() {
        navigationController?.popViewController(animated: true)
    }
}

// MARK: - Life cycle 
extension VideoDetailViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        view.addSubview(statuBarView)
        view.addSubview(playerBgView)
        view.addSubview(networkWarningView)
        view.addSubview(backButton)
        view.addSubview(tableView)
        view.addSubview(videoCommentView)
        layoutPageSubviews()
        addViewModelLoadDataCallBack()
        addCommentViewCallBackHandler()
        addNetworkWarningKeepPlayingCallBack()
        let _ = videoDetailAPI.loadData()
        loadViewModelData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // 注册APP被挂起 + 进入前台通知
        NotificationCenter.default.addObserver(self, selector: #selector(applicationResignActivity(_:)), name: UIApplication.willResignActiveNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(applicationBecomeActivity(_:)), name: UIApplication.didBecomeActiveNotification, object: nil)
        navigationController?.setNavigationBarHidden(true, animated: isNavAnimated ? animated : false)
        // 网络监听
        NotificationCenter.default.addObserver(self, selector: #selector(VideoDetailViewController.netWorkStatusChange), name: NSNotification.Name.kRealReachabilityStatusChanged, object: nil)
        /// 进入页面判断是否隐藏网络提示框(条件： 1. wifi ，2.允许过4G网播放)
        networkWarningView.isHidden = isNetWorkStatusWifi() || allowWannaPlay
        
        /// 这里是否考虑，在播放时添加 ，允许屏幕旋转
        playerView.enableDeviceOrientationChange()
        
        isNavAnimated = false
        // 如果当前播放器已经添加，支持横竖屏
        if playerBgView.subviews.contains(playerView) && networkWarningView.isHidden {
            orientationSupport = NicooPlayerOrietation.orientationAll
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        getWatchVideoSatisfy()
        saveVideoToLocalDB()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        /// 离开视频播放页面，只支持竖屏
        playerView.playerStatu = PlayerStatus.Pause
        orientationSupport = NicooPlayerOrietation.orientationPortrait
    }
    
    /// 点击继续播放
    func addNetworkWarningKeepPlayingCallBack() {
        networkWarningView.keepPlayingCallBackHandler = { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.allowWannaPlay = true
            strongSelf.networkWarningView.isHidden = true
            /// 播放器已经添加(网络中途变化)
            if strongSelf.playerBgView.subviews.contains(strongSelf.playerView) {
                strongSelf.playerView.playerStatu = PlayerStatus.Playing
            } else {
                /// 第一次进入就不是wifi
                strongSelf.playVideoInCurrentResource()
            }
        }
    }
    
 
    /// - 进入后台， 计算时间，保存（剔除无效时间）
    @objc func applicationResignActivity(_ sender: NSNotification) {
        let forMat = DateFormatter()
        forMat.dateFormat = "yyyy-MM-dd HH:mm:ss"
        if let startTime = forMat.date(from: UserModel.share().startTime ?? "") {
            let time = viewModel.getWatchVideoTime(statTime: startTime, endTime: Date())
            UserModel.share().watchedTime += time
        }
        saveVideoToLocalDB()
    }
    
    // MARK: - APP进入前台，恢复播放状态  重新记录播放开始时间
    @objc func applicationBecomeActivity(_ sender: NSNotification) {
        UserModel.share().startTime = viewModel.getStartTime()
    }
    
    /// 检测网络变化， 这里只需要知道是否为 wifi
    @objc func netWorkStatusChange() {
        if NicooNetworkManager.currentNetworkType() != .wifi {            // 非wifi 状态下
            networkWarningView.isHidden = allowWannaPlay
            playerView.playerStatu = allowWannaPlay ? PlayerStatus.Playing : PlayerStatus.Pause
        } else {
            networkWarningView.isHidden = true
            if playerBgView.subviews.contains(playerView) {
                playerView.playerStatu = PlayerStatus.Playing
            } else {
                playerView.playerStatu = PlayerStatus.Playing
                playVideoInCurrentResource(currentVideoIndex)
            }
        }
    }
    
    /// 获取观影奖励
    func getWatchVideoSatisfy() {
        let forMat = DateFormatter()
        forMat.dateFormat = "yyyy-MM-dd HH:mm:ss"
        /// 一次性30分钟， 判断今天领过没有： 1. 取出时间，比对当前时间。（判断上次领奖时间是不是今天） 是: 不在领  不是： 领一把。
        if let startTime = forMat.date(from: UserModel.share().startTime ?? "") {
            let time =  UserModel.share().watchedTime + viewModel.getWatchVideoTime(statTime: startTime, endTime: Date())
            if time >= 30 {  // 看满30分钟
                if let day = UserDefaults.standard.string(forKey: UserDefaults.kLastTimeDay) {
                    if day != viewModel.getCurrentDay() { // 领奖, 领完，存一下领奖时间
                        // 请求奖励，成功后删除时间，今日存放时间为0
                        taskViewModel.getWatchSatisfy()
                    }
                } else {  /// 没有领奖记录时间 ， 直接领奖，领完，存一下领奖时间
                    taskViewModel.getWatchSatisfy()
                }
            }
        }
    }
}

// MARK: - User -- Actions
private extension VideoDetailViewController {
    
    /// 点👍
    ///
    /// - Parameter isThumUp: 是否已经点击
    func thumUpButtonClick(_ isThumUp: Bool) {
        if UserModel.share().isLogin && UserModel.share().isRealUser {
            viewModel.loadUserThumAddApiData(UserThumAddApi.kRecommend, statu: isThumUp ? 0 : 1)
        } else {
            LoginManager().login { [weak self] in
                self?.viewModel.loadUserThumAddApiData(UserThumAddApi.kRecommend, statu: isThumUp ? 0 : 1)
            }
        }
    }
    
    /// 点👎
    ///
    /// - Parameter isThumDown: 是否已经点击
    func thumDownButtonClick(_ isThumDown: Bool) {
        if UserModel.share().isLogin && UserModel.share().isRealUser {
            viewModel.loadUserThumAddApiData(UserThumAddApi.kNegative, statu: isThumDown ? 0 : 1)
        } else {
            LoginManager().login { [weak self] in
                self?.viewModel.loadUserThumAddApiData(UserThumAddApi.kNegative, statu: isThumDown ? 0 : 1)
            }
        }
    }
    
    /// 添加评论
    ///
    /// - Parameter commentText: 评论的文字
    func commentAdd(_ commentText: String) {
        if UserModel.share().isLogin && UserModel.share().isRealUser {
            viewModel.loadCommentApiData(content: commentText, globalType: videoModel?.global_type ?? "")
        } else {
            LoginManager().login { [weak self] in
                guard let strongSelf = self else { return }
                strongSelf.viewModel.loadCommentApiData(content: commentText, globalType: strongSelf.videoModel?.global_type ?? "")
            }
        }
    }
    
    /// 添加收藏
    func addFavor() {
        if UserModel.share().isLogin && UserModel.share().isRealUser {
            loadFavorAddOrCancleApi()
        } else {
            LoginManager().login { [weak self] in
                guard let strongSelf = self else { return }
                strongSelf.loadFavorAddOrCancleApi()
            }
        }
    }
    
    func loadFavorAddOrCancleApi() {
        if videoModel?.user_collect?.isCollected ?? false {
            viewModel.loadFavorCancleApiData()
        } else {
            viewModel.loadFavorAddApiData(globalType: videoModel?.global_type ?? "")
        }
    }
    
    /// 分享或反馈
    func shareOrFadeBackButtonClick(_ index: Int) {
        if index == 1 { // 用户反馈
            if UserModel.share().isLogin && UserModel.share().isRealUser {
                let fadeBackVC = HelpController()
                fadeBackVC.navHidenCallBackHandler = { [weak self] (isAnimate) in
                    self?.isNavAnimated = isAnimate
                }
                navigationController?.pushViewController(fadeBackVC, animated: true)
            } else {
                LoginManager().login { [weak self] in
                    guard let strongSelf = self else { return }
                    let fadeBackVC = HelpController()
                    fadeBackVC.navHidenCallBackHandler = { [weak self] (isAnimate) in
                        self?.isNavAnimated = isAnimate
                    }
                    strongSelf.navigationController?.pushViewController(fadeBackVC, animated: true)
                }
            }
        }
        if index == 2 {
            share()
        }
    }
}

// MARK: - Private Funcs
private extension VideoDetailViewController {
    
    /// 视频详情信息请求成功回调
    func requestSuccess(_ model: VideoDetailModel) {
        videoModel = model
        viewModel.globalTypeString = model.global_type
        tableView.reloadData()
        // 筛选掉源地址为空的
        fixCorrectSouceLists()
        videoCommentView.favorButton.isSelected = videoModel?.user_collect?.isCollected ?? false
        videoCommentView.favorLable.text = videoCommentView.favorButton.isSelected ? localStr("kAlreadyCollected") : localStr("kCollectedTitle")
    }
    
    /// 获取猜你喜欢,评论列表 数据
    func loadViewModelData() {
        viewModel.videoId = videoId
        viewModel.loadGuessFavorApiData()
        viewModel.loadCommentListData()
    }
    
    /// 添加评论栏点击回调
    func addCommentViewCallBackHandler() {
        videoCommentView.sendCommentTextHandler = { [weak self] (text) in
            guard let strongSelf = self else { return }
            strongSelf.commentAdd(text)
        }
        videoCommentView.favorButtonClickHandler = { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.addFavor()
        }
        videoCommentView.shareButtonClickHandler = { [weak self] in
            self?.share()
        }
        videoCommentView.downloadButtonClickHandler = { [weak self] in
            self?.downloadVideo()
        }
    }
    
    /// 添加viewModel回调
    func addViewModelLoadDataCallBack() {
        /// 猜你x喜欢回调
        viewModel.loadFavorDataSuccessHandler = { [weak self] in
            self?.tableView.reloadData()
        }
        viewModel.loadFavorDataFailHandler = { (empty) in }
        /// 评论列表回调
        viewModel.loadCommentListDataSuccessHandler = { [weak self] in
            self?.tableView.reloadSections([3], with: .none)
        }
        viewModel.loadCommentListDataFailHandler = { [weak self] (empty) in
            self?.tableView.reloadSections([3], with: .none)
        }
        // 添加评论回调
        viewModel.loadCommentApiSuccess = { [weak self] in
            self?.viewModel.loadCommentListData()
            self?.tableView.scrollToRow(at: IndexPath(row: 0, section: 3), at: .bottom, animated: false)
        }
        viewModel.loadCommentApiFail = { [weak self] in
            guard let strongSelf = self else { return }
            XSAlert.show(type: .error, text: strongSelf.localStr("kCommentFailAlert"))
        }
        // 添加收藏添加接口回掉
        viewModel.loadFavorAddApiSuccessHandler = { [weak self] in
            guard let strongSelf = self else { return }
            XSAlert.show(type: .success, text: strongSelf.localStr("kCollectedSuccessAlert"))
            strongSelf.videoCommentView.favorButton.isSelected = true
            strongSelf.videoCommentView.favorLable.text = strongSelf.localStr("kAlreadyCollected")
        }
        viewModel.loadFavorAddApiFailHandler = { [weak self]  (msg) in
            guard let strongSelf = self else { return }
            XSAlert.show(type: .error, text: strongSelf.localStr("kCollectedFailAlert"))
            if msg == XSAlertMessages.kHaveBeenCollectyedMsg {
                self?.videoCommentView.favorButton.isSelected = true
                self?.videoCommentView.favorLable.text = strongSelf.localStr("kAlreadyCollected")
            }
        }
        // 取消收藏回调
        viewModel.loadFavorCancleApiSuccessHandler = { [weak self] in
            self?.videoCommentView.favorButton.isSelected = false
            self?.videoModel?.user_collect = Collected.noCollected
            self?.videoCommentView.favorLable.text = self?.localStr("kCollectedTitle")
        }
        viewModel.loadFavorCancleApiFailHandler = { [weak self] (msg) in
            guard let strongSelf = self else { return }
            XSAlert.show(type: .error, text: strongSelf.localStr("kCancleCollectedFailAlert"))
        }
        // 点赞， 点👎回调
        viewModel.loadUserThumApiSuccessHandler = { [weak self] (isThumUp) in
            let resultModel = self?.viewModel.getThumResultModel()
            if resultModel?.recommend == nil { return }
            if resultModel?.negative == nil { return }
            let recommendSum = self?.videoModel?.recommend_sum ?? 0
            let negativeSum = self?.videoModel?.negative_sum ?? 0
            let isRecoment = self?.videoModel?.user_recommend?.isThumUp ?? false
            let isNegative = self?.videoModel?.user_negative?.isNegative ?? false
            self?.videoModel?.user_recommend = Recommend(rawValue: resultModel!.recommend!)
            self?.videoModel?.user_negative = Negative(rawValue: resultModel?.negative ?? 0)
            if isThumUp {
                if resultModel?.recommend ?? 0 == 0 {
                    self?.videoModel?.recommend_sum = recommendSum > 0 ? recommendSum - 1 : 0
                } else {
                    self?.videoModel?.recommend_sum = recommendSum + 1
                }
                if resultModel?.negative ?? 0 == 0 {
                    self?.videoModel?.negative_sum = (negativeSum > 0 && isNegative) ? negativeSum - 1 : negativeSum
                } else {
                    self?.videoModel?.negative_sum = negativeSum + 1
                }
            } else {
                if resultModel?.negative ?? 0 == 0 {
                    self?.videoModel?.negative_sum = negativeSum > 0 ? negativeSum - 1 : 0
                } else {
                    self?.videoModel?.negative_sum = negativeSum + 1
                }
                if resultModel?.recommend ?? 0 == 0 {
                    self?.videoModel?.recommend_sum = (recommendSum > 0 && isRecoment) ? recommendSum - 1 : recommendSum
                } else {
                    self?.videoModel?.recommend_sum = recommendSum + 1
                }
            }
            self?.tableView.reloadRows(at: [IndexPath.init(row: 0, section: 0)], with: .none)
        }
        viewModel.loadUserThumApiFailHandler = { (msg) in }
    }
    
    func downloadVideo() {
        if DownLoadMannager.share().yagorsDownloading.count >= 3 {
            XSAlert.show(type: .warning, text: "最多允许同时下载3个任务。")
            return
        }
        if currentPalyResource?.video_list != nil && videoModel != nil {
            let videoRes = currentPalyResource!.video_list![currentVideoIndex]
            let videoName = String(format: "%@ %@", videoModel!.title ?? "",videoRes.play_series ?? "")
            let vDirectoryName = String(format: "%d%@", videoModel!.id ?? 0,videoRes.play_url_m3u8 ?? "").md5()
            /// 排重处理
            var isHaveCurrenYagor = false
            for yagor in DownLoadMannager.share().yagors {
                if yagor.directoryName == vDirectoryName {
                    isHaveCurrenYagor = true
                }
            }
            if !isHaveCurrenYagor {
                let model = VideoDownLoad(videoName: videoName, videoDirectory: vDirectoryName, videoDownLoadUrl: videoRes.play_url_m3u8, videoImagePath: videoModel?.cover_path)
                DownLoadMannager.share().downloadViedoWith(model)
                XSAlert.show(type: .success, text: String(format: "已添加到下载列表", videoName))
            } else {
                XSAlert.show(type: .success, text: String(format: "已存在于下载列表", videoName))
            }
            
        }
    }
    
    /// 展示简介
    func showIntroduceView() {
        let introduceVC = VideoIntroduceController()
        introduceVC.videoModel = self.videoModel
        introduceVC.closeButtonClickHandler = {
            introduceVC.view.removeFromSuperview()
            introduceVC.removeFromParent()
        }
        addChild(introduceVC)
        view.addSubview(introduceVC.view)
        introduceVC.view.frame = CGRect(x: 0, y: ConstValue.kScreenHeight, width: ConstValue.kScreenWdith, height: ConstValue.kScreenHeight - ConstValue.kScreenWdith * 9/16 - ConstValue.kStatusBarHeight )
        UIView.animate(withDuration: 0.25) {
            self.layoutCoverChildView(view: introduceVC.view)
            self.view.layoutIfNeeded()
        }
    }
    
    /// 展示电视剧选集
    func showTVSerialCollectView() {
        let tvSerialCollectVc = TVSerialCollectController()
        tvSerialCollectVc.resources = currentPalyResource
        tvSerialCollectVc.currentIndex = currentVideoIndex
        tvSerialCollectVc.closeButtonClickHandler = {
            tvSerialCollectVc.view.removeFromSuperview()
            tvSerialCollectVc.removeFromParent()
        }
        tvSerialCollectVc.itemClickHandler = { [weak self] (index) in
            self?.playVideoInCurrentResource(index)
            self?.tableView.reloadRows(at: [IndexPath(row: 0, section: 1)], with: .none)
        }
        addChild(tvSerialCollectVc)
        view.addSubview(tvSerialCollectVc.view)
        tvSerialCollectVc.view.frame = CGRect(x: 0, y: ConstValue.kScreenHeight, width: ConstValue.kScreenWdith, height:  ConstValue.kScreenHeight - ConstValue.kScreenWdith * 9/16 - ConstValue.kStatusBarHeight )
        UIView.animate(withDuration: 0.25) {
            self.layoutCoverChildView(view: tvSerialCollectVc.view)
            self.view.layoutIfNeeded()
        }
    }
    
    /// 展示综艺节目选集
    func showVarietyShowCollectView() {
        let varietyShowCollectVc = VarietyShowCollectController()
        varietyShowCollectVc.resources = currentPalyResource
        varietyShowCollectVc.currentIndex = currentVideoIndex
        varietyShowCollectVc.closeButtonClickHandler = {
            varietyShowCollectVc.view.removeFromSuperview()
            varietyShowCollectVc.removeFromParent()
        }
        varietyShowCollectVc.itemClickHandler = { [weak self] (index) in
            self?.playVideoInCurrentResource(index)
            self?.tableView.reloadRows(at: [IndexPath(row: 0, section: 1)], with: .none)
        }
        addChild(varietyShowCollectVc)
        view.addSubview(varietyShowCollectVc.view)
        varietyShowCollectVc.view.frame = CGRect(x: 0, y: ConstValue.kScreenHeight, width: ConstValue.kScreenWdith, height:  ConstValue.kScreenHeight - ConstValue.kScreenWdith * 9/16 - ConstValue.kStatusBarHeight )
        UIView.animate(withDuration: 0.25) {
            self.layoutCoverChildView(view: varietyShowCollectVc.view)
            self.view.layoutIfNeeded()
        }
    }
    
    /// 播放当前视频源 第 0 个
    func playVideoInCurrentResource(_ index: Int? = 0) {
        guard let videoResources = videoModel?.resource else { return }
        if videoResources.count == 0 { return }
        if currentPalyResource == nil { return }
        var urlString = ""
        if let list = currentPalyResource!.video_list, list.count > 0 {
            // 帅选掉播放地址为空的源
            let availList = list.filter({ (resouceModel) -> Bool in
                return resouceModel.play_url_m3u8 != nil && !resouceModel.play_url_m3u8!.isEmpty
            })
            if availList.count > (index ?? 0 ) {      // 刷选掉 没有m3u8格式的视频
                urlString = availList[(index ?? 0 )].play_url_m3u8!
                currentPlayResId = availList[(index ?? 0 )].id
                let url = URL(string: urlString)
                UserModel.share().startTime = viewModel.getStartTime()// 记录播放开始时间
                let record = self.readVideoRecordInLocalDB(currentPlayResId)
                addPlayer(url: url, videoName: videoModel?.title ?? "", recordTime: record)
            } else { // 没有m3u8格式的视频，这里添加一个WEB播放H5链接
                let availH5List = list.filter({ (resouceModel) -> Bool in
                    return resouceModel.play_url_h5 != nil && !resouceModel.play_url_h5!.isEmpty
                })
                let web = WebPlayerController()
                web.videoUrl = availH5List[index ?? 0].play_url_h5
                web.title = videoModel?.title ?? ""
                web.videoModel = self.videoModel
                web.navHidenCallBackHandler = { [weak self] (isAnimate) in
                    self?.isNavAnimated = isAnimate
                }
                navigationController?.pushViewController(web, animated: true)
            }
        }
        currentVideoIndex = index ?? 0
        view.bringSubviewToFront(backButton)
    }
    
    /// 初始化播放器
    func addPlayer(url: URL?, videoName: String, recordTime: Float) {
        if isNetWorkStatusWifi() || allowWannaPlay {
            if recordTime > 10.0  {
                // 初始化播放器，并从某个时间点开始播放
                playerView.replayVideo(url, videoModel?.title ?? "", playerBgView, recordTime)
            } else {
                playerView.playVideo(url, videoModel?.title ?? "", playerBgView)
            }
        }
    }
    
    /// 筛选掉空源
    func fixCorrectSouceLists() {
        guard let videoModel = self.videoModel else { return }
        if let infoResourceList = videoModel.resource, infoResourceList.count > 0 {
            let resourceList = infoResourceList.filter({ (resouceModel) -> Bool in
                if let resourceList = resouceModel.video_list, resourceList.count > 0 {
                    return true
                } else {
                    return false
                }
            })
            self.videoModel?.resource = resourceList
            self.videoResourceList = resourceList
            if resourceList.count > 0 {
                // 默认当前播放的源为第0个
                currentPalyResource = resourceList[0]
            }
        }
        playVideoInCurrentResource()
    }
    
    //判断网络状态是否是wifi
    func isNetWorkStatusWifi() -> Bool {
        if NicooNetworkManager.currentNetworkType() == .wifi {
            return true
        }
        return false
    }
    
    /// 判断是否是电影
    func isFlim(_ globalType: String?) -> Bool {
        if globalType != nil {
            if globalType == "film" {
                return true
            } else {
                return false
            }
        }
        return false
    }
    
    /// 获取是否是电视剧 或 综艺节目
    func getVideoType(_ type: String) -> VideoType {
        if type == "teleplay" || type == "cartoon" {
            return .videoTVSerial
        }
        if type == "variety" {
            return .videoVarietyShow
        }
        return .videoTVSerial
    }
    
    /// 获取评论列表
    func getComments() -> [VideoCommentModel] {
        if let comments = viewModel.getCommentModelList() {
            return comments
        }
        return [VideoCommentModel]()
    }
    
    /// 将播放记录存入本地数据库
    func saveVideoToLocalDB() {
        let points = playerView.getNowPlayPositionTimeAndVideoDuration()
        if points.count <= 0 { return }    // 没获取到播放时长， 不存
        let playPoint = points[0]
        if playPoint <= 10.0 { return }    // 播放少于10秒， 不存
        if videoModel?.id == nil { return }
        if currentPlayResId == nil { return }
        let params: [String: Any] = [WatchedVideoListParams.kVideoId: videoModel?.id ?? 0,
                                     WatchedVideoListParams.kVideoName: videoModel?.title ?? localStr("kNot"),
                                     WatchedVideoListParams.kVideoCover_Path: videoModel?.cover_path ?? "",
                                     WatchedVideoListParams.kVideoWatchedPoint: playPoint]
        let store = XSKeyValueStore(dbWithName: ConstValue.kXSVideoLocalDBName)
        if store.isTableExists(ConstValue.kVideoWatchedListTable) {  // 观看历史表存在, 直接插入当前播放的数据
            store.put(params, withId: String(format: "%d", currentPlayResId!), intoTable: ConstValue.kVideoWatchedListTable)
        } else {  // 不存在，创建一个表， 再存
            store.createTable(withName: ConstValue.kVideoWatchedListTable)
            store.put(params, withId: String(format: "%d", currentPlayResId!), intoTable: ConstValue.kVideoWatchedListTable)
        }
    }
  
    /// 读取当前视频是否有观看本地记录
    func readVideoRecordInLocalDB(_ resId: Int?) -> Float {
        if resId == nil { return 0.0 }
        let store = XSKeyValueStore(dbWithName: ConstValue.kXSVideoLocalDBName)
        if let videoKeyValue = store.getObjectById(String(format: "%d", resId!), fromTable: ConstValue.kVideoWatchedListTable) as? [String: Any] {
            return videoKeyValue[WatchedVideoListParams.kVideoWatchedPoint] as! Float
        }
        return 0.0
    }
    
    /// 用户兑换提示框
    private func satisfyAlertShow(_ info: String) {
        guard let window = UIApplication.shared.keyWindow else { return }
        guard let satisfyAlert = Bundle.main.loadNibNamed("SatisfyAlertView", owner: nil, options: nil)?[0] as? SatisfyAlertView else { return }
        satisfyAlert.frame = view.bounds
        satisfyAlert.titleLable.text = "温馨提示"
        satisfyAlert.infoMsgLable.text = info
        window.addSubview(satisfyAlert)
        satisfyAlert.okButtonClickHandler = { [weak self] in
            let convertVC = UserTaskConvertController()
            self?.navigationController?.pushViewController(convertVC, animated: true)
            satisfyAlert.removeFromSuperview()
        }
        satisfyAlert.cancleButtonClickHandler = {
            satisfyAlert.removeFromSuperview()
        }
    }
    
}

// MARK: - UITableViewDataSource
extension VideoDetailViewController: UITableViewDataSource {
   
    func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 2
        } else if section == 1 {
            if let types = videoModel?.type, types.count > 0 {
               return 2
            } else {
               return 1
            }
        } else if section == 2 {
            return 1
        } else if section == 3 {
            if getComments().count > 0 {
                return getComments().count
            } else {
                return 1
            }
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = cellForRow(indexPath: indexPath)
        return cell
    }
    
    func cellForRow(indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            if indexPath.row == 0 {
                let cell = tableView.dequeueReusableCell(withIdentifier: VideoDetailViewController.videoInfoMsgCellId, for: indexPath) as! VideoInfoMsgCell
                cell.introduceBtnClickHandler = { [weak self] in
                    self?.showIntroduceView()
                }
                cell.thumUpBtnClickHandler = { [weak self] (isThumUp) in
                    self?.thumUpButtonClick(isThumUp)
                }
                cell.thumDownBtnClickHandler = { [weak self] (isThumUp) in
                    self?.thumDownButtonClick(isThumUp)
                }
                cell.fadeOrShareButtonClickHandler = { [weak self] (index) in
                    self?.shareOrFadeBackButtonClick(index)
                }
                cell.hotImageHiden = videoModel?.label_status != 1
                cell.videoNameLable.text = videoModel?.title ?? ""
                cell.hotMsgLable.text = "\(getStringWithNumber(videoModel?.play_count ?? 0)) \(localStr("kPlayTimeRightMsg"))" + " \(videoModel?.dist_label ?? "")"
                cell.fromLable.text = "\(localStr("kVideoSouceTitle")) \(self.currentPalyResource?.title ?? "")"
                cell.hotCommentBtn.setTitle("\(getStringWithNumber(videoModel?.comment_sum ?? 0))\(localStr("kHotCommentRightMsg"))", for: .normal)
                cell.thumUpBtn.setTitle("\(getStringWithNumber(videoModel?.recommend_sum ?? 0))", for: .normal)
                cell.thumDownBtn.setTitle("\( getStringWithNumber(videoModel?.negative_sum ?? 0))", for: .normal)
                cell.thumUpBtn.isSelected = videoModel?.user_recommend?.isThumUp ?? false
                cell.thumDownBtn.isSelected = videoModel?.user_negative?.isNegative ?? false
                return cell
            }
            
            if indexPath.row == 1 {
                let cell = tableView.dequeueReusableCell(withIdentifier: VideoResourceCell.cellId, for: indexPath) as! VideoResourceCell
                if let resList = videoModel?.resource, resList.count > 0 {
                    cell.setResource(resList,currentResIndex)
                }
                // 切换源播放
                cell.itemClickHandler = { [weak self] (resourceModel, currentIndex) in
                    guard let strongSelf = self else { return }
                    strongSelf.currentPalyResource = resourceModel
                    strongSelf.currentResIndex = currentIndex
                    strongSelf.tableView.reloadRows(at: [IndexPath(row: 0, section: 1)], with: .none)
                    // 切源后默认播放第一集 (因为不同源，中的集数可能不同，如果播放当前集，可能会导致数组越界)
                    strongSelf.currentVideoIndex = 0
                    strongSelf.tableView.reloadRows(at: [IndexPath(row: 1, section: 1)], with: .none)
                    strongSelf.playVideoInCurrentResource()
                }
                return cell
            }
            
        } else if indexPath.section == 1 {
            if indexPath.row == 0 {
                let cell = tableView.dequeueReusableCell(withIdentifier: VideoDetailViewController.collectChoseCellId, for: indexPath) as! CollectChoseCell
                cell.videoType = getVideoType(videoModel?.global_type ?? "")
                if let videoList = currentPalyResource?.video_list, videoList.count > 0 {
                    cell.setResource(videoList, currentVideoIndex)
                }
                // 选集播放
                cell.itemClickHandler =  { [weak self] (index) in
                    self?.playVideoInCurrentResource(index)
                }
                return cell
            }
            
            if indexPath.row == 1 {
                 let cell = tableView.dequeueReusableCell(withIdentifier: VideoInfoTypeTipsCell.cellId, for: indexPath) as! VideoInfoTypeTipsCell
                if let tips = videoModel?.type, tips.count > 0 {
                     cell.setTips(tips)
                }
               return cell
            }
           
        } else if indexPath.section == 2 {
            let cell = tableView.dequeueReusableCell(withIdentifier: VideoGuessLikeCell.cellId, for: indexPath) as! VideoGuessLikeCell
            cell.setModels(viewModel.getVideoModelList())
            cell.itemClickHandler = { [weak self] (index) in
                guard let strongSelf = self else { return }
                if let model = strongSelf.viewModel.getVideoModel(index) {
                    strongSelf.videoId = model.id ?? 0
                    strongSelf.viewModel.videoId = model.id ?? 0
                    let _ = strongSelf.videoDetailAPI.loadData()
                    strongSelf.viewModel.loadGuessFavorApiData()
                    strongSelf.viewModel.loadCommentListData()
                }
            }
            return cell
        } else if indexPath.section == 3 {
            if getComments().count > 0 {
                let cell = tableView.dequeueReusableCell(withIdentifier: VideoComListCell.cellId, for: indexPath) as! VideoComListCell
                if let commentModel = viewModel.getCommentModel(indexPath.row) {
                    cell.headerImage.kfSetHeaderImageWithUrl(commentModel.cover_path, placeHolder: UIImage(named: "defaultHeader"))
                    cell.nameLable.text = commentModel.name ?? localStr("kUnknownUser")
                    cell.timeLable.text = commentModel.created_at ?? localStr("kUnknownTime")
                    cell.contentLable.attributedText = TextSpaceManager.getAttributeStringWithString(commentModel.content ?? "", lineSpace: 7)
                }
                return cell
            } else {
                let cell = tableView.dequeueReusableCell(withIdentifier: VideoNoDataCell.cellId, for: indexPath) as! VideoNoDataCell
                return cell
            }
        }
        return UITableViewCell()
    }
}

// MARK: - UITableViewDelegate
extension VideoDetailViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            if indexPath.row == 0 {
                return 155
            } else if indexPath.row == 1 {
                return 60
            } else {
                return 0
            }
        } else if indexPath.section == 1 {
            if indexPath.row == 1 {
                return 50
            }
            return 50
        } else if indexPath.section == 2 {
            return 220
        } else if indexPath.section == 3 {
            if getComments().count > 0 {
                tableView.rowHeight = UITableView.automaticDimension
                tableView.estimatedRowHeight = 100.0
                return tableView.rowHeight
            } else {
                return 70
            }
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 { return 0 }
        return 50
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return loadSectionHeaderView(section: section)
    }
    
    func loadSectionHeaderView(section: Int) -> UIView? {
        if section != 0 {
            let headerView = VideoDetailSectionHeaderView.init(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 50))
            headerView.backgroundColor = UIColor.white
            if section == 1 {
                var moreTitle = ""
                var headerTitle = ""
                if let videoList = currentPalyResource?.video_list, videoList.count > 0 {
                    if getVideoType(videoModel?.global_type ?? "") == .videoTVSerial { // 电视剧
                        moreTitle = String(format: "%@%d%@", localStr("kAll"),videoList.count,localStr("kSerial"))
                        headerTitle = localStr("kChoseSerial")
                    }
                    if getVideoType(videoModel?.global_type ?? "") == .videoVarietyShow { // 综艺
                        moreTitle = String(format: "%@%d%@", localStr("kAll"),videoList.count,localStr("kVerity"))
                        headerTitle = localStr("kChoseVerity")
                    }
                }
                headerView.moreButtonHiden = isFlim(videoModel?.global_type)
                headerView.moreInfoLable.text = isFlim(videoModel?.global_type) ? "" : moreTitle
                headerView.titleLable.text = isFlim(videoModel?.global_type) ? localStr("kResolution") : headerTitle
            }
            if section == 2 {
                headerView.moreButtonHiden = true
                headerView.moreInfoLable.text = ""
                headerView.titleLable.text = localStr("kGuessLikeTitle")
            }
            if section == 3 {
                headerView.moreButtonHiden = true
                if getComments().count > 0 {
                    headerView.titleLable.text = "\(localStr("kCommentListTitle"))（\(getComments().count)）"
                } else {
                    headerView.titleLable.text = localStr("kCommentListTitle")
                }
            }
            headerView.moreButtonClickHandler = { [weak self] in
                if section == 1 {
                    DLog("选集")
                    if self?.getVideoType(self?.videoModel?.global_type ?? "") == .videoTVSerial {
                        self?.showTVSerialCollectView()
                    }
                    if self?.getVideoType(self?.videoModel?.global_type ?? "") == .videoVarietyShow {
                         self?.showVarietyShowCollectView()
                    }
                }
                if section == 2 {
                    DLog("猜你喜欢")
                }
            }
            return headerView
            
        } else {
            return nil
        }
       
    }
}

// MARK: - UIScrollViewDelegate
extension VideoDetailViewController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let sectionHeaderHeight: CGFloat = 50
        if scrollView.contentOffset.y <= sectionHeaderHeight && scrollView.contentOffset.y > 0 {
           scrollView.contentInset = UIEdgeInsets(top: -scrollView.contentOffset.y, left: 0, bottom: 0, right: 0)
            
        } else if scrollView.contentOffset.y >= sectionHeaderHeight {
            scrollView.contentInset = UIEdgeInsets(top: -sectionHeaderHeight, left: 0, bottom: 0, right: 0)
        }
    }
    
}

// MARK: - NicooCustomMuneDelegate NicooPlayerDelegate
extension VideoDetailViewController: NicooPlayerDelegate, NicooCustomMuneDelegate {
    
    func retryToPlayVideo(_ player: NicooPlayerView, _ videoModel: NicooVideoModel?, _ fatherView: UIView?) {
        DLog("网络不可用时调用")
        let url = URL(string: videoModel?.videoUrl ?? "")
        if  let sinceTime = videoModel?.videoPlaySinceTime, sinceTime > 0 {
            playerView.replayVideo(url, videoModel?.videoName, fatherView, sinceTime)
        }else {
            playerView.playVideo(url, videoModel?.videoName, fatherView)
        }
        view.bringSubviewToFront(backButton)
    }
    
    /// 播放结束调用
    func currentVideoPlayToEnd(_ videoModel: NicooVideoModel?, _ isPlayingDownLoadFile: Bool) {
        
    }
   
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension VideoDetailViewController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        var parmas = [String: Any]()
        parmas[VideoInfoApi.kVideo_Id] = videoId ?? 0
        return parmas
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is VideoInfoApi {
            if let infoModel = manager.fetchJSONData(VideoReformer()) as? VideoDetailModel {
                requestSuccess(infoModel)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is VideoInfoApi {
            if manager.errorMessage.contains(localStr("kConvertCenterTitle")) {
                satisfyAlertShow(manager.errorMessage)
            } else {
                if !manager.errorMessage.isEmpty {
                    showErrorMessage(manager.errorMessage, cancelHandler: nil)
                }
            }
        }
    }
}

// MARK: - Layout
private extension VideoDetailViewController {
    
    func layoutPageSubviews() {
        layoutStatuBarView()
        layoutPlayerBgView()
        layoutNetworkWarnViewView()
        layoutCommentView()
        layoutTableView()
        layoutBackButton()
    }
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(playerBgView.snp.bottom).offset(1)
            make.bottom.equalTo(videoCommentView.snp.top).offset(-1)
        }
    }
    func layoutBackButton() {
        backButton.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalTo(ConstValue.kStatusBarHeight + 10)
            make.width.height.equalTo(30)
        }
    }
    func layoutPlayerBgView() {
        playerBgView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(statuBarView.snp.bottom)
            make.width.equalTo(ConstValue.kScreenWdith)
            make.height.equalTo(ConstValue.kScreenWdith * 9/16)
        }
    }
    func layoutStatuBarView() {
        statuBarView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(0)
            make.height.equalTo(ConstValue.kStatusBarHeight)
        }
    }
    func layoutCommentView() {
        videoCommentView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalToSuperview()
            }
            make.height.equalTo(50)
        }
    }
    func layoutCoverChildView(view: UIView) {
        view.snp.makeConstraints { (make) in
            make.top.equalTo(tableView)
            make.leading.trailing.equalToSuperview()
            make.bottom.equalTo(videoCommentView.snp.bottom)   
        }
    }
    func layoutNetworkWarnViewView() {
        networkWarningView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(statuBarView.snp.bottom)
            make.width.equalTo(ConstValue.kScreenWdith)
            make.height.equalTo(ConstValue.kScreenWdith * 9/16)
        }
    }
}



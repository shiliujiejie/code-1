//
//  VideoResItem.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/15.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation


struct VideoResItem {
    var selected: Bool = false
    var index: Int = 0
    var videoModel: VideoResource?
}

struct VideoDownLoad {
    var videoName: String?
    var videoDirectory: String?
    var videoDownLoadUrl: String?
    var videoImagePath: String?
    
}

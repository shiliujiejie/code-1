//
//  VideoThumResultModel.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/2.
//  Copyright © 2019年 pro5. All rights reserved.
//

import Foundation

/// 视频详情点赞  返回数据model
struct VideoThumResultModel: Codable  {
    var id: Int?
    var user_id: Int?
    var video_id: Int?
    var recommend: Int?
    var negative: Int?
    var created_at: String?
    var updated_at: String?
    
}

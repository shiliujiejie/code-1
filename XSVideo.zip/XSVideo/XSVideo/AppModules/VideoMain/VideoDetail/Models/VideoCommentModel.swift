//
//  VideoCommentModel.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/14.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation

/// 视频评论Model
struct VideoCommentModel: Codable {
    var id: Int?
    var video_id: Int?
    var global_type: String?
    var user_id: Int?
    var content: String?
    var status: Int?
    var created_at: String?
    var updated_at: String?
    var name: String?
    var email: String?
    var cover_path: String?
    
}

/// 视频评论列表
struct VideoCommentListModel: Codable {
    var current_page: Int?
    var data: [VideoCommentModel]?
}

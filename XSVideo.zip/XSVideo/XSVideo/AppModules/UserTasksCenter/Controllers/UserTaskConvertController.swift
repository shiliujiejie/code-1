//
//  UserTaskCovertController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/20.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class UserTaskConvertController: UIViewController {

    private lazy var headerView: TaskConvertHeaderView =  {
        let view = TaskConvertHeaderView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 190 + ConstValue.kStatusBarHeight))
        return view
    }()
    private lazy var headerFakeBg: UIImageView = {
        let imageview = UIImageView()
        imageview.image = UIImage(named: "maskTaskCenter")
        return imageview
    }()
    private lazy var fakeNavBar: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.clear
        return view
    }()
    private lazy var backButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "navBackWhite"), for: .normal)
        button.addTarget(self, action: #selector(backButtonClick), for: .touchUpInside)
        return button
    }()
    var navLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.white
        lable.textAlignment = .center
        lable.font = UIFont.boldSystemFont(ofSize: 18)
        lable.text = localStr("kConvertCenterTitle")
        return lable
    }()
    private lazy var lineView: UIView = {
        let line = UIView()
        line.backgroundColor = UIColor.clear
        return line
    }()
    private lazy var tableView: UITableView = {
        let table = UITableView()
        table.backgroundColor = UIColor.clear
        table.showsVerticalScrollIndicator = false
        table.allowsSelection = false
        table.delegate = self
        table.dataSource = self
        table.separatorStyle = .none
        table.tableHeaderView = headerView
        table.register(UINib(nibName: "ConvertItemCell", bundle: Bundle.main), forCellReuseIdentifier: ConvertItemCell.cellId)
        return table
    }()
    let viewModel = ConvertViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        addPageSubviews()
        addViewModelCallBackHandler()
        loadConvertListData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
        refreshHeaderView()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
       // navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    func loadConvertListData() {
        XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        NicooErrorView.removeErrorMeesageFrom(view)
        viewModel.loadConvertList()
    }
    
    func addPageSubviews() {
        view.addSubview(headerFakeBg)
        view.addSubview(tableView)
        view.addSubview(fakeNavBar)
        fakeNavBar.addSubview(backButton)
        fakeNavBar.addSubview(navLable)
        fakeNavBar.addSubview(lineView)
        addHeaderButtonClickHandler()
        layoutPageSubviews()
    }
    
    func createSectionHeaderView() -> UIView? {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 45))
        view.backgroundColor = UIColor.white
        let tipsView = UIView(frame: CGRect(x: 15, y: 12.5, width: 5, height: 20))
        tipsView.layer.cornerRadius = 1.5
        tipsView.backgroundColor = ConstValue.kAppDefaultColor
        view.addSubview(tipsView)
        let lable = UILabel()
        lable.text = localStr("kConvertListTitle")
        lable.font = UIFont.boldSystemFont(ofSize: 18)
        view.addSubview(lable)
        layoutSectionHeaderTipsView(tipsView)
        layoutSectionTitleLable(lable)
        return view
    }
    
    func addHeaderButtonClickHandler() {
        headerView.headerButtonClickHandler = { }
    }
    
    func addViewModelCallBackHandler() {
        viewModel.loadConvertListSuccessHandler = { [weak self] in
            guard let strongSelf = self else { return }
            NicooErrorView.removeErrorMeesageFrom(strongSelf.view)
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            strongSelf.tableView.reloadData()
        }
        viewModel.loadConvertListFailHandler = { [weak self] (msg)in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            NicooErrorView.showErrorMessage(.noNetwork, on: strongSelf.view, clickHandler: {
                strongSelf.loadConvertListData()
            })
        }
        viewModel.loadConvertTaskSuccessHandler = { [weak self] in
            guard let strongSelf = self else { return }
            XSAlert.show(type: .success, text: strongSelf.localStr("kConvertSuccessAlert"))
            strongSelf.refreshHeaderView()
        }
        viewModel.loadConvertTaskFailHandler = { [weak self] (msg) in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            strongSelf.showErrorMessage(msg, cancelHandler: nil)
        }
    }
    
    @objc func backButtonClick() {
        navigationController?.popViewController(animated: true)
    }
    
    func convertTask(_ index: Int) {
        if UserModel.share().isLogin && UserModel.share().isRealUser {
            showDialogForConvert(index)
        } else {
            LoginManager().login(nil)
        }
    }
    
    func showDialogForConvert(_ index: Int) {
        showDialog(title: nil, message: XSAlertMessages.kConvertTasksOrNot, okTitle: localStr("kConvertNow"), cancelTitle: localStr("kCancle"), okHandler: { [weak self] in
            guard let strongSelf = self else { return }
            XSProgressHUD.showProgress(msg: nil, onView: strongSelf.view, animated: false)
            strongSelf.viewModel.loadConvertTask(index)
        }, cancelHandler: nil)
    }
    
    func refreshHeaderView() {
        headerView.coinCountLable.text = "\(UserModel.share().coins ?? 0)"
        headerView.headerButton.kfSetHeaderImageWithUrl(UserModel.share().cover_path, placeHolder: ConstValue.kDefaultHeader)
    }
    
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension UserTaskConvertController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.getConvertList().count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: ConvertItemCell.cellId, for: indexPath) as! ConvertItemCell
        let convertModel = viewModel.getConvertModel(indexPath.row)

        cell.convertName.text = convertModel.title ?? ""
        cell.convertImage.image = viewModel.getConvertImage(indexPath.row)
        cell.convertDoBtn.isEnabled = !(convertModel.sign?.isDone ?? false)
        cell.coinCountBtn.setTitle("- \(convertModel.coins ?? 0)\(localStr("kAiDouCoins"))", for: .normal)
        cell.availTimeLab.text = "\(localStr("kAvailTimeTitle")) \(convertModel.untile ?? "")"
        let taskDoTitle = viewModel.getConvertDoButtonTitle(indexPath.row)
        cell.convertDoBtn.setTitle(taskDoTitle , for: .normal)
        cell.convertDoBtn.setTitle(taskDoTitle , for: .disabled)
        cell.convertButtonCliclHandler = { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.convertTask(indexPath.row)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 45
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return createSectionHeaderView()
    }
    
    
}

// MARK: - UIScrollViewDelegate
extension UserTaskConvertController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let sectionHeaderHeight: CGFloat = 45
        if scrollView.contentOffset.y <= sectionHeaderHeight && scrollView.contentOffset.y > 0 {
            scrollView.contentInset = UIEdgeInsets(top: -scrollView.contentOffset.y, left: 0, bottom: 0, right: 0)
            
        } else if scrollView.contentOffset.y >= sectionHeaderHeight {
            scrollView.contentInset = UIEdgeInsets(top: -sectionHeaderHeight, left: 0, bottom: 0, right: 0)
        }
        if scrollView.contentOffset.y > 90 {
            fakeNavBar.backgroundColor = UIColor.white
            navLable.textColor = UIColor.darkText
            backButton.setImage(UIImage(named: "navBackDefault"), for: .normal)
            lineView.backgroundColor = UIColor(white: 0.1, alpha: 0.2)
        } else {
            fakeNavBar.backgroundColor = UIColor.clear
            lineView.backgroundColor = UIColor.clear
            backButton.setImage(UIImage(named: "navBackWhite"), for: .normal)
            navLable.textColor = UIColor.white
        }
    }
    
}

// MARK: - Layout
private extension UserTaskConvertController {
    
    func layoutPageSubviews() {
        layoutHeaderFakeBg()
        layoutTableView()
        layoutFakeNavBarView()
        layoutBackButton()
        layoutNavLable()
        layoutLineView()
    }
    
    func layoutBackButton() {
        backButton.snp.makeConstraints { (make) in
            make.top.equalTo(ConstValue.kStatusBarHeight + 5)
            make.leading.equalTo(15)
            make.width.equalTo(30)
            make.height.equalTo(30)
        }
    }
    
    func layoutLineView() {
        lineView.snp.makeConstraints { (make) in
            make.leading.trailing.bottom.equalToSuperview()
            make.height.equalTo(0.25)
        }
    }
    
    func layoutNavLable() {
        navLable.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(ConstValue.kStatusBarHeight + 10)
            make.height.equalTo(24)
        }
    }
    
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            make.top.equalTo(0)
            make.leading.trailing.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalToSuperview()
            }
        }
    }
    
    func layoutFakeNavBarView() {
        fakeNavBar.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(ConstValue.kNavigationBarHeight + ConstValue.kStatusBarHeight)
        }
    }
    
    func layoutHeaderFakeBg() {
        headerFakeBg.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(-ConstValue.kStatusBarHeight)
            make.height.equalTo(250)
        }
    }
    
    func layoutSectionHeaderTipsView(_ tipsView: UIView) {
        tipsView.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(15)
            make.centerY.equalToSuperview()
            make.height.equalTo(20)
            make.width.equalTo(5)
        }
    }
    
    func layoutSectionTitleLable(_ lable: UILabel) {
        lable.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(30)
            make.centerY.equalToSuperview()
            make.height.equalTo(20)
        }
    }
}

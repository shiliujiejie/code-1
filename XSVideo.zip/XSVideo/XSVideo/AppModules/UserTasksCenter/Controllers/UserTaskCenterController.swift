//
//  UserTaskCenterController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/19.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class UserTaskCenterController: UIViewController {
    
    private lazy var headerView: TaskCenterHeaderView =  {
        let view = TaskCenterHeaderView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 250 + ConstValue.kStatusBarHeight))
        return view
    }()
    private lazy var headerFakeBg: UIImageView = {
        let imageview = UIImageView()
        imageview.isUserInteractionEnabled = true
        imageview.image = UIImage(named: "maskTaskCenter")
        return imageview
    }()
    private lazy var fakeNavBar: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.clear
        return view
    }()
    private lazy var lineView: UIView = {
        let line = UIView()
        line.backgroundColor = UIColor.clear
        return line
    }()
   private lazy var navLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.white
        lable.textAlignment = .center
        lable.font = UIFont.boldSystemFont(ofSize: 18)
        lable.text = localStr("kTaskCenterTitle")
        return lable
    }()
    private lazy var tableView: UITableView = {
        let table = UITableView()
        table.backgroundColor = UIColor.clear
        table.showsVerticalScrollIndicator = false
        table.allowsSelection = false
        table.delegate = self
        table.dataSource = self
        table.separatorStyle = .none
        table.tableHeaderView = headerView
        table.register(UINib(nibName: "TaskDailyCell", bundle: Bundle.main), forCellReuseIdentifier: TaskDailyCell.cellId)
        return table
    }()
    /// 是否是第一次加载数据
    var isFirstLoad = true
    let viewModel = TasksViewModel()
    var daiySiginInIndex: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        addPageSubviews()
        addViewModelCallBackHandler()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: isNavAnimated ? animated : false)
        isNavAnimated = false
        headerView.headerButton.kfSetHeaderImageWithUrl(UserModel.share().cover_path, placeHolder: ConstValue.kDefaultHeader)
        loadTaskList()
    }
    
}

// MARK: - Privite - Funcs
private extension UserTaskCenterController {
    
    func loadTaskList() {
        NicooErrorView.removeErrorMeesageFrom(view)
        if isFirstLoad {
            XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        }
        viewModel.loadTasksList()
    }
    
    func addPageSubviews() {
        view.addSubview(headerFakeBg)
        view.addSubview(tableView)
        view.addSubview(fakeNavBar)
        fakeNavBar.addSubview(lineView)
        fakeNavBar.addSubview(navLable)
        layoutPageSubviews()
        addHeaderButtonClickCallBackHandler()
    }
    
    func addHeaderButtonClickCallBackHandler() {
        headerView.headerButtonClickHandler = {
            
        }
        headerView.inviteButtonClickHandler = { [weak self] in
            if UserModel.share().isLogin {
                let myinviteVC = MyPopularController()
                myinviteVC.navHidenCallBackHandler = { [weak self] (isAnimate) in
                    self?.isNavAnimated = isAnimate
                }
                self?.navigationController?.pushViewController(myinviteVC, animated: true)
            } else {
                LoginManager().login(nil)
            }
        }
        headerView.convertButtonClickHandler = { [weak self] in
            let taskConvertVC = UserTaskConvertController()
            self?.navigationController?.pushViewController(taskConvertVC, animated: true)
        }
    }
    
    func addViewModelCallBackHandler() {
        viewModel.loadTaskListSuccessHandler = { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.isFirstLoad = false
            NicooErrorView.removeErrorMeesageFrom(strongSelf.view)
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            strongSelf.tableView.reloadData()
        }
        
        viewModel.loadTaskListFailHandler = { [weak self] in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            if strongSelf.isFirstLoad {
                NicooErrorView.showErrorMessage(.noNetwork, on: strongSelf.view, clickHandler: {
                    strongSelf.loadTaskList()
                })
            }
        }
        
        viewModel.dailySignInSuccessHandler = { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.viewModel.loadTasksList()
        }
        viewModel.dailySignInFailHandler = { [weak self]  (mesg) in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            if mesg != nil && !mesg!.isEmpty {
                XSAlert.show(type: .error, text: mesg!)
            }
        }
    }
    
    func createSectionHeaderView(_ section: Int) -> UIView? {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 45))
        view.backgroundColor = UIColor.white
        let tipsView = UIView(frame: CGRect(x: 15, y: 12.5, width: 5, height: 20))
        tipsView.layer.cornerRadius = 1.5
        tipsView.backgroundColor = ConstValue.kAppDefaultColor
        view.addSubview(tipsView)
        let lable = UILabel()
        lable.text = viewModel.getSectionTitle(section)
        lable.font = UIFont.boldSystemFont(ofSize: 18)
        view.addSubview(lable)
        layoutSectionHeaderTipsView(tipsView)
        layoutSectionTitleLable(lable)
        return view
    }
    
    /// 做任务
    ///
    /// - Parameter index: 任务index
    func doUserTasks(_ indexPath: IndexPath) {
        if UserModel.share().isLogin && UserModel.share().isRealUser {
            let taskModel = viewModel.getTaskModel(indexPath)
            if taskModel.key == TaskType.watchVideo || taskModel.key == TaskType.adClick || taskModel.key == TaskType.share {
                tabBarController?.selectedIndex = 0
            } else if taskModel.key == TaskType.invite {
                let inviteCodeVC = InviteCodeController()
                navigationController?.pushViewController(inviteCodeVC, animated: true)
            } else if taskModel.key == TaskType.signIn {
                /// 调用签到接口
                XSProgressHUD.showProgress(msg: nil, onView: view, animated: false)
                viewModel.dailySignin()
            }
        }  else {
            DLog("请登录, 登录回来，要在请求一次任务列表API")
            LoginManager().login { [weak self] in
                self?.viewModel.loadTasksList()
            }
        }
    }
    
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension UserTaskCenterController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return viewModel.getSectionCount()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 100.0
        return tableView.rowHeight
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.getRowCount(section)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: TaskDailyCell.cellId, for: indexPath) as! TaskDailyCell
        let taskModel = viewModel.getTaskModel(indexPath)
        
        cell.taskDesLable.attributedText = TextSpaceManager.getAttributeStringWithString( taskModel.remark ?? "", lineSpace: 5)
        cell.taskName.text = taskModel.title ?? ""
        cell.taskImage.kfSetHeaderImageWithUrl(taskModel.icon, placeHolder: UIImage(named: "starHeaderPh"))
        cell.taskDoButton.isEnabled = !(taskModel.sign?.isDone ?? false)
        cell.taskEarnCount.setTitle("+ \(taskModel.coins ?? 0)\(localStr("kAiDouCoins"))", for: .normal)
        let taskDoTitle = viewModel.getTaskDoButtonTitle(indexPath)
        cell.taskDoButton.setTitle(taskDoTitle , for: .normal)
        cell.taskDoButton.setTitle(taskDoTitle , for: .disabled)
        cell.doButtonClickHandler = { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.doUserTasks(indexPath)
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 45
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return createSectionHeaderView(section)
    }
    
    
}

// MARK: - UIScrollViewDelegate
extension UserTaskCenterController: UIScrollViewDelegate {
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let sectionHeaderHeight: CGFloat = 45
        if scrollView.contentOffset.y <= sectionHeaderHeight && scrollView.contentOffset.y > 0 {
            scrollView.contentInset = UIEdgeInsets(top: -scrollView.contentOffset.y, left: 0, bottom: 0, right: 0)
            
        } else if scrollView.contentOffset.y >= sectionHeaderHeight {
            scrollView.contentInset = UIEdgeInsets(top: -sectionHeaderHeight, left: 0, bottom: 0, right: 0)
        }
        if scrollView.contentOffset.y > 130 {
            fakeNavBar.backgroundColor = UIColor.white
            navLable.textColor = UIColor.darkText
            lineView.backgroundColor = UIColor(white: 0.1, alpha: 0.2)
        } else {
            fakeNavBar.backgroundColor = UIColor.clear
            lineView.backgroundColor = UIColor.clear
            navLable.textColor = UIColor.white
        }
    }
    
}

// MARK: - Layout
private extension UserTaskCenterController {
    
    func layoutPageSubviews() {
        layoutHeaderFakeBg()
        layoutTableView()
        layoutFakeNavBarView()
        layoutNavLable()
        layoutLineView()
    }
    
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            make.top.equalTo(0)
            make.leading.trailing.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalToSuperview()
            }
        }
    }
    
    func layoutHeaderFakeBg() {
        headerFakeBg.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(-ConstValue.kStatusBarHeight)
            make.height.equalTo(300)
        }
    }
    
    func layoutFakeNavBarView() {
        fakeNavBar.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(ConstValue.kNavigationBarHeight + ConstValue.kStatusBarHeight)
        }
    }
    
    func layoutNavLable() {
        navLable.snp.makeConstraints { (make) in
            make.centerY.equalTo(ConstValue.kStatusBarHeight + ConstValue.kNavigationBarHeight/2)
            make.centerX.equalToSuperview()
            make.height.equalTo(24)
        }
    }
    
    func layoutLineView() {
        lineView.snp.makeConstraints { (make) in
            make.leading.trailing.bottom.equalToSuperview()
            make.height.equalTo(0.25)
        }
    }
    
    func layoutSectionHeaderTipsView(_ tipsView: UIView) {
        tipsView.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(15)
            make.centerY.equalToSuperview()
            make.height.equalTo(20)
            make.width.equalTo(5)
        }
    }
    
    func layoutSectionTitleLable(_ lable: UILabel) {
        lable.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(30)
            make.centerY.equalToSuperview()
            make.height.equalTo(20)
        }
    }
    
}

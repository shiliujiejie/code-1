//
//  ConvertViewModel.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/20.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// 兑换中心ViewModel
class ConvertViewModel: NSObject {
    
    private lazy var convertListApi: UserConvertListApi = {
        let api = UserConvertListApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var convertApi: UserCovertApi = {
        let api = UserCovertApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    
    var loadConvertListSuccessHandler:(() -> Void)?
    var loadConvertListFailHandler:((_ msg: String) -> Void)?
    
    var loadConvertTaskSuccessHandler:(() -> Void)?
    var loadConvertTaskFailHandler:((_ msg: String) -> Void)?
    
    var convertList: [ConvertModel]?
    var convertTaskIndex: Int?
    let userInfo = UserInfoViewModel()
    
    /// 查询兑换列表
    func loadConvertList() {
        let _  = convertListApi.loadData()
    }
    
    /// 兑换操作
    func loadConvertTask(_ index: Int) {
        convertTaskIndex = index
        let _ = convertApi.loadData()
    }
    
}

// MARK: - Fix - ConvertListData
extension ConvertViewModel {
    
    func requestConvertListSuccess(_ convertList: [ConvertModel]) {
        self.convertList = convertList
        loadConvertListSuccessHandler?()
    }
    
    func getConvertList() -> [ConvertModel] {
        if convertList != nil, convertList!.count > 0 {
            return convertList!
        }
        return [ConvertModel]()
    }
    
    func getConvertModel(_ index: Int) -> ConvertModel {
        if convertList != nil, convertList!.count > index {
            return convertList![index]
        }
        return ConvertModel()
    }
    
    func getConvertImage(_ index: Int) -> UIImage? {
        let convert = getConvertModel(index)
        if convert.key == ConvertType.convert_HD {
            return UIImage(named: "watch_HD")
        }
        if convert.key == ConvertType.convert_Thrid {
            return UIImage(named: "watchThird")
        }
        if convert.key == ConvertType.convert_Nine {
            return UIImage(named: "newUserConverIcon")
        }
        if convert.key == ConvertType.convert_Ten {
            return UIImage(named: "watchTen")
        }
        if convert.key == ConvertType.convert_DailyFree {
            return UIImage(named: "dailyFree")
        }
        if convert.key == ConvertType.convert_Free {
            return UIImage(named: "watchFree")
        }
        return ConstValue.kHorizontalPHImage
    }
    
    func getConvertDoButtonTitle(_ index: Int) -> String {
        let convert = getConvertModel(index)
        return (convert.sign?.isDone ?? false) ? UIViewController.localStr("kHaveConverted") : UIViewController.localStr("kConvertNow")
    }
    
    func loadConvertTaskSuccess() {
        let _ = convertListApi.loadData()
        let convertModel = getConvertModel(convertTaskIndex ?? 0)
        if UserModel.share().coins != nil && UserModel.share().coins! > (convertModel.coins ?? 0) {
            UserModel.share().coins = UserModel.share().coins! - (convertModel.coins ?? 0)
        }
        userInfo.loadUserInfo()
        loadConvertTaskSuccessHandler?()
    }
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParameterEncodeing
extension ConvertViewModel: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        var params = [String: Any]()
        if manager is UserCovertApi {
            let convertModel = getConvertModel(convertTaskIndex ?? 0)
            let convertType = convertModel.key?.rawValue
            params[UserCovertApi.kEvent] = convertType
            return params
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        if manager is UserConvertListApi {
            if let convertList = manager.fetchJSONData(UserConvertReformer()) as? [ConvertModel] {
                requestConvertListSuccess(convertList)
            }
        }
        if manager is UserCovertApi {
             loadConvertTaskSuccess()
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        if manager is UserCovertApi {
            loadConvertTaskFailHandler?(manager.errorMessage)
        }
        if manager is UserConvertListApi {
            loadConvertListFailHandler?(manager.errorMessage)
        }
    }
    
}

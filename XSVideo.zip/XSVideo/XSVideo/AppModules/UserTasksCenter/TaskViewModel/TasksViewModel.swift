//
//  TasksViewModel.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/20.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import NicooNetwork

/// 任务中心ViewMedel
class TasksViewModel: NSObject {
    
    private lazy var watchSatisfyApi: WatchVideoSatisfyApi = {
        let api = WatchVideoSatisfyApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var dailySigninApi: UserDailySigninApi = {
        let api = UserDailySigninApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var taskListApi: UserTaskListApi = {
        let api = UserTaskListApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var convertListApi: UserConvertListApi = {
        let api = UserConvertListApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    /// 任务列表回调
    var loadTaskListSuccessHandler:(() -> Void)?
    var loadTaskListFailHandler:(() -> Void)?
    /// 签到回调
    var dailySignInSuccessHandler:(() -> Void)?
    var dailySignInFailHandler:((_ msg: String?) -> Void)?
   
    
    var taskList: [TaskModel]?
    var taskGroups = [[TaskModel]]()
    let userInfo = UserInfoViewModel()
    
    /// 查询任务列表
    func loadTasksList() {
        let _  = taskListApi.loadData()
    }
    
    /// 查询兑换列表
    func loadConvertList() {
        let _  = convertListApi.loadData()
    }
    
    /// 签到
    func dailySignin() {
        let _ = dailySigninApi.loadData()
    }
    
    /// 领取观影奖励
    func getWatchSatisfy() {
        let _ = watchSatisfyApi.loadData()
    }

}

// MARK: - Fix - TaskListData
extension TasksViewModel {
    
    private func requestTaskListSuccess(_ taskList: [TaskModel]) {
        self.taskList = taskList
        taskGroups.removeAll()
        var dailyTasks = [TaskModel]()
        var extentTasks = [TaskModel]()
        for task in taskList {
            if task.group == TaskGroup.daily {
                dailyTasks.append(task)
            } else {
                extentTasks.append(task)
            }
        }
        if extentTasks.count > 0 {
            taskGroups.append(extentTasks)
        }
        if dailyTasks.count > 0 {
            taskGroups.append(dailyTasks)
        }
        loadTaskListSuccessHandler?()
    }
    
    func getSectionCount() -> Int {
        return taskGroups.count
    }
    
    func getRowCount(_ section: Int) -> Int {
        return taskGroups[section].count
    }
    
    func getSectionTitle(_ section: Int) -> String {
        if taskGroups.count == 0 { return ""}
        let task = taskGroups[section][0]
        if task.group == TaskGroup.daily {
            return UIViewController.localStr("kDailyTaskTitle")
        } else {
            return UIViewController.localStr("kExtentTaskTitle")
        }
    }
    
    func getTaskGroups() -> [[TaskModel]] {
        return taskGroups
    }
    
    func getTaskList() -> [TaskModel] {
        if taskList != nil, taskList!.count > 0 {
            return taskList!
        }
        return [TaskModel]()
    }
    
    func getTaskModel(_ indexPath: IndexPath) -> TaskModel {
        let task = taskGroups[indexPath.section][indexPath.row]
        return task
    }
    
    func getTaskDoButtonTitle(_ indexPath: IndexPath) -> String {
        let task = getTaskModel(indexPath)
        if task.key == TaskType.watchVideo {
            return (task.sign?.isDone ?? false) ? UIViewController.localStr("kFinishTaskStatu") : UIViewController.localStr("kGoFinshWatchTask")
        }
        if task.key == TaskType.signIn {
            return (task.sign?.isDone ?? false) ? UIViewController.localStr("kFinishDailySignInTaskStatu") : UIViewController.localStr("kGoFinishSigninTask")
        }
        if task.key == TaskType.invite {
            return (task.sign?.isDone ?? false) ? UIViewController.localStr("kFinishTaskStatu") : UIViewController.localStr("kGoFinishInviteTask")
        }
        if task.key == TaskType.share {
            return (task.sign?.isDone ?? false) ? UIViewController.localStr("kFinishShareTaskStatu") : UIViewController.localStr("kGoFinishShareTask")
        }
        if task.key == TaskType.adClick {
            return (task.sign?.isDone ?? false) ? UIViewController.localStr("kFinishTaskStatu") : UIViewController.localStr("kGoFinishAdClickTask")
        }
        return ""
    }
}

// MARK: - TasksCallBack
extension TasksViewModel {
    
    func dailySigninSuccess() {
        dailySignInSuccessHandler?()
        userInfo.loadUserInfo()
    }
    
    func watchVideoSatisfySuccess() {
        /// 标记当日已经领取过奖励
        UserDefaults.standard.set(getCurrentDay(), forKey: UserDefaults.kLastTimeDay)
        UserModel.share().watchedTime = 0
        userInfo.loadUserInfo()
    }
    
    /// 获取当日时间，并转换为字符串
    ///
    /// - Returns: 时间字符串 "yyyy-MM-dd" 格式
    func getCurrentDay()-> String {
        let now = Date()
        let dataFormater = DateFormatter()
        dataFormater.dateFormat = "yyyy-MM-dd"
        let nowDay = dataFormater.string(from: now)
        return nowDay
    }
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParameterEncodeing
extension TasksViewModel: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        if manager is UserTaskListApi {
            if let taskList = manager.fetchJSONData(UserTasksReformer()) as? [TaskModel] {
                requestTaskListSuccess(taskList)
            }
        }
        if manager is UserDailySigninApi {
            dailySigninSuccess()
        }
        if manager is WatchVideoSatisfyApi {
            watchVideoSatisfySuccess()
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        if manager is UserTaskListApi {
            loadTaskListFailHandler?()
        }
        if manager is UserDailySigninApi {
            dailySignInFailHandler?(manager.errorMessage)
        }
    }
    
}

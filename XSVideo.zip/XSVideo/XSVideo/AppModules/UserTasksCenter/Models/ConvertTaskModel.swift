//
//  ConvertTaskModel.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/20.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation

/// 是否完成任务
enum ConvertCompleted: Int, Codable {
    case notCompleted = 0    // 未完成
    case completed = 1 // 完成
    var isDone: Bool {
        switch self {
        case .completed:
            return true
        case .notCompleted:
            return false
        }
    }
}

/// 兑换类型
///
/// - convert_HD: 蓝光，高清兑换
/// - convert_Thrid: 当日3次观影次数
/// - convert_Nine: 当日9次观影次数 （新手福利）
/// - convert_Ten: 当日10次观影次数
/// - convert_DailyFree: 当日无限次数观影
/// - convert_Free: 永久观影
enum ConvertType: String, Codable {
    case convert_HD = "CONVERT_HD"
    case convert_Thrid = "CONVERT_DAILY_VIEW_COUNT_3"
    case convert_Nine = "CONVERT_DAILY_VIEW_COUNT_9"
    case convert_Ten = "CONVERT_DAILY_VIEW_COUNT_10"
    case convert_DailyFree = "CONVERT_DAILY_VIEW_COUNT_NO"
    case convert_Free = "CONVERT_ALL_VIEW_COUNT_NO"
}

/// 兑换model
struct ConvertModel: Codable {
    var id: Int?
    /// 类型
    var key: ConvertType?
    /// 名称
    var title: String?
    /// 兑换等级说明
    var untile: String?
    /// 兑换所需金币
    var coins: Int?
    var remark: String?
    var status: Int?
    var created_at: String?
    var updated_at: String?
    /// 是否兑换完成
    var sign: ConvertCompleted?
}


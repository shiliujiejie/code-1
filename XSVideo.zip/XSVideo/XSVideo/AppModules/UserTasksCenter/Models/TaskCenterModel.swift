//
//  TaskCenterModel.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/20.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation

/// 是否完成任务
enum TaskCompleted: Int, Codable {
    case notCompleted = 0    // 未完成
    case completed = 1 // 完成
    var isDone: Bool {
        switch self {
        case .completed:
            return true
        case .notCompleted:
            return false
        }
    }
}

/// 任务类型
///
/// - signIn: 签到
/// - watchVideo: 观影
/// - invite: 邀请用户
/// - share: 分享
/// - adClick: 点击广告
enum TaskType: String, Codable {
    case signIn = "SAILY_SIGN_IN"
    case watchVideo = "LOOKED_VIDEO_SATISFY"
    case invite = "INVITE_REGISTER"
    case share = "DAILY_SHARED"
    case adClick = "CLICK_AD"  
}
///
/// 任务分组
///
/// - extend: 推广任务
/// - daily: 日常任务
enum TaskGroup: String, Codable {
    case extend = "extend"
    case daily = "daily"
}

/// 任务model
struct TaskModel: Codable {
    var id: Int?
    /// 类型
    var key: TaskType?
    var group: TaskGroup?
    /// 名称
    var title: String?
    /// icon
    var icon: String?
    /// 奖励金
    var coins: Int?
    var remark: String?
    var status: Int?
    /// 只有观影有， 时长要求
    var extend: String?
    var created_at: String?
    var updated_at: String?
    /// 是否完成
    var sign: TaskCompleted?
}

//
//  TaskConvertHeaderView.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/20.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 兑换中心头部
class TaskConvertHeaderView: UIView {

    private lazy var bgImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.backgroundColor = ConstValue.kAppDefaultColor
        imageView.isUserInteractionEnabled = true
        imageView.image = UIImage(named: "maskTaskCenter")
        return imageView
    }()
    private lazy var backButton: UIButton = {
        let button = UIButton(type: .custom)
        button.isHidden = true
        return button
    }()
    var navLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.white
        lable.isHidden = true
        return lable
    }()
    var msgLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.white
        lable.textAlignment = .center
        lable.font = UIFont.boldSystemFont(ofSize: 16)
        lable.text = UIViewController.localStr("kMyAiDouCoinsCountTitle")
        return lable
    }()
    lazy var headerButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(ConstValue.kDefaultHeader, for: .normal)
        button.layer.cornerRadius = 35
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return button
    }()
    var coinCountLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.white
        lable.textAlignment = .right
        lable.font = UIFont.boldSystemFont(ofSize: 18)
        return lable
    }()
    private lazy var goldCoinButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "goldCoin"), for: .normal)
        button.isUserInteractionEnabled = false
        return button
    }()
    var backButtonClickHandler:(() -> Void)?
    var headerButtonClickHandler:(() -> Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.white
        addSubview(bgImageView)
        addSubview(backButton)
        addSubview(navLable)
        addSubview(headerButton)
        addSubview(msgLable)
        addSubview(coinCountLable)
        addSubview(goldCoinButton)
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    @objc private func buttonClick(_ sender: UIButton) {
        if sender == backButton {
            backButtonClickHandler?()
        }
        if sender == headerButton {
            headerButtonClickHandler?()
        }
    }
    
}

// MARK: - Layout
private extension TaskConvertHeaderView {
    
    func layoutPageSubviews() {
        layoutBgimage()
        layoutBackButton()
        layoutNavLable()
        layoutHeaderImage()
        layoutMsgLable()
        layoutCoinCountLable()
        layoutCoinButton()
    }
    
    func layoutBgimage() {
        bgImageView.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(189 + ConstValue.kStatusBarHeight)
        }
    }
    
    func layoutBackButton() {
        backButton.snp.makeConstraints { (make) in
            make.top.equalTo(ConstValue.kStatusBarHeight + 5)
            make.leading.equalTo(15)
            make.width.equalTo(30)
            make.height.equalTo(30)
        }
    }
    
    func layoutNavLable() {
        navLable.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(ConstValue.kStatusBarHeight + 10)
            make.height.equalTo(24)
        }
    }
    
    func layoutHeaderImage() {
        headerButton.snp.makeConstraints { (make) in
            make.leading.equalTo(backButton)
            make.top.equalTo(navLable.snp.bottom).offset(0)
            make.height.width.equalTo(70)
        }
    }
    
    func layoutMsgLable() {
        msgLable.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(headerButton.snp.top).offset(10)
            make.height.equalTo(20)
        }
    }
    
    func layoutCoinCountLable() {
        coinCountLable.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview().offset(-10)
            make.top.equalTo(msgLable.snp.bottom).offset(20)
            make.height.equalTo(20)
        }
    }

    func layoutCoinButton() {
        goldCoinButton.snp.makeConstraints { (make) in
            make.leading.equalTo(coinCountLable.snp.trailing).offset(5)
            make.centerY.equalTo(coinCountLable)
        }
    }
    
}

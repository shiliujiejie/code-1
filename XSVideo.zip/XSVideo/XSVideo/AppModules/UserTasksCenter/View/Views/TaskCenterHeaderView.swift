//
//  TaskCenterHeaderView.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/19.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 任务中心头部
class TaskCenterHeaderView: UIView {
    
    private lazy var bgImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(named: "maskTaskCenter")
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    private lazy var backButton: UIButton = {
        let button = UIButton(type: .custom)
        button.isHidden = true
        return button
    }()
    var navLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.white
        lable.isHidden = true
        return lable
    }()
    var msgLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.white
        lable.textAlignment = .center
        lable.font = UIFont.boldSystemFont(ofSize: 14)
        lable.text = UIViewController.localStr("kTaskCenterTipsTitle")
        return lable
    }()
    lazy var headerButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(ConstValue.kDefaultHeader, for: .normal)
        button.layer.cornerRadius = 35
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return button
    }()
    private lazy var inviteButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setBackgroundImage(UIImage(named: "taskButtonBG"), for: .normal)
        button.setTitle(UIViewController.localStr("kMyInviteListTitle"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        button.setImage(UIImage(named: "inviteButton"), for: .normal)
        button.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return button
    }()
    private lazy var convertButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setBackgroundImage(UIImage(named: "taskButtonBG"), for: .normal)
        button.setTitle(UIViewController.localStr("kConvertCenterTitle"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        button.setImage(UIImage(named: "convertButton"), for: .normal)
        button.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return button
    }()
    var headerButtonClickHandler:(() -> Void)?
    var inviteButtonClickHandler:(() -> Void)?
    var convertButtonClickHandler:(() -> Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.white
        addSubview(bgImageView)
        addSubview(backButton)
        addSubview(navLable)
        addSubview(headerButton)
        addSubview(msgLable)
        addSubview(inviteButton)
        addSubview(convertButton)
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func buttonClick(_ sender: UIButton) {
        if sender == headerButton {
            headerButtonClickHandler?()
        }
        if sender == inviteButton {
            inviteButtonClickHandler?()
        }
        if sender == convertButton {
            convertButtonClickHandler?()
        }
    }
    
}


// MARK: - Layout
private extension TaskCenterHeaderView {
    
    func layoutPageSubviews() {
        layoutBgimage()
        layoutBackButton()
        layoutNavLable()
        layoutHeaderImage()
        layoutMsgLable()
        layoutInviteButton()
        layoutConvertButton()
    }
    
    func layoutBgimage() {
        bgImageView.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(189 + ConstValue.kStatusBarHeight)
        }
    }
    
    func layoutBackButton() {
        backButton.snp.makeConstraints { (make) in
            make.top.equalTo(ConstValue.kStatusBarHeight + 5)
            make.leading.equalTo(15)
            make.width.equalTo(30)
            make.height.equalTo(30)
        }
    }
    
    func layoutNavLable() {
        navLable.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(ConstValue.kStatusBarHeight + 10)
            make.height.equalTo(24)
        }
    }
    
    func layoutHeaderImage() {
        headerButton.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(navLable.snp.bottom).offset(0)
            make.height.width.equalTo(70)
        }
    }
    
    func layoutMsgLable() {
        msgLable.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(headerButton.snp.bottom).offset(10)
            make.height.equalTo(20)
        }
    }
    
    func layoutInviteButton() {
        inviteButton.snp.makeConstraints { (make) in
            make.leading.equalTo((ConstValue.kScreenWdith/2 - 120)/2)
            make.top.equalTo(bgImageView.snp.bottom).offset(10)
            make.height.equalTo(35)
            make.width.equalTo(120)
        }
    }
    
    func layoutConvertButton() {
        convertButton.snp.makeConstraints { (make) in
            make.trailing.equalTo(-(ConstValue.kScreenWdith/2 - 120)/2)
            make.top.equalTo(bgImageView.snp.bottom).offset(10)
            make.height.equalTo(35)
            make.width.equalTo(120)
        }
    }
}

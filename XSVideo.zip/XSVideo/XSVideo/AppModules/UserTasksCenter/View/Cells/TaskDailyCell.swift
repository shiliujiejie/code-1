//
//  TaskDailyCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/20.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class TaskDailyCell: UITableViewCell {

    static let cellId = "TaskDailyCell"
    
    @IBOutlet weak var taskContainerView: UIView!
    @IBOutlet weak var taskImage: UIImageView!
    @IBOutlet weak var taskName: UILabel!
    @IBOutlet weak var taskEarnCount: UIButton!
    @IBOutlet weak var taskDesLable: UILabel!
    @IBOutlet weak var taskDoButton: UIButton!
    var doButtonClickHandler:(() ->Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        contentView.backgroundColor = UIColor.white
        taskContainerView.layer.cornerRadius = 10
        taskContainerView.layer.shadowColor = UIColor.groupTableViewBackground.cgColor
        taskContainerView.layer.shadowOffset = CGSize()
        taskContainerView.layer.shadowOpacity = 0.8
        taskContainerView.layer.shadowRadius = 6
        taskContainerView.clipsToBounds = false
        taskDoButton.setBackgroundImage(UIImage.imageFromColor(UIColor.groupTableViewBackground, frame: CGRect(x: 0, y: 0, width: 80, height: 30)), for: .disabled)
        taskDoButton.layer.cornerRadius = 16
        taskDoButton.layer.masksToBounds = true
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func taskButtonClick(_ sender: UIButton) {
        doButtonClickHandler?()
    }
}

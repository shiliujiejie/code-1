//
//  ConvertItemCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/20.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class ConvertItemCell: UITableViewCell {
    
    static let cellId = "ConvertItemCell"

    @IBOutlet weak var converContainerView: UIView!
    @IBOutlet weak var convertImage: UIImageView!
    @IBOutlet weak var convertName: UILabel!
    @IBOutlet weak var coinCountBtn: UIButton!
    @IBOutlet weak var availTimeLab: UILabel!
    @IBOutlet weak var convertDoBtn: UIButton!
    
    var convertButtonCliclHandler:(() -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        contentView.backgroundColor = UIColor.white
        converContainerView.layer.cornerRadius = 10
        converContainerView.layer.shadowColor = UIColor.groupTableViewBackground.cgColor
        converContainerView.layer.shadowOffset = CGSize()
        converContainerView.layer.shadowOpacity = 0.8
        converContainerView.layer.shadowRadius = 6
        converContainerView.clipsToBounds = false
        convertDoBtn.setBackgroundImage(UIImage.imageFromColor(UIColor.groupTableViewBackground, frame: CGRect(x: 0, y: 0, width: 80, height: 30)), for: .disabled)
        convertDoBtn.layer.cornerRadius = 16
        convertDoBtn.layer.masksToBounds = true
    }

    
    @IBAction func convertDoBtnClick(_ sender: UIButton) {
        convertButtonCliclHandler?()
    }
}

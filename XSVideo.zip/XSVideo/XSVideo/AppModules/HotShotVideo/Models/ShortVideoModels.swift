//
//  ShortVideoModels.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/26.
//  Copyright © 2019年 pro5. All rights reserved.
//

import Foundation

/// 短视频头部 类型
struct ShortVideoTypeModel: Codable {
    var id: Int?
    var title: String?
    var icon: String?
    var status: Int?
    var created_at: String?
    var updated_at: String?
    var full_icon: String?
}

/// 短视频列表model
struct  ShortVideoListModel: Codable {
    var current_page: Int?
    var data: [ShortVideoModel]?
    var first_page_url: String?
    var last_page: Int?
}

/// 短视频model
struct ShortVideoModel: Codable {
    var id: Int?
    var type_id: Int?
    var title: String?
    var cover_path: String?
    var play_count: Int?
    var play_count_real: Int?
    var created_at: String?
    var play_url: String?
}

//
//  ShotVideoMainController.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/26.
//  Copyright © 2019年 pro5. All rights reserved.
//

import UIKit
import SnapKit
import LTScrollView
import NicooNetwork

/// 短视频主页
class ShortVideoMainController: UIViewController {
    
    private let glt_iphoneX = (UIScreen.main.bounds.height >= 812.0)
    
    private lazy var titles: [String] = {
        return [localStr("kRecomment"), localStr("kFilm"), localStr("kTVSerial"), localStr("kCatoon"), localStr("kVarietyShow")]
    }()
    private lazy var viewControllers: [ShortVideoTypePageController] = {
        var vcs = [ShortVideoTypePageController]()
        for i in 0..<self.titles.count {
            if let globalTypeModel = globalTypeList?[i] {
                let oneVc = ShortVideoTypePageController()
                oneVc.typeId = globalTypeModel.id ?? 1
                vcs.append(oneVc)
            }
        }
        return vcs
    }()
    private lazy var layout: LTLayout = {
        let layout = LTLayout()
        layout.titleViewBgColor = UIColor.white
        layout.titleColor = UIColor(r: 0.4, g: 0.4, b: 0.4)
        layout.titleSelectColor = ConstValue.kAppDefaultTitleColor
        layout.bottomLineColor = ConstValue.kAppDefaultTitleColor
        layout.showsHorizontalScrollIndicator = false
        layout.sliderHeight = 50
        layout.titleFont = UIFont.boldSystemFont(ofSize: 18)
        layout.isShowBounces = true
        layout.scale = 1.1
        layout.lrMargin = 25
        layout.titleMargin = 25
        return layout
    }()
    /// 顶部栏目切换控件
    private lazy var pageView: LTPageView = {
        let tabBarH = self.tabBarController?.tabBar.bounds.height ?? 0.0
        let Y: CGFloat = ConstValue.kStatusBarHeight //+ VideoMainViewController.searchBarHeight
        let H: CGFloat = glt_iphoneX ? (view.bounds.height - Y - tabBarH) : view.bounds.height - Y - tabBarH
        //let H: CGFloat = view.bounds.height - Y - tabBarH
        let pageView = LTPageView(frame: CGRect(x: 0, y: Y, width: view.bounds.width , height: H), currentViewController: self, viewControllers: viewControllers, titles: titles, layout: layout)
        // pageView.backgroundColor = UIColor.clear
        pageView.isClickScrollAnimation = true
        return pageView
    }()
    /// 最大分类请求
    private lazy var shortTypeAPI: ShortVideoTypeListApi = {
        let api = ShortVideoTypeListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private var globalTypeList: [ShortVideoTypeModel]?
    
    var topIndex: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        loadGlobalData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: isNavAnimated ? animated : false)
        isNavAnimated = false
    }
    
    func loadGlobalData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        let _ = shortTypeAPI.loadData()
    }
}

// MARK: - Private - Funcs
private extension ShortVideoMainController {
    
    /// 请求成功
    func loadGlobalDataSuccess(_ typeList: [ShortVideoTypeModel]?) {
        NicooErrorView.removeErrorMeesageFrom(view)
        if typeList != nil && typeList!.count > 0 {
            globalTypeList = typeList
            var allTitles = [String]()
            for i in 0..<typeList!.count {
                let model = typeList![i]
                allTitles.append(model.title ?? "")
            }
            titles = allTitles
            view.addSubview(pageView)
            //layoutPageSubviews()
            addTitlePageViewCallBack()
        }
    }
    
    /// 请求失败
    func requestFail(error: String?, manager: NicooBaseAPIManager?) {
        NicooErrorView.showErrorMessage(.noNetwork, on: view) { [weak self] in
            self?.loadGlobalData()
        }
    }
    
    func addTitlePageViewCallBack() {
        pageView.didSelectIndexBlock = { [weak self] (_, index) in
            guard let strongSelf = self else { return }
            DLog("pageView.didSelectIndexBlock ")
            if index != strongSelf.topIndex {
                let vc = strongSelf.viewControllers[strongSelf.topIndex]
                vc.removePlayer()
            }
            strongSelf.topIndex = index
        }
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension ShortVideoMainController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is ShortVideoTypeListApi {
            if let list = manager.fetchJSONData(ShortVideoReformer()) as? [ShortVideoTypeModel] {
                loadGlobalDataSuccess(list)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is ShortVideoTypeListApi {
            requestFail(error: "", manager: manager)
        }
    }
    
    
}

// MARK: - Layout
private extension SpecialTopicMoreController {
    
    func layoutPageSubviews () {
        
    }
    

}


//class ShortVideoMainController: UIViewController {
//
//    // MARK: - Private Var
//    private let glt_iphoneX = (UIScreen.main.bounds.height >= 812.0)
//
//    private lazy var viewControllers: [UIViewController] = {
//        var vcs = [UIViewController]()
//        for i in 0..<self.titles.count {
//            if let typeModel = shortTypeList?[i] {
//                let oneVc = ShortVideoTypePageController()
//                oneVc.typeId = typeModel.id ?? 1
//                oneVc.view.backgroundColor = UIColor.yellow
//                vcs.append(oneVc)
//            }
//        }
//        return vcs
//    }()
//    private lazy var titles = [String]()
//    /// 记录顶部选中的Index
//    private var topIndex: Int = 0
//    private lazy var layout: LTLayout = {
//        let layout = LTLayout()
//        layout.titleViewBgColor = UIColor.clear
//        layout.titleColor = UIColor(r: 0.4, g: 0.4, b: 0.4)
//        layout.titleSelectColor = ConstValue.kAppDefaultTitleColor
//        layout.bottomLineColor = ConstValue.kAppDefaultTitleColor
//        layout.showsHorizontalScrollIndicator = false
//        layout.sliderHeight = 50
//        layout.titleFont = UIFont.boldSystemFont(ofSize: 18)
//        layout.isShowBounces = true
//        layout.scale = 1.1
//        layout.titleMargin = 25
//        layout.lrMargin = 20
//        return layout
//    }()
//    /// 顶部栏目切换控件
//    private lazy var pageView: LTPageView = {
//        let tabBarH = self.tabBarController?.tabBar.bounds.height ?? 0.0
//        let Y: CGFloat = ConstValue.kStatusBarHeight //+ VideoMainViewController.searchBarHeight
//        let H: CGFloat = glt_iphoneX ? (view.bounds.height - Y - tabBarH) : view.bounds.height - Y - tabBarH
//        //let H: CGFloat = view.bounds.height - Y - tabBarH
//        let pageView = LTPageView(frame: CGRect(x: 0, y: Y, width: view.bounds.width , height: H), currentViewController: self, viewControllers: viewControllers, titles: titles, layout: layout)
//        // pageView.backgroundColor = UIColor.clear
//        pageView.isClickScrollAnimation = true
//
//        return pageView
//    }()
//
//    private lazy var typeListApi: ShortVideoTypeListApi = {
//        let api = ShortVideoTypeListApi()
//        api.delegate = self
//        api.paramSource = self
//        return api
//    }()
//
//    private var shortTypeList: [ShortVideoTypeModel]?
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        view.backgroundColor = UIColor.white
//        loadTypeList()
//    }
//
//    override func viewWillAppear(_ animated: Bool) {
//        super.viewWillAppear(animated)
//        navigationController?.setNavigationBarHidden(true, animated: isNavAnimated ? animated : false)
//        isNavAnimated = false
//    }
//
//    func loadTypeList() {
//        let _ = typeListApi.loadData()
//    }
//
//    func addTitlePageViewCallBack() {
//        pageView.didSelectIndexBlock = { [weak self] (_, index) in
//            DLog("pageView.didSelectIndexBlock ")
//            self?.topIndex = index
//        }
//    }
//
//}
//
//private extension ShortVideoMainController {
//
//    func requestSucceeded(_ typeList: [ShortVideoTypeModel]) {
//        NicooErrorView.removeErrorMeesageFrom(view)
//        if typeList.count > 0 {
//            shortTypeList = typeList
//            var allTitles = [String]()
//            for i in 0..<typeList.count {
//                let model = typeList[i]
//                allTitles.append(model.title ?? "")
//            }
//            titles = allTitles
//            view.addSubview(pageView)
//            addTitlePageViewCallBack()
//            layoutPageSubviews()
//        }
//    }
//
//    func requestFailed(_ manager: NicooBaseAPIManager) {
//
//    }
//}
//
//// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
//extension ShortVideoMainController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
//
//    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
//        XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
//        return nil
//    }
//
//    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
//        XSProgressHUD.hide(for: view, animated: false)
//        if manager is ShortVideoTypeListApi {
//            if let list = manager.fetchJSONData(ShortVideoReformer()) as? [ShortVideoTypeModel] {
//                requestSucceeded(list)
//            }
//        }
//    }
//
//    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
//        XSProgressHUD.hide(for: view, animated: false)
//        if manager is ShortVideoTypeListApi {
//           requestFailed(manager)
//        }
//    }
//}
//
//
//// MARK: - Layout
//private extension ShortVideoMainController {
//    func layoutPageSubviews() {
//
//    }
//}

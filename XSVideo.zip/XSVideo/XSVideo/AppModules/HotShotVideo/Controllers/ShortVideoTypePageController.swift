//
//  ShotVideoTypePageController.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/26.
//  Copyright © 2019年 pro5. All rights reserved.
//

import UIKit
import NicooPlayer
import MJRefresh
import NicooNetwork

class ShortVideoTypePageController: UIViewController {
    
    /// 这里重写系统方法，为了让 StatusBar 跟随播放器的操作栏一起 隐藏或显示，且在全屏播放时， StatusBar 样式变为 lightContent
    override var preferredStatusBarStyle: UIStatusBarStyle {
        let orirntation = UIApplication.shared.statusBarOrientation
        if  orirntation == UIInterfaceOrientation.landscapeLeft || orirntation == UIInterfaceOrientation.landscapeRight {
            return .lightContent
        }
        return .default
    }
    
    private lazy var tableView: UITableView = {
        let table = UITableView(frame: view.bounds, style: .plain)
        table.delegate = self
        table.dataSource = self
        table.tableFooterView = UIView()
        table.separatorStyle = .none
        table.register(ShortVideoListCell.classForCoder(), forCellReuseIdentifier: ShortVideoListCell.cellId)
        table.mj_header = refreshView
        table.mj_footer = loadMoreView
        return table
    }()
    private lazy var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        return MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
    }()
    private lazy var refreshView: MJRefreshGifHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshGifHeader(refreshingBlock: {
            weakSelf?.isRefreshOperation = true
            weakSelf?.loadData()
        })
        var gifImages = [UIImage]()
        for string in ConstValue.refreshImageNames {
            gifImages.append(UIImage(named: string)!)
        }
        mjRefreshHeader?.setImages(gifImages, for: .refreshing)
        mjRefreshHeader?.setImages(gifImages, for: .idle)
        return mjRefreshHeader!
    }()
    private lazy var videoLsApi: ShortVideoListApi = {
        let api = ShortVideoListApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var videoInfoApi: ShortVideoInfoApi = {
        let api = ShortVideoInfoApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    
    var isRefreshOperation = false
    
    var videoListModel: ShortVideoListModel?
    var videoModels = [ShortVideoModel]()
    /// 用于记录播放次数
    var videoPlayId: Int = 0
    
    /// 当前正在播放的cell 所在的 indexPath
    var playerCellIndex: IndexPath?
    /// 当前添加播放器的cell
    var lastPlayerCell: ShortVideoListCell?
    /// 类型id
    var typeId: Int = 1
    
    //cell上播放需要添加deinit， 移除播放器。释放播放器
    deinit {
        print("试图控制器被释放了")
        removePlayer()
        if let cc = lastPlayerCell?.value(forKey: "retainCount"),let vv = self.value(forKey: "retainCount") {
            print("cccccccccccccccccc = \(cc)  ==  \(vv)")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        view.addSubview(tableView)
        layoutPageSubviews()
        loadMoreView.isHidden = true
        loadData()
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        removePlayer()
    }
    
    func loadData() {
        if !isRefreshOperation {
            XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        } else {
            isRefreshOperation = false
        }
        let _ = videoLsApi.loadData()
    }
    
    func loadNextPage() {
        let _ = videoLsApi.loadNextPage()
    }
    
    /// 移除播放器
    func removePlayer() {
        if self.lastPlayerCell != nil && lastPlayerCell!.isPlayerExist {
            for view in lastPlayerCell!.backGroundImage.subviews {
                if view is NicooPlayerView {
                    view.removeFromSuperview()
                    lastPlayerCell!.isPlayerExist = false
                    playerCellIndex = nil
                    lastPlayerCell = nil
                }
            }
        }
    }
    
    /// 请求一次详情，方便后台添加播放次数
    func loadVideoInfo(_ indexPath: IndexPath) {
        videoPlayId = videoModels[indexPath.row].id ?? 0
        let _ = videoInfoApi.loadData()
    }
    
    
}

// MARK: - LoadData Funcs
private extension ShortVideoTypePageController {
    
    func requesSuccess(_ listModel: ShortVideoListModel) {
        NicooErrorView.removeErrorMeesageFrom(view)
        tableView.mj_footer?.endRefreshing()
        tableView.mj_header?.endRefreshing()
        loadMoreView.isHidden = true
        videoListModel = listModel
        if let list = listModel.data,let pageNumber = listModel.current_page {
            if pageNumber == 1 {
                guard list.count > 0 else {
                    NicooErrorView.showErrorMessage(.noData, on: view, clickHandler: nil)
                    return
                }
                videoModels = list
                if list.count >= VideoListApi.kDefaultCount { // 表示可能还有数据
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
                isRefreshOperation = true
            } else {
                videoModels.append(contentsOf: list)
                if list.count >= VideoListApi.kDefaultCount { // 表示可能还有数据
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
            }
            tableView.reloadData()
        }
    }
    
    func requestFailed(_ manager: NicooBaseAPIManager) {
        tableView.mj_footer.endRefreshing()
        tableView.mj_header.endRefreshing()
        tableView.mj_footer.isHidden = true
        // 头部刷新或者第一次进入
        if !isRefreshOperation {
            NicooErrorView.showErrorMessage(.noNetwork, on: view, topMargin: 0) { [weak self] in
                self?.loadData()
            }
            removePlayer()
        }
    }
    
    
}

// MARK: - Player Fix Funcs
private extension ShortVideoTypePageController {
    
    /// 跳转到详情
    ///
    /// - Parameter indexPath: 点击的indexPath
    func pushToDetailPage(_ indexPath: IndexPath) {
        let next = ShortVideoDetailController()
        if playerCellIndex == nil {
            /// 这里要播第几个，根据tableView 点击第几个cell来确定。
            next.videoModel = videoModels[indexPath.row]
            navigationController?.pushViewController(next, animated: true)
            return
        }
        /// 当前正在播放，点击当前播放的cell
        if playerCellIndex! == indexPath {
            if self.lastPlayerCell != nil && lastPlayerCell!.isPlayerExist {
                for view in lastPlayerCell!.backGroundImage.subviews {
                    if view is NicooPlayerView {
                        next.playerView = (view as! NicooPlayerView)
                        lastPlayerCell!.isPlayerExist = false
                        playerCellIndex = nil
                        lastPlayerCell = nil
                        (view as! NicooPlayerView).interfaceOrientation(UIInterfaceOrientation.portrait)  // 先回到竖屏状态
                        /// 这里要播第几个，根据tableView 点击第几个cell来确定。
                        next.videoModel = videoModels[indexPath.row]
                        navigationController?.pushViewController(next, animated: true)
                    }
                }
            }
        } else {
            /// 当前正在播放, 点击 非 正在播放的cell ，先移除正在播放的播放器
            if lastPlayerCell != nil && playerCellIndex != nil  {
                for view in lastPlayerCell!.backGroundImage.subviews {
                    if view is NicooPlayerView {
                        view.removeFromSuperview()
                        lastPlayerCell!.isPlayerExist = false
                    }
                }
            }
            /// 这里要播第几个，根据tableView 点击第几个cell来确定。
            next.videoModel = videoModels[indexPath.row]
            navigationController?.pushViewController(next, animated: true)
        }
    }
}

// MARK: - UITableViewDelegate UITableViewDataSource
extension ShortVideoTypePageController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return ConstValue.kScreenWdith * 9/16 + 110
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return videoModels.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: ShortVideoListCell.cellId, for: indexPath) as! ShortVideoListCell
        configCell(cell: cell, indexPath: indexPath)
        return cell
    }
   
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        loadVideoInfo(indexPath)
        pushToDetailPage(indexPath)
    }
    
    func tableView(_ tableView: UITableView, didEndDisplaying cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        let cellNicoo = cell as! ShortVideoListCell
        if cellNicoo.isPlayerExist {
            for view in cellNicoo.backGroundImage.subviews {
                if view is NicooPlayerView {
                    view.removeFromSuperview()
                    cellNicoo.isPlayerExist = false
                    playerCellIndex = nil
                    lastPlayerCell = nil
                }
            }
        }
    }
    
    func configCell(cell: ShortVideoListCell, indexPath: IndexPath) {
        guard videoModels.count > indexPath.row else { return } // 防止数组越界
        let model = videoModels[indexPath.row]
        cell.titleLab.text = model.title ?? ""
        cell.backGroundImage.kfSetHorizontalImageWithUrl(model.cover_path)
        cell.playCountLable.text = String(format: "%@ %@", getStringWithNumber(model.play_count ?? 0), localStr("kPlayTimeRightMsg"))
        cell.playButtonClickBlock = { [weak self] (sender) in
            guard let strongSelf = self else { return }
            /// 当前页面已经存在一个播放器，并且本地点击不是上次一个cell ，先移除上一个
            if strongSelf.lastPlayerCell != nil && strongSelf.playerCellIndex != nil && strongSelf.playerCellIndex! != indexPath {
                for view in strongSelf.lastPlayerCell!.backGroundImage.subviews {
                    if view is NicooPlayerView {
                        view.removeFromSuperview()
                        strongSelf.lastPlayerCell!.isPlayerExist = false
                    }
                }
            }
            /// cell 上没有播放器，才添加 （不加这个，循环引用，具体多少个对象的循环引用，自己数）
            if !cell.isPlayerExist {
                let player = NicooPlayerView(frame: cell.backGroundImage.bounds , bothSidesTimelable: true)
                player.videoLayerGravity = .resizeAspect
                player.videoNameShowOnlyFullScreen = true
                player.delegate = self
                // player.customViewDelegate = self   // 这个是用于自定义右上角按钮的显示
                let url = URL(string: model.play_url ?? "")
                player.playVideo(url, model.title ?? "", cell.backGroundImage)
                cell.isPlayerExist = true
                strongSelf.playerCellIndex = indexPath
                strongSelf.lastPlayerCell = cell
            } else {
                print("not player exsit")
            }
            /// 记录播放次数
            strongSelf.loadVideoInfo(indexPath)
            
        }
        cell.shareHandler = { [weak self] in
            guard let strongSelf = self else {  return }
            strongSelf.shareWith(model.title ?? "", model.play_url ?? "")
        }
    }
    
}

// MARK: - 代理方法： 1. 网络不好，点击重试的操作。   2、 自定义操作栏
extension ShortVideoTypePageController: NicooPlayerDelegate, NicooCustomMuneDelegate {
    
    // NicooPlayerDelegate 网络重试
    func retryToPlayVideo(_ player: NicooPlayerView, _ videoModel: NicooVideoModel?, _ fatherView: UIView?) {
        let url = URL(string: videoModel?.videoUrl ?? "")
        if  let sinceTime = videoModel?.videoPlaySinceTime, sinceTime > 0 {
            player.replayVideo(url, videoModel?.videoName, fatherView, sinceTime)
        }else {
            player.playVideo(url, videoModel?.videoName, fatherView)
        }
    }
    
    func currentVideoPlayToEnd(_ videoModel: NicooVideoModel?, _ isPlayingDownLoadFile: Bool) {
        print("CellPlayVC ---> currentVideoPlayToEnd")
    }
}


// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension ShortVideoTypePageController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is ShortVideoListApi {
            return [ShortVideoListApi.kTypeId: typeId]
        } else if manager is ShortVideoInfoApi {
            return [ShortVideoInfoApi.kVideo_Id: videoPlayId]
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is ShortVideoListApi {
            if let list = manager.fetchJSONData(ShortVideoReformer()) as? ShortVideoListModel {
                requesSuccess(list)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is ShortVideoListApi {
            requestFailed(manager)
        }
    }
}



// MARK: - layout
private extension ShortVideoTypePageController {
    
    func layoutPageSubviews() {
        layoutTableView()
    }
    
    func layoutTableView() {
        let bottomMargin =  UIDevice.current.isiPhoneXSeriesDevices() ? 0 : -50
        tableView.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(bottomMargin)
            } else {
                make.bottom.equalTo(bottomMargin)
            }
        }
    }
}

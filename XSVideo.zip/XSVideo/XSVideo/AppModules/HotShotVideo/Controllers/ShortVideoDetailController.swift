//
//  ShortVideoDetailController.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/26.
//  Copyright © 2019年 pro5. All rights reserved.
//

import UIKit
import NicooPlayer
import MJRefresh
import NicooNetwork

/// 短视频详页面
class ShortVideoDetailController: UIViewController {

    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    private lazy var backButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "navBackWhite"), for: .normal)
        button.backgroundColor = UIColor(white: 0.0, alpha: 0.2)
        button.layer.cornerRadius = 15
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(backButtonClick), for: .touchUpInside)
        return button
    }()
    private let statuBarView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.black
        return view
    }()
    private lazy var fateherView: UIView = {
        let view = UIView()
        view.frame = CGRect(x:0, y: ConstValue.kStatusBarHeight, width: ConstValue.kScreenWdith, height: ConstValue.kScreenWdith * 9/16)
        view.backgroundColor = UIColor.gray
        return view
    }()
    private let tableHeaderView: UIView = {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 100))
        view.backgroundColor = UIColor.white
        return view
    }()
    private let videoTitleLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 16)
        lable.numberOfLines = 2
        return lable
    }()
    private let playCountLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 14)
        return lable
    }()
    private lazy var shareButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "shortShareBtnIcon"), for: .normal)
        button.addTarget(self, action: #selector(shareButtonClick), for: .touchUpInside)
        return button
    }()
    private lazy var tableView: UITableView = {
        let table = UITableView(frame: view.bounds, style: .plain)
        table.delegate = self
        table.dataSource = self
        table.tableFooterView = UIView()
        table.separatorStyle = .none
        table.register(ShortVideoRecommendCell.classForCoder(), forCellReuseIdentifier: ShortVideoRecommendCell.cellId)
        table.mj_footer = loadMoreView
        return table
    }()
    private lazy var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        return MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
    }()
    private lazy var videoRecApi: ShortReconmentApi = {
        let api = ShortReconmentApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var videoInfoApi: ShortVideoInfoApi = {
        let api = ShortVideoInfoApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    var isRefreshOperation = false
    
    var videoListModel: ShortVideoListModel?
    var videoModels = [ShortVideoModel]()
    /// 用于记录播放次数
    var currentPlayId = 0
    
    /// 当前播的第几条 ， 如果是刚进入，为空
    var currentPlayIndex: IndexPath?
    
    /// 播放器是否存在
    var playerViewExist = false
    var videoModel: ShortVideoModel?
    var playerView: NicooPlayerView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        view.addSubview(statuBarView)
        view.addSubview(fateherView)
        view.addSubview(backButton)
        tableHeaderView.addSubview(videoTitleLable)
        tableHeaderView.addSubview(playCountLable)
        tableHeaderView.addSubview(shareButton)
        tableView.tableHeaderView = tableHeaderView
        view.addSubview(tableView)
        layoutPageSubviews()
        loadMoreView.isHidden = true
        setVideoInfo(videoModel)
        loadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
        createOrRecivePlayer()
        // 如果当前播放器已经添加，支持横竖屏
        if fateherView.subviews.contains(playerView!) {
            orientationSupport = NicooPlayerOrietation.orientationAll
        }
    }
    
    private func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        let _ = videoRecApi.loadData()
    }
    
    private func loadNextPage() {
        let _ = videoRecApi.loadNextPage()
    }
    
    private func setVideoInfo(_ model: ShortVideoModel?) {
        videoTitleLable.text = model?.title ?? ""
        playCountLable.text = String(format: "%@ %@", getStringWithNumber(model?.play_count ?? 0), localStr("kPlayTimeRightMsg"))
    }
    
    private func loadVideoInfo(_ indexPath: IndexPath) {
        currentPlayId = videoModels[indexPath.row].id ?? 0
        let _ = videoInfoApi.loadData()
    }
    
}

// MARK: - User - Actions
extension ShortVideoDetailController {
    
    @objc private func barButtonClick() {
        /// 离开视频详情播放页面，push进入别的页面，只支持竖屏
        
        //(这里，如果有网络监听，要将网络监听取消掉，否则在4G切换到wifi 时视频会自动播放，导致，页面在下一级页面，而播放器却在播放声音)
        /// 移除监听 ： 详情页面会有
        NotificationCenter.default.removeObserver(self)
        
        playerView!.playerStatu = PlayerStatus.Pause
        orientationSupport = NicooPlayerOrietation.orientationPortrait
        let next = UIViewController()
        next.view.backgroundColor = UIColor.white
        navigationController?.pushViewController(next, animated: true)
    }
    
    @objc private func backButtonClick() {
        navigationController?.popViewController(animated: true)
    }
    
    @objc private func shareButtonClick() {
        shareWith(self.videoModel?.title ?? "", self.videoModel?.play_url ?? "")
    }
}

// MARK: - Private Funcs
private extension ShortVideoDetailController {

    /// 创建或者接收播放器
    func createOrRecivePlayer() {
        if !playerViewExist {
            if playerView != nil {
                /// 接受列表页面传过来的 播放器
                recivePlayerFromLastPage()
            } else {
                /// 创建一个播放器
                playerView = NicooPlayerView.init(frame: fateherView.bounds, bothSidesTimelable: true)
                playerView?.videoLayerGravity = .resizeAspect
                playerView?.videoNameShowOnlyFullScreen = true
                playerView?.delegate = self
                playVideo(videoModel)
            }
            playerViewExist = true
        }
    }
    
    /// 接收上个页面的播放器
    func recivePlayerFromLastPage() {
        if playerView != nil {
            playerView!.changeVideoContainerView(fateherView)
            playerView!.delegate = self
        }
    }
    
    /// 播放视频
    ///
    /// - Parameter model: model
    func playVideo(_ model: ShortVideoModel?) {
        let url = URL(string: model?.play_url ?? "")
        playerView?.playVideo(url, model?.title ?? "", fateherView)
        self.videoModel = model
    }
    
    /// 创建区头View
    func createSectionHeaderView(_ section: Int) -> UIView? {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 45))
        view.backgroundColor = UIColor.white
        let tipsView = UIView(frame: CGRect(x: 15, y: 12.5, width: 5, height: 20))
        tipsView.layer.cornerRadius = 1.5
        tipsView.backgroundColor = ConstValue.kAppDefaultColor
        view.addSubview(tipsView)
        let lable = UILabel()
        lable.text = localStr("kRecommentShort")
        lable.font = UIFont.boldSystemFont(ofSize: 18)
        view.addSubview(lable)
        layoutSectionHeaderTipsView(tipsView)
        layoutSectionTitleLable(lable)
        return view
    }
    
    func requesSuccess(_ listModel: ShortVideoListModel) {
        NicooErrorView.removeErrorMeesageFrom(view)
        tableView.mj_footer?.endRefreshing()
        XSProgressHUD.hide(for: view, animated: false)
        loadMoreView.isHidden = true
        videoListModel = listModel
        if let list = listModel.data,let pageNumber = listModel.current_page {
            if pageNumber == 1 {
                guard list.count > 0 else {
                    let topMargin = ConstValue.kScreenWdith * 9/16 + ConstValue.kStatusBarHeight + 150
                    NicooErrorView.showErrorMessage(.noData, on: view, topMargin: topMargin, clickHandler: nil)
                    return
                }
                videoModels = list
                if list.count >= VideoListApi.kDefaultCount { // 表示可能还有数据
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
                isRefreshOperation = true
            } else {
                videoModels.append(contentsOf: list)
                if list.count >= VideoListApi.kDefaultCount { // 表示可能还有数据
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
            }
            tableView.reloadData()
        }
    }
    
    func requestFailed(_ manager: NicooBaseAPIManager) {
        if !isRefreshOperation {
            let topMargin = ConstValue.kScreenWdith * 9/16 + ConstValue.kStatusBarHeight + 150
            NicooErrorView.showErrorMessage(.noNetwork, on: view, topMargin: topMargin) { [weak self] in
                self?.loadData()
            }
        }
    }
    
}

// MARK: - UITableViewDelegate UITableViewDataSource
extension ShortVideoDetailController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return videoModels.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: ShortVideoRecommendCell.cellId, for: indexPath) as! ShortVideoRecommendCell
        let model = videoModels[indexPath.row]
        cell.videoCoverImage.kfSetHorizontalImageWithUrl(model.cover_path)
        cell.videoTitleLable.text = model.title ?? ""
        cell.playCountLable.text = String(format: "%@ %@", getStringWithNumber(model.play_count ?? 0), localStr("kPlayTimeRightMsg"))
        if currentPlayIndex != nil && currentPlayIndex! == indexPath {
            cell.videoTitleLable.textColor = ConstValue.kAppDefaultColor
        } else {
            cell.videoTitleLable.textColor = UIColor.darkText
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        // 非 点击了当前正在播放的视频
        if currentPlayIndex == nil {
            let model = videoModels[indexPath.row]
            // 记录当前点击的播放位置
            currentPlayIndex = indexPath
            playVideo(model)
            setVideoInfo(model)
            tableView.reloadData()
            loadVideoInfo(indexPath)
        } else {
            if currentPlayIndex! != indexPath {
                let model = videoModels[indexPath.row]
                // 记录当前点击的播放位置
                currentPlayIndex = indexPath
                playVideo(model)
                setVideoInfo(model)
                tableView.reloadData()
                loadVideoInfo(indexPath)
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 45
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return createSectionHeaderView(section)
    }
  
}


// MARK: - NicooPlayerDelegate
extension ShortVideoDetailController: NicooPlayerDelegate {
 
    func retryToPlayVideo(_ player: NicooPlayerView , _ videoModel: NicooVideoModel?, _ fatherView: UIView?) {
        
    }
    
    func currentVideoPlayToEnd(_ videoModel: NicooVideoModel?, _ isPlayingDownLoadFile: Bool) {
        print("NextViewController -->> currentVideoPlayToEnd")
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension ShortVideoDetailController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is ShortReconmentApi {
            return [ShortReconmentApi.kVideoId: videoModel?.id ?? 0]
        } else if manager is ShortVideoInfoApi {
            return [ShortVideoInfoApi.kVideo_Id: currentPlayId]
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is ShortReconmentApi {
            if let list = manager.fetchJSONData(ShortVideoReformer()) as? ShortVideoListModel {
                requesSuccess(list)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is ShortReconmentApi {
            requestFailed(manager)
        }
    }
}

// MARK: - UIScrollViewDelegate
extension ShortVideoDetailController: UIScrollViewDelegate {
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let sectionHeaderHeight: CGFloat = 45
        if scrollView.contentOffset.y <= sectionHeaderHeight && scrollView.contentOffset.y > 0 {
            scrollView.contentInset = UIEdgeInsets(top: -scrollView.contentOffset.y, left: 0, bottom: 0, right: 0)
            
        } else if scrollView.contentOffset.y >= sectionHeaderHeight {
            scrollView.contentInset = UIEdgeInsets(top: -sectionHeaderHeight, left: 0, bottom: 0, right: 0)
        }
    }
    
}

// MARK: - Layout
private extension ShortVideoDetailController {
    
    func layoutPageSubviews() {
        layoutStatuBarView()
        layoutPlayerBgView()
        layoutBackButton()
        layoutTableView()
        layoutVideoTitleLable()
        layoutPlayCountLable()
        layoutShareButton()
    }
    func layoutBackButton() {
        backButton.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalTo(ConstValue.kStatusBarHeight + 10)
            make.width.height.equalTo(30)
        }
    }
    func layoutPlayerBgView() {
        fateherView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(statuBarView.snp.bottom)
            make.width.equalTo(ConstValue.kScreenWdith)
            make.height.equalTo(ConstValue.kScreenWdith * 9/16)
        }
    }
    func layoutStatuBarView() {
        statuBarView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(0)
            make.height.equalTo(ConstValue.kStatusBarHeight)
        }
    }
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(fateherView.snp.bottom)
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalToSuperview()
            }
        }
    }
    func layoutVideoTitleLable() {
        videoTitleLable.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(10)
            make.height.equalTo(40)
        }
    }
    func layoutPlayCountLable() {
        playCountLable.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalTo(videoTitleLable.snp.bottom).offset(10)
            make.height.equalTo(30)
        }
    }
    func layoutShareButton() {
        shareButton.snp.makeConstraints { (make) in
            make.centerY.equalTo(playCountLable)
            make.trailing.equalTo(-10)
            make.height.equalTo(40)
            make.width.equalTo(40)
        }
    }
    func layoutSectionHeaderTipsView(_ tipsView: UIView) {
        tipsView.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(15)
            make.centerY.equalToSuperview()
            make.height.equalTo(20)
            make.width.equalTo(5)
        }
    }
    func layoutSectionTitleLable(_ lable: UILabel) {
        lable.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(30)
            make.centerY.equalToSuperview()
            make.height.equalTo(20)
        }
    }
   
}

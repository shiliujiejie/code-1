//
//  ShortVideoListCell.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/26.
//  Copyright © 2019年 pro5. All rights reserved.
//

import UIKit

class ShortVideoListCell: UITableViewCell {
    
    static let cellId = "ShortVideoListCell"
    
    let titleLab: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 16)
        lable.numberOfLines = 2
        return lable
    }()
    let backGroundImage: UIImageView = {
        let imageView = UIImageView()
       // imageView.contentMode = .scaleAspectFit
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    lazy var playButton: UIButton = {
        let button = UIButton(type: .custom)
        button.backgroundColor = UIColor(white: 0, alpha: 0.5)
        button.layer.cornerRadius = 30
        button.layer.masksToBounds = true
        button.setImage(UIImage(named: "pause"), for: .normal)
        button.addTarget(self, action: #selector(playButtonClick(_:)), for: .touchUpInside)
        return button
    }()
    lazy var shareButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "shortShareBtnIcon"), for: .normal)
        button.addTarget(self, action: #selector(shareButtonClick), for: .touchUpInside)
        return button
    }()
    let playCountLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 14)
        lable.textColor = UIColor.darkGray
        return lable
    }()
    let underLine: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.groupTableViewBackground
        return view
    }()
    // 是否播放器已经存在
    var isPlayerExist = false
    
    var playButtonClickBlock:((_ sender: UIButton) ->())?
    var goDetailClick:((_ sender: UIButton) ->Void)?
    var shareHandler:(() -> Void)?
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.backgroundColor = UIColor.white
        contentView.addSubview(titleLab)
        contentView.addSubview(backGroundImage)
        backGroundImage.addSubview(playButton)
        contentView.addSubview(playCountLable)
        contentView.addSubview(shareButton)
        contentView.addSubview(underLine)
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func playButtonClick(_ sender: UIButton) {
        playButtonClickBlock?(sender)
    }
    
    @objc private func shareButtonClick() {
        shareHandler?()
    }
}

private extension ShortVideoListCell {
    
    func layoutPageSubviews() {
        layoutTitleLable()
        layoutBackGroundImage()
        layoutPlayButton()
        layoutPlayCountLable()
        layoutShareButton()
        layoutUnderLine()
    }
    func layoutTitleLable() {
        titleLab.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(10)
            make.height.equalTo(40)
        }
    }
    func layoutBackGroundImage() {
        backGroundImage.snp.makeConstraints { (make) in
            make.leading.equalTo(1)
            make.trailing.equalTo(-1)
            make.top.equalTo(titleLab.snp.bottom).offset(10)
            make.height.equalTo(ConstValue.kScreenWdith * 9/16)
        }
    }
    func layoutPlayButton() {
        playButton.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.height.width.equalTo(60)
        }
    }
    func layoutPlayCountLable() {
        playCountLable.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalTo(backGroundImage.snp.bottom).offset(10)
            make.height.equalTo(25)
        }
    }
    func layoutShareButton() {
        shareButton.snp.makeConstraints { (make) in
            make.trailing.equalTo(-10)
            make.centerY.equalTo(playCountLable)
            make.width.equalTo(40)
            make.height.equalTo(40)
        }
    }
    func layoutUnderLine() {
        underLine.snp.makeConstraints { (make) in
            make.leading.equalTo(5)
            make.trailing.equalToSuperview()
            make.height.equalTo(0.5)
            make.bottom.equalToSuperview()
        }
    }
    
}

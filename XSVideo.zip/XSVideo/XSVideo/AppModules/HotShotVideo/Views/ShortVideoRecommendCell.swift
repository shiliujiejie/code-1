//
//  ShortVideoRecommendCell.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/26.
//  Copyright © 2019年 pro5. All rights reserved.
//

import UIKit

class ShortVideoRecommendCell: UITableViewCell {

    static let cellId = "ShortVideoRecommendCell"
    
    let videoTitleLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 14)
        lable.numberOfLines = 2
        return lable
    }()
    let playCountLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 12)
        lable.textColor = UIColor.darkGray
        return lable
    }()
    let videoCoverImage: UIImageView = {
        let imageView = UIImageView()
        return imageView
    }()
    let underLine: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.groupTableViewBackground
        return view
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.backgroundColor = UIColor.white
        contentView.addSubview(videoTitleLable)
        contentView.addSubview(playCountLable)
        contentView.addSubview(videoCoverImage)
        contentView.addSubview(underLine)
        layoutPageSubViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }    

}


// MARK: - Layout
private extension ShortVideoRecommendCell {
    
    func layoutPageSubViews() {
        layoutVideoImage()
        layoutTitleLable()
        layoutPlayCountLable()
        layoutUnderLine()
    }
    func layoutVideoImage() {
        videoCoverImage.snp.makeConstraints { (make) in
            make.trailing.equalTo(-15)
            make.top.equalTo(10)
            make.bottom.equalTo(-10)
            make.width.equalTo(80 * 16/9)
        }
    }
    func layoutTitleLable() {
        videoTitleLable.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalTo(10)
            make.height.equalTo(40)
            make.trailing.equalTo(videoCoverImage.snp.leading).offset(-10)
        }
    }
    func layoutPlayCountLable() {
        playCountLable.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.bottom.equalTo(videoCoverImage)
            make.trailing.equalTo(videoCoverImage.snp.leading).offset(-10)
        }
    }
    func layoutUnderLine() {
        underLine.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalToSuperview()
            make.height.equalTo(0.5)
            make.bottom.equalToSuperview()
        }
    }
    
}

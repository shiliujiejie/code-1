//
//  UserInfoModel.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/19.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation

/// 用户信息model
struct UserInfoModel: Codable {
    var id: Int?
    var type: Int?  // 0: 手机号注册用户   10：设备号注册用户（游客）
    var name: String?
    var mobile: String?
    var email: String?
    var sex: Int? // 1：男 2 ：女
    var status: Int? 
    var api_token: String?
    var created_at: String?
    var updated_at: String?
    var cover_path: String?
    var empirical: Int?
    var coins: Int?
    var lv_title: String?
    var view_count_daily_total: Int? //
    var view_count_daily_use: Int?
    var view_count: Int?
    var remain_count: Int?
    var invite_code: String?
}

/// 登录model
struct LoginInfoModel: Codable {
    var user: UserInfoModel?
    var token: String?
}

//
//  CoinRecordModel.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/26.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation


/// 金币历史记录列表model
struct CoinRecordListModel: Codable {
    var current_page: Int?
    var data: [CoinRecordModel]?
}

struct CoinRecordModel: Codable {
    var id: Int?
    var user_id: Int?
    var event: String?
    var value: Int?
    var created_at: String?
    var updated_at: String?
    var event_label: String?
}


/// 用户邀请记录
struct InvitedListModel: Codable {
    var current_page: Int?
    var data: [InvitedModel]?
}

struct InvitedModel: Codable {
    var id: Int?
    var use_user_id: Int?
    var code: String?
    var owner_user_id: Int?
    var created_at: String?
    var updated_at: String?
    var invite_name: String?
    var invite_mobile: String?
}

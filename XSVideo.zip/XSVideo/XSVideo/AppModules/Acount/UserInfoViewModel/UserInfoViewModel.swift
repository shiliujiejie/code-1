//
//  UserInfoViewModel.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/14.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import NicooNetwork

/// 用户信息ViewModel
class UserInfoViewModel: NSObject {
    
    private lazy var userInfoApi: UserInfoApi = {
        let api = UserInfoApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var collectListApi: UserFavorListApi = {
        let api = UserFavorListApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var watchedListApi: UserWatchedListApi = {
        let api = UserWatchedListApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var cancleFavorApi: UserFavorCancleApi = {
        let api = UserFavorCancleApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var deleWatchedApi: UserDeleteWatchedApi = {
        let api = UserDeleteWatchedApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var userFadeBackApi: UserFadeBackApi = {
        let api = UserFadeBackApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    
    var videoList = [VideoModel]()
    var cellEditModelList = [CellEditModel]()
    /// 批量删除 视频Id列表(收藏，历史观看)
    var cancleVideoIds: [Int]?
    /// 用户反馈Api参数
    var paramsFadeBack: [String: Any]?
    
    /// 用户收藏列表,观看历史记录 回调
    var loadUserVideoListApiSuccess:((_ dataCount: Int) -> Void)?
    var loadUserVideoListApiFail: (() ->Void)?
    
    /// 历史观看删除成功回调（用于回调用户主页，刷新历史观看列表）
    var loadDeletedWatchedListSuccessHandler:(() ->Void)?
    
    var loadUserInfoSuccessHandler:(() ->Void)?
    var loadUserInfoFailHandler:(() ->Void)?
    
    var fadeBackSuccessHandler:(() ->Void)?
    var fadeBackFailHandler:((_ msg: String) ->Void)?
    
    /// 请求用户信息
    func loadUserInfo() {
        let _ = userInfoApi.loadData()
    }
    
    /// 请求用户收藏列表第一页
    func loadUserCollectedListApi() {
        let _ = collectListApi.loadData()
    }
    
    /// 请求用户收藏列表下一页
    func loadUserCollectedNextPage() {
        let _ = collectListApi.loadNextPage()
    }
    
    /// 请求用户观看列表第一页
    func loadUserWatchedListApi() {
        let _ = watchedListApi.loadData()
    }
    
    /// 请求用户观看列表下一页
    func loadUserWatchedNextPage() {
        let _ = watchedListApi.loadNextPage()
    }
    
    /// 批量删除收藏
    ///
    /// - Parameter videoIds: 视屏Id集合
    func cancleFavor(_ videoIds: [Int]) {
        cancleVideoIds = videoIds
        let _ = cancleFavorApi.loadData()
    }
    
    /// 批量删除观看历史
    func deleteWatchedList(_ videoIds: [Int]) {
        cancleVideoIds = videoIds
        let _ = deleWatchedApi.loadData()
    }
    
    /// 用户反馈
    func fadeBack(_ params: [String: Any]) {
        paramsFadeBack = params
        let _ = userFadeBackApi.loadData()
    }
    
}

// MARK: - 收藏 , 历史观看 列表
extension UserInfoViewModel {
    
    private func requestVideoListSuccess(_ listModel: VideoListModel) {
        if let list = listModel.data, let pageNumber = listModel.current_page {
            if pageNumber == 1 {
                videoList = list
                cellEditModelList = createFakeModel(list)
            } else {
                videoList.append(contentsOf: list)
                cellEditModelList.append(contentsOf: createFakeModel(list))
            }
            loadUserVideoListApiSuccess?(list.count)
        }
    }
    
    /// 创建表编辑model
    private func createFakeModel(_ videoList: [VideoModel]) -> [CellEditModel] {
        var fakeModelList = [CellEditModel]()
        for video in videoList {
            let fakeModel = CellEditModel(videoModel: video, isSelected: false)
            fakeModelList.append(fakeModel)
        }
        return fakeModelList
    }
    
    /// 获取视频列表
    func getVideoList() -> [VideoModel] {
        return videoList
    }
   
    /// 获取视频Model
    func getVideoModel(_ index: Int) -> VideoModel {
        if videoList.count > index {
            return videoList[index]
        }
        return VideoModel()
    }
    
    /// 获取表编辑对象和Model
    func getCellEditModelList() -> [CellEditModel] {
        return cellEditModelList
    }
    
    func getCellEditModel(_ index: Int) -> CellEditModel {
        if cellEditModelList.count > index {
            return cellEditModelList[index]
        }
        return CellEditModel()
    }
}

// MARK: - 请求用户信息
extension UserInfoViewModel {
    /// 请求成功，给单利赋值
    func requestUserInfoSuccess(_ user: UserInfoModel) {
        UserModel.share().api_token = user.api_token
        UserModel.share().coins = user.coins ?? 0
        UserModel.share().id = user.id ?? 0
        UserModel.share().mobile = user.mobile
        UserModel.share().cover_path = user.cover_path
        UserModel.share().name = user.name
        UserModel.share().email = user.email
        UserModel.share().empirical = user.empirical ?? 0
        UserModel.share().created_at = user.created_at
        UserModel.share().lv_title = user.lv_title
        UserModel.share().updated_at = user.updated_at
        UserModel.share().view_count_daily_total = user.view_count_daily_total ?? 0
        UserModel.share().view_count_daily_use = user.view_count_daily_use ?? 0
        UserModel.share().view_count = user.view_count ?? 0
        UserModel.share().invite_code = user.invite_code
        UserModel.share().remain_count = user.remain_count ?? 0
        
        UserModel.share().type = user.type
        UserModel.share().isRealUser = user.type == 0
        UserModel.share().isLogin = true
        UserDefaults.standard.set(user.invite_code, forKey: UserDefaults.kUserInviteCode)
        UserDefaults.standard.set(user.api_token, forKey: UserDefaults.kUserToken)
        loadUserInfoSuccessHandler?()
    }
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension UserInfoViewModel: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        var params = [String: Any]()
        if manager is UserFavorCancleApi || manager is UserDeleteWatchedApi {
            params[UserFavorCancleApi.kVideo_ids] = cancleVideoIds
            return params
        }
        if manager is UserFadeBackApi {
            return paramsFadeBack
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        if manager is UserInfoApi {
            if let userInfo = manager.fetchJSONData(UserReformer()) as? UserInfoModel {
                requestUserInfoSuccess(userInfo)
            }
        }
        if manager is UserFavorListApi || manager is UserWatchedListApi {
            if let list = manager.fetchJSONData(VideoReformer()) as? VideoListModel {
                requestVideoListSuccess(list)
            }
        }
        if manager is UserFavorCancleApi {
            loadUserCollectedListApi()
        }
        if manager is UserDeleteWatchedApi {
            loadUserWatchedListApi()
        }
        if manager is UserFadeBackApi {
            fadeBackSuccessHandler?()
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        if manager is UserInfoApi {
            loadUserInfoFailHandler?()
        }
        if manager is UserFavorListApi || manager is UserWatchedListApi {
            loadUserVideoListApiFail?()
        }
        if manager is UserFadeBackApi {
            fadeBackFailHandler?(manager.errorMessage)
        }
    }
}

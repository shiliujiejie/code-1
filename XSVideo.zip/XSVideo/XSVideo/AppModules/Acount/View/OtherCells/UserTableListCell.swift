//
//  UserTableListCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/10.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class UserTableListCell: UITableViewCell {

    static let cellId = "UserTableListCell"
    
    @IBOutlet weak var switchSet: UISwitch!
    @IBOutlet weak var titleLab: UILabel!
    @IBOutlet weak var msgLable: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

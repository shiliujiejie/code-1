//
//  WatchedListNoDataCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/20.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 未登录，或没有
class WatchedListNoDataCell: UITableViewCell {
    
    static let cellId = "WatchedListNoDataCell"
    
    private let noDateMsgLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.lightGray
        lable.text = UIViewController.localStr("kNotWatchedListTitle")
        lable.font = UIFont.systemFont(ofSize: 16)
        return lable
    }()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.backgroundColor = UIColor.white
        contentView.addSubview(noDateMsgLable)
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

// MARK: - Layout
private extension WatchedListNoDataCell {
    
    func layoutPageSubviews() {
        layoutNodataLable()
    }
    func layoutNodataLable() {
        noDateMsgLable.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
        }
    }
}

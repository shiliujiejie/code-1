//
//  PopLarizeCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/25.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class PopLarizeCell: UITableViewCell {

    static let cellId = "PopLarizeCell"
    
    @IBOutlet weak var containserView: UIView!
    @IBOutlet weak var barImage: UIImageView!
    @IBOutlet weak var numberLable: UILabel!
    @IBOutlet weak var nameLable: UILabel!
    @IBOutlet weak var infoLable: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        containserView.backgroundColor = UIColor.white
        containserView.layer.cornerRadius = 10
        containserView.layer.shadowColor = UIColor.lightGray.cgColor
        containserView.layer.shadowOffset = CGSize()
        containserView.layer.shadowOpacity = 0.8
        containserView.layer.shadowRadius = 6
        containserView.clipsToBounds = false
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

//
//  UserHeaderCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/10.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class UserHeaderCell: UITableViewCell {
    
    static let cellId = "UserHeaderCell"
    
    let imageHeader: UIImageView = {
        let header = UIImageView()
        header.layer.cornerRadius = 35
        header.image = ConstValue.kDefaultHeader
        header.layer.masksToBounds = true
        return header
    }()
    let headerLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.darkGray
        lable.textAlignment = .right
        lable.text = UIViewController.localStr("kChangeHeaderTitle")
        lable.font = UIFont .systemFont(ofSize: 16)
        return lable
    }()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.accessoryType = .disclosureIndicator
        contentView.addSubview(imageHeader)
        contentView.addSubview(headerLable)
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}


// MARK: - Layout
private extension UserHeaderCell {
    
    func layoutPageSubviews() {
        layoutHeaderImage()
        layoutHeaderLable()
    }
    
    func layoutHeaderImage() {
        imageHeader.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.height.width.equalTo(70)
            make.leading.equalTo(20)
        }
    }
    
    func layoutHeaderLable() {
        headerLable.snp.makeConstraints { (make) in
            make.trailing.equalTo(-10)
            make.centerY.equalToSuperview()
        }
    }
}

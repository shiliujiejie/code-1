//
//  CoinRecordCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/26.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class CoinRecordCell: UITableViewCell {
    static let cellId = "CoinRecordCell"
    
    private let namelable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.darkGray
        lable.font = UIFont.systemFont(ofSize: 16)
        return lable
    }()
    private let timelable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.darkGray
        lable.font = UIFont.systemFont(ofSize: 12)
        return lable
    }()
    private let countlable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor(r: 240 , g: 98 , b: 0)
        lable.font = UIFont.systemFont(ofSize: 16)
        lable.textAlignment = .right
        return lable
    }()
    private let coinImage: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(named: "goldCoin")
        return imageView
    }()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.addSubview(namelable)
        contentView.addSubview(timelable)
        contentView.addSubview(coinImage)
        contentView.addSubview(countlable)
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setRecorModel(_ model: CoinRecordModel) {
        namelable.text = model.event_label ?? ""
        timelable.text = model.created_at ?? ""
        countlable.text = String(format: "%d", model.value ?? 0)
    }
    
}


private extension CoinRecordCell {
    
    func layoutPageSubviews() {
        layoutNameLable()
        layoutTimeLable()
        layoutCoinImage()
        layoutCountLable()
    }
    
    func layoutNameLable() {
        namelable.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalTo(10)
            make.height.equalTo(20)
        }
    }
    
    func layoutTimeLable() {
        timelable.snp.makeConstraints { (make) in
            make.leading.equalTo(namelable)
            make.top.equalTo(namelable.snp.bottom).offset(5)
            make.height.equalTo(15)
        }
    }
    
    func layoutCoinImage() {
        coinImage.snp.makeConstraints { (make) in
            make.trailing.equalTo(-18)
            make.centerY.equalToSuperview()
            make.width.equalTo(20)
            make.height.equalTo(20)
        }
    }
    
    func layoutCountLable() {
        countlable.snp.makeConstraints { (make) in
            make.trailing.equalTo(coinImage.snp.leading).offset(-10)
            make.centerY.equalToSuperview()
            make.height.equalTo(20)
        }
    }
}

//
//  ExperienInfoCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/26.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class ExperienInfoCell: UITableViewCell {

    static let cellId = "ExperienInfoCell"
    
    @IBOutlet weak var containerView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib() 
        containerView.layer.cornerRadius = 8
        containerView.layer.masksToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

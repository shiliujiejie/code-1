//
//  HistoryWatchEditCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/8.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class HistoryWatchEditCell: UITableViewCell {
    
    let videoImageView: UIImageView = {
        let imageView = UIImageView()
        return imageView
    }()
    
    let videoNameLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.darkText
        lable.font = UIFont.boldSystemFont(ofSize: 15)
        return lable
    }()
    let watchRecodLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.darkGray
        lable.font = UIFont.systemFont(ofSize: 13)
        return lable
    }()
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.addSubview(videoImageView)
        contentView.addSubview(videoNameLable)
        contentView.addSubview(watchRecodLable)
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}

// MARK: - Layout
private extension HistoryWatchEditCell {
    
    func layoutPageSubviews() {
        layoutVideoImage()
        layoutVideoNameLable()
        layoutVideoRecordLable()
    }
    
    func layoutVideoImage() {
        videoImageView.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.centerY.equalToSuperview()
            make.height.equalTo(90 * 7/5)
            make.width.equalTo(90)
        }
    }
    
    func layoutVideoNameLable() {
        videoNameLable.snp.makeConstraints { (make) in
            make.leading.equalTo(videoImageView.snp.trailing).offset(10)
            make.top.equalTo(videoImageView)
            make.height.equalTo(20)
        }
    }
    
    func layoutVideoRecordLable() {
        watchRecodLable.snp.makeConstraints { (make) in
            make.leading.equalTo(videoNameLable)
            make.bottom.equalTo(videoImageView).offset(-10)
            make.height.equalTo(20)
        }
    }
    
}

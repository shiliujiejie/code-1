//
//  InvitedUserListCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/26.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class InvitedUserListCell: UITableViewCell {
    
    static let cellId = "InvitedUserListCell"

    private let container: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white
        view.layer.cornerRadius = 8
        view.layer.shadowColor = UIColor.lightGray.cgColor
        view.layer.shadowOffset = CGSize()
        view.layer.shadowOpacity = 0.8
        view.layer.shadowRadius = 6
        view.clipsToBounds = false
        return view
    }()
    private let nameLable: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .left
        lable.font = UIFont.systemFont(ofSize: 14)
        return lable
    }()
    private let timeLable: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .right
        lable.font = UIFont.systemFont(ofSize: 12)
        return lable
    }()
    private let phoneLable: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .center
        lable.font = UIFont.systemFont(ofSize: 14)
        return lable
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.addSubview(container)
        container.addSubview(nameLable)
        container.addSubview(timeLable)
        container.addSubview(phoneLable)
        layoutPageSubViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setModel(_ model: InvitedModel) {
        nameLable.text = model.invite_name ?? UIViewController.localStr("kUnknownUser")
        phoneLable.text = model.invite_mobile ?? ""
        timeLable.text =  getTime(model.created_at ?? "" )
    }
    
    func getTime(_ time: String) -> String {
        let dataFormater = DateFormatter()
        dataFormater.dateFormat = "yyyy-MM-dd HH:mm:ss"
        if let nowTime = dataFormater.date(from: time) {
            dataFormater.dateFormat = "yyyy-MM-dd"
            let changTime = dataFormater.string(from: nowTime)
            return changTime
        }
        return time
    }
}


// MARK: - Layout
private extension InvitedUserListCell {
    
    func layoutPageSubViews() {
        layoutContainer()
        layoutTopBarSubviews()
    }
    
    func layoutContainer() {
        container.snp.makeConstraints { (make) in
            make.leading.equalTo(0)
            make.trailing.equalTo(0)
            make.top.equalTo(10)
            make.bottom.equalTo(-10)
        }
    }
    
    
    func layoutTopBarSubviews() {
        nameLable.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.centerY.equalToSuperview()
            make.width.equalTo(90)
        }
        timeLable.snp.makeConstraints { (make) in
            make.trailing.equalTo(-10)
            make.centerY.equalToSuperview()
        }
        phoneLable.snp.makeConstraints { (make) in
            make.centerY.centerX.equalToSuperview()
            make.width.equalTo(120)
        }
        
    }
}

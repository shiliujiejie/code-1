//
//  AcountMsgHeaderView.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/6.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 用户信息头部
class AcountMsgHeaderView: UIView {
    
    
    lazy var headerbgImage: UIImageView = {
        let image = UIImageView()
        image.isUserInteractionEnabled = true
        image.image = UIImage(named: "acountHeaderBg")
        return image
    }()
    lazy var headerButton: UIButton = {
        let button = UIButton(type: .custom)
        button.layer.cornerRadius = 31.5
        button.layer.masksToBounds = true
        button.setImage(ConstValue.kDefaultHeader, for: .normal)
        button.addTarget(self, action: #selector(userHeaderNickNameClick), for: .touchUpInside)
        return button
    }()
    private lazy var nickNameButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitleColor(UIColor.white, for: .normal)
        button.setTitle(UIViewController.localStr("kNickNameDefaultTitle"), for: .normal)
        button.addTarget(self, action: #selector(userHeaderNickNameClick), for: .touchUpInside)
        return button
    }()
    private lazy var lvButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "LV2_icon"), for: .normal)
        button.addTarget(self, action: #selector(lvButtonClick), for: .touchUpInside)
        button.isHidden = true
        return button
    }()
    lazy var lvLable: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .center
        lable.font = UIFont.systemFont(ofSize: 14)
        lable.textColor = UIColor.white
        lable.isHidden = true
        return lable
    }()
    lazy var userTypeLable: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .center
        lable.font = UIFont.systemFont(ofSize: 14)
        lable.textColor = UIColor.white
        lable.isHidden = true
        return lable
    }()
    
    private lazy var topUpButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle(UIViewController.localStr("kChargeCoinsTitle"), for: .normal)
        button.setTitleColor(UIColor.white, for: .normal)
        button.setBackgroundImage(UIImage(named: "chargeCoinsBg"), for: .normal)
        button.layer.cornerRadius = 17.5
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(useChargeClick), for: .touchUpInside)
        button.isHidden = true
        return button
    }()
    private lazy var itemsContainer: UIView = {
        let view = UIView(frame: CGRect(x: 15, y: 170, width: ConstValue.kScreenWdith - 30, height: 84))
        view.backgroundColor = UIColor.white
        view.layer.cornerRadius = 8
        view.layer.shadowColor = UIColor.lightGray.cgColor
        view.layer.shadowOffset = CGSize()
        view.layer.shadowOpacity = 0.8
        view.layer.shadowRadius = 6
        view.clipsToBounds = false
        return view
    }()
    lazy var freeWatchTimeLable: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .center
        lable.textColor = ConstValue.kAppDefaultTitleColor
        lable.font = UIFont.systemFont(ofSize: 20)
        lable.text = "0"
        return lable
    }()
    lazy var freeWatchLable: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .center
        lable.font = UIFont.systemFont(ofSize: 14)
        lable.text = UIViewController.localStr("kTodayWatchCountTitle")
        return lable
    }()
    lazy var recommentLable: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .center
        lable.font = UIFont.systemFont(ofSize: 14)
        lable.text = UIViewController.localStr("kGoPopularTitle")
        return lable
    }()
    private let recommentImage: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "recommentIcon")
        image.contentMode = .scaleAspectFit
        return image
    }()
    private lazy var recommentButton: UIButton = {
        let button = UIButton(type: .custom)
        button.addTarget( self, action: #selector(recommentButtonClick), for: .touchUpInside)
        return button
    }()
    private let lineView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.gray
        return view
    }()
    
    var userHeaderItemClick:(() -> Void)?
    var userChargeClickHandler:(() -> Void)?
    var recommentClickHandler:(() -> Void)?
    var lvButtonClickHandler:(() -> Void)?
    var actionItemClick:((_ index: Int) -> Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.white
        addSubview(headerbgImage)
        addSubview(itemsContainer)
        headerbgImage.addSubview(headerButton)
        headerbgImage.addSubview(nickNameButton)
        headerbgImage.addSubview(topUpButton)
        headerbgImage.addSubview(lvButton)
        headerbgImage.addSubview(lvLable)
        headerbgImage.addSubview(userTypeLable)
        
        itemsContainer.addSubview(lineView)
        itemsContainer.addSubview(recommentImage)
        itemsContainer.addSubview(recommentLable)
        itemsContainer.addSubview(freeWatchTimeLable)
        itemsContainer.addSubview(freeWatchLable)
        itemsContainer.addSubview(recommentButton)
    
        layoutPageSubviews()
        layoutHeaderBgSubviews()
        layoutItemContainerPageSubviews()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fixUserData() {
        headerButton.kfSetHeaderImageWithUrl(UserModel.share().cover_path, placeHolder: ConstValue.kDefaultHeader)
        nickNameButton.setTitle( UserModel.share().name ?? UIViewController.localStr("kNickNameDefaultTitle"), for: .normal)
        lvButton.isHidden = !UserModel.share().isRealUser
        lvLable.isHidden = !UserModel.share().isRealUser
        lvLable.text = UserModel.share().lv_title ?? "LV1"
        userTypeLable.isHidden = !UserModel.share().isLogin || UserModel.share().isRealUser
        userTypeLable.text = UIViewController.localStr("kYoukeType")
        lvButton.setImage(UIImage(named: String(format: "%@_Icon", UserModel.share().lv_title ?? "LV1")), for: .normal)
        let leaseCount = (UserModel.share().view_count_daily_total ?? 0) - (UserModel.share().view_count_daily_use ?? 0)
        if leaseCount >= 0 {
            freeWatchTimeLable.text = "\(leaseCount)/\(UserModel.share().view_count_daily_total ?? 0)"
        }
        if UserModel.share().view_count_daily_total ?? 0 >= 10000 {
             freeWatchTimeLable.text = UIViewController.localStr("kWatchVideoFreeTitle")
        }
    }
    
}

// MARK: - User-Action
private extension AcountMsgHeaderView {
    
    @objc func useChargeClick() {
       userChargeClickHandler?()
    }
    
    @objc func userHeaderNickNameClick() {
        userHeaderItemClick?()
    }
    
    @objc func recommentButtonClick() {
        recommentClickHandler?()
    }
    
    @objc func lvButtonClick() {
        lvButtonClickHandler?()
    }
    
}

// MARK: - Layout
private extension AcountMsgHeaderView {
    
    func layoutPageSubviews() {
        layoutHeaderBg()
        layoutItemsContainer()
    }
    
    func layoutItemContainerPageSubviews() {
        lineView.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.height.equalTo(26)
            make.width.equalTo(1.4)
        }
        freeWatchTimeLable.snp.makeConstraints { (make) in
            make.leading.equalToSuperview()
            make.trailing.equalTo(lineView.snp.leading)
            make.top.equalTo(5)
            make.height.equalTo(37)
        }
        freeWatchLable.snp.makeConstraints { (make) in
            make.leading.equalToSuperview()
            make.bottom.equalTo(-7)
            make.trailing.equalTo(freeWatchTimeLable)
            make.height.equalTo(35)
        }
        recommentLable.snp.makeConstraints { (make) in
            make.trailing.equalToSuperview()
            make.leading.equalTo(lineView.snp.trailing)
            make.bottom.equalTo(-7)
            make.height.equalTo(35)
        }
        recommentImage.snp.makeConstraints { (make) in
            make.centerX.equalTo(recommentLable)
            make.top.equalTo(8)
            make.bottom.equalTo(recommentLable.snp.top).offset(-8)
            make.width.equalTo(24)
        }
        recommentButton.snp.makeConstraints { (make) in
            make.leading.equalTo(lineView.snp.trailing)
            make.top.bottom.trailing.equalToSuperview()
        }
       
    }
    
    func layoutHeaderBgSubviews() {
        layoutHeaderImageView()
        layoutNickNameLable()
        layoutLvbutton()
        layoutLvLable()
        layoutUserTypeLable()
        layoutTopUpButton()
    }
    
    func layoutHeaderBg() {
        headerbgImage.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(200)
        }
    }
    
    func layoutHeaderImageView() {
        headerButton.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview().offset(-20)
            make.leading.equalTo(15)
            make.width.equalTo(63)
            make.height.equalTo(63)
        }
    }
    
    func layoutNickNameLable() {
        nickNameButton.snp.makeConstraints { (make) in
            make.leading.equalTo(headerButton.snp.trailing).offset(10)
            make.centerY.equalTo(headerButton)
            make.height.equalTo(30)
        }
    }
    func layoutLvbutton() {
        lvButton.snp.makeConstraints { (make) in
            make.leading.equalTo(nickNameButton)
            make.top.equalTo(nickNameButton.snp.bottom).offset(5)
            make.height.equalTo(30)
            make.width.equalTo(30)
        }
    }
    func layoutLvLable() {
        lvLable.snp.makeConstraints { (make) in
            make.leading.equalTo(lvButton.snp.trailing)
            make.top.equalTo(nickNameButton.snp.bottom).offset(5)
            make.height.equalTo(30)
            make.width.equalTo(50)
        }
    }
    func layoutUserTypeLable() {
        userTypeLable.snp.makeConstraints { (make) in
            make.leading.equalTo(nickNameButton)
            make.top.equalTo(nickNameButton.snp.bottom).offset(5)
            make.height.equalTo(30)
            make.width.equalTo(50)
        }
    }
    func layoutTopUpButton() {
        topUpButton.snp.makeConstraints { (make) in
            make.trailing.equalTo(20)
            make.centerY.equalTo(headerButton)
            make.width.equalTo(140)
            make.height.equalTo(35)
        }
    }
    
    func layoutItemsContainer() {
        itemsContainer.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(headerbgImage.snp.bottom).offset(-38)
            make.height.equalTo(84)
        }
    }
    
}


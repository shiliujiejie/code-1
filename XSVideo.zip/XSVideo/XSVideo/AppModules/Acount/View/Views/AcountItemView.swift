//
//  AcountItemView.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/6.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 个人中心的Item (爱逗币 / 邀请码 / 邀请朋友 / )
class AcountItemView: UIView {
    
    private let itemImage: UIImageView = {
        let imageView = UIImageView()
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    private let itemTitle: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .center
        lable.font = UIFont.systemFont(ofSize: 14)
        lable.textColor = UIColor.darkText
        return lable
    }()
   let itemTipsLable: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .center
        lable.font = UIFont.systemFont(ofSize: 12)
        lable.textColor = UIColor.darkGray
        return lable
    }()
    private lazy var fakeButton: UIButton = {
        let button = UIButton(type: .custom)
        button.backgroundColor = UIColor.clear
        button.addTarget(self, action: #selector(itemClick), for: .touchUpInside)
        return button
    }()
    var itemClickHandler:((_ itemTag: Int) -> Void)?

    init(frame: CGRect, title: String, image: String,tips: String?,actionHandler:((_ itemTag: Int) -> Void)?) {
        super.init(frame: frame)
        backgroundColor = UIColor.white
        itemImage.image = UIImage(named: image)
        itemTitle.text = title
        itemTipsLable.text  = tips ?? ""
        addSubview(itemImage)
        addSubview(itemTitle)
        addSubview(itemTipsLable)
        addSubview(fakeButton)
        layoutPageSubvies()
        itemClickHandler = actionHandler
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

// MARK: - User-Action
private extension AcountItemView {
    
    @objc func itemClick() {
        itemClickHandler?(self.tag)
    }
}

// MARK: - Layout
private extension AcountItemView {
    
    func layoutPageSubvies() {
        layoutItemImage()
        layoutTitleLable()
        layoutItemTipsLable()
        layoutFakeButton()
    }
    
    func layoutItemImage() {
        itemImage.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(5)
            make.height.width.equalTo(30)
        }
    }
    
    func layoutTitleLable() {
        itemTitle.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(itemImage.snp.bottom).offset(5)
            make.height.equalTo(20)
        }
    }
    
    func layoutItemTipsLable() {
        itemTipsLable.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(itemTitle.snp.bottom).offset(5)
            make.height.equalTo(18)
        }
    }
    
    func layoutFakeButton() {
        fakeButton.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
}

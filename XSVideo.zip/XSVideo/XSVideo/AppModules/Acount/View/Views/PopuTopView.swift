//
//  PopuTopView.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/25.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class PopuTopView: UIView {

    private lazy var headerbgImage: UIImageView = {
        let image = UIImageView()
        image.isUserInteractionEnabled = true
        image.image = UIImage(named: "acountHeaderBg")
        return image
    }()
    private lazy var headerButton: UIButton = {
        let button = UIButton(type: .custom)
        button.layer.cornerRadius = 31.5
        button.layer.masksToBounds = true
        button.setImage(ConstValue.kDefaultHeader, for: .normal)
        button.addTarget(self, action: #selector(userHeaderNickNameClick), for: .touchUpInside)
        return button
    }()
    private lazy var nickNameButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitleColor(UIColor.white, for: .normal)
        button.setTitle(UIViewController.localStr("kNickNameDefaultTitle"), for: .normal)
        button.addTarget(self, action: #selector(userHeaderNickNameClick), for: .touchUpInside)
        return button
    }()
   
    let myInviteCodeLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 14)
        lable.textColor = UIColor.white
        lable.text = "我的邀请码: --"
        return lable
    }()
    
    private lazy var lvContainer: UIView = {
        let view = UIView(frame: CGRect(x: 15, y: 170, width: ConstValue.kScreenWdith - 30, height: 92))
        view.backgroundColor = UIColor.white
        view.layer.cornerRadius = 8
        view.layer.shadowColor = UIColor.lightGray.cgColor
        view.layer.shadowOffset = CGSize()
        view.layer.shadowOpacity = 0.8
        view.layer.shadowRadius = 6
        view.clipsToBounds = false
        return view
    }()
    private lazy var lvContainerButton: UIButton = {
        let button = UIButton(type: .custom)
        button.addTarget(self, action: #selector(containerButtonClick), for: .touchUpInside)
        return button
    }()
    
    private lazy var lvAImage: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(named: "LV1_Icon")
        imageView.contentMode = .scaleAspectFit
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    private let lvALable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 16)
        lable.textAlignment = .center
        lable.text = "LV1"
        return lable
    }()
    
    private let progressView: UIProgressView = {
        let view = UIProgressView()
        view.progressTintColor = UIColor(r: 255 , g: 207 , b: 0)
        view.trackTintColor = UIColor.lightGray
        view.layer.cornerRadius = 1.5
        view.layer.masksToBounds = true
        view.progress = 0.0
        return view
    }()
    private let msgLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 12)
        lable.textColor = ConstValue.kAppDefaultTitleColor
        lable.textAlignment = .center
        lable.text = "---"
        return lable
    }()
    private lazy var lvBImage: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(named: "LV2_Icon")
        imageView.contentMode = .scaleAspectFit
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    private let lvBLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 16)
        lable.textAlignment = .center
        lable.text = "LV2"
        return lable
    }()
    
    var itemsContainer: UIImageView = {
        let view = UIImageView(frame: CGRect(x: 15, y: 170, width: ConstValue.kScreenWdith - 30, height: 84))
        view.image = UIImage(named: "watchedCountBg")
        view.layer.cornerRadius = 8
        view.layer.shadowColor = UIColor.lightGray.cgColor
        view.layer.shadowOffset = CGSize()
        view.layer.shadowOpacity = 0.8
        view.layer.shadowRadius = 6
        view.clipsToBounds = false
        return view
    }()
    
    private lazy var freeWatchTimeLable: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .center
        lable.textColor = UIColor.white
        lable.font = UIFont.systemFont(ofSize: 20)
        lable.text = "0"
        return lable
    }()
    private lazy var freeWatchLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.white
        lable.textAlignment = .center
        lable.font = UIFont.systemFont(ofSize: 16)
        lable.text = UIViewController.localStr("kTodayWatchCountTitle")
        return lable
    }()
    private lazy var rleaseCountLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor(r: 255 , g: 207 , b: 0)
        lable.textAlignment = .center
        lable.font = UIFont.systemFont(ofSize: 20)
        lable.text = "0"
        return lable
    }()
    private lazy var leaseTimeLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.white
        lable.textAlignment = .center
        lable.font = UIFont.systemFont(ofSize: 16)
        lable.text = UIViewController.localStr("kLeaseWatchCountTitle")
        return lable
    }()
   
    private let lineView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white
        return view
    }()
    
    var buttonClick:((_ index:Int) -> Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.white
        addSubview(headerbgImage)
        addSubview(lvContainer)
        addSubview(itemsContainer)
        headerbgImage.addSubview(headerButton)
        headerbgImage.addSubview(nickNameButton)
        headerbgImage.addSubview(myInviteCodeLable)
    
        lvContainer.addSubview(progressView)
        lvContainer.addSubview(msgLable)
        lvContainer.addSubview(lvAImage)
        lvContainer.addSubview(lvALable)
        lvContainer.addSubview(lvBImage)
        lvContainer.addSubview(lvBLable)
        lvContainer.addSubview(lvContainerButton)
        
        itemsContainer.addSubview(lineView)
        itemsContainer.addSubview(rleaseCountLable)
        itemsContainer.addSubview(leaseTimeLable)
        itemsContainer.addSubview(freeWatchTimeLable)
        itemsContainer.addSubview(freeWatchLable)
        
        layoutPageSubviews()
        layoutHeaderBgSubviews()
        layoutLvContainerSubviews()
        layoutItemContainerPageSubviews()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setUserInfo() {
        lvContainer.isHidden = !UserModel.share().isRealUser
        if UserModel.share().isRealUser {
            lvContainer.snp.updateConstraints { (make) in
                make.height.equalTo(92)
            }
        } else {
            lvContainer.snp.updateConstraints { (make) in
                make.height.equalTo(38)
            }
        }
        headerButton.kfSetHeaderImageWithUrl(UserModel.share().cover_path, placeHolder: ConstValue.kDefaultHeader)
        nickNameButton.setTitle(UserModel.share().name ?? UIViewController.localStr("kNot"), for: .normal)
        freeWatchTimeLable.text = "\(UserModel.share().view_count_daily_use ?? 0)"
        let leaseCount = (UserModel.share().view_count_daily_total ?? 0) - (UserModel.share().view_count_daily_use ?? 0)
        rleaseCountLable.text = leaseCount > 0 ? "\(leaseCount)" : "0"
        myInviteCodeLable.text = "\(UIViewController.localStr("kLvMyInviteCodeTitle")): \(UserModel.share().invite_code ?? UIViewController.localStr("kNot"))"
        if UserModel.share().view_count_daily_total ?? 0 >= 10000 {
            rleaseCountLable.text = UIViewController.localStr("kWatchVideoFreeTitle")
        }
        lvAImage.image = UIImage(named: String(format: "%@_Icon", UserModel.share().lv_title ?? "LV1"))
        let leftTitle = UIViewController.localStr("kNextLvLeftTitel")
        let rightTitle = UIViewController.localStr("kLvExperienTitle")
        
        if let exp = UserModel.share().empirical {
            if 0 < exp && exp < 50 {
                lvALable.text = "LV1"
                lvBLable.text = "LV2"
                progressView.progress = Float(exp)/50.0
                msgLable.text = "\(leftTitle)\(50-exp)\(rightTitle)"
            } else if 50 <= exp && exp < 200 {
                lvALable.text = "LV2"
                lvBLable.text = "LV3"
                progressView.progress = Float(exp - 50)/150.0
                msgLable.text = "\(leftTitle)\(200-exp)\(rightTitle)"
            }
            else if 200 <= exp && exp < 500 {
                lvALable.text = "LV3"
                lvBLable.text = "LV4"
                progressView.progress = Float(exp - 200)/300
                msgLable.text = "\(leftTitle)\(500-exp)\(rightTitle)"
            }
            else if 500 <= exp && exp < 1100 {
                lvALable.text = "LV4"
                lvBLable.text = "LV5"
                progressView.progress = Float(exp - 500)/600
                msgLable.text = "\(leftTitle)\(1100-exp)\(rightTitle)"
            }
            else if 1100 <= exp && exp < 2000 {
                lvALable.text = "LV5"
                lvBLable.text = "LV6"
                progressView.progress = Float(exp - 1100)/900
                msgLable.text = "\(leftTitle)\(2000-exp)\(rightTitle)"
            }
            else if 2000 <= exp && exp < 3200 {
                lvALable.text = "LV6"
                lvBLable.text = "LV7"
                progressView.progress = Float(exp - 2000)/1200
                msgLable.text = "\(leftTitle)\(3200-exp)\(rightTitle)"
            }
            else if 3200 <= exp && exp < 4700 {
                lvALable.text = "LV7"
                lvBLable.text = "LV8"
                progressView.progress = Float(exp - 3200)/1500
                msgLable.text = "\(leftTitle)\(4700-exp)\(rightTitle)"
            }
            else if 4700 < exp && exp < 6500 {
                lvALable.text = "LV8"
                lvBLable.text = "LV9"
                progressView.progress = Float(exp - 4700)/1800
                msgLable.text = "\(leftTitle)\(6500-exp)\(rightTitle)"
            }
            else if 6500 <= exp && exp < 8900 {
                lvALable.text = "LV9"
                lvBLable.text = "LV10"
                progressView.progress = Float(exp - 6500)/2400
                msgLable.text = "\(leftTitle)\(8900-exp)\(rightTitle)"
            }
            lvBImage.image = UIImage(named: String(format: "%@_Icon", lvBLable.text ?? "LV2"))
        }
    }

}

// MARK: - User-Action
private extension PopuTopView {
    
    @objc func userHeaderNickNameClick() {
        buttonClick?(1)
    }
    
    @objc func recommentButtonClick() {
        buttonClick?(2)
    }
    
    @objc func containerButtonClick() {
        buttonClick?(3)
    }
    
}

// MARK: - Layout
private extension PopuTopView {
    
    func layoutPageSubviews() {
        layoutHeaderBg()
        layoutlvContainer()
        layoutItemContainer()
    }
    
    func layoutItemContainerPageSubviews() {
        lineView.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.height.equalTo(40)
            make.width.equalTo(1.4)
        }
        freeWatchLable.snp.makeConstraints { (make) in
            make.leading.equalToSuperview()
            make.bottom.equalTo(-7)
            make.trailing.equalTo(lineView.snp.leading)
            make.height.equalTo(35)
        }
        freeWatchTimeLable.snp.makeConstraints { (make) in
            make.leading.equalToSuperview()
            make.trailing.equalTo(lineView.snp.leading)
            make.bottom.equalTo(freeWatchLable.snp.top).offset(-8)
        }
        leaseTimeLable.snp.makeConstraints { (make) in
            make.trailing.equalToSuperview()
            make.leading.equalTo(lineView.snp.trailing)
            make.bottom.equalTo(-7)
            make.height.equalTo(35)
        }
        rleaseCountLable.snp.makeConstraints { (make) in
            make.leading.equalTo(lineView.snp.trailing)
            make.bottom.equalTo(leaseTimeLable.snp.top).offset(-8)
            make.trailing.equalToSuperview()
        }
        
    }
    
    func layoutLvContainerSubviews() {
        progressView.snp.makeConstraints { (make) in
            make.bottom.equalTo(lvContainer.snp.centerY).offset(-10)
            make.leading.equalTo(80)
            make.trailing.equalTo(-80)
            make.height.equalTo(3)
        }
        
        msgLable.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(lvContainer.snp.centerY).offset(8)
            make.leading.trailing.equalTo(progressView)
        }
        
        lvAImage.snp.makeConstraints { (make) in
            make.trailing.equalTo(progressView.snp.leading).offset(-15)
            make.centerY.equalTo(progressView)
            make.height.width.equalTo(40)
        }
        lvALable.snp.makeConstraints { (make) in
            make.centerX.equalTo(lvAImage)
            make.centerY.equalTo(msgLable)
            make.height.equalTo(20)
            make.width.equalTo(45)
        }
        lvBImage.snp.makeConstraints { (make) in
            make.leading.equalTo(progressView.snp.trailing).offset(15)
            make.centerY.equalTo(progressView)
            make.height.width.equalTo(40)
        }
        lvBLable.snp.makeConstraints { (make) in
            make.centerX.equalTo(lvBImage)
            make.centerY.equalTo(msgLable)
            make.height.equalTo(20)
            make.width.equalTo(45)
        }
        lvContainerButton.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    func layoutHeaderBgSubviews() {
        layoutHeaderImageView()
        layoutNickNameLable()
        layoutInviteCodeLable()
    }
    
    func layoutHeaderBg() {
        headerbgImage.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(207)
        }
    }
    
    func layoutHeaderImageView() {
        headerButton.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.leading.equalTo(15)
            make.width.equalTo(63)
            make.height.equalTo(63)
        }
    }
    
    func layoutNickNameLable() {
        nickNameButton.snp.makeConstraints { (make) in
            make.leading.equalTo(headerButton.snp.trailing).offset(10)
            make.centerY.equalTo(headerButton)
            make.height.equalTo(30)
        }
    }
    
    func layoutInviteCodeLable() {
        myInviteCodeLable.snp.makeConstraints { (make) in
            make.leading.equalTo(nickNameButton)
            make.top.equalTo(nickNameButton.snp.bottom).offset(7)
            make.height.equalTo(20)
        }
    }
    
    func layoutlvContainer() {
        lvContainer.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(headerbgImage.snp.bottom).offset(-38)
            make.height.equalTo(92)
        }
    }
    
    func layoutItemContainer() {
        itemsContainer.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(lvContainer.snp.bottom).offset(25)
            make.height.equalTo(92)
        }
    }
    
}


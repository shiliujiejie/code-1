//
//  AcountItemCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/24.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class AcountItemCell: UITableViewCell {
    
    static let cellId = "AcountItemCell"
    static let itemTagBase = 555
    let itemWidth: CGFloat = (ConstValue.kScreenWdith - 90)/4
    let itemHeight: CGFloat = 80
    
    var coinItem: AcountItemView?
    var acountItemClick:((_ index: Int) ->Void)?
    
    var coinsCount: Int = 0 {
        didSet {
            coinItem?.itemTipsLable.text = "\(UIViewController.localStr("kCoinsLeaseTitle")) \(coinsCount)"
        }
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        createItems()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func createItems() {
        let titles = [UIViewController.localStr("kAiDouCoins"), UIViewController.localStr("kItemInviteCodeTitle"), UIViewController.localStr("kItemInviteFriendsTitle"), UIViewController.localStr("kConvertCenterTitle")]
        let images = ["myCoinIcon","myInviteCodeIcon","InviteFriendIcon","taskCenterIcon"]
        for i in 0..<4 {
            let adbItem = AcountItemView (frame: CGRect.zero, title: titles[i], image: images[i], tips: "") { [weak self] (itemTag) in
                let tag =  itemTag - AcountItemCell.itemTagBase
                self?.acountItemClick?(tag)
            }
            if i == 0 {
                coinItem = adbItem
            }
            adbItem.tag = i + AcountItemCell.itemTagBase
            contentView.addSubview(adbItem)
            adbItem.snp.makeConstraints { (make) in
                make.leading.equalTo(15 + (itemWidth + 20) * CGFloat(i))
                make.centerY.equalToSuperview()
                make.height.equalTo(itemHeight)
                make.width.equalTo(itemWidth)
            }
        }
    }

}

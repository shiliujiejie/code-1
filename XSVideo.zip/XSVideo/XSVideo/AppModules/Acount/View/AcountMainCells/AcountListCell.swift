//
//  AcountListCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/6.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// AcountListItem
class AcountListCell: UITableViewCell {

    static let cellId = "AcountListCell"
    
    @IBOutlet weak var itemImage: UIImageView!
    @IBOutlet weak var itemTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
}

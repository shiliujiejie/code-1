//
//  HelpController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/25.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import SnapKit

/// 用户反馈页面
class HelpController: UIViewController {
    
    lazy var textView: UITextView = {
        let textView = UITextView()
        textView.textColor = UIColor.darkGray
        textView.font = UIFont.systemFont(ofSize: 14)
        textView.layer.cornerRadius = 10
        textView.layer.shadowColor = UIColor.groupTableViewBackground.cgColor
        textView.layer.shadowOffset = CGSize()
        textView.layer.shadowOpacity = 0.8
        textView.layer.shadowRadius = 6
        textView.clipsToBounds = false
        textView.delegate = self
        return textView
    }()
    let placeHodlerLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.lightGray
        lable.font = UIFont.systemFont(ofSize: 14)
        lable.text = UIViewController.localStr("kHelpCenterInfoMsgPlaceholder")
        return lable
    }()
    
    lazy var connetionView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = 10
        view.layer.shadowColor = UIColor.groupTableViewBackground.cgColor
        view.layer.shadowOffset = CGSize()
        view.layer.shadowOpacity = 0.8
        view.layer.shadowRadius = 6
        view.clipsToBounds = false
        return view
    }()
    lazy var connectTitleLab: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.darkText
        lable.font = UIFont.systemFont(ofSize: 14)
        lable.text = localStr("kContactWayTitle")
        return lable
    }()
    lazy var connectTextF: UITextField = {
        let textF = UITextField()
        textF.borderStyle = .none
        textF.font = UIFont.systemFont(ofSize: 14)
        textF.textColor = UIColor.darkGray
        textF.placeholder = UIViewController.localStr("kHelpCenterContactPlaceholder")
        return textF
    }()
    lazy var commitBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.backgroundColor = ConstValue.kAppDefaultColor
        button.layer.cornerRadius = 22.5
        button.layer.masksToBounds = true
        button.setTitle(UIViewController.localStr("kCommitHelpMsgTitle"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        button.addTarget(self, action: #selector(commitClick), for: .touchUpInside)
        return button
    }()
    let viewMode = UserInfoViewModel()
    /// 处理导航栏
    var navHidenCallBackHandler:((_ isAnimated: Bool) -> Void)?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        title = localStr("kHelpCenterTitle")
        view.addSubview(textView)
        view.addSubview(placeHodlerLable)
        view.addSubview(connetionView)
        connetionView.addSubview(connectTitleLab)
        connetionView.addSubview(connectTextF)
        view.addSubview(commitBtn)
        layoutPageSubviews()
        addViewModelCallBackHandler()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: false)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navHidenCallBackHandler?(true)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    private func addViewModelCallBackHandler() {
        viewMode.fadeBackSuccessHandler = { [weak self] in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            strongSelf.showErrorMessage(strongSelf.localStr("kFadeBackSuccessAlert"), cancelHandler: {
                strongSelf.navigationController?.popViewController(animated: true)
            })
        }
        viewMode.fadeBackFailHandler = { [weak self] (msg) in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            XSAlert.show(type: .warning, text: msg)
        }
    }

    @objc private func commitClick() {
        var params = [String: Any]()
        if let content = textView.text {
            if content.isEmpty {
                XSAlert.show(type: .warning, text: localStr("kNotInputHelpMsgAlert"))
                return
            }
            params[UserFadeBackApi.kContent] = content
        }
        if let connectStr = connectTextF.text {
            let connect = connectStr.removeAllSpace()
//            if connect == nil || connect!.isEmpty {
//                XSAlert.show(type: .warning, text: localStr("kPleaseInputContactWayAlert"))
//                return
//            }
            params[UserFadeBackApi.kContact] = connect
        }
        XSProgressHUD.showProgress(msg: nil, onView: view, animated: false)
        viewMode.fadeBack(params)
    }
}

// MARK: - UITextViewDelegate
extension HelpController: UITextViewDelegate {
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        placeHodlerLable.text = ""
    }
    func textViewShouldEndEditing(_ textView: UITextView) -> Bool {
        if textView.text.isEmpty {
           placeHodlerLable.text = UIViewController.localStr("kHelpCenterInfoMsgPlaceholder")
        }
        return true
    }
}

// MARK: - Layout
private extension HelpController {
    
    func layoutPageSubviews() {
        textView.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalTo(20)
            make.trailing.equalTo(-15)
            make.height.equalTo(120)
        }
        placeHodlerLable.snp.makeConstraints { (make) in
            make.leading.top.equalTo(textView).offset(5)
            make.height.equalTo(20)
        }
        connetionView.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(textView)
            make.top.equalTo(textView.snp.bottom).offset(25)
            make.height.equalTo(60)
        }
        connectTitleLab.snp.makeConstraints { (make) in
            make.leading.equalTo(20)
            make.centerY.equalToSuperview()
            make.width.equalTo(70)
        }
        connectTextF.snp.makeConstraints { (make) in
            make.leading.equalTo(connectTitleLab.snp.trailing).offset(5)
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-10)
        }
        commitBtn.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(connetionView)
            make.top.equalTo(connetionView.snp.bottom).offset(30)
            make.height.equalTo(45)
        }
    }
}


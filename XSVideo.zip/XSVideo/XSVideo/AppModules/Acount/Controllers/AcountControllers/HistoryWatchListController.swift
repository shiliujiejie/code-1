//
//  HistoryWatchListController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/8.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import SnapKit

struct CellEditModel {
    var videoModel: VideoModel?
    var isSelected: Bool?   // 此属性是本地为了区分数据Model的选中状态而加的，初始值应该为nil
    
}

class HistoryWatchListController: UIViewController {
    
    /// 每页应有的数据条数
    static let kPageDataCount = 15
    
    enum ListType {
        case collectedList
        case watchedList
    }
    
    fileprivate var isEdit = false {
        didSet {
            if !isEdit {
                updateButtonView(0, 0)     // 取消编辑时，重置底部按钮
            }
            navigationItem.rightBarButtonItem?.title = isEdit ? "取消" : "编辑"
            baseListVC.tableEditing = isEdit
            updateButtonViewlayout()
        }
    }
    private lazy var baseListVC: NicooTableListViewController = {
        let vc = NicooTableListViewController()
        vc.delegate = self
        return vc
    }()
    private lazy var editBarButton: UIBarButtonItem = {
        let barBtn = UIBarButtonItem(title: localStr("kEditTitle"),  style: .plain, target: self, action: #selector(rightBarButtonClick))
        barBtn.tintColor = UIColor.blue
        barBtn.setTitleTextAttributes([NSAttributedString.Key.font: UIFont.systemFont(ofSize: 16), NSAttributedString.Key.foregroundColor: UIColor.black], for: .normal)
        return barBtn
    }()
    private lazy var buttonsView: MutableButtonsView = {
        let view = MutableButtonsView(frame: CGRect(x: 0, y: 0, width: 100, height: 50))
        view.titlesForNormalStatus = [localStr("kAllChose"), localStr("kDelete")]
        view.titlesForSelectedStatus = [localStr("kCancleAllChose"), localStr("kDelete")]
        view.colorsForNormalStatus = [UIColor.darkGray, UIColor.purple]
        view.delegate = self
        return view
    }()
    var listType: ListType = ListType.collectedList
    
    private lazy var dataSource = [CellEditModel]()
    
    let viewModel = UserInfoViewModel()
    
    /// 处理导航栏
    var navHidenCallBackHandler:((_ isAnimated: Bool) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
         navigationItem.rightBarButtonItem = editBarButton
        if listType == .collectedList {
            title = localStr("kCollectedCellTitle")
        } else if listType == .watchedList {
            title = localStr("kPlayHistoryCellTitle")
        }
        view.addSubview(buttonsView)
        addChild(baseListVC)
        view.addSubview(baseListVC.view)
        layoutPageSubviews()
        addViewModelLoadDataCallBackHandler()
        loadVideoListData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navHidenCallBackHandler?(true)
    }
    
    // MARK: - User actions
    @objc func rightBarButtonClick() {
        if dataSource.count > 0 {
            isEdit = !isEdit
        } else {
            isEdit = false
        }
    }
    
    /// 请求第一页数据
    func loadVideoListData() {
        // 下拉刷新操作不需要HUD. 第一次进入页面需要
        if !baseListVC.isRefreshOperation {    // 判断是不是刷新操作
            XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        }
        if listType == .collectedList {
            viewModel.loadUserCollectedListApi()
        }
        if listType == .watchedList {
            viewModel.loadUserWatchedListApi()
        }
        
    }
    
    func loadVideoListNextPage() {
        if listType == .collectedList {
            viewModel.loadUserCollectedNextPage()
        }
        if listType == .watchedList {
            viewModel.loadUserWatchedNextPage()
        }
    }
    
    func addViewModelLoadDataCallBackHandler() {
        viewModel.loadUserVideoListApiSuccess = { [weak self] (count) in
            self?.isEdit = false
            self?.fakeHeaderRequest(count)
        }
        viewModel.loadUserVideoListApiFail = { [weak self] in
            self?.fakeDataFail()
        }
    }
    
}

// MARK: - FakeNetworkData  网络请求数据，以及加载数据失败，上下拉刷新
extension HistoryWatchListController {
    
    /// 模拟请求单页数据
    func fakeHeaderRequest(_ videoCount: Int) {
        XSProgressHUD.hide(for: view, animated: false)
        // 成功后结束刷新，刷新表
        baseListVC.endRefreshing()
        dataSource = viewModel.getCellEditModelList()
        if listType == .collectedList { navigationItem.title = String(format: "%@(%@)", localStr("kCollectedCellTitle"), "\(dataSource.count)") }
        if listType == .watchedList { navigationItem.title = String(format: "%@(%@)", localStr("kPlayHistoryCellTitle"), "\(dataSource.count)") }
        if videoCount >= HistoryWatchListController.kPageDataCount { // 单页数据大于等于 每页请求数据，表示有可能有下一页，显示加载更多的UI
             baseListVC.hideRefreshFooterView(false)
        } else {
             baseListVC.hideRefreshFooterView(true)
        }
        // 网络请求成功， 刷新数据
        baseListVC.reloadData()
        if videoCount == 0 {
            navigationItem.rightBarButtonItem = nil
        } else {
            navigationItem.rightBarButtonItem = editBarButton
        }
    }
    
    func fakeDataFail() {
        //模拟网络请求失败，展示失败的页面
        XSProgressHUD.hide(for: view, animated: false)
        baseListVC.showRequestFailedView()
    }
    
    func getActorsLableText(_ videoModel: VideoModel) -> String? {
        var actorsString: String = localStr("kAcotrTitle")
        if let actors = videoModel.author, actors.count > 0 {
            for actor in actors {
                if actor.actor_label != nil {
                    let string = String(format: "%@  ", actor.actor_label!)
                    actorsString = String(format:"%@ %@", actorsString, string)
                }
            }
            return actorsString
        }
        return nil
    }
    
}

// MARK: - MutableButtonsViewDelegate    全选删除操作
extension HistoryWatchListController: MutableButtonsViewDelegate {
    
    func didClickButton(button: UIButton, at index: Int) {
        if index == 0 {                                    /// 全选 + 反选
            print( button.isSelected)
            selectedAllRows(button.isSelected)
        } else if index == 1 {                             /// 删除
            deleteSelectedRowsAndDataDources()
        }
    }
}


// MARK: - EditingConfig  编辑时的操
extension HistoryWatchListController {
    
    /// 全选或者全反选
    func selectedAllRows(_ isAllSelected: Bool) {
        for index in 0 ..< dataSource.count {
            if !isAllSelected {          ///
                dataSource[index].isSelected = false
                baseListVC.deselectedRowAtIndexPath(IndexPath(row: index, section: 0))  ///
            } else {
                dataSource[index].isSelected = true
                baseListVC.selectedRowAtIndexPath(IndexPath(row: index, section: 0))
            }
        }
        updateSelectedRows()
    }
    
    /// 删除选中的rows 以及数据源
    func deleteSelectedRowsAndDataDources() {
        guard let selectedRows = baseListVC.getAllSelectedRows(), selectedRows.count > 0 else {return}         // 选中rows数组不为空
        /// 调用删除接口，成功后更新UI ,在接口成功的方法中 调用下面方法：
       // updateDataSourcesAfterDeletedModels()
        let videoDeleteGroups = dataSource.filter { (model) -> Bool in
            return model.isSelected == true
        }
        var videoIds = [Int]()
        for cellModel in videoDeleteGroups {
            videoIds.append(cellModel.videoModel?.id ?? 0)
        }
        if listType == .collectedList {
            XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
            viewModel.cancleFavor(videoIds)
        } else if listType == .watchedList {
            XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
            viewModel.deleteWatchedList(videoIds)
        }
        
    }
    
    /// 更新数据源 以及 table的选中非选中cell
    func updateSelectedRows() {
        if let selectedIndexPaths = baseListVC.getAllSelectedRows(), selectedIndexPaths.count > 0 {   /// 有选中
            updateButtonView(selectedIndexPaths.count, dataSource.count)
        } else {
            updateButtonView(0, dataSource.count)
        }
    }
    
    /// 删除之后更新数据源
    private func updateDataSourcesAfterDeletedModels() {
        let videoAfterDeleteGroups = dataSource.filter { (model) -> Bool in
            model.isSelected == nil || model.isSelected == false
        }
        dataSource = videoAfterDeleteGroups
        baseListVC.reloadData()
        // 删除操作完成之后，判断是否还有数据，有则不管，无则取消编辑状态
        updateButtonView(0, dataSource.count)
        baseListVC.resetStatisticsData()
        isEdit = false
    }
    
    /// 跟新底部按钮的删除个数
    private func updateButtonView(_ selectedCount: Int, _ allCount: Int) {
        if selectedCount == 0 {
            buttonsView.buttons?[0].isSelected = false
            buttonsView.updateButtonTitle(title: localStr("kDelete"), at: 1, for: .normal)
            buttonsView.updateButtonTitle(title: localStr("kDelete"), at: 1, for: .selected)
        } else {
            buttonsView.buttons?[0].isSelected = selectedCount == allCount
            buttonsView.updateButtonTitle(title: "\(localStr("kDelete"))(\(selectedCount))", at: 1, for: .normal)
            buttonsView.updateButtonTitle(title: "\(localStr("kDelete"))(\(selectedCount))", at: 1, for: .selected)
        }
    }
}

// MARK: - NicooTableViewDelegate   需要编辑才实现编辑的代理，需要头部底部舒心才实现刷新代理
extension HistoryWatchListController: NicooTableViewDelegate {
    
    /// 是否带头部刷新
    func haveHeaderRefreshView() -> Bool {
        return true
    }
    /// 是否带底部加载更多
    func haveFooterRefreshView() -> Bool {
        return true
    }
    /// 头部刷新
    func headerRefreshing(_ tableView: UITableView?) {
        loadVideoListData()
    }
    /// 加载更多
    func loadMoreData(_ tableView: UITableView?) {
        loadVideoListNextPage()
    }
    
    /// 网络请求失败，再来一次
    func requestDataAgain() {
        loadVideoListData()
    }
    
    /// 是否显示底部的数据统计
    func shouldShowStatics(_ listBaseViewController: NicooTableListViewController) -> Bool {
        return false
    }
    
    func cellHeight(for listBaseViewController: NicooTableListViewController) -> CGFloat? {
        return (ConstValue.kScreenWdith - 20)/3 * 1.4 + 20
    }
    
    func cellClass(for listBaseViewController: NicooTableListViewController) -> AnyClass? {
        return SpeciaTpMoreCell.classForCoder()
    }
    
    func cellReuseIdentifier(for listBaseViewController: NicooTableListViewController) -> String? {
        return SpeciaTpMoreCell.cellId
    }
    
    func listTableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.getCellEditModelList().count
    }
    
    func listTableView(_ listBaseViewController: NicooTableListViewController, tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell? {
        let cell = tableView.dequeueReusableCell(withIdentifier: SpeciaTpMoreCell.cellId, for: indexPath) as! SpeciaTpMoreCell
        return cell
    }
    
    /// 处理Model的方法，与cellForRow方法分开
    func configCell(_ tableView: UITableView, for cell: UITableViewCell, cellForRowAt indexPath: IndexPath) {
        let cell = cell as! SpeciaTpMoreCell
        let fakeModel = dataSource[indexPath.row]
        cell.topicImage.kfSetVerticalImageWithUrl(fakeModel.videoModel?.cover_path)
        cell.nameLable.text = fakeModel.videoModel?.title ?? ""
        if fakeModel.videoModel?.intro != nil && !fakeModel.videoModel!.intro!.isEmpty {
            cell.desLable.text = fakeModel.videoModel!.intro!
        }else {
            cell.desLable.text = localStr("kNotIntrolMsg")
        }
        if let actorString = getActorsLableText(fakeModel.videoModel ?? VideoModel()) {
            cell.actorLable.text = actorString as String
        }
        if let actorString = getActorsLableText(fakeModel.videoModel ?? VideoModel()) {
            cell.typeLable.text = actorString as String
        }
        cell.actorLable.text = String(format: "%@ %@", fakeModel.videoModel?.epoch_id ?? "", fakeModel.videoModel?.dist_label ?? "")
    }
    
    /// 非编辑状态下选中
    func listTableView(_ tableView: UITableView, didSelectedAtIndexPath indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let fakeModel = dataSource[indexPath.row]
        if let model = fakeModel.videoModel {
            let videoDetailVC = VideoDetailViewController()
            videoDetailVC.videoId = model.id ?? 0
            navigationController?.pushViewController(videoDetailVC, animated: true)
        }
    }
    
    /// 编辑状态下的选中
    func editingListTableView(_ tableView: UITableView, didSelectedAtIndexPath indexPath: IndexPath, didSelected indexPaths: [IndexPath]?) {
        dataSource[indexPath.row].isSelected = true   // 选中
        updateSelectedRows()
    }
    
    /// 编辑状态下的反选
    func editingListTableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath, didSelected indexPaths: [IndexPath]?) {
        dataSource[indexPath.row].isSelected = false  // 反选
        updateSelectedRows()
    }
    
    func editingSelectedViewColor() -> UIColor {
        return ConstValue.kAppDefaultColor
    }
}

// MARK: - layout subViews
private extension HistoryWatchListController {
    
    func layoutPageSubviews() {
        layoutButtonsView()
        layoutBaseListTableView()
    }
    
    private func layoutButtonsView() {
        buttonsView.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(0)
            if #available(iOS 11.0, *) {  // 适配X
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalToSuperview()
            }
            make.height.equalTo(0)
        }
    }
    
    func layoutBaseListTableView() {
        baseListVC.view.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.bottom.equalTo(buttonsView.snp.top)
        }
    }
    
    private func updateButtonViewlayout() {
        buttonsView.snp.updateConstraints { (make) in
            if isEdit {
                make.height.equalTo(50)
            } else {
                make.height.equalTo(0)
            }
        }
        buttonsView.redrawButtonLines()   // 重新绘制线条
        UIView.animate(withDuration: 0.3, animations: {
            self.view.layoutIfNeeded()
        })
    }
    
}

//
//  AcountSettingController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/10.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import ImagePicker
import NicooNetwork

/// 账户设置页面
class AcountSettingController: UIViewController {

    private lazy var tableView: UITableView = {
        let table = UITableView(frame: view.bounds, style: .plain)
        table.delegate = self
        table.dataSource = self
        table.separatorStyle = .singleLine
        table.tableFooterView = UserModel.share().isRealUser ? footerView : UIView(frame: .zero)
        table.register(UserHeaderCell.classForCoder(), forCellReuseIdentifier: UserHeaderCell.cellId)
        table.register(UINib(nibName: "UserTableListCell", bundle: Bundle.main), forCellReuseIdentifier: UserTableListCell.cellId)
        return table
    }()
    private let footerView: UIView = {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 90))
        view.backgroundColor = UIColor.clear
        return view
    }()
    private lazy var logoutButton: UIButton = {
        let button = UIButton(type: .custom)
        button.frame = CGRect(x: 30, y: 25, width: ConstValue.kScreenWdith - 60, height: 40)
        button.setTitle(localStr("kLogoutButtonTitle"), for: .normal)
        button.backgroundColor = ConstValue.kAppDefaultColor
        button.titleLabel?.font = UIFont.systemFont(ofSize: 18)
        button.addTarget(self, action: #selector(logout), for: .touchUpInside)
        button.layer.cornerRadius = 20
        button.layer.masksToBounds = true
        return button
    }()
    lazy var commentInputView: CommentInputView = {
        let view = CommentInputView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 80))
        view.sendButton.setTitle(localStr("kCommit"), for: .normal)
        view.titleLable.text = localStr("kChangeNickNameTitle")
        view.textInputView.placeholder = localStr("kChangeNickNamePlaceholder")
        return view
    }()
    lazy var fakeTxf: UITextField = {
        let txf = UITextField.init(frame: CGRect(x: 0, y: view.bounds.size.height + 40, width: ConstValue.kScreenWdith, height: 40))
        txf.borderStyle = .none
        txf.delegate = self
        txf.inputAccessoryView = commentInputView
        return txf
    }()
    private lazy var uploadApi: UploadImageTool = {
        let api = UploadImageTool()
        api.delegate = self
        return api
    }()
    private lazy var userInfoSetApi: UserChangeInfoApi = {
        let api = UserChangeInfoApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var userLogoutApi: UserLogoutApi = {
        let api = UserLogoutApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    var infoValue: String?
    var infokey: String?
    var infoSex: Int = 1
    var headerImage: UIImage?
    private let userInfo = UserInfoViewModel()
    private let registerModel = RegisterLoginViewModel()
    
    /// 处理导航栏
    var navHidenCallBackHandler:((_ isAnimated: Bool) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        title = localStr("kSettingTitle")
        view.addSubview(tableView)
        footerView.addSubview(logoutButton)
        layoutPageSubviews()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: false)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
      navHidenCallBackHandler?(true)
    }
    
    private func getAppVersion() -> String {
        let filePath = Bundle.main.path(forResource: "Info", ofType: "plist")
        let dictionary = NSDictionary(contentsOfFile: filePath!)
        return dictionary!["CFBundleShortVersionString"] as! String
    }
    
    /// 退出登录
    @objc private func logout() {
        let _ = userLogoutApi.loadData()
    }

}

// MARK: - Privite - Funcs
private extension AcountSettingController {
    /// 更换头像
    func changeHeaderImage() {
        let config = Configuration()
        config.doneButtonTitle = localStr("kSure")
        config.noImagesTitle = localStr("kNotFoundImageTips")
        config.cancelButtonTitle = localStr("kCancle")
        config.recordLocation = true
        config.allowVideoSelection = false
        
        let imagePicker = ImagePickerController(configuration: config)
        imagePicker.delegate = self
        imagePicker.imageLimit = 1
        present(imagePicker, animated: true, completion: nil)
    }
    
    func changeNickName() {
        view.addSubview(fakeTxf)
        addKeyBoardViewCallBack()
        fakeTxf.becomeFirstResponder()
    }
    
    func changeSex() {
        let allterController = UIAlertController.init(title: nil, message: localStr("kPleaseChoseSex"), preferredStyle: .actionSheet)
        let actionMan = UIAlertAction(title: localStr("kMan"), style: .default) { [weak self] (action) in
            self?.infoSex = 1
            self?.loadChangeNickNameApi()
        }
        let actionWoman = UIAlertAction(title: localStr("kWoman"), style: .default) { [weak self] (action) in
            self?.infoSex = 2
            self?.loadChangeNickNameApi()
        }
        let cancleAction = UIAlertAction.init(title:  localStr("kCancle"), style: .cancel, handler: nil)
        
        allterController.addAction(actionMan)
        allterController.addAction(actionWoman)
        allterController.addAction(cancleAction)
        self.present(allterController, animated: true, completion: nil)
    }
    
    func addKeyBoardViewCallBack() {
        commentInputView.keyBoardDownHandler = { [weak self] (text) in
            self?.fakeTxf.resignFirstResponder()
        }
        commentInputView.sendButtonHandler = { [weak self] (text) in
            self?.fakeTxf.resignFirstResponder()
            self?.infoValue = text
            self?.loadChangeNickNameApi()
        }
    }
    
    func loadChangeNickNameApi() {
        let _ = userInfoSetApi.loadData()
    }
    
    func logoutSuccess() {
        LoginManager().logout(nil)
        registerModel.loadDeviceRegisterSuccess = { [weak self] in
            self?.navigationController?.popViewController(animated: true)
        }
        registerModel.loadDeviceRegisterFail = { [weak self] in
            self?.navigationController?.popViewController(animated: true)
        }
        registerModel.registerDevice()
    }
}

// MARK: - UITextFieldDelegate
extension AcountSettingController: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return true
    }

}

 // MARK: - ImagePickerDelegate
extension AcountSettingController: ImagePickerDelegate {
   
    func cancelButtonDidPress(_ imagePicker: ImagePickerController) {
        imagePicker.dismiss(animated: true, completion: nil)
    }
    
    func wrapperDidPress(_ imagePicker: ImagePickerController, images: [UIImage]) {
        guard images.count > 0 else { return }
    }
    
    func doneButtonDidPress(_ imagePicker: ImagePickerController, images: [UIImage]) {
        if images.count > 0 {
            headerImage = images[0]
            uploadApi.upload(images[0])
        }
        imagePicker.dismiss(animated: true, completion: nil)
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension AcountSettingController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return indexPath.section == 0 ? 100 : 50
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return section == 0 ? 1 : 6
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: UserHeaderCell.cellId, for: indexPath) as! UserHeaderCell
            cell.imageHeader.kfSetHeaderImageWithUrl(UserModel.share().cover_path, placeHolder: ConstValue.kDefaultHeader)
            return cell
        }
        if indexPath.section == 1 {
            let cell  = tableView.dequeueReusableCell(withIdentifier: UserTableListCell.cellId, for: indexPath) as! UserTableListCell
            cell.titleLab.text = [localStr("kAcountSafeCenterCellTitle"), localStr("kNickNameCellTitle"), localStr("kSexCellTitle"), localStr("kVersionCellTitle"), localStr("kCleanDeskCellTitle"), localStr("kNetworkAllowCellTitle")][indexPath.row]
            var sex = ""
            if UserModel.share().sex == 1 {
                sex = localStr("kMan")
            } else {
                sex = localStr("kWoman")
            }
            cell.msgLable.text = ["",UserModel.share().name ?? "", sex, getAppVersion(), "",""][indexPath.row]
            if indexPath.row == 5 {
                cell.switchSet.isHidden = false
                cell.accessoryType = .none
            } else {
                cell.switchSet.isHidden = true
                cell.accessoryType = .disclosureIndicator
            }
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if indexPath.section == 0 {
            changeHeaderImage()
        } else if indexPath.section == 1 && indexPath.row == 0 {
            let changepsw = ForgetPswController()
            navigationController?.pushViewController(changepsw, animated: true)
        } else if indexPath.section == 1 && indexPath.row == 1 {
            infokey = UserChangeInfoApi.kNickname
            changeNickName()
        } else if indexPath.section == 1 && indexPath.row == 2 {
            infokey = UserChangeInfoApi.kSex
            changeSex()
        }
    }
    
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension AcountSettingController: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        XSProgressHUD.showProgress(msg: nil, onView: view, animated: false)
        var params = [String: Any]()
        if manager is UserChangeInfoApi {
            params[UserChangeInfoApi.kInfoKey] =  infokey
            if infokey == UserChangeInfoApi.kNickname {
                params[UserChangeInfoApi.kInfoValue] = infoValue
            } else if infokey == UserChangeInfoApi.kSex {
                params[UserChangeInfoApi.kInfoValue] = "\(infoSex)" 
            }
        }
        return params
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is UserChangeInfoApi {
            if infokey == UserChangeInfoApi.kNickname {
                UserModel.share().name = infoValue
                tableView.reloadRows(at: [IndexPath(row: 1, section: 1)], with: .none)
            } else if infokey == UserChangeInfoApi.kSex {
                UserModel.share().sex = infoSex
                tableView.reloadRows(at: [IndexPath(row: 2, section: 1)], with: .none)
            }
        }
        if manager is UserLogoutApi {
            logoutSuccess()
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is UserChangeInfoApi {
            XSAlert.show(type: .warning, text: manager.errorMessage)
        }
    }
 
}

// MARK: - UploadImageDelegate
extension AcountSettingController: UploadImageDelegate {
    
    func paramsForAPI(_ uploadImageTool: UploadImageTool) -> [String : String]? {
        XSProgressHUD.showProgress(msg: nil, onView: view, animated: false)
        return nil
    }
    
    func uploadImageMethod(_ uploadImageTool: UploadImageTool) -> String {
        return "/api/user/upload"
    }
    
    func uploadImageSuccess(_ uploadImageTool: UploadImageTool, resultDic: [String : Any]?) {
        XSProgressHUD.hide(for: view, animated: false)
        userInfo.loadUserInfoSuccessHandler = { [weak self] in
            self?.tableView.reloadRows(at: [IndexPath(row: 0, section: 0)], with: .none)
        }
        userInfo.loadUserInfo()
        
//        if let path = resultDic?["result"] as? String {
//            // urlDecode
//            let decodResultPath = path.urlDecoded()
//            if !decodResultPath.isEmpty {
//                if let decryptPath = decodResultPath.aes128DecryptString(withKey: "bUYJ3nTV6VBasdJF") {  // AES解密
//                    let correctPath = decryptPath.replacingOccurrences(of: "\"", with: "")
//                    UserModel.share().cover_path = correctPath.replacingOccurrences(of: "\"", with: "")
//                    tableView.reloadData()
//                }
//            }
//
//        }
    }
    
    func uploadImageFailed(_ uploadImageTool: UploadImageTool, errorMessage: String?) {
        XSProgressHUD.hide(for: view, animated: false)
        XSAlert.show(type: .error, text: localStr("kUploadHeaderFailAlert"))
    }
    
    func uploadFailedByTokenError() {
        XSProgressHUD.hide(for: view, animated: false)
        showErrorMessage(XSAlertMessages.kNotAvailTokenAlertMsg) {
            LoginManager().login(nil)
        }
    }
    
}


// MARK: - Layout
private extension AcountSettingController {

    func layoutPageSubviews() {
        layoutTableView()
    }
    
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.edges.equalTo(view.safeAreaLayoutGuide.snp.edges)
            } else {
                make.edges.equalToSuperview()
            }
        }
    }
    
}


//
//  MyPopularController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/26.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import NicooNetwork
import MJRefresh

class MyPopularController: UIViewController {

    private lazy var topBarView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(r: 73 , g: 114 , b: 255)
        return view
    }()
    private lazy var nameLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.white
        lable.font = UIFont.systemFont(ofSize: 18)
        lable.textAlignment = .left
        lable.text = localStr("kMyPopUserNickNameTitle")
        return lable
    }()
    private lazy var timeLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.white
        lable.font = UIFont.systemFont(ofSize: 18)
        lable.textAlignment = .right
        lable.text = localStr("kMyPopRegisterTimeTitle")
        return lable
    }()
    private lazy var phoneLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.white
        lable.font = UIFont.systemFont(ofSize: 18)
        lable.textAlignment = .center
        lable.text = localStr("kMyPopPhoneTitle")
        return lable
    }()
    private lazy var tableView: UITableView = {
        let table = UITableView(frame: view.bounds, style: .grouped)
        table.backgroundColor = UIColor.clear
        table.rowHeight = 70
        table.showsVerticalScrollIndicator = false
        table.showsHorizontalScrollIndicator = false
        table.allowsSelection = false
        table.delegate = self
        table.dataSource = self
        table.separatorStyle = .none
        table.tableFooterView = UIView.init(frame: CGRect.zero)
        table.mj_header = refreshView
        table.mj_footer = loadMoreView
        table.register(InvitedUserListCell.classForCoder(), forCellReuseIdentifier: InvitedUserListCell.cellId)
        return table
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        return MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
    }()
    lazy private var refreshView: MJRefreshNormalHeader = {
        weak var weakSelf = self
        return MJRefreshNormalHeader(refreshingBlock: {
            weakSelf?.isRefreshOperation = true
            weakSelf?.loadData()
        })
    }()
    private lazy var invitedListApi: UserInvitedListApi = {
        let api = UserInvitedListApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    var isRefreshOperation = false
    var invitedList = [InvitedModel]()
    
    /// 处理导航栏
    var navHidenCallBackHandler:((_ isAnimated: Bool) -> Void)?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        title = localStr("kMyPopularTitle")
        view.addSubview(topBarView)
        view.addSubview(tableView)
        topBarView.addSubview(nameLable)
        topBarView.addSubview(timeLable)
        topBarView.addSubview(phoneLable)
        layoutPageSubviews()
        layoutTopBarSubviews()
        loadMoreView.isHidden = true
        loadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: false)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navHidenCallBackHandler?(true)
    }
   
    
   
}

// MARK: - Privite - Funcs
extension MyPopularController {
    
    private func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        if !isRefreshOperation {
            XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        } else {
            isRefreshOperation = false
        }
        let _ = invitedListApi.loadData()
    }
    
    private func loadNextPage() {
        let _ = invitedListApi.loadNextPage()
    }
    
    private func loadListDataSuccess(_ model: InvitedListModel) {
        XSProgressHUD.hide(for: view, animated: false)
        tableView.mj_header.endRefreshing()
        tableView.mj_footer.endRefreshing()
        if let list = model.data, let pageNumber = model.current_page {
            if pageNumber == 1 {
                guard list.count > 0 else {
                    NicooErrorView.showNoInvitedMessage(on: view, topMargin: 45, clickHandler: nil)
                    return
                }
                invitedList = list
                if list.count >= VideoListApi.kDefaultCount { // 表示可能还有数据
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
                isRefreshOperation = true
                tableView.reloadData()
            } else {
                invitedList.append(contentsOf: list)
                if list.count >= VideoListApi.kDefaultCount { // 表示可能还有数据
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
                tableView.reloadData()
            }
        }
    }
    
    private func loadListDataFail() {
        XSProgressHUD.hide(for: view, animated: false)
        tableView.mj_header.endRefreshing()
        tableView.mj_footer.endRefreshing()
        if !isRefreshOperation {
            NicooErrorView.showErrorMessage(.noData, on: view, topMargin: 44, clickHandler: nil)
        }
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension MyPopularController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return invitedList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: InvitedUserListCell.cellId, for: indexPath) as! InvitedUserListCell
        let model = invitedList[indexPath.row]
        cell.setModel(model)
        return cell
    }
    
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension MyPopularController: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        if let list = manager.fetchJSONData(UserReformer()) as? InvitedListModel {
            loadListDataSuccess(list)
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        loadListDataFail()
    }
    
}

// MARK: - Layout
private extension MyPopularController {
    
    func layoutPageSubviews() {
        layoutTopBarView()
        layoutTableView()
    }
    
    func layoutTopBarView() {
        topBarView.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(44)
        }
    }
    
    func layoutTopBarSubviews() {
        nameLable.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.centerY.equalToSuperview()
        }
        timeLable.snp.makeConstraints { (make) in
            make.trailing.equalToSuperview().offset(-10)
            make.centerY.equalToSuperview()
        }
        phoneLable.snp.makeConstraints { (make) in
            make.centerY.centerX.equalToSuperview()
        }
    }
    
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            make.top.equalTo(topBarView.snp.bottom)
            make.leading.trailing.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalToSuperview()
            }
        }
    }
}

//
//  ExperienController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/26.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class ExperienController: UIViewController {

    
    let infos: [String] = [localStr("kExperienGetTypeADWatch"), localStr("kExperienGetTypeLogin"), localStr("kExperienGetTypeWatchVideo"), localStr("kExperienGetTypeShareVideo")]
    
    private lazy var fakeNavBar: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.clear
        return view
    }()
    private lazy var backButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "navBackWhite"), for: .normal)
        button.addTarget(self, action: #selector(backButtonClick(_:)), for: .touchUpInside)
        return button
    }()
    var navLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.white
        lable.textAlignment = .center
        lable.font = UIFont.boldSystemFont(ofSize: 18)
        lable.text = localStr("kExperienTitle")
        return lable
    }()
    
    private let topBgimage: UIImageView = {
        let image = UIImageView()
        image.isUserInteractionEnabled = true
        image.image = UIImage(named: "acountHeaderBg")
        return image
    }()
    private let headerView: PopuTopView = {
        let header = PopuTopView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: UserModel.share().isRealUser ? 275 : 221))
        header.backgroundColor = UIColor.white
        header.itemsContainer.isHidden = true
        header.myInviteCodeLable.isHidden = true
        return header
    }()
    private lazy var tableView: UITableView = {
        let table = UITableView(frame: view.bounds, style: .grouped)
        table.backgroundColor = UIColor.clear
        table.showsVerticalScrollIndicator = false
        table.showsHorizontalScrollIndicator = false
        table.allowsSelection = false
        table.delegate = self
        table.dataSource = self
        table.separatorStyle = .none
        table.tableFooterView = UIView.init(frame: CGRect.zero)
        table.tableHeaderView = headerView
        table.register(UITableViewCell.classForCoder(), forCellReuseIdentifier: "Normalcell")
        table.register(UINib(nibName: "ExperienInfoCell", bundle: Bundle.main), forCellReuseIdentifier: ExperienInfoCell.cellId)
        return table
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        view.addSubview(topBgimage)
        view.addSubview(tableView)
        view.addSubview(fakeNavBar)
        fakeNavBar.addSubview(backButton)
        fakeNavBar.addSubview(navLable)
        layoutPageSubviews()
        fixUserData()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
       // navigationController?.setNavigationBarHidden(false, animated: false)
    }
    
    private func fixUserData() {   
        headerView.setUserInfo()
    }
}

// MARK: - User - action
private extension ExperienController {
    
    @objc func backButtonClick(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
   
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension ExperienController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            return 50
        }
        return 200
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return section == 0 ? 4 : 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "Normalcell", for: indexPath)
            cell.textLabel?.text = "     \(infos[indexPath.row])"
            return cell
        } else {
             let cell = tableView.dequeueReusableCell(withIdentifier: ExperienInfoCell.cellId, for: indexPath) as! ExperienInfoCell
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 50))
        view.backgroundColor = UIColor.white
        let tipsView = UIImageView(frame: CGRect(x: 15, y: 15, width: 20, height: 20))
        tipsView.image = UIImage(named: "sectionIconRout")
        view.addSubview(tipsView)
        let lable = UILabel(frame: CGRect(x: 40, y: 16, width: 200, height: 18))
        lable.text = [localStr("kExperienGetTitle"), localStr("kExperienLvTitle")][section]
        lable.textColor = ConstValue.kAppDefaultTitleColor
        lable.font = UIFont.boldSystemFont(ofSize: 18)
        view.addSubview(lable)
        return view
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    
}
// MARK: - UIScrollViewDelegate
extension ExperienController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let sectionHeaderHeight: CGFloat = 50
        if scrollView.contentOffset.y <= sectionHeaderHeight && scrollView.contentOffset.y > 0 {
            scrollView.contentInset = UIEdgeInsets(top: -scrollView.contentOffset.y, left: 0, bottom: 0, right: 0)
            
        } else if scrollView.contentOffset.y >= sectionHeaderHeight {
            scrollView.contentInset = UIEdgeInsets(top: -sectionHeaderHeight, left: 0, bottom: 0, right: 0)
        }
        if scrollView.contentOffset.y > 170 {
            fakeNavBar.backgroundColor = UIColor.white
            navLable.textColor = UIColor.darkText
            backButton.setImage(UIImage(named: "navBackDefault"), for: .normal)
            
        } else {
            fakeNavBar.backgroundColor = UIColor.clear
            backButton.setImage(UIImage(named: "navBackWhite"), for: .normal)
            navLable.textColor = UIColor.white
        }
    }
    
}

// MARK: - Layout
private extension ExperienController {
    
    func layoutPageSubviews() {
        layoutTopImage()
        layoutTableView()
        layoutFakeNavBarView()
        layoutNavLable()
        layoutBackButton()
       
    }
    
    func layoutTopImage() {
        topBgimage.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(-ConstValue.kStatusBarHeight)
            make.height.equalTo(300)
        }
    }
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.edges.equalTo(view.safeAreaLayoutGuide.snp.edges)
            } else {
                make.edges.equalToSuperview()
            }
        }
    }
    
    func layoutBackButton() {
        backButton.snp.makeConstraints { (make) in
            make.top.equalTo(ConstValue.kStatusBarHeight + 5)
            make.leading.equalTo(15)
            make.width.equalTo(30)
            make.height.equalTo(30)
        }
    }
    
    func layoutNavLable() {
        navLable.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(ConstValue.kStatusBarHeight + 10)
            make.height.equalTo(24)
        }
    }
    
    func layoutFakeNavBarView() {
        fakeNavBar.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(ConstValue.kNavigationBarHeight + ConstValue.kStatusBarHeight)
        }
    }
    
}

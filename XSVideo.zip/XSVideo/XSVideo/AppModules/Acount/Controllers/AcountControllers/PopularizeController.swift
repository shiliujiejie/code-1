//
//  PopularizeController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/25.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class PopularizeController: UIViewController {
    
    let infos: [String] = [localStr("kUserRegisterSatisfyMsg"), localStr("kUserInviteSatisfyMsg"), localStr("kUserDailiSignInSatisfyMsg")]
    
    private lazy var fakeNavBar: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.clear
        return view
    }()
    private lazy var backButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "navBackWhite"), for: .normal)
        button.addTarget(self, action: #selector(backButtonClick(_:)), for: .touchUpInside)
        return button
    }()
    var navLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.white
        lable.textAlignment = .center
        lable.font = UIFont.boldSystemFont(ofSize: 18)
        lable.text = localStr("kPopularTitle")
        return lable
    }()
    
    private let topBgimage: UIImageView = {
        let image = UIImageView()
        image.isUserInteractionEnabled = true
        image.image = UIImage(named: "acountHeaderBg")
        return image
    }()
    private lazy var popButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle(localStr("kMyPopularTitle"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        button.addTarget(self, action: #selector(myPopButtonClick(_:)), for: .touchUpInside)
        return button
    }()
    private let footerView: UIView = {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 60))
        view.backgroundColor = UIColor.clear
        return view
    }()
    private lazy var goPopButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle(localStr("kGoPopularTitle"), for: .normal)
        button.backgroundColor = ConstValue.kAppDefaultColor
        button.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        button.addTarget(self, action: #selector(goPopButtonClick), for: .touchUpInside)
        button.layer.cornerRadius = 20
        button.layer.masksToBounds = true
        return button
    }()
    private let headerView: PopuTopView = {
        let header = PopuTopView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: UserModel.share().isRealUser ? 400 : 348))
        header.backgroundColor = UIColor.white
        return header
    }()
    private lazy var tableView: UITableView = {
        let table = UITableView(frame: view.bounds, style: .grouped)
        table.backgroundColor = UIColor.clear
        table.showsVerticalScrollIndicator = false
        table.showsHorizontalScrollIndicator = false
        table.allowsSelection = false
        table.delegate = self
        table.dataSource = self
        table.separatorStyle = .none

        table.tableHeaderView = headerView
        table.register(UINib(nibName: "PopLarizeCell", bundle: Bundle.main), forCellReuseIdentifier: PopLarizeCell.cellId)
        return table
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        view.addSubview(topBgimage)
        footerView.addSubview(goPopButton)
        view.addSubview(footerView)
        view.addSubview(tableView)
        view.addSubview(fakeNavBar)
        fakeNavBar.addSubview(backButton)
        fakeNavBar.addSubview(navLable)
        fakeNavBar.addSubview(popButton)
        layoutPageSubviews()
        addHeaderClickHnadler()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fixUserData()
        navigationController?.setNavigationBarHidden(true, animated: isNavAnimated ? animated : false)
        isNavAnimated = false
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    private func addHeaderClickHnadler() {
        headerView.buttonClick = { [weak self]  (index) in
            if index == 1 {
                
            }
            if index == 2 {
                
            }
            if index == 3 {
                let experienVC = ExperienController()
                self?.navigationController?.pushViewController(experienVC, animated: true)
            }
        }
    }
    
    private func fixUserData() {
        headerView.setUserInfo()
    }
}

// MARK: - User - action
private extension PopularizeController {
    
    @objc func backButtonClick(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    
    @objc func myPopButtonClick(_ sender: UIButton) {
        let myPopVC = MyPopularController()
        myPopVC.navHidenCallBackHandler = { [weak self] (isAnimate) in
            self?.isNavAnimated = isAnimate
        }
        navigationController?.pushViewController(myPopVC, animated: true)
    }
    
    @objc func goPopButtonClick() {
        let inviteCodeVC = InviteCodeController()
        navigationController?.pushViewController(inviteCodeVC, animated: true)
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension PopularizeController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 130.0
        return tableView.rowHeight
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: PopLarizeCell.cellId, for: indexPath) as! PopLarizeCell
        cell.numberLable.text = "\(indexPath.row + 1)"
        cell.nameLable.text = [localStr("kUserRegisterTitle"), localStr("kInviteCodeRegisterTitle"), localStr("kUserDailySignInTitle")][indexPath.row]
        cell.infoLable.attributedText = TextSpaceManager.getAttributeStringWithString(infos[indexPath.row], lineSpace: 6)
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 50))
        view.backgroundColor = UIColor.white
        let tipsView = UIView(frame: CGRect(x: 15, y: 17.5, width: 2, height: 15))
        tipsView.layer.cornerRadius = 1
        tipsView.layer.masksToBounds = true
        tipsView.backgroundColor = ConstValue.kAppDefaultColor
        view.addSubview(tipsView)
        let lable = UILabel(frame: CGRect(x: 27, y: 16, width: 200, height: 18))
        lable.text = localStr("kUserRecommentSatisfy")
        lable.textColor = UIColor.darkText
        lable.font = UIFont.systemFont(ofSize: 18)
        view.addSubview(lable)
        return view
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    
}
// MARK: - UIScrollViewDelegate
extension PopularizeController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let sectionHeaderHeight: CGFloat = 50
        if scrollView.contentOffset.y <= sectionHeaderHeight && scrollView.contentOffset.y > 0 {
            scrollView.contentInset = UIEdgeInsets(top: -scrollView.contentOffset.y, left: 0, bottom: 0, right: 0)
            
        } else if scrollView.contentOffset.y >= sectionHeaderHeight {
            scrollView.contentInset = UIEdgeInsets(top: -sectionHeaderHeight, left: 0, bottom: 0, right: 0)
        }
        if scrollView.contentOffset.y > 207 {
            fakeNavBar.backgroundColor = UIColor.white
            navLable.textColor = UIColor.darkText
            backButton.setImage(UIImage(named: "navBackDefault"), for: .normal)
            popButton.setTitleColor(UIColor.darkText, for: .normal)
        } else {
            fakeNavBar.backgroundColor = UIColor.clear
            backButton.setImage(UIImage(named: "navBackWhite"), for: .normal)
            popButton.setTitleColor(UIColor.white, for: .normal)
            navLable.textColor = UIColor.white
        }
    }
    
}

// MARK: - Layout
private extension PopularizeController {
    
    func layoutPageSubviews() {
        layoutTopImage()
        layoutFooterView()
        layoutgoPopButton()
        layoutTableView()
        layoutFakeNavBarView()
        layoutNavLable()
        layoutBackButton()
        layoutPopButton()
    }
    
    func layoutTopImage() {
        topBgimage.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(-ConstValue.kStatusBarHeight)
            make.height.equalTo(300)
        }
    }
    
    func layoutFooterView() {
        footerView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalToSuperview()
            }
            make.height.equalTo(60)
        }
    }
    
    func layoutgoPopButton() {
        goPopButton.snp.makeConstraints { (make) in
            make.leading.equalTo(20)
            make.trailing.equalTo(-20)
            make.centerY.equalToSuperview()
            make.height.equalTo(40)
        }
    }
    
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            make.top.leading.trailing.equalToSuperview()
            make.bottom.equalTo(footerView.snp.top)
        }
    }
    
    func layoutPopButton() {
        popButton.snp.makeConstraints { (make) in
            make.trailing.equalTo(-18)
            make.top.equalTo(ConstValue.kStatusBarHeight + 7)
            make.height.equalTo(30)
            
        }
    }
    
    func layoutBackButton() {
        backButton.snp.makeConstraints { (make) in
            make.top.equalTo(ConstValue.kStatusBarHeight + 5)
            make.leading.equalTo(15)
            make.width.equalTo(30)
            make.height.equalTo(30)
        }
    }

    func layoutNavLable() {
        navLable.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(ConstValue.kStatusBarHeight + 10)
            make.height.equalTo(24)
        }
    }
    
    func layoutFakeNavBarView() {
        fakeNavBar.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(ConstValue.kNavigationBarHeight + ConstValue.kStatusBarHeight)
        }
    }

    
}

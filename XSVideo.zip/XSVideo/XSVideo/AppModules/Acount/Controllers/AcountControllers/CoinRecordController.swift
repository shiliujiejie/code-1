//
//  CoinRecordController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/26.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import NicooNetwork
import MJRefresh

/// 爱逗币记录
class CoinRecordController: UIViewController {

    private lazy var headerButton: UIButton = {
        let button = UIButton(type: .custom)
        button.layer.cornerRadius = 31.5
        button.layer.masksToBounds = true
        button.setImage(ConstValue.kVerticalPHImage, for: .normal)
        return button
    }()
    private lazy var nickNameButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitleColor(UIColor.darkText, for: .normal)
        return button
    }()
    private lazy var toGetButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitleColor(UIColor.white, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        button.setTitle(localStr("kGoEarnCoinsTitle"), for: .normal)
        button.setBackgroundImage(UIImage(named: "rectangle"), for: .normal)
        button.addTarget(self, action: #selector(toGetCoinClick), for: .touchUpInside)
        return button
    }()
    private lazy var coinLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor(r: 240 , g: 98 , b: 0)
        lable.text = "0"
        lable.font = UIFont.systemFont(ofSize: 18)
        return lable
    }()
    private let coinImage: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(named: "goldCoin")
        return imageView
    }()
    private let tableHeaderView: UIView = {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 124))
        view.backgroundColor = UIColor.white
        return view
    }()
    private lazy var tableView: UITableView = {
        let table = UITableView(frame: view.bounds, style: .grouped)
        table.backgroundColor = UIColor.clear
        table.rowHeight = 70
        table.showsVerticalScrollIndicator = false
        table.showsHorizontalScrollIndicator = false
        table.allowsSelection = false
        table.delegate = self
        table.dataSource = self
        table.tableFooterView = UIView.init(frame: CGRect.zero)
        table.tableHeaderView = tableHeaderView
        table.mj_header = refreshView
        table.mj_footer = loadMoreView
        table.register(CoinRecordCell.classForCoder(), forCellReuseIdentifier: CoinRecordCell.cellId)
        return table
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        return MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
    }()
    lazy private var refreshView: MJRefreshNormalHeader = {
        weak var weakSelf = self
        return MJRefreshNormalHeader(refreshingBlock: {
            weakSelf?.isRefreshOperation = true
            weakSelf?.loadData()
        })
    }()
    private lazy var recordApi: UserCoinRecordApi = {
        let api = UserCoinRecordApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    var isRefreshOperation = false
    var recordList = [CoinRecordModel]()
    
    /// 处理导航栏
    var navHidenCallBackHandler:((_ isAnimated: Bool) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = localStr("kCoinsDetailTitle")
        view.backgroundColor = UIColor.white
        tableHeaderView.addSubview(headerButton)
        tableHeaderView.addSubview(nickNameButton)
        tableHeaderView.addSubview(toGetButton)
        tableHeaderView.addSubview(coinLable)
        tableHeaderView.addSubview(coinImage)
        view.addSubview(tableView)
        layoutPageSubviews()
        loadMoreView.isHidden = true
        loadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: false)
        navigationController?.navigationBar.shadowImage = UIImage()
        fixUserInfo()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navHidenCallBackHandler?(true)
    }
    
    @objc func toGetCoinClick() {
        self.tabBarController?.selectedIndex = 2
    }
    
}

// MARK: - Privite - Funcs
extension CoinRecordController {
    
    private func fixUserInfo() {
        headerButton.kfSetHeaderImageWithUrl(UserModel.share().cover_path, placeHolder: ConstValue.kDefaultHeader)
        nickNameButton.setTitle(UserModel.share().name ?? "", for: .normal)
        coinLable.text = String(format: "%d", UserModel.share().coins ?? 0)
    }
    
    private func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        if !isRefreshOperation {
            XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        } else {
            isRefreshOperation = false
        }
        let _ = recordApi.loadData()
    }
    
    private func loadNextPage() {
        let _ = recordApi.loadNextPage()
    }
    
    private func loadListDataSuccess(_ model: CoinRecordListModel) {
        XSProgressHUD.hide(for: view, animated: false)
        tableView.mj_header.endRefreshing()
        tableView.mj_footer.endRefreshing()
        if let list = model.data, let pageNumber = model.current_page {
            if pageNumber == 1 {
                guard list.count > 0 else {
                    NicooErrorView.showErrorMessage(.noData, on: view, topMargin: 175, clickHandler: nil)
                    return
                }
                recordList = list
                if list.count >= VideoListApi.kDefaultCount { // 表示可能还有数据
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
                isRefreshOperation = true
                tableView.reloadData()
            } else {
                recordList.append(contentsOf: list)
                if list.count >= VideoListApi.kDefaultCount { // 表示可能还有数据
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
                tableView.reloadData()
            }
        }
    }
    
    private func loadListDataFail() {
        XSProgressHUD.hide(for: view, animated: false)
        tableView.mj_header.endRefreshing()
        tableView.mj_footer.endRefreshing()
        if !isRefreshOperation {
            NicooErrorView.showErrorMessage(.noNetwork, on: view, topMargin: 175, clickHandler: nil)
        }
    }
    
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension CoinRecordController: UITableViewDelegate, UITableViewDataSource {
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return recordList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CoinRecordCell.cellId, for: indexPath) as! CoinRecordCell
        if recordList.count > indexPath.row {
            let coinModel = recordList[indexPath.row]
            cell.setRecorModel(coinModel)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 50))
        view.backgroundColor = UIColor.white
        let lable = UILabel(frame: CGRect(x: 15, y: 16, width: 200, height: 18))
        lable.text = localStr("kCoinsDetailTitle")
        lable.textColor = UIColor.darkText
        lable.font = UIFont.boldSystemFont(ofSize: 18)
        view.addSubview(lable)
        return view
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension CoinRecordController: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if let list = manager.fetchJSONData(UserReformer()) as? CoinRecordListModel {
            loadListDataSuccess(list)
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        loadListDataFail()
    }

}


// MARK: - Layout
private extension CoinRecordController {
    
    func layoutPageSubviews() {
        layoutTableView()
        layoutHeaderViews()
    }
    
    func layoutHeaderViews() {
        headerButton.snp.makeConstraints { (make) in
            make.leading.equalTo(25)
            make.top.equalTo(10)
            make.height.width.equalTo(63)
        }
        nickNameButton.snp.makeConstraints { (make) in
            make.leading.equalTo(headerButton.snp.trailing).offset(15)
            make.top.equalTo(headerButton).offset(10)
            make.height.equalTo(20)
        }
        coinLable.snp.makeConstraints { (make) in
            make.leading.equalTo(headerButton.snp.trailing).offset(15)
            make.bottom.equalTo(headerButton)
            make.height.equalTo(20)
        }
        coinImage.snp.makeConstraints { (make) in
            make.leading.equalTo(coinLable.snp.trailing).offset(5)
            make.bottom.equalTo(headerButton)
            make.height.width.equalTo(20)
        }
        toGetButton.snp.makeConstraints { (make) in
            make.trailing.equalToSuperview()
            make.centerY.equalTo(headerButton).offset(10)
            make.height.equalTo(30)
            make.width.equalTo(80)
        }
    }
    
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.edges.equalTo(view.safeAreaLayoutGuide.snp.edges)
            } else {
                make.edges.equalToSuperview()
            }
        }
    }
    
}

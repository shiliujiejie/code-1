//
//  AcountMainViewController.swift
//  XSVideo
//
//  Created by pro5 on 2018/11/26.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 个人中心
class AcountMainViewController: UIViewController {

    private let topBgimage: UIImageView = {
        let image = UIImageView()
        image.isUserInteractionEnabled = true
        image.image = UIImage(named: "acountHeaderBg")
        return image
    }()
    private lazy var msgButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "messageBtn"), for: .normal)
        button.isHidden = true
        button.addTarget(self, action: #selector(msgButtonClick), for: .touchUpInside)
        return button
    }()
    private lazy var settingButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "settingButn"), for: .normal)
        button.addTarget(self, action: #selector(settingButtonClick), for: .touchUpInside)
        return button
    }()
    private let headerView: AcountMsgHeaderView = {
        let header = AcountMsgHeaderView.init(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 250))
        return header
    }()
    private lazy var tableView: UITableView = {
        let table = UITableView(frame: view.bounds, style: .grouped)
        table.backgroundColor = UIColor.clear
        table.showsVerticalScrollIndicator = false
        table.showsHorizontalScrollIndicator = false
        table.delegate = self
        table.dataSource = self
        table.rowHeight = 50
        table.separatorStyle = .none
        table.tableFooterView = UIView.init(frame: CGRect.zero)
        table.tableHeaderView = headerView
        table.register(AcountItemCell.classForCoder(), forCellReuseIdentifier: AcountItemCell.cellId)
        table.register(UINib(nibName: "AcountListCell", bundle: Bundle.main), forCellReuseIdentifier: AcountListCell.cellId)
        table.register(HistoryWatchedCell.classForCoder(), forCellReuseIdentifier: HistoryWatchedCell.cellId)
        table.register(WatchedListNoDataCell.classForCoder(), forCellReuseIdentifier: WatchedListNoDataCell.cellId)
        return table
    }()
    let viewModel = UserInfoViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        view.addSubview(topBgimage)
        view.addSubview(tableView)
        view.addSubview(msgButton)
        view.addSubview(settingButton)
        layoutPageSubviews()
        addHeaderBtnClickCallBack()
        addViewModelCallBackHandler()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: isNavAnimated ? animated : false)
        isNavAnimated = false
        if UserModel.share().isLogin {
            viewModel.loadUserInfo()
            loadWatchedList()
        }
        fixUserData()
    }
    
    // User -Action
    @objc private func msgButtonClick() {
        
    }
    
    @objc private func settingButtonClick() {
        if UserModel.share().isLogin {
            let acountSetVC = AcountSettingController()
            acountSetVC.navHidenCallBackHandler = { [weak self] (isAnimate) in
                self?.isNavAnimated = isAnimate
            }
            navigationController?.pushViewController(acountSetVC, animated: true)
        } else {
            LoginManager().login { [weak self] in
                let acountSetVC = AcountSettingController()
                acountSetVC.navHidenCallBackHandler = { [weak self] (isAnimate) in
                    self?.isNavAnimated = isAnimate
                }
                self?.navigationController?.pushViewController(acountSetVC, animated: true)
            }
        }
    }
    
}

// MARK: - Provate - Funcs
private extension AcountMainViewController {
    
    func loadWatchedList() {
        viewModel.loadUserWatchedListApi()
    }
    
    func addViewModelCallBackHandler() {
        viewModel.loadUserVideoListApiSuccess = { [weak self] (count) in
            self?.tableView.reloadData()
        }
        viewModel.loadUserVideoListApiFail = { [weak self] in
            self?.tableView.reloadData()
        }
        viewModel.loadUserInfoSuccessHandler = { [weak self] in
            self?.fixUserData()
        }
        viewModel.loadUserInfoFailHandler = { [weak self] in
            self?.fixUserData()
        }
    }
    
    /// 刷新用户信息
    func fixUserData() {
        headerView.fixUserData()
        tableView.reloadRows(at: [IndexPath(row: 0, section: 0)], with: .none)
    }
    
    /// 头部电弧回调
    func addHeaderBtnClickCallBack() {
        /// 登录
        headerView.userHeaderItemClick = { [weak self] in
            if UserModel.share().isLogin {
                let acountSetVC = AcountSettingController()
                acountSetVC.navHidenCallBackHandler = { [weak self] (isAnimate) in
                    self?.isNavAnimated = isAnimate
                }
                self?.navigationController?.pushViewController(acountSetVC, animated: true)
            } else {
                LoginManager().login {
                    self?.fixUserData()
                }
            }
        }
        headerView.recommentClickHandler = { [weak self] in
            if UserModel.share().isLogin {
                let popVC = PopularizeController()
                self?.navigationController?.pushViewController(popVC, animated: true)
            } else {
                LoginManager().login {
                    let popVC = PopularizeController()
                    self?.navigationController?.pushViewController(popVC, animated: true)
                }
            } 
        }
        headerView.lvButtonClickHandler = { [weak self] in
            let experiVC = ExperienController()
            self?.navigationController?.pushViewController(experiVC, animated: true)
        }
        
        headerView.userChargeClickHandler = {
            XSAlert.show(type: .info, text: "开发中...")
        }
    }
    
    func itemClickHandler(_ index: Int) {
        if index == 0 {
            if UserModel.share().isLogin && UserModel.share().isRealUser {
                let coinRecordVC = CoinRecordController()
                coinRecordVC.navHidenCallBackHandler = { [weak self] (isAnimate) in
                    self?.isNavAnimated = isAnimate
                }
                navigationController?.pushViewController(coinRecordVC, animated: true)
            } else {
                LoginManager().login(nil)
            }
        } else if index == 1 {
            let inviteCodeVC = InviteCodeController()
            navigationController?.pushViewController(inviteCodeVC, animated: true)
        } else if index == 2 {
            share()
        } else if index == 3 {
            let taskConvertVC = UserTaskConvertController()
            navigationController?.pushViewController(taskConvertVC, animated: true)
        }
        
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension AcountMainViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0.0
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 1 && indexPath.row == 1 {
            let watchedList = viewModel.getVideoList()
            if watchedList.count > 0 {
                return 220
            } else {
                return 90
            }
        }
        if indexPath.section == 0 {
            return 120
        }
        return 50
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        } else if section == 1 {
            return 2
        }
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: AcountItemCell.cellId, for: indexPath) as! AcountItemCell
            cell.coinsCount = UserModel.share().coins ?? 0
            cell.acountItemClick = { [weak self] (index) in
                self?.itemClickHandler(index)
            }
            return cell
        } else if indexPath.section == 1 && indexPath.row == 1 {
            let watchedLsit = viewModel.getVideoList()
            if watchedLsit.count > 0 {
                let cell = tableView.dequeueReusableCell(withIdentifier: HistoryWatchedCell.cellId, for: indexPath) as! HistoryWatchedCell
                cell.setVideoList(viewModel.getVideoList())
                return cell
            } else {
                let cell = tableView.dequeueReusableCell(withIdentifier: WatchedListNoDataCell.cellId, for: indexPath) as! WatchedListNoDataCell
                return cell
            }
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: AcountListCell.cellId, for: indexPath) as! AcountListCell
            if indexPath.section == 1 { cell.itemTitle.text = localStr("kPlayHistoryCellTitle")
                cell.itemImage.image = UIImage(named: "watchHisIcon")
            }
            if indexPath.section == 2 {
                cell.itemTitle.text = [localStr("kDownloadCellTitle"), localStr("kCollectedCellTitle"), localStr("kAppGroupCellTitle"), localStr("kFadeBackCellTitle")][indexPath.row]
                cell.itemImage.image = UIImage(named: ["download", "acountCollIcon", "appGroup", "helpIcon"][indexPath.row])
            }
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if indexPath.section == 1 && indexPath.row == 0 {
            let historyWatchVC = HistoryWatchListController()
            historyWatchVC.listType = .watchedList
            historyWatchVC.navHidenCallBackHandler = { [weak self] (isAnimate) in
                self?.isNavAnimated = isAnimate
            }
            if UserModel.share().isLogin {
                navigationController?.pushViewController(historyWatchVC, animated: true)
            } else {
                LoginManager().login { [weak self] in
                    self?.navigationController?.pushViewController(historyWatchVC, animated: true)
                }
            }
        }
        
        if indexPath.section == 2 && indexPath.row == 0 {
            let downloadVC = DownloadTasksController()
            downloadVC.navHidenCallBackHandler = { [weak self] (isAnimate) in
                self?.isNavAnimated = isAnimate
            }
            navigationController?.pushViewController(downloadVC, animated: true)
        }
        
        if indexPath.section == 2 && indexPath.row == 1 {
            let historyWatchVC = HistoryWatchListController()
            historyWatchVC.listType = .collectedList
            historyWatchVC.navHidenCallBackHandler = { [weak self] (isAnimate) in
                self?.isNavAnimated = isAnimate
            }
            if UserModel.share().isLogin && UserModel.share().isRealUser {
                navigationController?.pushViewController(historyWatchVC, animated: true)
            } else {
                LoginManager().login(nil)
            }
        }
        
        if indexPath.section == 2 && indexPath.row == 2 {
            if let url = URL.init(string: "https://pt.im/joinchat/acfae5d71eff2bb9aa2c30539e6376ee") {
                if UIApplication.shared.canOpenURL(url) {
                    UIApplication.shared.openURL(url)
                }
            }
        }
        
        if indexPath.section == 2 && indexPath.row == 3 {
            let helpVC = HelpController()
            helpVC.navHidenCallBackHandler = { [weak self] (isAnimate) in
                self?.isNavAnimated = isAnimate
            }
            navigationController?.pushViewController(helpVC, animated: true)
        }
        
       
    }
    
}

// MARK: - Layout
private extension AcountMainViewController {
    
    func layoutPageSubviews() {
        layoutTopImage()
        layoutTableView()
        layoutMsgButton()
        layoutSettingButton()
    }
    
    func layoutTopImage() {
        topBgimage.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(-ConstValue.kStatusBarHeight)
            make.height.equalTo(250)
        }
    }
    
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.edges.equalTo(view.safeAreaLayoutGuide.snp.edges)
            } else {
                make.edges.equalToSuperview()
            }
        }
    }
    
    func layoutMsgButton() {
        msgButton.snp.makeConstraints { (make) in
            make.leading.equalTo(20)
            make.top.equalTo(ConstValue.kStatusBarHeight + 7)
            make.width.height.equalTo(30)
        }
    }
    
    func layoutSettingButton() {
        settingButton.snp.makeConstraints { (make) in
            make.trailing.equalTo(-18)
            make.top.equalTo(ConstValue.kStatusBarHeight + 7)
            make.width.height.equalTo(30)
        }
    }
    
}

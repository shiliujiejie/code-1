//
//  SearchResultController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/25.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import MJRefresh
import NicooNetwork

class SearchResultController: UIViewController {

    private lazy var tableView: UITableView = {
        let table = UITableView(frame: view.bounds, style: .plain)
        table.showsVerticalScrollIndicator = false
        table.delegate = self
        table.dataSource = self
        table.tableFooterView = UIView(frame: CGRect.zero)
        table.register(SpeciaTpMoreCell.classForCoder(), forCellReuseIdentifier: SpeciaTpMoreCell.cellId)
        table.mj_header = refreshView
        return table
    }()
    private lazy var nodaVC: SearchNotDataController = {
        let noDataVc = SearchNotDataController()
        noDataVc.hotSearchModels = hotSearchModels
        return noDataVc
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        return MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
    }()
    lazy private var refreshView: MJRefreshGifHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshGifHeader(refreshingBlock: {
            weakSelf?.isRefreshOperation = true
            weakSelf?.loadData()
        })
        var gifImages = [UIImage]()
        for string in ConstValue.refreshImageNames {
            gifImages.append(UIImage(named: string)!)
        }
        mjRefreshHeader?.setImages(gifImages, for: .refreshing)
        mjRefreshHeader?.setImages(gifImages, for: .idle)
        return mjRefreshHeader!
    }()
    private lazy var videoLsApi: VideoListApi = {
        let api = VideoListApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    var isRefreshOperation = false
    /// 视频类型
    var videoTitle: String?
    var videoListModel: VideoListModel?
    var videoModels = [VideoModel]()
    /// 热搜列表
    var hotSearchModels: [VideoModel]?
    
    var endEditingCallBackHandler:(() ->Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        view.addSubview(tableView)
        layoutPageSubviews()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadData()
    }
    
    func loadData() {
        if children.contains(nodaVC) {
            nodaVC.removeFromParent()
            nodaVC.view.removeFromSuperview()
        }
        if !isRefreshOperation {
            XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        }
        let _ = videoLsApi.loadData()
    }
    
    func loadNextPage() {
        let _ = videoLsApi.loadNextPage()
    }
    
}

// MARK: - Privite - Funcs
private extension SearchResultController {
    
    func loadVideoDataSuccess(_ listModel: VideoListModel) {
        NicooErrorView.removeErrorMeesageFrom(view)
        tableView.mj_footer?.endRefreshing()
        tableView.mj_header?.endRefreshing()
        loadMoreView.isHidden = true
        videoListModel = listModel
        if let list = listModel.data,let pageNumber = listModel.current_page {
            refreshView.isHidden = false
            if pageNumber == 1 {
                guard list.count > 0 else {
                    addNodataView()
                    return
                }
                videoModels = list
                if list.count >= VideoListApi.kDefaultCount { // 表示可能还有数据
                    tableView.mj_footer = loadMoreView
                    loadMoreView.isHidden = false
                    
                } else {
                    loadMoreView.isHidden = true
                }
                isRefreshOperation = true
                tableView.reloadData()
                tableView.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: false)
            } else {
                videoModels.append(contentsOf: list)
                if list.count >= VideoListApi.kDefaultCount { // 表示可能还有数据
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
            }
            tableView.reloadData()
        }
    }
    
    func loadVideoDataFail(_ manager: NicooBaseAPIManager) {
        addNodataView()
    }
    
    func addNodataView() {
        if !children.contains(nodaVC) {
            addChild(nodaVC)
            view.addSubview(nodaVC.view)
            nodaVC.view.snp.makeConstraints { (make) in
                make.leading.top.trailing.equalToSuperview()
                if #available(iOS 11.0, *) {
                    make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
                } else {
                    make.bottom.equalToSuperview()
                }
            }
        }
    }
    
    func getActorsLableText(_ videoModel: VideoModel) -> String? {
        var actorsString: String = localStr("kAcotrTitle")
        if let actors = videoModel.author, actors.count > 0 {
            for actor in actors {
                if actor.actor_label != nil {
                    let string = String(format: "%@  ", actor.actor_label!)
                    actorsString = String(format:"%@ %@", actorsString, string)
                }
            }
            return actorsString
        }
        return nil
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension SearchResultController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return (ConstValue.kScreenWdith - 20)/3 * 1.4 + 20
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return videoModels.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: SpeciaTpMoreCell.cellId, for: indexPath) as! SpeciaTpMoreCell
        let model = videoModels[indexPath.row]
        cell.topicImage.kfSetVerticalImageWithUrl(model.cover_path)
        cell.nameLable.text = model.title ?? ""
        if model.intro != nil && !model.intro!.isEmpty {
            cell.desLable.text = model.intro!
        }else {
            cell.desLable.text = localStr("kNotIntrolMsg")
        }
        if let actorString = getActorsLableText(model) {
            cell.actorLable.text = actorString as String
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let model = videoModels[indexPath.row]
        let videoDetailVC = VideoDetailViewController()
        videoDetailVC.videoId = model.id ?? 0
        navigationController?.pushViewController(videoDetailVC, animated: true)
    }
    
}

// MARK: - UIScrollViewDelegate
extension SearchResultController: UIScrollViewDelegate {
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        endEditingCallBackHandler?()
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension SearchResultController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        var params = [String: Any]()
        if manager is VideoListApi {
            params[VideoListApi.kVideo_title] = videoTitle
            return params
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is VideoListApi {
            if let list = manager.fetchJSONData(VideoReformer()) as? VideoListModel {
                loadVideoDataSuccess(list)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is VideoListApi {
            loadVideoDataFail(manager)
        }
    }
    
    
}

// MARK: - Layout
private extension SearchResultController {
    
    func layoutPageSubviews() {
        layoutTableView()
    }
    
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalToSuperview()
            }
        }
    }
    
}


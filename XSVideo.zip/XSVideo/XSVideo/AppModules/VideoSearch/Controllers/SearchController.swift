//
//  SearchController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/25.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import NicooNetwork

/// 搜索主页
class SearchController: UIViewController {

    private lazy var tableView: UITableView = {
        let table = UITableView(frame: view.bounds, style: .plain)
        table.showsVerticalScrollIndicator = false
        table.separatorStyle = .none
        table.delegate = self
        table.dataSource = self
        table.tableFooterView = UIView(frame: CGRect.zero)
        table.register(HistorySearchCell.classForCoder(), forCellReuseIdentifier: HistorySearchCell.cellId)
        table.register(HotSearchCell.classForCoder(), forCellReuseIdentifier: HotSearchCell.cellId)
        return table
    }()
    private lazy var cancleBarButton: UIBarButtonItem = {
        let barButton = UIBarButtonItem.init(title: localStr("kCancle"), style: .plain, target: self, action: #selector(cancleSearch))
        barButton.tintColor = UIColor.darkText
        return barButton
    }()
    private lazy var searchBar: UISearchBar = {
        let searchBar = UISearchBar(frame: CGRect(x: 20, y: 7, width: ConstValue.kScreenWdith - 120, height: 30))
        searchBar.placeholder = localStr("kSearchPlaceHolder")
        searchBar.changeTextFieldBackgroundColor(UIColor.groupTableViewBackground)
        searchBar.delegate = self
        return searchBar
    }()
    private lazy var resultVC : SearchResultController = {
        let result = SearchResultController()
        return result
    }()
    private lazy var hotListApi: VideoListApi = {
        let api = VideoListApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    var videoList: [VideoModel]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        navigationController?.navigationBar.addSubview(searchBar)
        navigationItem.rightBarButtonItem = cancleBarButton
        view.addSubview(tableView)
        layoutPageSubviews()
        resultVC.endEditingCallBackHandler = { [weak self] in
            self?.searchBar.resignFirstResponder()
            self?.searchBar.endEditing(true)
        }
        loadHotSearch()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    private func loadHotSearch() {
        let _ = hotListApi.loadData()
    }

}

// MARK: - Privite Funcs
extension SearchController {
    
    /// 取消搜索点击
    @objc private func cancleSearch() {
        searchBar.resignFirstResponder()
        searchBar.endEditing(true)
        self.dismiss(animated: true, completion: nil)
    }
    
    /// 清空搜索历史
    @objc private func deleteSearchHistory() {
        UserDefaults.standard.removeObject(forKey: UserDefaults.kSearchHistory)
        tableView.reloadSections([0], with: .none)
    }
    
    /// 搜索
    ///
    /// - Parameter keyWord: 关键词
    private func searchWithKey(_ keyWord: String?) {
        if keyWord == nil {
            XSAlert.show(type: .warning, text: localStr("kSearchTextNilAlert"))
            return
        }
        searchBar.resignFirstResponder()
        searchBar.endEditing(true)
        if view.subviews.contains(resultVC.view) {
            resultVC.videoTitle = keyWord
            resultVC.loadData()
        } else {
            resultVC.videoTitle = keyWord
            resultVC.hotSearchModels = videoList
            addChild(resultVC)
            view.addSubview(resultVC.view)
            layoutResultView(resultVC.view)
        }
    }
    
    /// 热搜列表拉取成功
    private func loadListDataSuccess(_ listModel: VideoListModel) {
        if let list = listModel.data, list.count > 0 {
            videoList = list
            tableView.reloadSections([1], with: .none)
        }
    }
    
    /// 存储搜索历史
    private func saveSearchHistoryItem(_ text: String?) {
        if text == nil { return }
        guard var hisList = UserDefaults.standard.array(forKey: UserDefaults.kSearchHistory) as? [String] else {
            var array = [String]()
            array.append(text!)
            UserDefaults.standard.set(array, forKey: UserDefaults.kSearchHistory)
            return
        }
        hisList.insert(text!, at: 0)
        if hisList.count > 9 {
           hisList.removeLast() // 移除最后一位
        }
        UserDefaults.standard.set(hisList, forKey: UserDefaults.kSearchHistory)
        tableView.reloadSections([0], with: .none)
    }

}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension SearchController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            if let hisList = UserDefaults.standard.array(forKey: UserDefaults.kSearchHistory) as? [String], hisList.count > 0 {
                return 1
            } else {
                return 0
            }
        } else {
            if videoList != nil {
                return videoList!.count > 0 ? 1 : 0
            } else {
                return 0
            }
            
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return cellForRow(indexPath)
    }
    
    func cellForRow(_ indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: HistorySearchCell.cellId, for: indexPath) as! HistorySearchCell
            guard let hisList = UserDefaults.standard.array(forKey: UserDefaults.kSearchHistory) as? [String] else {
                return UITableViewCell()
            }
            cell.setHistorySearchData(hisList)
            cell.itemClickHandler = { [weak self] (text) in
                self?.view.endEditing(true)
                self?.searchBar.text = text
                self?.searchWithKey(text)
            }
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: HotSearchCell.cellId, for: indexPath) as! HotSearchCell
            if let model = videoList {
                cell.setHistorySearchData(model)
            }
            cell.itemClickHandler = {[weak self] (videoId) in
                let videoDetailVC = VideoDetailViewController()
                videoDetailVC.videoId = videoId
                self?.navigationController?.pushViewController(videoDetailVC, animated: true)
            }
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            if let hisList = UserDefaults.standard.array(forKey: UserDefaults.kSearchHistory) as? [String], hisList.count > 0 {
                let yu = (hisList.count%3) > 0 ? 1 : 0
                return CGFloat(((hisList.count/3) + yu) * 45 + 30)
            } else {
                return 0
            }
        } else { return 315}
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        if indexPath.section == 1 {
            if let model = videoList?[indexPath.row] {
                let videoDetailVC = VideoDetailViewController()
                videoDetailVC.videoId = model.id ?? 0
                navigationController?.pushViewController(videoDetailVC, animated: true)
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 {
            if let hisList = UserDefaults.standard.array(forKey: UserDefaults.kSearchHistory) as? [String], hisList.count > 0 {
                return 50
            } else {
                return 0
            }
        } else {
            return 50
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 50))
        let lable = UILabel(frame: CGRect(x:15, y: 15, width: 150, height: 20))
        lable.font = UIFont.boldSystemFont(ofSize: 18)
        lable.textColor = UIColor.darkText
        lable.text = [localStr("kSearchHistoryTitle") ,localStr("kHotSearchTitle")][section]
        view.addSubview(lable)
        let button = UIButton(type: .custom)
        button.setTitleColor(UIColor.darkText, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        button.frame = CGRect(x: ConstValue.kScreenWdith - 60, y: 10, width: 50, height: 30)
        button.setImage(UIImage(named: "cleanAllSearchHis"), for: .normal)
        if section == 1 { button.isHidden = true } else {
            if let hisList = UserDefaults.standard.array(forKey: UserDefaults.kSearchHistory) as? [String], hisList.count > 0 {
                button.isHidden = false
            } else {
                button.isHidden = true
            }
        }
        button.addTarget(self, action: #selector(deleteSearchHistory), for: .touchUpInside)
        view.addSubview(button)
        return view
    }
}

// MARK: - UIScrollViewDelegate
extension SearchController: UIScrollViewDelegate {
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        searchBar.resignFirstResponder()
        searchBar.endEditing(true)
        let sectionHeaderHeight: CGFloat = 50
        if scrollView.contentOffset.y <= sectionHeaderHeight && scrollView.contentOffset.y > 0 {
            scrollView.contentInset = UIEdgeInsets(top: -scrollView.contentOffset.y, left: 0, bottom: 0, right: 0)
            
        } else if scrollView.contentOffset.y >= sectionHeaderHeight {
            scrollView.contentInset = UIEdgeInsets(top: -sectionHeaderHeight, left: 0, bottom: 0, right: 0)
        }
    }
}


// MARK: - UISearchBarDelegate
extension SearchController: UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchWithKey(searchBar.text)
        saveSearchHistoryItem(searchBar.text)
    }
    
    func searchBarShouldBeginEditing(_ searchBar: UISearchBar) -> Bool {
        return true
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        let searchStr = searchText.removeAllSpace()
        if searchStr == nil || searchStr!.isEmpty {
            resultVC.view.removeFromSuperview()
            resultVC.removeFromParent()
        }
    }
    
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension SearchController: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        XSProgressHUD.showProgress(msg: nil, onView: view, animated: false)
        var params = [String: Any]()
        params[VideoListApi.kExponent_bd] = VideoListApi.kDefaultExponent_bd
        params[VideoListApi.kPageCount] = 10
        return params
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if let list = manager.fetchJSONData(VideoReformer()) as? VideoListModel {
            loadListDataSuccess(list)
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
    }
    
}

// MARK: - Layout
private extension SearchController {
    
    func layoutPageSubviews() {
        layoutTableView()
    }
    
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.edges.equalTo(view.safeAreaLayoutGuide.snp.edges)
            } else {
                make.edges.equalToSuperview()
            }
        }
    }
    
    func layoutResultView(_ childview: UIView) {
        childview.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.edges.equalTo(view.safeAreaLayoutGuide.snp.edges)
            } else {
                make.edges.equalToSuperview()
            }
        }
    }
}

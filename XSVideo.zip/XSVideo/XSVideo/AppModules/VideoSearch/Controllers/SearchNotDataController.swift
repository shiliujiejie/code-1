//
//  SearchNotDataController.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/10.
//  Copyright © 2019年 pro5. All rights reserved.
//

import UIKit
import MJRefresh
import NicooNetwork

class SearchNotDataController: UIViewController {
    
    private lazy var tableView: UITableView = {
        let table = UITableView(frame: view.bounds, style: .plain)
        table.showsVerticalScrollIndicator = false
        table.delegate = self
        table.dataSource = self
        table.tableFooterView = UIView(frame: CGRect.zero)
        table.register(SpeciaTpMoreCell.classForCoder(), forCellReuseIdentifier: SpeciaTpMoreCell.cellId)
        table.tableHeaderView = tableHeader
        return table
    }()
    private lazy var tableHeader: UIView = {
        let header = UIView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 180))
        header.backgroundColor = UIColor.white
        return header
    }()
   
    private lazy var imageView: UIImageView = {
        let nodataImage = UIImageView()
        nodataImage.image = UIImage(named: "invitedNodata")
        nodataImage.contentMode = .scaleAspectFit
        return nodataImage
    }()
    private let nodataLable: UILabel = {
        let lable = UILabel()
        lable.text = localStr("kNoDataAlertMsg")
        lable.font = UIFont.systemFont(ofSize: 16)
        return lable
    }()
    
    /// 热搜列表
    var hotSearchModels: [VideoModel]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        tableHeader.addSubview(imageView)
        tableHeader.addSubview(nodataLable)
        view.addSubview(tableView)
        layoutPageSubviews()
    }
    
    
}

// MARK: - Privite - Funcs
private extension SearchNotDataController {
    
    func getActorsLableText(_ videoModel: VideoModel) -> String? {
        var actorsString: String = localStr("kAcotrTitle")
        if let actors = videoModel.author, actors.count > 0 {
            for actor in actors {
                if actor.actor_label != nil {
                    let string = String(format: "%@  ", actor.actor_label!)
                    actorsString = String(format:"%@ %@", actorsString, string)
                }
            }
            return actorsString
        }
        return nil
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension SearchNotDataController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 50))
        view.backgroundColor = UIColor.white
        let lable = UILabel(frame: CGRect(x:15, y: 15, width: 150, height: 20))
        lable.font = UIFont.boldSystemFont(ofSize: 18)
        lable.textColor = UIColor.darkText
        lable.text = localStr("kSearchNodataTitle")
        view.addSubview(lable)
        return view
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return (ConstValue.kScreenWdith - 20)/3 * 1.4 + 20
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return hotSearchModels?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: SpeciaTpMoreCell.cellId, for: indexPath) as! SpeciaTpMoreCell
        if let model = hotSearchModels?[indexPath.row] {
            cell.topicImage.kfSetVerticalImageWithUrl(model.cover_path)
            cell.nameLable.text = model.title ?? ""
            if model.intro != nil && !model.intro!.isEmpty {
                cell.desLable.text = model.intro!
            }else {
                cell.desLable.text = localStr("kNotIntrolMsg")
            }
            if let actorString = getActorsLableText(model) {
                cell.actorLable.text = actorString as String
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if let model = hotSearchModels?[indexPath.row] {
            let videoDetailVC = VideoDetailViewController()
            videoDetailVC.videoId = model.id ?? 0
            navigationController?.pushViewController(videoDetailVC, animated: true)
        }
    }
    
}

// MARK: - Layout
private extension SearchNotDataController {
    
    func layoutPageSubviews() {
        layoutNodataImage()
        layoutNodataLable()
        layoutTableView()
    }
    
    func layoutNodataImage() {
        imageView.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview().offset(-20)
            make.width.height.equalTo(80)
        }
    }
    
    func layoutNodataLable() {
        nodataLable.snp.makeConstraints { (make) in
            make.top.equalTo(imageView.snp.bottom).offset(5)
            make.centerX.equalToSuperview()
            make.height.equalTo(20)
        }
    }
    
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalToSuperview()
            }
        }
    }
    
}


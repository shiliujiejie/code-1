//
//  HotSearchCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/25.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 热搜
class HotSearchCell: UITableViewCell {

    static let cellId = "HotSearchCell"
    
    private let customLayout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: (ConstValue.kScreenWdith - 50)/2, height: 44)
        //layout.estimatedItemSize = CGSize(width: (ConstValue.kScreenWdith - 60)/3, height: 35)
        layout.minimumLineSpacing = 15.0
        layout.sectionInset = UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 15)
        return layout
    }()
    private lazy var collectionView: UICollectionView = {
        let collection = UICollectionView.init(frame: self.bounds, collectionViewLayout: customLayout)
        collection.delegate = self
        collection.dataSource = self
        collection.backgroundColor = UIColor.white
        collection.showsVerticalScrollIndicator = false
        collection.register(UINib(nibName: "HotSearchItemCell", bundle: Bundle.main), forCellWithReuseIdentifier: HotSearchItemCell.cellId)
        return collection
    }()
    private var items: [VideoModel]?
    
    var itemClickHandler:((_ videoId: Int) ->Void)?
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.backgroundColor = UIColor.white
        contentView.addSubview(collectionView)
        layoutCollection()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setHistorySearchData(_ list: [VideoModel]) {
        items = list
        collectionView.reloadData()
    }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension HotSearchCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return items?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: HotSearchItemCell.cellId, for: indexPath) as! HotSearchItemCell
        if let model = items?[indexPath.row] {
            cell.videNameLab.text = items![indexPath.row].title
            if indexPath.row <= 2 {
                cell.rankLable.backgroundColor = [UIColor.red, UIColor(r: 255 , g: 205 , b: 10), ConstValue.kAppDefaultTitleColor][indexPath.row]
                cell.rankLable.textColor = UIColor.white
            } else {
                cell.rankLable.textColor = ConstValue.kAppDefaultTitleColor
                cell.rankLable.layer.borderColor = ConstValue.kAppDefaultTitleColor.cgColor
                cell.rankLable.layer.borderWidth = 0.5
            }
            cell.rankLable.text = "\(indexPath.row + 1)"
            if model.label_status == 0 {
                cell.reconmentLab.isHidden = true
                cell.hotButton.isHidden = true
            } else if model.label_status == 1 {
                cell.hotButton.isHidden = false
                cell.reconmentLab.isHidden = true
            } else if model.label_status == 2 {
                cell.hotButton.isHidden = true
                cell.reconmentLab.isHidden = false
            } else if model.label_status == 3 {
                cell.hotButton.isHidden = true
                cell.reconmentLab.isHidden = false
                cell.reconmentLab.text = UIViewController.localStr("kRecomment")
                cell.reconmentLab.textColor = ConstValue.kAppDefaultColor
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
          if let model = items?[indexPath.row] {
            itemClickHandler?(model.id ?? 0)
        }
    }
    
}

// MARK: - Layout
private extension HotSearchCell {
    
    private func layoutCollection() {
        collectionView.snp.makeConstraints { (make) in
            make.top.equalTo(10)
            make.center.equalToSuperview()
            make.leading.trailing.equalToSuperview()
            make.height.equalTo(44)
        }
    }
    
}

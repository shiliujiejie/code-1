//
//  SpecialTopicModel.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/10.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit


/// 专题演员列表Model
struct TopicStarListModel: Codable {
    var current_page: Int?
    var data: [TopicStarModel]?
}

/// 专题m演员Model
struct TopicStarModel: Codable {
    var actor_id: Int?
    var name: String?
    var intro: String?
    var cover_path: String?
    var video_count: Int?
}

/// 专题分类列表model
struct TopicTypeListModel: Codable {
    var film: [TopicTypeModel]?
    var teleplay: [TopicTypeModel]?
    var cartoon: [TopicTypeModel]?
    var variety: [TopicTypeModel]?
}

/// 专题分类model
struct TopicTypeModel: Codable {
    var id: Int?
    var global_type: String?
    var type_id: Int?
    var video_count: Int?
    var type_cover_path: String?
    var type_name: String?
}

/// 演员详情model
struct TopicActorInfoModel: Codable {
    var id: Int?
    var name: String?
    var intro: String?
    var cover_path: String?
    var created_at: String?
    var updated_at: String?
    var introHieght: CGFloat?

}

/// 新专题列表
struct TopicVideoListModel: Codable {
    var current_page: Int?
    var data: [TopicVideosModel]?
    var path: String?
}

struct TopicVideosModel: Codable {
    var id : Int?
    var title: String?
    var cover_img: String?
    var intro: String?
    var intro_img: String?
    var video_ids: String?
    var sort: Int?
    var created_at: String?
}

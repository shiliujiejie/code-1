//
//  SpecialTopicCardCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/10.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class SpecialTopicCardCell: UICollectionViewCell {
    
    static let cellId = "SpecialTopicCardCell"
    
    private let customLayout: CustomFlowSingleLayout = {
        let layout = CustomFlowSingleLayout()
        layout.itemSize = CGSize(width: (ConstValue.kScreenWdith - 20)/1.5, height: 200)
        return layout
    }()
    private lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect(x: 0, y: 5, width: ConstValue.kScreenWdith, height: 210), collectionViewLayout: customLayout)
        collection.backgroundColor = UIColor.white
        collection.showsHorizontalScrollIndicator = false
        collection.delegate = self
        collection.dataSource = self
        collection.register(UINib(nibName: "TopicCardCell", bundle: Bundle.main), forCellWithReuseIdentifier: TopicCardCell.cardTopicCellId)
        return collection
    }()
    var cardItemClickHandler:((_ index: Int) -> Void)?
    var starModels: [TopicStarModel]?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = UIColor.white
        contentView.addSubview(collectionView)
        layoutCollection()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setModels(_ models: [TopicStarModel]) {
        starModels = models
        collectionView.reloadData()
    }
    
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension SpecialTopicCardCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return starModels?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: TopicCardCell.cardTopicCellId, for: indexPath) as! TopicCardCell
        if starModels != nil && starModels!.count > indexPath.row {
            let starModel = starModels![indexPath.row]
            cell.topicName.text = starModel.name ?? UIViewController.localStr("kNot")
            cell.topicImageView.kfSetHeaderImageWithUrl(starModel.cover_path, placeHolder: ConstValue.kTopicTypeHolder)   
            cell.actLable.text = "\(UIViewController.localStr("kVideoCountTitle")) \(starModel.video_count ?? 0)"
            cell.desLable.text = starModel.intro ?? UIViewController.localStr("kNot")
            cell.seeButton.setTitle(UIViewController.localStr("kWatchJustRightNowTitle"), for: .normal)
        }   
        cell.cardItemClickHandler = { [weak self] in
            self?.cardItemClickHandler?(indexPath.row)
        }
        return cell
    }
    
    
}

// MARK: - Layout
private extension SpecialTopicCardCell {
    
    private func layoutCollection() {
        collectionView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
}


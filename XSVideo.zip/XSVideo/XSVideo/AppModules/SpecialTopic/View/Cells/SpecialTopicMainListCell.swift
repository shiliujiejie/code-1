//
//  SpecialTopicMainListCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/6.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 专题主页列表cell
class SpecialTopicMainListCell: UITableViewCell {
    
    static let cellId = "SpecialTopicCell"
    
    lazy var topicImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.layer.cornerRadius = 10
        imageView.layer.masksToBounds = true
        return imageView
    }()
    
    private lazy var bottomBarBgLayer: CAGradientLayer = {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.darkGray.withAlphaComponent(0.0).cgColor, UIColor(white: 0.0, alpha: 0.6).cgColor]
        gradientLayer.frame = CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith - 20, height: 40)
        gradientLayer.locations = [0, 0.99, 1]
        return gradientLayer
    }()
    
    lazy var desLable: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .center
        lable.font = UIFont.systemFont(ofSize: 15)
        lable.textColor = UIColor.white
        lable.layer.addSublayer(bottomBarBgLayer)
        return lable
    }()

    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.backgroundColor = UIColor.white
        contentView.addSubview(topicImageView)
        contentView.addSubview(desLable)
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}


// MARK: - Layout
private extension SpecialTopicMainListCell {
    
    func layoutPageSubviews() {
        layoutImageView()
        layoutDesLable()
    }
    
    func layoutImageView() {
        topicImageView.snp.makeConstraints { (make) in
            make.leading.equalTo(10)
            make.trailing.equalTo(-10)
            make.top.equalTo(10)
            make.bottom.equalTo(-10)
        }
    }
    
    func layoutDesLable() {
        desLable.snp.makeConstraints { (make) in
            make.leading.trailing.bottom.equalTo(topicImageView)
            make.height.equalTo(40)
        }
    }
}

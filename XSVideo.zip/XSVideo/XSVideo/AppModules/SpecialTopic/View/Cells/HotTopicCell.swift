//
//  HotTopicCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/10.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 热门专题cell
class HotTopicCell: UICollectionViewCell {
    
    static let hotTopicCellId = "HotTopicCell"
    
    lazy var topicImage: UIImageView = {
        let imageView = UIImageView()
        imageView.layer.cornerRadius = 32.5
        imageView.layer.masksToBounds = true
        return imageView
    }()
    
    lazy var topicName: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.darkText
        lable.font = UIFont.systemFont(ofSize: 13)
        lable.textAlignment = .center
        return lable
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(topicImage)
        contentView.addSubview(topicName)
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

// MARK: - Layout
private extension HotTopicCell {
    
    func layoutPageSubviews() {
        layoutImageView()
        layoutTopicName()
    }
    
    func layoutImageView() {
        topicImage.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(10)
            make.height.width.equalTo(65)
        }
    }
    
    func layoutTopicName() {
        topicName.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(topicImage.snp.bottom).offset(10)
            make.bottom.equalToSuperview()
        }
    }
}

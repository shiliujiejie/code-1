//
//  SpeciaTpMoreCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/10.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class SpeciaTpMoreCell: UITableViewCell {

    static let cellId = "SpeciaTpMoreCell"
    
    let topicImage: UIImageView = {
        let imageView = UIImageView()
        imageView.layer.cornerRadius = 3
        imageView.layer.masksToBounds = true
        return imageView
    }()
    let nameLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.darkText
        lable.font = UIFont.boldSystemFont(ofSize: 16)
        return lable
    }()
    let desLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.darkText
        lable.font = UIFont.systemFont(ofSize: 15)
        lable.numberOfLines = 2
        return lable
    }()
    let typeLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.darkGray
        lable.font = UIFont.systemFont(ofSize: 15)
        lable.text = ""
        return lable
    }()
    let actorLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.darkGray
        lable.font = UIFont.systemFont(ofSize: 15)
        return lable
    }()
    let directorLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.darkGray
        lable.font = UIFont.systemFont(ofSize: 15)
        return lable
    }()
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.addSubview(topicImage)
        contentView.addSubview(nameLable)
        contentView.addSubview(desLable)
        contentView.addSubview(typeLable)
        contentView.addSubview(actorLable)
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

// MARK: - Layout
private extension SpeciaTpMoreCell {
    
    func layoutPageSubviews() {
        layoutImageView()
        layoutNameLable()
        layoutDesLable()
        layoutTypeLable()
        layoutActorLable()
    }
    
    func layoutImageView() {
        topicImage.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.width.equalTo((ConstValue.kScreenWdith - 20)/3)
            make.top.equalTo(10)
            make.bottom.equalTo(-10)
        }
    }
    func layoutNameLable() {
        nameLable.snp.makeConstraints { (make) in
            make.leading.equalTo(topicImage.snp.trailing).offset(15)
            make.top.equalTo(topicImage).offset(10)
            make.trailing.equalTo(-15)
            make.height.equalTo(20)
        }
    }
    func layoutDesLable() {
        desLable.snp.makeConstraints { (make) in
            make.leading.equalTo(nameLable)
            make.trailing.equalTo(-15)
            make.top.equalTo(nameLable.snp.bottom).offset(5)
            make.height.equalTo(40)
        }
    }
    func layoutTypeLable() {
        typeLable.snp.makeConstraints { (make) in
            make.leading.equalTo(desLable)
            make.top.equalTo(desLable.snp.bottom).offset(5)
            make.trailing.equalTo(-15)
            make.height.equalTo(20)
        }
    }
   
    func layoutActorLable() {
        actorLable.snp.makeConstraints { (make) in
            make.leading.equalTo(typeLable)
            make.top.equalTo(typeLable.snp.bottom).offset(10)
            make.trailing.equalTo(-15)
            make.height.equalTo(20)
        }
    }
}

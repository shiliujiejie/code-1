//
//  TopicCardCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/10.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class TopicCardCell: UICollectionViewCell {

    static let cardTopicCellId = "TopicCardCell"
    
    @IBOutlet weak var fakeContainerView: UIView!
    @IBOutlet weak var topicImageView: UIImageView!
    @IBOutlet weak var topicName: UILabel!
    @IBOutlet weak var actLable: UILabel!
    @IBOutlet weak var desLable: UILabel!
    @IBOutlet weak var seeButton: UIButton!
    var cardItemClickHandler:(() -> Void)?
    override func awakeFromNib() {
        super.awakeFromNib()
        contentView.backgroundColor = UIColor.white
        fakeContainerView.layer.cornerRadius = 8
        fakeContainerView.backgroundColor = UIColor.white
        fakeContainerView.layer.shadowColor = UIColor.groupTableViewBackground.cgColor
        fakeContainerView.layer.shadowOffset = CGSize()
        fakeContainerView.layer.shadowOpacity = 1
        fakeContainerView.layer.shadowRadius = 6
        fakeContainerView.clipsToBounds = false
        topicImageView.layer.cornerRadius = 35
        topicImageView.layer.masksToBounds = true
        seeButton.layer.cornerRadius = 15
        seeButton.backgroundColor = ConstValue.kAppDefaultColor
        seeButton.layer.masksToBounds = true
        //contentView.layer.shadowColor = UIColor.lightGray.cgColor
       // contentView.layer.shadowOpacity = 0.5
    }

    @IBAction func seeButtonClick(_ sender: UIButton) {
        cardItemClickHandler?()
    }
}

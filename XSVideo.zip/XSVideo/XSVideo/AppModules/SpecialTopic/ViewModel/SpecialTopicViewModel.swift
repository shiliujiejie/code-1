//
//  SpecialTopicViewModel.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/10.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import NicooNetwork

class SpecialTopicViewModel: NSObject {
    
    /// item之间的最小间隙 (这些size应该放入ViewModel)
    static let videoInteritemSpacing: CGFloat = 5
    static let videoItemWidth: CGFloat = (ConstValue.kScreenWdith - 20)/3
    static let videoItemHieght: CGFloat = videoItemWidth * 1.4 + 55
    static let videoItemSize: CGSize = CGSize(width: videoItemWidth, height: videoItemHieght)
    
    /// 专题卡片样式
    static let cardItemWidth: CGFloat = ConstValue.kScreenWdith
    static let cardItemHeight: CGFloat = 210
    static let cardItemSize: CGSize = CGSize(width: cardItemWidth, height: cardItemHeight)
    
    /// 热门专题
    static let hotTpItemWidth: CGFloat = (ConstValue.kScreenWdith - 20)/4
    static let hotTpItemHeight: CGFloat = 100
    static let hotTpItemSize: CGSize = CGSize(width: hotTpItemWidth, height: hotTpItemHeight)
    
    /// 广告 排版
    static let advertisingItemWith: CGFloat = ConstValue.kScreenWdith - 10
    static let advertisingItemHeight: CGFloat =  200
    static let advertisingItemSize: CGSize = CGSize(width: advertisingItemWith, height: advertisingItemHeight)
    
    /// 区对应的模块
    enum SectionType {
        case topicActor
        case topicType
        case topicVideo
        case advertisement
    }
    
    private(set) lazy var sectionItems: [AnyObject] = {
        let sections = [AnyObject]()
        return sections
    }()
    private lazy var specialStarsApi: SpecialActorListApi = {
        let api = SpecialActorListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var specialTypeApi: SpecialTypeListApi = {
        let api = SpecialTypeListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var specialVideoLsApi: VideoListApi = {
        let api = VideoListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    /// 专题明星接口回调
    var loadTopicStarListDataSuccessHandler:(() -> Void)?
    var loadTopicStarListDataFailHandler:((_ empty: Bool) -> Void)?
    /// 专题分类接口回调
    var loadTopicTypeListDataSuccessHandler:(() -> Void)?
    var loadTopicTypeListDataFailHandler:((_ empty: Bool) -> Void)?
    /// 专题视屏接口回调
    var loadTopicVideoListDataSuccessHandler:(() -> Void)?
    var loadTopicVideoListDataFailHandler:((_ empty: Bool) -> Void)?
    
    var isRefreshOperation = false
    /// 用于区分该分区的数据类型，和cell类型
    var sectionType: SectionType = SectionType.topicActor
    
    var topicStarListModel: TopicStarListModel?
    var topicTypeListModel: TopicTypeListModel?
    var topicVideoListModel: VideoListModel?
    
    
    func loadSpecialTopicData(){
        sectionItems.removeAll()
        //创建c行队列
        var queue: DispatchQueue
        let queueName = "SpecialTopic"
        if #available(iOS 10.0, *) {
            queue = DispatchQueue(label: queueName, qos: .default, attributes: .concurrent, autoreleaseFrequency: .workItem, target: nil)
        } else {
            queue = DispatchQueue(label: queueName, qos: .default, attributes: .concurrent, autoreleaseFrequency: .inherit, target: nil)
        }
        let _ = specialStarsApi.loadData()
        let _ = specialTypeApi.loadData()
        queue.async(group: nil, qos: .default, flags: .barrier) {
            DLog("栅栏间隔 -------------------")
        }
        let _ = specialVideoLsApi.loadData()
    }
    
}

// MARK: - 处理tableView列表 Modules

extension SpecialTopicViewModel {
    
    /// g获取多少个区
    func sectionCount() -> Int {
        return sectionItems.count
    }
    /// 获取每个区显示多少数据
    func getRowCountWith(section: Int) -> Int {
        let sectionType = getSectionType(section: section)
        if sectionType == .topicActor {
            return 1
        }
        if sectionType == .topicType {
            if let filmList = topicTypeListModel?.film, filmList.count >= 8 {
                return 8
            }
            return topicTypeListModel?.film?.count ?? 0
        }
        if sectionType == .topicVideo {
            return topicVideoListModel?.data?.count ?? 0
        }
        return 0
    }
    /// 获取该区显示得是哪种类型的数据，从而选择使用哪种cell， 哪种布局方式
    func getSectionType(section: Int) -> SectionType {
        if sectionItems.count > section {
            if sectionItems[section] is VideoListModel {
                return .topicVideo
            }
            if sectionItems[section] is TopicTypeListModel {
                return .topicType
            }
            if sectionItems[section] is TopicStarListModel {
                return .topicActor
            }
            if sectionItems[section] is [AdvertisingModel] {
                return .advertisement
            }
        }
        return sectionType
    }
    
    /// 获取区头高度
    func getSectionHeaderSize(sectionType: SectionType) -> CGSize? {
        if sectionType == .advertisement {
            return .zero
        }
        if sectionType == .topicVideo {
            if let videoList = topicVideoListModel?.data, videoList.count > 0 {
                return CGSize(width: ConstValue.kScreenWdith, height: 50)
            }
        } else if sectionType == .topicActor {
            if let starList = topicStarListModel?.data, starList.count > 0 {
                return CGSize(width: ConstValue.kScreenWdith, height: 50)
            }
        } else if sectionType == .topicType {
            if let typeList = topicTypeListModel?.film, typeList.count > 0 {
                return CGSize(width: ConstValue.kScreenWdith, height: 50)
            }
        } else if sectionType == .advertisement {
            return .zero
        }
        return .zero
    }
    
    /// 获取Item大小
    func getItemSize(sectionType: SectionType) -> CGSize? {
        if sectionType == .topicVideo {
            return SpecialTopicViewModel.videoItemSize
        } else if sectionType == .topicActor {
            return SpecialTopicViewModel.cardItemSize
        } else if sectionType == .topicType {
            return SpecialTopicViewModel.hotTpItemSize
        } else if sectionType == .advertisement {
            return SpecialTopicViewModel.advertisingItemSize
        }
        return CGSize.zero
    }
    
    /// 获取区头名
    func getSectionTitle(sectionType: SectionType) -> String {
        if sectionType == .topicActor {
            return UIViewController.localStr("kStarCardTitle")
        } else if sectionType == .topicType {
            return UIViewController.localStr("kHotSpecialTopicTitle")
        } else if sectionType == .topicVideo {
            return UIViewController.localStr("kSpecialTopicRecomment")
        }
        return ""
    }
    func getSectionIcon(sectionType: SectionType) -> UIImage? {
        if sectionType == .topicActor {
            return nil
        } else if sectionType == .topicType {
            return UIImage(named: "topicHot")
        } else if sectionType == .topicVideo {
            return UIImage(named: "topicVideo")
        }
        return nil
    }
    
}

// MARK: - 处理Star的数据展示
extension SpecialTopicViewModel {
    
    private func requestTopicStarSuccess(_ model: TopicStarListModel) {
        topicStarListModel = model
        if let list = model.data, list.count > 0 {
            sectionItems.insert(model as AnyObject, at: 0)
            loadTopicStarListDataSuccessHandler?()
        } else {
            loadTopicStarListDataFailHandler?(true)
        }
    }
    
    func getStarList() -> [TopicStarModel] {
        if let starList = topicStarListModel?.data, starList.count > 0 {
            return starList
        }
        return [TopicStarModel]()
    }
    
    func getStarModel(_ index: Int) -> TopicStarModel {
        if let starList = topicStarListModel?.data, starList.count > 0 {
            return starList[index]
        }
        return TopicStarModel()
    }
  
}

// MARK: - 处理Type的数据展示
extension SpecialTopicViewModel {
    
    private func requestTypeListDataSuccess(_ model: TopicTypeListModel) {
        topicTypeListModel = model
        if let list = model.film, list.count > 0 {
            sectionItems.append(model as AnyObject)
            loadTopicTypeListDataSuccessHandler?()
        } else {
            loadTopicTypeListDataFailHandler?(true)
        }
    }
    
    func getTypeList() -> [TopicTypeModel] {
        if let typeList = topicTypeListModel?.film, typeList.count > 0 {
            return typeList
        }
        return [TopicTypeModel]()
    }
    func getTypeModel(_ index: Int) -> TopicTypeModel {
        if let typeList = topicTypeListModel?.film, typeList.count > 0 {
            return typeList[index]
        }
        return TopicTypeModel()
    }
}

// MARK: - 处理Video的数据展示
extension SpecialTopicViewModel {
    
    private func requestVideoListDataSuccess(_ model: VideoListModel) {
        topicVideoListModel = model
        if let list = model.data, list.count > 0 {
            isRefreshOperation = true
            sectionItems.append(model as AnyObject)
            loadTopicVideoListDataSuccessHandler?()
        } else {
            loadTopicVideoListDataFailHandler?(true)
        }
    }
    func getVideoList() -> [VideoModel] {
        if let videoList = topicVideoListModel?.data, videoList.count > 0 {
            return videoList
        }
        return [VideoModel]()
    }
    func getVideoModel(_ index: Int) -> VideoModel {
        if let videoList = topicVideoListModel?.data, videoList.count > 0 {
            return videoList[index]
        }
        return VideoModel()
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension SpecialTopicViewModel: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        var params = [String: Any]()
        if manager is VideoListApi {
            params[VideoListApi.kExponent_bd] = VideoListApi.kDefaultExponent_bd
            params[VideoListApi.kCreated_at]  = VideoListApi.kDefaultCreat_at
            return params
        }
        return nil
    }

    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        if manager is SpecialActorListApi {
            if let topicListModel = manager.fetchJSONData(SpecialTopicReformer()) as? TopicStarListModel {
                requestTopicStarSuccess(topicListModel)
            }
        }
        if manager is SpecialTypeListApi {
            if let topicTypeModel = manager.fetchJSONData(SpecialTopicReformer()) as? TopicTypeListModel {
                requestTypeListDataSuccess(topicTypeModel)
            }
        }
        if manager is VideoListApi {
            if let topicVideoModel = manager.fetchJSONData(VideoReformer()) as? VideoListModel {
                requestVideoListDataSuccess(topicVideoModel)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        if manager is SpecialActorListApi {
            loadTopicStarListDataFailHandler?(false)
        }
        if manager is SpecialTypeListApi {
            loadTopicTypeListDataFailHandler?(false)
        }
        if manager is VideoListApi {
            loadTopicVideoListDataFailHandler?(false)
        }
    }
}

//
//  SpecialTopicMoreController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/10.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import LTScrollView
import NicooNetwork

class SpecialTopicMoreController: UIViewController {

    private let glt_iphoneX = (UIScreen.main.bounds.height >= 812.0)
    private lazy var titles: [String] = {
        return [localStr("kRecomment"), localStr("kFilm"), localStr("kTVSerial"), localStr("kCatoon"), localStr("kVarietyShow")]
    }()
    private lazy var viewControllers: [UIViewController] = {
        var vcs = [UIViewController]()
        
        for i in 0..<self.titles.count {
            if let globalTypeModel = globalTypeList?[i] {
                let oneVc = SpecialTpMoreChildController()
                oneVc.globalType = globalTypeModel.key
                vcs.append(oneVc)
            }
        }
        return vcs
    }()
    private lazy var layout: LTLayout = {
        let layout = LTLayout()
        layout.titleViewBgColor = UIColor.white
        layout.titleColor = UIColor(r: 0.1, g: 0.1, b: 0.1)
        layout.titleSelectColor = ConstValue.kAppDefaultTitleColor
        layout.bottomLineColor = ConstValue.kAppDefaultTitleColor
        layout.showsHorizontalScrollIndicator = false
        layout.sliderHeight = 50
        layout.titleFont = UIFont.boldSystemFont(ofSize: 16)
        layout.isShowBounces = true
        layout.lrMargin = 20
        layout.titleMargin = 35
        return layout
    }()
    /// 顶部栏目切换控件
    private lazy var pageView: LTPageView = {
        let tabBarH = self.tabBarController?.tabBar.bounds.height ?? 0.0
        let H: CGFloat = glt_iphoneX ? view.bounds.height - 34: view.bounds.height
        let pageView = LTPageView(frame: CGRect(x: 0, y: 0, width: view.bounds.width , height: H), currentViewController: self, viewControllers: viewControllers, titles: titles, layout: layout)
        // pageView.backgroundColor = UIColor.clear
        pageView.isClickScrollAnimation = true
        return pageView
    }()
    /// 最大分类请求
    private lazy var globalTypeAPI: GlobalTypeApi = {
        let api = GlobalTypeApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private var globalTypeList: [GlobalType]?
    var topIndex: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        title = localStr("kMostHotTopicRecommentTitle")
        loadGlobalData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    func loadGlobalData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        let _ = globalTypeAPI.loadData()
    }
}

// MARK: - Private - Funcs
private extension SpecialTopicMoreController {
    
    /// 请求成功
    func loadGlobalDataSuccess(_ typeList: [GlobalType]?) {
        NicooErrorView.removeErrorMeesageFrom(view)
        if typeList != nil && typeList!.count > 0 {
            globalTypeList = typeList
            var allTitles = [String]()
            for i in 0..<typeList!.count {
                let model = typeList![i]
                allTitles.append(model.name ?? "")
            }
            titles = allTitles
            view.addSubview(pageView)
            //layoutPageSubviews()
            addTitlePageViewCallBack()
        }
    }
    
    /// 请求失败
    func requestFail(error: String?, manager: NicooBaseAPIManager?) {
        NicooErrorView.showErrorMessage(.noNetwork, on: view) { [weak self] in
            self?.loadGlobalData()
        }
    }
    
    func addTitlePageViewCallBack() {
        pageView.didSelectIndexBlock = { [weak self] (_, index) in
            DLog("pageView.didSelectIndexBlock ")
            self?.topIndex = index
            if let globleTypeModel = self?.globalTypeList?[index] {
            }
        }
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension SpecialTopicMoreController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        if manager is GlobalTypeApi {
            if let list = manager.fetchJSONData(GlobalTypeReformer()) as? [GlobalType] {
                loadGlobalDataSuccess(list)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        if manager is GlobalTypeApi {
            requestFail(error: "", manager: manager)
        }
    }
    
}

// MARK: - Layout
private extension SpecialTopicMoreController {
    
    func layoutPageSubviews () {
       
    }

}

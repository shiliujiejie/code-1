//
//  SpecialTopicMainController.swift
//  XSVideo
//
//  Created by pro5 on 2019/2/13.
//  Copyright © 2019年 pro5. All rights reserved.
//

import UIKit
import MJRefresh
import NicooNetwork

class SpecialTopicMainController: UIViewController {

    private lazy var tableView: UITableView = {
        let table = UITableView(frame: view.bounds, style: .plain)
        table.backgroundColor = UIColor.clear
        table.rowHeight = (ConstValue.kScreenWdith - 20 ) * 9/16
        table.showsVerticalScrollIndicator = false
        table.showsHorizontalScrollIndicator = false
        table.delegate = self
        table.dataSource = self
        table.separatorStyle = .none
        table.tableFooterView = UIView.init(frame: CGRect.zero)
        table.mj_header = refreshView
        table.mj_footer = loadMoreView
        table.register(SpecialTopicMainListCell.classForCoder(), forCellReuseIdentifier: SpecialTopicMainListCell.cellId)
        return table
    }()
   
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        return MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
    }()
    private lazy var refreshView: MJRefreshGifHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshGifHeader(refreshingBlock: {
            weakSelf?.isRefreshOperation = true
            weakSelf?.loadData()
        })
        var gifImages = [UIImage]()
        for string in ConstValue.refreshImageNames {
            gifImages.append(UIImage(named: string)!)
        }
        mjRefreshHeader?.setImages(gifImages, for: .refreshing)
        mjRefreshHeader?.setImages(gifImages, for: .idle)
        return mjRefreshHeader!
    }()
    private lazy var specialVideoApi: SpecialVideoListApi = {
        let api = SpecialVideoListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    
    private var isRefreshOperation = false
    var videoListModel: TopicVideoListModel?
    var videoModels = [TopicVideosModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = localStr("kSpecialTopic")
        view.backgroundColor = UIColor.white
        view.addSubview(tableView)
        layoutPageSubviews()
        loadMoreView.isHidden = true
        loadData()
    }
    
   
   
    private func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        if !isRefreshOperation {
            XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        } else {
            isRefreshOperation = false
        }
        let _ = specialVideoApi.loadData()
    }
    
    private func loadNextPage() {
        let _ = specialVideoApi.loadNextPage()
    }
    
    private func loadListDataSuccess(_ listModel: TopicVideoListModel) {
        NicooErrorView.removeErrorMeesageFrom(view)
        tableView.mj_footer?.endRefreshing()
        tableView.mj_header?.endRefreshing()
        loadMoreView.isHidden = true
        videoListModel = listModel
        if let list = listModel.data,let pageNumber = listModel.current_page {
            if pageNumber == 1 {
                guard list.count > 0 else {
                    NicooErrorView.showErrorMessage(.noData, on: view, clickHandler: nil)
                    return
                }
                videoModels = list
                if list.count >= VideoListApi.kDefaultCount { // 表示可能还有数据
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
                isRefreshOperation = true
            } else {
                videoModels.append(contentsOf: list)
                if list.count >= VideoListApi.kDefaultCount { // 表示可能还有数据
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
            }
            tableView.reloadData()
        }
    }
    
    private func loadListDataFail() {
        tableView.mj_footer.endRefreshing()
        tableView.mj_header.endRefreshing()
        tableView.mj_footer.isHidden = true
        // 头部刷新或者第一次进入
        if !isRefreshOperation {
            NicooErrorView.showErrorMessage(.noNetwork, on: view, topMargin: 0) { [weak self] in
                self?.loadData()
            }
        }
    }

}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension SpecialTopicMainController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return videoModels.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: SpecialTopicMainListCell.cellId, for: indexPath) as!  SpecialTopicMainListCell
        let model = videoModels[indexPath.row]
        cell.topicImageView.kfSetHorizontalImageWithUrl(model.cover_img)
        cell.desLable.text = model.title
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let model = videoModels[indexPath.row]
        let detailVC = SpecialTopicDetailController()
        detailVC.special_id = model.id
        detailVC.videosModel = model
        var height: CGFloat = 0
        if let intro = model.intro {
            height = intro.getLableHeight(font: UIFont.systemFont(ofSize: 14), width: ConstValue.kScreenWdith - 40)
        }
        detailVC.headerInfoHeight = height
        navigationController?.pushViewController(detailVC, animated: true)
    }
   
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension SpecialTopicMainController: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if let list = manager.fetchJSONData(SpecialTopicReformer()) as? TopicVideoListModel {
            loadListDataSuccess(list)
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        loadListDataFail()
    }
    
}

// MARK: - Layout
private extension SpecialTopicMainController {
    
    func layoutPageSubviews() {
        layoutTableView()
    }
    
    func layoutTableView() {
        let bottomMargin = 0
        tableView.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(bottomMargin)
            } else {
                make.bottom.equalTo(bottomMargin)
            }
        }
    }
}

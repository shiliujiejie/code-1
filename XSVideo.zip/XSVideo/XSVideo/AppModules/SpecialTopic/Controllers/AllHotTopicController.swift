//
//  AllHotTopicController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/10.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import MJRefresh
import NicooNetwork

/// 更多热门专题选择vc
class AllHotTopicController: UIViewController {

    static let footerViewId = "footViewId"
    
    private let layout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = SpecialTopicViewModel.hotTpItemSize
        layout.minimumLineSpacing = 5   // 垂直最小间距
        layout.minimumInteritemSpacing = 5.0 // 水平最小间距
        layout.sectionInset = UIEdgeInsets(top: 10, left: 0, bottom: 10, right: 0)
        return layout
    }()
    private lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.backgroundColor = UIColor.white
        collection.showsVerticalScrollIndicator = false
        collection.register(HotTopicCell.classForCoder(), forCellWithReuseIdentifier: HotTopicCell.hotTopicCellId)
       // collection.register(UINib(nibName: "AdvertisingCollectionCell", bundle: Bundle.main), forCellWithReuseIdentifier: AdvertisingCollectionCell.advertisingCellId)
        collection.register(DefautReusableView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: DefautReusableView.identifier)
        collection.register(UICollectionReusableView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: AllHotTopicController.footerViewId)
        return collection
    }()
    private lazy var specialTypeApi: SpecialTypeListApi = {
        let api = SpecialTypeListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    
    private var typeModel: TopicTypeListModel?
    
    private var itemContainer = [[TopicTypeModel]]()
    private var itemTitles = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        title = localStr("kAllHotTopicTitle")
        view.addSubview(collectionView)
        layoutPageSubviews()
        loadData()
    }

    func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        let _ = specialTypeApi.loadData()
    }
    
}

// MARK: - Private - Funcs
private extension AllHotTopicController {
    
    func loadDataSuccess(_ model: TopicTypeListModel) {
        typeModel = model
        if let filmList = model.film, filmList.count > 0 {
            itemTitles.append(localStr("kFilm"))
            itemContainer.append(filmList)
        }
        if let tvShowList = model.teleplay, tvShowList.count > 0 {
            itemTitles.append(localStr("kTVSerial"))
            itemContainer.append(tvShowList)
        }
        if let catoonList = model.cartoon, catoonList.count > 0 {
            itemTitles.append(localStr("kCatoon"))
            itemContainer.append(catoonList)
        }
        if let varietyList = model.variety, varietyList.count > 0 {
            itemTitles.append(localStr("kVarietyShow"))
            itemContainer.append(varietyList)
        }
        collectionView.reloadData()
    }
    
    func laodDataFail(_ manager: NicooBaseAPIManager) {
        NicooErrorView.showErrorMessage(.noNetwork, on: view) { [weak self] in
            self?.loadData()
        }
    }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension AllHotTopicController: UICollectionViewDelegate, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return itemContainer.count
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return itemContainer[section].count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cellForRow(with: indexPath)
        return cell
    }
    
    /// 配置cell
    func cellForRow(with indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: HotTopicCell.hotTopicCellId, for: indexPath) as! HotTopicCell
        let model = itemContainer[indexPath.section][indexPath.row]
        cell.topicName.text = model.type_name ?? localStr("kNot")
        cell.topicImage.kfSetHeaderImageWithUrl(model.type_cover_path, placeHolder: ConstValue.kTopicTypeHolder)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
         let model = itemContainer[indexPath.section][indexPath.row]
        let singleCateVC = SingleCategoryController()
        singleCateVC.navTitle = model.type_name ?? ""
        singleCateVC.isSpecialTopic = true
        singleCateVC.parmas = [VideoListApi.kType_id: model.type_id ?? 0, VideoListApi.kGlobal_type: model.global_type ?? ""]
        navigationController?.pushViewController(singleCateVC, animated: true)
    }
}

// MARK: - UICollectionViewDelegateFlowLayout
extension AllHotTopicController: UICollectionViewDelegateFlowLayout {
    
    /// sectionHeader高度
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize.init(width: ConstValue.kScreenWdith, height: 45)
    }
    
    /// sectionFooter 高度
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        return CGSize(width: UIScreen.main.bounds.size.width, height: 1)
    }
    
    /// 区头 && 区脚 - View
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        
        if kind == UICollectionView.elementKindSectionHeader { // header
            let view = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: DefautReusableView.identifier, for: indexPath) as! DefautReusableView
            view.backgroundColor = UIColor.white
            /// 这里的赋值也应该放入ViewModel
            view.titleLable.text = itemTitles[indexPath.section]
            view.titleLable.font = UIFont.boldSystemFont(ofSize: 18)
            view.hideTitleIcon = true
            view.hideMoreButton = true
            
            return view
            
        } else { // footer
            let footer = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: AllHotTopicController.footerViewId, for: indexPath)
            return footer
        }
    }
    
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension AllHotTopicController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is SpecialTypeListApi {
            if let topicTypeModel = manager.fetchJSONData(SpecialTopicReformer()) as? TopicTypeListModel {
                loadDataSuccess(topicTypeModel)
            }
        }
        
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is SpecialTypeListApi {
            laodDataFail(manager)
        }
       
    }
}


// MARK: - Layout
private extension AllHotTopicController {
    
    func layoutPageSubviews() {
        layoutCollectionView()
    }
    
    func layoutCollectionView() {
        collectionView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalTo(0)
            }
        }
    }
}

//
//  SpecialTpMainController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/10.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import MJRefresh

class SpecialTpMainController: UIViewController {

    static let advertisingCellId = "scrollCellId"
    static let footerViewId = "footViewId"
    /// item之间的最小间隙 (这些size应该放入ViewModel)
    static let interitemSpacing: CGFloat = 5
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        let collection = UICollectionView.init(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.backgroundColor = UIColor.white
        collection.showsVerticalScrollIndicator = false
        collection.register(VideoThridItemCell.classForCoder(), forCellWithReuseIdentifier: VideoThridItemCell.cellId)
        collection.register(UINib(nibName: "AdvertisingCollectionCell", bundle: Bundle.main), forCellWithReuseIdentifier: AdvertisingCollectionCell.cellId)
        collection.register(HotTopicCell.classForCoder(), forCellWithReuseIdentifier: HotTopicCell.hotTopicCellId)
        collection.register(SpecialTopicCardCell.classForCoder(), forCellWithReuseIdentifier: SpecialTopicCardCell.cellId)
        collection.register(DefautReusableView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: DefautReusableView.identifier)
        collection.register(UICollectionReusableView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: SpecialTpMainController.footerViewId)
        collection.mj_header = refreshView
        return collection
    }()
    private lazy var refreshView: MJRefreshNormalHeader = {
        weak var weakSelf = self
        return MJRefreshNormalHeader(refreshingBlock: {
            weakSelf?.viewModel.isRefreshOperation = true
            weakSelf?.loadData()
        })
    }()
    
    var viewModel: SpecialTopicViewModel = SpecialTopicViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = localStr("kSpecialTopic")
        view.backgroundColor = UIColor.white
        view.addSubview(collectionView)
        layoutCollectionView()
        addViewModelLoadDataCallBackHandler()
        loadData()
    }
    
}

// MARK: - Private - fUNCS
private extension SpecialTpMainController {
    
    func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        if !viewModel.isRefreshOperation {
           XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        }
        viewModel.loadSpecialTopicData()
    }
    
    func addViewModelLoadDataCallBackHandler() {
        
        viewModel.loadTopicStarListDataSuccessHandler = { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.collectionView.reloadData()
            
        }
        viewModel.loadTopicTypeListDataSuccessHandler = { [weak self] in
            self?.collectionView.reloadData()
        }
        viewModel.loadTopicVideoListDataSuccessHandler = { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.collectionView.mj_header.endRefreshing()
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            strongSelf.collectionView.reloadData()
            
        }
        viewModel.loadTopicVideoListDataFailHandler = { [weak self] (empty) in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            strongSelf.collectionView.mj_header.endRefreshing()
            NicooErrorView.showErrorMessage(.noNetwork, on: strongSelf.view, clickHandler: {
                strongSelf.loadData()
            })
        }
    }
    
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension SpecialTpMainController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return viewModel.sectionCount()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.getRowCountWith(section: section)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cellForRow(with: indexPath)
        return cell
    }
    
    /// 配置cell
    func cellForRow(with indexPath: IndexPath) -> UICollectionViewCell {
        let sectionType = viewModel.getSectionType(section: indexPath.section)
        
        if sectionType == .topicVideo {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: VideoThridItemCell.cellId, for: indexPath) as! VideoThridItemCell
            let model = viewModel.getVideoModel(indexPath.row)
            cell.videoNameLable.text = model.title ?? localStr("kNot")
            if let introl = model.intro, !introl.isEmpty {
                cell.videoIntroLable.text = introl
            } else {
                cell.videoIntroLable.text = localStr("kNotIntrolMsg")
            }
            if model.score != nil &&  !model.score!.isEmpty {
                cell.pointLable.isHidden = false
                cell.pointLable.attributedText = TextSpaceManager.configScoreString(allString: String(format: "%@", model.score!))
            } else {
                cell.pointLable.isHidden = true
            }
            cell.videoImageView.kfSetVerticalImageWithUrl(model.cover_path)
            return cell
        } else if sectionType == .topicActor {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SpecialTopicCardCell.cellId, for: indexPath) as! SpecialTopicCardCell
            cell.setModels(viewModel.getStarList())
            return cell
        } else if sectionType == .topicType {
            let cell =  collectionView.dequeueReusableCell(withReuseIdentifier: HotTopicCell.hotTopicCellId, for: indexPath) as! HotTopicCell
            let model = viewModel.getTypeModel(indexPath.row)
            cell.topicImage.kfSetHeaderImageWithUrl(model.type_cover_path, placeHolder: UIImage(named: "TopicTypeHolder"))
            cell.topicName.text = model.type_name ?? localStr("kNot")
            return cell
        } else if sectionType == .advertisement {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: AdvertisingCollectionCell.cellId, for: indexPath) as! AdvertisingCollectionCell
            cell.advertisingDesLable.text = "阿汤哥全程开挂模式。"
            cell.advertisingImage.image = UIImage(named: "")
            cell.advertisingNameLable.text = "广告"
            return cell
        }
        return UICollectionViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        let sectionType = viewModel.getSectionType(section: indexPath.section)
        if sectionType == .topicVideo {
            let videoModel = viewModel.getVideoModel(indexPath.row)
            let videoDetail = VideoDetailViewController()
            videoDetail.videoId = videoModel.id ?? 0
            navigationController?.pushViewController(videoDetail, animated: true)
        } else if sectionType == .topicActor {
    
        } else if sectionType == .topicType {
            let typeModel = viewModel.getTypeModel(indexPath.row)
            let singleCateVC = SingleCategoryController()
            singleCateVC.isSpecialTopic = true
            singleCateVC.navTitle = typeModel.type_name ?? ""
            singleCateVC.parmas = [VideoListApi.kType_id: typeModel.type_id ?? 0, VideoListApi.kGlobal_type: typeModel.global_type ?? ""]
            navigationController?.pushViewController(singleCateVC, animated: true)   
        }
    }
    
}

// MARK: - UICollectionViewDelegateFlowLayout

extension SpecialTpMainController: UICollectionViewDelegateFlowLayout {
    
    /// 所有的布局都要根据 ViewModel 获取到的数据来决定
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let sectionType = viewModel.getSectionType(section: indexPath.section)
        if let itemSize = viewModel.getItemSize(sectionType: sectionType) {
            return itemSize
        }
        return CGSize.zero
    }
    
    /// 边距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        let sectionType = viewModel.getSectionType(section: section)
        if sectionType == .topicVideo {
            return UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 5)
        }
        return UIEdgeInsets.zero
    }
    
    /// 垂直最小间距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        let sectionType = viewModel.getSectionType(section: section)
        if sectionType == .topicVideo  {
            return 15
        } else if sectionType == .topicActor || sectionType == .topicType {
            return 5
        }
        return 0
    }
    
    /// 水平最小间距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        // 当然这里也是可以根据数据类型来判断
        return VideoTypePageController.interitemSpacing
    }
    
    /// sectionHeader高度
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        let sectionType = viewModel.getSectionType(section: section)
        guard let size = viewModel.getSectionHeaderSize(sectionType: sectionType) else { return .zero }
        return size
    }
    
    /// sectionFooter 高度
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        return CGSize(width: UIScreen.main.bounds.size.width, height: 10)
    }
    
    /// 区头 && 区脚 - View
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let sectionType = viewModel.getSectionType(section: indexPath.section)
        if kind == UICollectionView.elementKindSectionHeader { // header
            let view = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: DefautReusableView.identifier, for: indexPath) as! DefautReusableView
            view.backgroundColor = UIColor.white
            /// 这里的赋值也应该放入ViewModel
            view.titleLable.text = viewModel.getSectionTitle(sectionType: sectionType)
            view.titleImage.image = viewModel.getSectionIcon(sectionType: sectionType)
            view.titleLable.font = UIFont.boldSystemFont(ofSize: 18)
            if sectionType == .topicActor {
                view.hideTitleIcon = true
            }
            view.moreButton.isHidden = sectionType == .topicActor
            view.moreClickHandler = { [weak self] in
                if sectionType == .topicType {
                    let alltopicVC = AllHotTopicController()
                    self?.navigationController?.pushViewController(alltopicVC, animated: true)
                }
                if sectionType == .topicVideo {
                    let moreTopicVc = SpecialTopicMoreController()
                    self?.navigationController?.pushViewController(moreTopicVc, animated: true)
                }
            }
            return view
        } else { // footer
            let footer = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: VideoTypePageController.footerViewId, for: indexPath)
            return footer
        }
    }
    
    
}

// MARK: - Layout
private extension SpecialTpMainController {
    
    func layoutCollectionView() {
        collectionView.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.edges.equalTo(view.safeAreaLayoutGuide.snp.edges)
            } else {
                make.edges.equalToSuperview()
            }
        }
    }
}


//
//  SpecialTopicDetailController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/6.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import NicooNetwork
import MJRefresh

class SpecialTopicDetailController: UIViewController {

    static let footerViewId = "footViewId"

    private lazy var fakeNavBar: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.clear
        return view
    }()
    private lazy var backButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "navBackWhite"), for: .normal)
        button.addTarget(self, action: #selector(backButtonClick), for: .touchUpInside)
        return button
    }()
    var navLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.white
        lable.textAlignment = .center
        lable.font = UIFont.boldSystemFont(ofSize: 18)
        return lable
    }()
    private lazy var lineView: UIView = {
        let line = UIView()
        line.backgroundColor = UIColor.clear
        return line
    }()
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        let collection = UICollectionView.init(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.backgroundColor = UIColor.white
        collection.showsVerticalScrollIndicator = false
        collection.register(VideoThridItemCell.classForCoder(), forCellWithReuseIdentifier: VideoThridItemCell.cellId)
        collection.register(SpecialTopicHeaderCell.classForCoder(), forCellWithReuseIdentifier: SpecialTopicHeaderCell.cellId)
        collection.register(DefautReusableView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: DefautReusableView.identifier)
        collection.register(UICollectionReusableView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: VideoTypePageController.footerViewId)
        collection.mj_footer = loadMoreView
        return collection
    }()
    
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        return MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
    }()
    private lazy var videoListApi: SpecialVideoInfoApi = {
        let api = SpecialVideoInfoApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    var isRefreshOperation = false
    var special_id: Int?
    var headerInfoHeight: CGFloat = 0.0
    var videosModel: TopicVideosModel?
    var videoList = [VideoModel]()
    var videoCount: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        addPageSubviews()
        loadMoreView.isHidden = true
        loadActorVideoList()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: isNavAnimated ? animated : false)
        isNavAnimated = false
    }
    
    func addPageSubviews() {
        view.addSubview(collectionView)
        view.addSubview(fakeNavBar)
        fakeNavBar.addSubview(backButton)
        fakeNavBar.addSubview(navLable)
        fakeNavBar.addSubview(lineView)
        navLable.text = self.videosModel?.title ?? ""
        layoutPageSubviews()
    }
    
    @objc private func backButtonClick() {
        navigationController?.popViewController(animated: true)
    }
   
    func loadActorVideoList() {
        NicooErrorView.removeErrorMeesageFrom(view)
        XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        let _ = videoListApi.loadData()
    }
    
    func loadNextPage() {
        let _ = videoListApi.loadNextPage()
    }
    
    func requestVideoListSuccess(_ videoListModel: VideoListModel) {
        collectionView.mj_footer.endRefreshing()
        XSProgressHUD.hide(for: view, animated: false)
        if let videos = videoListModel.data, let pageNumber = videoListModel.current_page {
            if pageNumber == 1 {
                videoList = videos
                if videos.count >= VideoListApi.kDefaultCount {
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
            } else {
                videoList.append(contentsOf: videos)
                if videos.count >= VideoListApi.kDefaultCount {
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
            }
            isRefreshOperation = true
            collectionView.reloadData()
        } else {
            NicooErrorView.showErrorMessage(.noNetwork, on: view, topMargin: 301 + headerInfoHeight) { [weak self] in
                self?.loadActorVideoList()
            }
        }
    }
    
    func requestLisDataFail(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        collectionView.mj_footer.endRefreshing()
        if !isRefreshOperation  {
            NicooErrorView.showErrorMessage(.noNetwork, on: view, topMargin: 301 + headerInfoHeight) { [weak self] in
                self?.loadActorVideoList()
            }
        } 
    }
    

}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource

extension SpecialTopicDetailController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return section == 0 ? 1 : videoList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cellForRow(with: indexPath)
        return cell
    }
    
    /// 配置cell
    func cellForRow(with indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.section == 0 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SpecialTopicHeaderCell.cellId, for: indexPath) as! SpecialTopicHeaderCell
            cell.imageBg.kfSetHorizontalImageWithUrl(videosModel?.intro_img)
            cell.infoLable.attributedText = TextSpaceManager.getAttributeStringWithString(videosModel?.intro ?? "", lineSpace: 7)
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: VideoThridItemCell.cellId, for: indexPath) as! VideoThridItemCell
            let videoModel = videoList[indexPath.row]
            cell.videoNameLable.text = videoModel.title ?? ""
            if let introl = videoModel.intro, !introl.isEmpty {
                cell.videoIntroLable.text = introl
            } else {
                cell.videoIntroLable.text = localStr("kNotIntrolMsg")
            }
            if videoModel.score != nil && !videoModel.score!.isEmpty {
                cell.pointLable.isHidden = false
                cell.pointLable.attributedText = TextSpaceManager.configScoreString(allString: String(format: "%@", videoModel.score!))
            } else {
                cell.pointLable.isHidden = true
            }
            cell.videoImageView.kfSetVerticalImageWithUrl(videoModel.cover_path)
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        if indexPath.section != 0 {
            let videoModel = videoList[indexPath.row]
            let videoDetail = VideoDetailViewController()
            videoDetail.videoId = videoModel.id ?? 0
            navigationController?.pushViewController(videoDetail, animated: true)
        }
    }
    
}

// MARK: - UICollectionViewDelegateFlowLayout

extension SpecialTopicDetailController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if indexPath.section == 0 {
            let height = 285 + headerInfoHeight/17 * 7 + headerInfoHeight
            return CGSize(width: ConstValue.kScreenWdith, height: height > 360 ? height : 360)
        } else {
            let bookItemWidth: CGFloat = (UIScreen.main.bounds.size.width - 20)/3
            let bookItemHieght: CGFloat = bookItemWidth * 1.4 + 55
            return CGSize(width: bookItemWidth, height: bookItemHieght)
        }
    }
    
    /// 边距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        if section == 0 {
            return UIEdgeInsets.zero
        }
        return UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 5)
    }
    
    /// 垂直最小间距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }
    
    /// 水平最小间距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        // 当然这里也是可以根据数据类型来判断
        return 5
    }
    
    /// sectionHeader高度
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        if section == 0 {
            return CGSize.zero
        }
        return CGSize(width: ConstValue.kScreenWdith, height: 40)
    }
    
    /// sectionFooter 高度
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        return CGSize.zero
    }
    
    /// 区头 && 区脚 - View
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if kind == UICollectionView.elementKindSectionHeader { // header
            if indexPath.section == 0 {
                let footer = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: VideoTypePageController.footerViewId, for: indexPath)
                return footer
            } else {
                let view = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: DefautReusableView.identifier, for: indexPath) as! DefautReusableView
                view.backgroundColor = UIColor.groupTableViewBackground
                /// 这里的赋值也应该放入ViewModel
                view.titleLable.text = localStr("kSpecialTopicDetailTitle")
                view.hideMoreButton = true
                view.titleImage.image = UIImage(named: "sectionIconRout")
                return view
            }
        } else { // footer
            let footer = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: VideoTypePageController.footerViewId, for: indexPath)
            return footer
        }
    }
    
}

// MARK: - UIScrollViewDelegate
extension SpecialTopicDetailController: UIScrollViewDelegate {
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        if scrollView.contentOffset.y > 130 {
            fakeNavBar.backgroundColor = UIColor.white
            navLable.textColor = UIColor.darkText
            backButton.setImage(UIImage(named: "navBackDefault"), for: .normal)
            lineView.backgroundColor = UIColor(white: 0.1, alpha: 0.2)
        } else {
            fakeNavBar.backgroundColor = UIColor.clear
            lineView.backgroundColor = UIColor.clear
            backButton.setImage(UIImage(named: "navBackWhite"), for: .normal)
            navLable.textColor = UIColor.white
        }
    }
    
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension SpecialTopicDetailController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        var params = [String: Any]()
        if manager is SpecialVideoInfoApi {
            params[SpecialVideoInfoApi.kSpecial_id] = self.special_id
            return params
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is SpecialVideoInfoApi {
            if let videoList = manager.fetchJSONData(SpecialTopicReformer()) as? VideoListModel {
                requestVideoListSuccess(videoList)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is SpecialVideoInfoApi {
            requestLisDataFail(manager)
        }
    }
}

// MARK: - Layout
private extension SpecialTopicDetailController {
    
    func layoutPageSubviews() {
        layoutCollectionView()
        layoutFakeNavBarView()
        layoutBackButton()
        layoutNavLable()
        layoutLineView()
    }
    
    func layoutCollectionView() {
        collectionView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalToSuperview().offset(-ConstValue.kStatusBarHeight)
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalTo(0)
            }
        }
    }
    
    func layoutFakeNavBarView() {
        fakeNavBar.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(ConstValue.kNavigationBarHeight + ConstValue.kStatusBarHeight)
        }
    }
    
    func layoutBackButton() {
        backButton.snp.makeConstraints { (make) in
            make.top.equalTo(ConstValue.kStatusBarHeight + 5)
            make.leading.equalTo(15)
            make.width.equalTo(30)
            make.height.equalTo(30)
        }
    }
    
    func layoutLineView() {
        lineView.snp.makeConstraints { (make) in
            make.leading.trailing.bottom.equalToSuperview()
            make.height.equalTo(0.25)
        }
    }
    
    func layoutNavLable() {
        navLable.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(ConstValue.kStatusBarHeight + 10)
            make.height.equalTo(24)
        }
    }
    
}

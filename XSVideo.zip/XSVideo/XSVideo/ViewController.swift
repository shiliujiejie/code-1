//
//  ViewController.swift
//  XSVideo
//
//  Created by pro5 on 2018/11/26.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 这里留着做一个过渡的LaunchScreen
class ViewController: UIViewController {

    private let fakeScreenImage: UIImageView = {
        let sImage = UIImageView(image: UIImage(named: "launchScreen"))
        sImage.contentMode = .scaleAspectFit
        return sImage
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(fakeScreenImage)
        fakeScreenImage.frame = self.view.bounds
    }


}


//
//  LoginManager.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/21.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 登录拦截器
class LoginManager: NSObject {
    
    private let viewModel = RegisterLoginViewModel()
    private let userInfo = UserInfoViewModel()
    
    /// 登录
    ///
    /// - Parameter successHandler: 成功回调
    func login(_ successHandler:(() -> Void)?) {
        let loginVC = LoginController()
        loginVC.loginSuccessCallBack = successHandler
        let loginNav = UINavigationController(rootViewController: loginVC)
        UIViewController.currentViewController()?.present(loginNav, animated: true, completion: nil)
    }
    
    /// 退出登录
    func logout(_ successhandler:(() -> Void)?) {
        UserModel.share().isLogin = false
        UserModel.share().isRealUser = false
        UserModel.share().api_token = nil
        UserModel.share().coins = nil
        UserModel.share().id = nil
        UserModel.share().mobile = nil
        UserModel.share().cover_path = nil
        UserModel.share().name = nil
        UserModel.share().email = nil
        UserModel.share().empirical = nil
        UserModel.share().created_at = nil
        UserModel.share().lv_title = nil
        UserModel.share().updated_at = nil
        UserModel.share().view_count_daily_total = nil
        UserModel.share().view_count_daily_use = nil
        UserModel.share().view_count = nil
        UserModel.share().invite_code = nil
        UserModel.share().remain_count = nil
        UserDefaults.standard.removeObject(forKey: UserDefaults.kUserToken)
    }
    
    /// 自动登录成功回调
    private func loginCallBackHandler() {
        viewModel.loadLoginApiSuccess = { [weak self] in
            self?.loadUserInfoData()
        }
    }
    
    /// 请求用户信息
    private func loadUserInfoData() {
        userInfo.loadUserInfo()
    }
}

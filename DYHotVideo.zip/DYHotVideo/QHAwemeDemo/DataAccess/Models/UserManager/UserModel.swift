//
//  UserModel.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/14.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 用户单利
class UserModel: Codable {
    
    static private let shareModel: UserModel = UserModel()
    class func share() -> UserModel {
        return shareModel
    }
    var id: Int?
    var type: Int?
    var name: String?
    var mobile: String?
    var email: String?
    var sex: Int? // 1：男 2 ：女
    var status: Int?
    var api_token: String?
    var created_at: String?
    var updated_at: String?
    var cover_path: String?
    var empirical: Int?
    var coins: Int?
    var lv_title: String?
    var view_count_daily_total: Int? //
    var view_count_daily_use: Int?
    var view_count: Int?
    var remain_count: Int?
    var invite_code: String?
    
    /// 是否已登录
    var isLogin: Bool = false
    /// 观影时间记录
    var startTime: String?
    /// 观看时长
    var watchedTime: Int = 0
    /// 是否是真实注册用户
    var isRealUser: Bool = false
   
}

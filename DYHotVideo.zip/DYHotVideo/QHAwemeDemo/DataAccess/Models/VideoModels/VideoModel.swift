
//

import Foundation

/// 视频列表model
struct VideoListModel: Codable {
    var current_page: Int?
    var data: [VideoModel]?
}

/// 视频Model
struct VideoModel: Codable {
    
    var id: Int?
    var title: String?
    var intro: String?
    var cover_path: String?
    var cover_path_oss: String?
    var play_count: Int?
    var play_url_m3u8: String?

    
    var recommend: Recommend?     // 是否点过❤️
    var appraise_count: Int?      // 点赞数
    var comment_count: Int?       // 评论数
    var view_flag: Bool? = false  // 当前用户是否可以播放 本视频
    var key: [VideoKey]?          // 视频标签
    
    
}

/// 视频key
struct VideoKey: Codable {
    var id: Int?
    var video_id: Int?
    var key_id: Int?
    var created_at: String?
    var key_label: String?
}

/// 是否点👍
enum Recommend: Int, Codable {
    case notRecommend = 0
    case recommend = 1
    
    var isFavor: Bool {
        switch self {
        case .recommend:
            return true
        case .notRecommend:
            return false
        }
    }
}

/// 视频大分类列表MOdel
struct VideoCategoryModel: Codable {
    var id: Int?
    var title: String?
}



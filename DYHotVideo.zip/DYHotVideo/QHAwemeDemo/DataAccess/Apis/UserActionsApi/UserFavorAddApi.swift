//
//  UserFavorAddApi.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/5.
//  Copyright © 2019年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork


/// 用户添加收藏
class UserFavorAddApi: XSVideoBaseAPI {
    
    static let kGlobal_type = "global_type"
    static let kVideo_id = "video_id"
    
    static let kUrlValue = "/api/video/user/collect/add"
    static let kMethodValue = "POST"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/video/user/collect/add"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func requestType() -> NicooAPIManagerRequestType {
        return ConstValue.kIsEncryptoApi ? super.requestType() : .post
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [UserFavorAddApi.kUrl: UserFavorAddApi.kUrlValue,
                                        UserFavorAddApi.kMethod: UserFavorAddApi.kMethodValue]
        allParams[UserFavorAddApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
    
}

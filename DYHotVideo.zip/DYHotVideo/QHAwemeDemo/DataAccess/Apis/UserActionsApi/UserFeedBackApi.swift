//
//  UserFeedBackApi.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/5.
//  Copyright © 2019年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// 用户反馈Api
class UserFadeBackApi: XSVideoBaseAPI {
    
    /// 反馈内容
    static let kContent = "title"
    /// 联系方式
    static let kContact = "contact"
    
    static let kUrlValue = "/api/feedback"
    static let kMethodValue = "POST"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/feedback"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func requestType() -> NicooAPIManagerRequestType {
        return ConstValue.kIsEncryptoApi ? super.requestType() : .post
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [UserFadeBackApi.kUrl: UserFadeBackApi.kUrlValue,
                                        UserFadeBackApi.kMethod: UserFadeBackApi.kMethodValue]
        allParams[UserFadeBackApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
    
}

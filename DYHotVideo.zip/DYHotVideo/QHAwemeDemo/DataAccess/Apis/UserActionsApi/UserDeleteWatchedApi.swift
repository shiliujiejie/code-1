//
//  UserDeleteWatchedApi.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/5.
//  Copyright © 2019年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork


/// 用户删除观看历史记录
class UserDeleteWatchedApi: XSVideoBaseAPI {
    
    static let kVideo_ids = "video_id"
    
    static let kUrlValue = "/api/video/user/history/cancel"
    static let kMethodValue = "POST"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/video/user/history/cancel"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func requestType() -> NicooAPIManagerRequestType {
        return ConstValue.kIsEncryptoApi ? super.requestType() : .post
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [UserDeleteWatchedApi.kUrl: UserDeleteWatchedApi.kUrlValue,
                                        UserDeleteWatchedApi.kMethod: UserDeleteWatchedApi.kMethodValue]
        allParams[UserDeleteWatchedApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
    
}

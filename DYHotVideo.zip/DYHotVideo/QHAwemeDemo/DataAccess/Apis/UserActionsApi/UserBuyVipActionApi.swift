//
//  UserThumAddApi.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/5.
//  Copyright © 2019年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// 用户 点击购买调用
class UserBuyVipActionApi: XSVideoBaseAPI {

    static let kVip_id = "vip_id"
    
    static let kUrlValue = "/\(ConstValue.kApiVersion)/user/vip"
    static let kMethodValue = "GET"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "\(ConstValue.kApiVersion)/user/vip"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [UserBuyVipActionApi.kUrl: UserBuyVipActionApi.kUrlValue,
                                        UserBuyVipActionApi.kMethod: UserBuyVipActionApi.kMethodValue]
        allParams[UserBuyVipActionApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
    
}


/// 用户 支付通道列表
class UserPayTypeListApi: XSVideoBaseAPI {
    
    static let kUrlValue = "/\(ConstValue.kApiVersion)/pay-list"
    static let kMethodValue = "GET"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "\(ConstValue.kApiVersion)/pay-list"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [UserPayTypeListApi.kUrl: UserPayTypeListApi.kUrlValue,
                                        UserPayTypeListApi.kMethod: UserPayTypeListApi.kMethodValue]
        allParams[UserPayTypeListApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
    
}

//
//  UserResetPswApi.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/27.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

 // 用户重置密码
class UserResetPswApi: XSVideoBaseAPI {
    
    static let kMobile = "mobile"  // 手机号，账号
    static let kVerification_key = "verification_key" // 验证码（如果是验证码登录必填）
    static let kPassword = "password"  // 用户密码（如果是密码登录必填
    static let kPassword_confirmation = "password_confirmation" // 密码验证
    static let kCode = "code"          // 验证码（如果是验证码登录必填）
    
    /// 固定参数，不需要外部传入
    static let kUrlValue = "/api/user/reset-pwd"
    static let kMethodValue = "POST"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/user/reset-pwd"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func requestType() -> NicooAPIManagerRequestType {
        return ConstValue.kIsEncryptoApi ? super.requestType() : .post
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [UserResetPswApi.kUrl: UserResetPswApi.kUrlValue,
                                        UserResetPswApi.kMethod: UserResetPswApi.kMethodValue]
        allParams[UserResetPswApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
   
}

//
//  UserReformer.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/14.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// 用户信息数据解析器
class UserReformer: NSObject {
    
//    /// 登录
//    private func reformLoginInfoDatas(_ data: Data?) -> Any? {
//        if let loginInfo = try? decode(response: data, of: ObjectResponse<LoginInfoModel>.self)?.result {
//            return loginInfo
//        }
//        return nil
//    }
//
//    /// 用户信息
//    private func reformUserInfoDatas(_ data: Data?) -> Any? {
//        if let videoList = try? decode(response: data, of: ObjectResponse<UserInfoModel>.self)?.result {
//            return videoList
//        }
//        return nil
//    }
//
//    
//    /// 邀请记录
//    private func reformInvitedListDatas(_ data: Data?) -> Any? {
//        if let invitedList = try? decode(response: data, of: ObjectResponse<InvitedListModel>.self)?.result {
//            return invitedList
//        }
//        return nil
//    }
}

extension UserReformer: NicooAPIManagerDataReformProtocol {
    
    func manager(_ manager: NicooBaseAPIManager, reformData jsonData: Data?) -> Any? {
//        if manager is UserInfoApi {
//            return reformUserInfoDatas(jsonData)
//        }
//        if manager is UserLoginApi {
//            return reformLoginInfoDatas(jsonData)
//        }
//
//        if manager is UserInvitedListApi {
//            return reformInvitedListDatas(jsonData)
//        }
        return nil
    }
}



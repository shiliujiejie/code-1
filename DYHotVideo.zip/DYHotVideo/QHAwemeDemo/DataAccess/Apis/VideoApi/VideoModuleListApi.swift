//
//  VideoModuleListApi.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/11.
//  Copyright © 2019年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// 视频分类筛  视频列表
class VideoModuleListApi: XSVideoBaseAPI {
    // 分页参数
    static let kPageNumber = "page"
    static let kPageCount = "limit"
    static let kDefaultCount = 10
    
    
    static let kUrlValue = "api/video/type-lists"
    static let kMethodValue = "GET"
    
    
    private var pageNumber: Int = 1
    
    // MARK: - Public method
    
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "api/video/type-lists"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [VideoModuleListApi.kUrl: VideoModuleListApi.kUrlValue,
                                        VideoModuleListApi.kMethod: VideoModuleListApi.kMethodValue]
        /// 分页参数
        var newParams: [String: Any] = [VideoModuleListApi.kPageNumber: pageNumber]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        allParams[VideoListApi.kParams] = newParams
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : newParams)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        self.pageNumber += 1
        return true
    }
    
}

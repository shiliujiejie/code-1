//
//  VideoReformer.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/12.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// 数据解析器
class VideoReformer: NSObject {
    
    /// 首页推荐、分类视频 列表
    private func reformVideoModulesDatas(_ data: Data?) -> Any? {
        if let videoModules = try? decode(response: data, of: ObjectResponse<[VideoCategoryModel]>.self)?.result {
            return videoModules
        }
        return nil
    }

    /// 分类页面视频列表
    private func reformVideoListDatas(_ data: Data?) -> Any? {
        if let videoList = try? decode(response: data, of: ObjectResponse<VideoListModel>.self)?.result {
            return videoList
        }
        return nil
    }

}

extension VideoReformer: NicooAPIManagerDataReformProtocol {
    
    func manager(_ manager: NicooBaseAPIManager, reformData jsonData: Data?) -> Any? {
        
        if manager is VideoListApi  {
            return reformVideoListDatas(jsonData)
        }

        if manager is VideoModuleListApi {
            return reformVideoModulesDatas(jsonData)
        }
        

        return nil
    }
}

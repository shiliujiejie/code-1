//
//  HotSearchItemCell.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/10.
//  Copyright © 2019年 pro5. All rights reserved.
//

import UIKit

class HotSearchItemCell: UICollectionViewCell {

    static let cellId = "HotSearchItemCell"
    
    @IBOutlet weak var videNameLab: UILabel!
    @IBOutlet weak var rankLable: UILabel!
  
    
    override func awakeFromNib() {
        super.awakeFromNib()
        rankLable.layer.cornerRadius = 8
        rankLable.layer.masksToBounds = true

    }
    

}

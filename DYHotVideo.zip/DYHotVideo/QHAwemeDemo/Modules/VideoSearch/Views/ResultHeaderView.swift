//
//  ResultHeaderView.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/19.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

class ResultHeaderView: UIView {
    
   
    @IBOutlet weak var lineView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        lineView.backgroundColor = ConstValue.kAppSepLineColor
        
    }
    
}

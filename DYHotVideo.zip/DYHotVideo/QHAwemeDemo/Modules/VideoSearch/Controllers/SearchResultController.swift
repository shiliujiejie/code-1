//
//  SearchResultController.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/19.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import MJRefresh
import NicooNetwork

/// 搜索结果页
class SearchResultController: UIViewController {
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    static let videoItemWidth: CGFloat = (ConstValue.kScreenWdith - 20)/3
    static let videoItemHieght: CGFloat = videoItemWidth * 1.3 + 35
    static let videoItemSize: CGSize = CGSize(width: videoItemWidth, height: videoItemHieght)
    
    private let headerView: ResultHeaderView = {
        if let view = Bundle.main.loadNibNamed("ResultHeaderView", owner: nil, options: nil)?[0] as? ResultHeaderView {
            view.frame = CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 130)
            return view
        }
        return ResultHeaderView()
    }()
    private let layout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = videoItemSize
        layout.minimumLineSpacing = 15   // 垂直最小间距
        layout.minimumInteritemSpacing = 5.0 // 水平最小间距
        layout.sectionInset = UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 5)
        return layout
    }()
    lazy var collectionView: UICollectionView = {
        let collection = UICollectionView.init(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.backgroundColor = UIColor.clear
        collection.showsVerticalScrollIndicator = false
        collection.register(VideoThridItemCell.classForCoder(), forCellWithReuseIdentifier: VideoThridItemCell.cellId)
        collection.register(UINib(nibName: "SeriesHeaderView", bundle: Bundle.main), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: SeriesHeaderView.reusableId)
        collection.mj_footer = loadMoreView
        return collection
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        let loadmore = MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
            
        })
        loadmore?.setTitle("", for: .idle)
        loadmore?.setTitle("已经到底了", for: .noMoreData)
        return loadmore!
    }()
    
    private let viewModel = VideoViewModel()
    var keyWord = ""
    var selectIndex = 0
    var endEditingCallBackHandler:(() ->Void)?
    var isDisMiss = false

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        view.addSubview(headerView)
        headerView.isHidden = true
        view.addSubview(collectionView)
        layoutPageSubviews()
        addViewModelCallBack()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if !isDisMiss {
            loadData()
        }
    }
    
    func loadData() {
        if !viewModel.isRefreshOperation {
            XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        } else {
            viewModel.isRefreshOperation = false
        }
        // 设置参数
        viewModel.params = [VideoListApi.kKeyword: self.keyWord, VideoListApi.kUpdateded_at: VideoListApi.kDefaultCreat_at]
        viewModel.loadData()
    }
    
    func loadReCommentVideoData() {
        showRecommentData(true)
        viewModel.params = [VideoListApi.kPlay_count: VideoListApi.kDefaultPlay_count, VideoListApi.kUpdateded_at: VideoListApi.kDefaultCreat_at]
        viewModel.loadData()
    }
    
    func showRecommentData(_ isRecomment: Bool) {
        if isRecomment {
            // 设置参数
            headerView.isHidden = false
            headerView.snp.updateConstraints { (make) in
                make.height.equalTo(130)
            }
        } else {
            headerView.isHidden = true
            headerView.snp.updateConstraints { (make) in
                make.height.equalTo(0)
            }
        }
    }
    
    private func loadNextPage() {
        viewModel.loadNextPage()
    }
    
    private func addViewModelCallBack() {
        viewModel.requestListSuccessHandle = { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.endRefreshing()
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            strongSelf.collectionView.reloadData()
            
            if strongSelf.viewModel.getVideoList().count == 0 { // 没有搜索到数据
                if let paramKeys = strongSelf.viewModel.params?.keys {
                    for key in paramKeys {
                        if key == VideoListApi.kKeyword {
                            strongSelf.loadReCommentVideoData()
                        }
                    }
                }
            } else {
                if let paramKeys = strongSelf.viewModel.params?.keys {
                    for key in paramKeys {
                        if key == VideoListApi.kKeyword {
                            strongSelf.showRecommentData(false)
                        }
                    }
                }
            }
        }
        viewModel.requestMoreListSuccessHandle = { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.endRefreshing()
             strongSelf.collectionView.reloadData()
        }
        viewModel.requestFailedHandle = { [weak self] (msg) in
            guard let strongSelf = self else { return }
            strongSelf.endRefreshing()
            XSAlert.show(type: .error, text: "数据走丢了。")
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
        }
    }
    
    private func endRefreshing() {
        collectionView.mj_footer.endRefreshing()
    }
    

}

// MARK: - UIScrollViewDelegate
extension SearchResultController: UIScrollViewDelegate {
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        endEditingCallBackHandler?()
    }
}

// MARK: - UIViewControllerTransitioningDelegate
extension SearchResultController :UIViewControllerTransitioningDelegate {
    
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        
        return ScalePresentAnimationForSearch()  // ScreenShotAnimation(presentingStyle: .presenting)
    }
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        
        return ScaleDismissAnimationForSearch() //ScreenShotAnimation(presentingStyle: .dismissing)
    }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension SearchResultController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.getVideoList().count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cellForRow(with: indexPath)
        return cell
    }
    
    /// 配置cell
    func cellForRow(with indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: VideoThridItemCell.cellId, for: indexPath) as! VideoThridItemCell
        if viewModel.getVideoList().count > indexPath.row {
            let model = viewModel.getVideoList()[indexPath.row]
            cell.videoImageView.kfSetVerticalImageWithUrl(model.cover_path)
            cell.videoNameLable.text = model.title ?? ""
            cell.favorCountLab.text = "\(model.recommend_count ?? 0)"
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        let controller = AcountVideoPlayController()
        controller.videos = viewModel.getVideoList()
        controller.currentIndex = indexPath.row
        controller.currentPlayIndex = indexPath.row
        selectIndex = indexPath.row
        controller.modalPresentationStyle = .overCurrentContext
        controller.transitioningDelegate = self
        controller.goVerbOrRefreshActionHandler = { [weak self] (isVerb) in
            if isVerb {
                let vipvc = VipCardsController()
                self?.navigationController?.pushViewController(vipvc, animated: false)
            } else {
                self?.collectionView.mj_header.beginRefreshing()
            }
        }
//        self.modalPresentationStyle = .currentContext
        self.present(controller, animated: true, completion: nil)
        self.isDisMiss = true
    }
}

// MARK: - Layout
private extension SearchResultController {
    
    func layoutPageSubviews() {
        layoutHeaderView()
        layoutCollection()
    }
    
    func layoutHeaderView() {
        headerView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(0)
            make.height.equalTo(0)
        }
    }
    
    func layoutCollection() {
        collectionView.snp.makeConstraints { (make) in
            make.top.equalTo(headerView.snp.bottom).offset(10)
            make.leading.trailing.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalToSuperview()
            }
        }
    }
    
}

//
//  SearchController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/25.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import NicooNetwork

/// 搜索主页
class SearchController: UIViewController {
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    private lazy var navBar: QHNavigationBar = {
        let bar = QHNavigationBar()
        bar.titleLabel.text = ""
        bar.titleLabel.textColor = UIColor.white
        bar.backgroundColor = UIColor.clear
        bar.backButton.isHidden = true
        bar.delegate = self
        return bar
    }()
    private lazy var cancleBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("取消", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 17)
        button.setTitleColor(UIColor.white, for: .normal)
        button.addTarget(self, action: #selector(cancleSearch), for: .touchUpInside)
        button.isHidden = false
        return button
    }()
    private lazy var tableView: UITableView = {
        let table = UITableView(frame: view.bounds, style: .plain)
        table.showsVerticalScrollIndicator = false
        table.separatorStyle = .none
        table.delegate = self
        table.dataSource = self
        table.tableFooterView = UIView(frame: CGRect.zero)
        table.backgroundColor = UIColor.clear
        table.register(HistorySearchCell.classForCoder(), forCellReuseIdentifier: HistorySearchCell.cellId)
        table.register(HotSearchCell.classForCoder(), forCellReuseIdentifier: HotSearchCell.cellId)
        return table
    }()
    private lazy var cancleBarButton: UIBarButtonItem = {
        let barButton = UIBarButtonItem.init(title: "取消", style: .plain, target: self, action: #selector(cancleSearch))
        barButton.tintColor = UIColor.white
        return barButton
    }()
    lazy var resultVC : SearchResultController = {
        let result = SearchResultController()
        return result
    }()
    private lazy var searchBar: UISearchBar = {
        let searchBar = UISearchBar(frame: CGRect(x: 20, y: 7, width: ConstValue.kScreenWdith - 120, height: 30))
        searchBar.placeholder = "～老湿你好，请多多指教"
        searchBar.backgroundColor = UIColor.clear
        searchBar.changeTitleColor(UIColor.groupTableViewBackground)
        searchBar.backgroundImage = UIImage()
        searchBar.changeFont(UIFont.systemFont(ofSize: 14))
        searchBar.changeTextFieldBackgroundColor(UIColor(red: 56/255.0, green: 59/255.0, blue: 71/255.0, alpha: 0.99))
        searchBar.delegate = self
        return searchBar
    }()
    private lazy var magicView: SearchMagneticView = {
        let view = SearchMagneticView.init(frame: CGRect.zero)
        return view
    }()
    private lazy var videoKeyApi: VideoSeriesListApi =  {
        let api = VideoSeriesListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var keyMagicApi: SearchMagicApi =  {
        let api = SearchMagicApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    
    var cateModels = [VideoCategoryModel]()
    var cateList: CateTypeListModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.setNavigationBarHidden(true, animated: false)
        view.backgroundColor = ConstValue.kVcViewColor
        navBar.addSubview(searchBar)
        navBar.addSubview(cancleBtn)
        view.addSubview(navBar)
        view.addSubview(tableView)
        view.addSubview(magicView)
        layoutPageSubviews()
        addMagicViewItemClickHandler()
        loadHotSearch()
        resultVC.endEditingCallBackHandler = { [weak self] in
            self?.searchBar.resignFirstResponder()
            self?.searchBar.endEditing(true)
            self?.hideMjView()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
       // navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    private func loadHotSearch() {
        let _ = videoKeyApi.loadData()
    }
    
    private func loadKeyMagicData() {
        let _ = keyMagicApi.loadData()
    }
    
    private func addMagicViewItemClickHandler() {
        magicView.itmClickActionHandler = { [weak self] (model) in
            self?.hideMjView()
            self?.searchBar.text = model.title ?? ""
            self?.searchWithKey(model.title)
            self?.saveSearchHistoryItem(model.title)
        }
    }
    
    private func showMjView(_ count: Int) {
        magicView.isHidden = false
        self.view.bringSubviewToFront(magicView)
        magicView.snp.updateConstraints { (make) in
            let height = 35*count
            make.height.equalTo(height > 350 ? 350 : 35*count)
        }
    }
    
    private func hideMjView() {
        magicView.isHidden = true
        magicView.snp.updateConstraints { (make) in
            make.height.equalTo(0)
        }
    }

}

// MARK: - QHNavigationBarDelegate
extension SearchController:  QHNavigationBarDelegate  {
    
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}


// MARK: - Privite Funcs
extension SearchController {
    
    /// 取消搜索点击
    @objc private func cancleSearch() {
        searchBar.resignFirstResponder()
        searchBar.endEditing(true)
        self.dismiss(animated: true, completion: nil)
    }
    
    /// 清空搜索历史
    @objc private func deleteSearchHistory() {
        UserDefaults.standard.removeObject(forKey: UserDefaults.kSearchHistory)
        tableView.reloadSections([0], with: .none)
    }
    
    /// 搜索
    ///
    /// - Parameter keyWord: 关键词
    private func searchWithKey(_ keyWord: String?) {
        if keyWord == nil {
            XSAlert.show(type: .warning, text: "～你是想看外星人啪啪啪吗～")
            return
        }
        searchBar.resignFirstResponder()
        searchBar.endEditing(true)
        if view.subviews.contains(resultVC.view) {
            resultVC.keyWord = keyWord ?? ""
            resultVC.isDisMiss = false
            resultVC.loadData()
        } else {
            resultVC.keyWord = keyWord ?? ""
            //resultVC.hotSearchModels = videoList
            resultVC.isDisMiss = false
            addChild(resultVC)
            view.addSubview(resultVC.view)
            layoutResultView(resultVC.view)
        }
    }
    
    /// 热搜列表拉取成功
    private func loadListDataSuccess(_ listModel: CateTypeListModel) {
        if let list = listModel.data, list.count > 0 {
            cateModels = list
            tableView.reloadSections([1], with: .none)
        }
    }
    
    /// 热搜列表拉取成功
    private func loadMagicListDataSuccess(_ listModel: SearchMagicListModel) {
        if let list = listModel.data, list.count > 0 {
            magicView.setModel(models: list)
            showMjView(list.count)
           
        } else {
            hideMjView()
        }
    }
    
    /// 存储搜索历史
    private func saveSearchHistoryItem(_ text: String?) {
        if text == nil { return }
        if text!.isEmpty  { return }
        guard var hisList = UserDefaults.standard.array(forKey: UserDefaults.kSearchHistory) as? [String] else {
            var array = [String]()
            array.append(text!)
            UserDefaults.standard.set(array, forKey: UserDefaults.kSearchHistory)
            return
        }
        hisList.insert(text!, at: 0)
        if hisList.count > 9 {
           hisList.removeLast() // 移除最后一位
        }
        UserDefaults.standard.set(hisList, forKey: UserDefaults.kSearchHistory)
        tableView.reloadSections([0], with: .none)
    }

}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension SearchController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            if let hisList = UserDefaults.standard.array(forKey: UserDefaults.kSearchHistory) as? [String], hisList.count > 0 {
                return 1
            } else {
                return 0
            }
        } else {
            return cateModels.count > 0 ? 1 : 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return cellForRow(indexPath)
    }
    
    func cellForRow(_ indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: HistorySearchCell.cellId, for: indexPath) as! HistorySearchCell
            guard let hisList = UserDefaults.standard.array(forKey: UserDefaults.kSearchHistory) as? [String] else {
                return UITableViewCell()
            }
            cell.setHistorySearchData(hisList)
            cell.itemClickHandler = { [weak self] (text) in
                self?.view.endEditing(true)
                self?.searchBar.text = text
                self?.searchWithKey(text)
            }
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: HotSearchCell.cellId, for: indexPath) as! HotSearchCell
            cell.setHistorySearchData(cateModels)
            cell.itemClickHandler = {[weak self] (index) in
                if let serModel = self?.cateModels[index] {
                    let serVC = SeriesVideosController()
                    serVC.keyCateModel = serModel
                    serVC.keyId = serModel.key_id ?? 1
                    self?.navigationController?.pushViewController(serVC, animated: true)
                }
            }
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            if let hisList = UserDefaults.standard.array(forKey: UserDefaults.kSearchHistory) as? [String], hisList.count > 0 {
                let yu = (hisList.count%3) > 0 ? 1 : 0
                return CGFloat(((hisList.count/3) + yu) * 45 + 30)
            } else {
                return 0
            }
        } else { return 315}
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        if indexPath.section == 1 {
           
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 {
            if let hisList = UserDefaults.standard.array(forKey: UserDefaults.kSearchHistory) as? [String], hisList.count > 0 {
                return 50
            } else {
                return 0
            }
        } else {
            return 50
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 50))
        let lable = UILabel(frame: CGRect(x:15, y: 15, width: 150, height: 20))
        lable.font = UIFont.boldSystemFont(ofSize: 15)
        lable.textColor = UIColor.white
        lable.text = ["您已撸过", "他人撸过"][section]
        view.addSubview(lable)
        let button = UIButton(type: .custom)
        button.setTitleColor(UIColor.darkText, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        button.frame = CGRect(x: ConstValue.kScreenWdith - 60, y: 10, width: 50, height: 30)
        button.setImage(UIImage(named: "cleanAllSearchHis"), for: .normal)
        if section == 1 { button.isHidden = true } else {
            if let hisList = UserDefaults.standard.array(forKey: UserDefaults.kSearchHistory) as? [String], hisList.count > 0 {
                button.isHidden = false
            } else {
                button.isHidden = true
            }
        }
        button.addTarget(self, action: #selector(deleteSearchHistory), for: .touchUpInside)
        view.addSubview(button)
        return view
    }
}

// MARK: - UIScrollViewDelegate
extension SearchController: UIScrollViewDelegate {
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        hideMjView()
        searchBar.resignFirstResponder()
        searchBar.endEditing(true)
        let sectionHeaderHeight: CGFloat = 50
        if scrollView.contentOffset.y <= sectionHeaderHeight && scrollView.contentOffset.y > 0 {
            scrollView.contentInset = UIEdgeInsets(top: -scrollView.contentOffset.y, left: 0, bottom: 0, right: 0)
            
        } else if scrollView.contentOffset.y >= sectionHeaderHeight {
            scrollView.contentInset = UIEdgeInsets(top: -sectionHeaderHeight, left: 0, bottom: 0, right: 0)
        }
    }
}


// MARK: - UISearchBarDelegate
extension SearchController: UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        hideMjView()
        searchWithKey(searchBar.text)
        saveSearchHistoryItem(searchBar.text)
    }
    
    func searchBarShouldBeginEditing(_ searchBar: UISearchBar) -> Bool {
        return true
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        let searchStr = searchText.removeAllSpace()
        if searchStr == nil || searchStr!.isEmpty {
            hideMjView()
            resultVC.view.removeFromSuperview()
            resultVC.removeFromParent()
        } else {
            let _ = keyMagicApi.loadData()
        }
    }
    
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension SearchController: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        var params = [String: Any]()
        if manager is VideoSeriesListApi {
            XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
            params[VideoSeriesListApi.kType] = "SEARCH"
            params[VideoSeriesListApi.kPageCount] = 15
            return params
        }
        if manager is SearchMagicApi {
            params[SearchMagicApi.kKeyword] = searchBar.text ?? ""
            return params
        }
       return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is VideoSeriesListApi {
            if let list = manager.fetchJSONData(VideoReformer()) as? CateTypeListModel {
                loadListDataSuccess(list)
            }
        }
        if manager is SearchMagicApi {
            if let list = manager.fetchJSONData(VideoReformer()) as? SearchMagicListModel {
                loadMagicListDataSuccess(list)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
    }
    
}

// MARK: - Layout
private extension SearchController {
    
    func layoutPageSubviews() {
        layoutNavBar()
        layoutCancleBtn()
        layoutSearchBar()
        layoutTableView()
        layoutMagicView()
    }
    
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            make.top.equalTo(navBar.snp.bottom)
            make.leading.trailing.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalToSuperview()
            }
        }
    }
    func layoutMagicView() {
        magicView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(ConstValue.kStatusBarHeight + 44)
            make.height.equalTo(0)
        }
    }
    
    func layoutResultView(_ childview: UIView) {
        childview.snp.makeConstraints { (make) in
            make.top.equalTo(navBar.snp.bottom)
            make.leading.trailing.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalToSuperview()
            }
        }
    }
    
    func layoutNavBar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kStatusBarHeight + 44)
        }
    }
    
    func layoutSearchBar() {
        searchBar.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.bottom.equalTo(-7)
            make.trailing.equalTo(-75)
            make.height.equalTo(35)
        }
    }
    
    func layoutCancleBtn() {
        cancleBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-15)
            make.bottom.equalTo(-7)
            make.width.equalTo(50)
            make.height.equalTo(35)
        }
    }
}

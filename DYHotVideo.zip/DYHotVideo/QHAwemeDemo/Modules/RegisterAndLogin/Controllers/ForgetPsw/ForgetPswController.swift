//
//  ForgetPswController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/24.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class ForgetPswController: UIViewController {
    
    private lazy var navBar: QHNavigationBar = {
        let bar = QHNavigationBar()
        bar.titleLabel.text = "wkkkkk"
        bar.backgroundColor = UIColor.groupTableViewBackground
        bar.delegate = self
        return bar
    }()
    
    lazy var phoneImage: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "phoneImage")
        image.contentMode = .scaleAspectFit
        return image
    }()
    lazy var countryCodeBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("+86", for: .normal)
        button.setTitleColor(UIColor.blue, for: .normal)
        button.addTarget(self, action: #selector(countryCodeButtonClick), for: .touchUpInside)
        return button
    }()
    lazy var phoneText: UITextField = {
        let txfild = UITextField()
        txfild.borderStyle = .none
        txfild.placeholder = localStr("kPleaceInputPhoneNum")
        txfild.clearButtonMode = .whileEditing
        txfild.font = UIFont.systemFont(ofSize: 16)
        return txfild
    }()
    lazy var codeImage: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "codeImage")
        image.contentMode = .scaleAspectFit
        return image
    }()
    lazy var codeText: UITextField = {
        let txfild = UITextField()
        txfild.borderStyle = .none
        txfild.placeholder = localStr("kPleaceInputMsgCode")
        txfild.font = UIFont.systemFont(ofSize: 16)
        return txfild
    }()
    lazy var codeBtn: CountDownButton = {
        let button = CountDownButton(frame: CGRect(x: 0, y: 0, width: 80, height: 40))
        button.layer.cornerRadius = 15
        button.layer.masksToBounds = true
        return button
    }()
    lazy var pswImage: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "pswImage")
        image.contentMode = .scaleAspectFit
        return image
    }()
    lazy var pswText: UITextField = {
        let txfild = UITextField()
        txfild.borderStyle = .none
        txfild.placeholder = localStr("kResetPswPlaceHolder")
        txfild.isSecureTextEntry = true
        txfild.font = UIFont.systemFont(ofSize: 16)
        return txfild
    }()
    lazy var seePswBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "pswSeeBtn"), for: .normal)
        button.setImage(UIImage(named: "noSeePsw"), for: .selected)
        button.addTarget(self, action: #selector(showPswText(_:)), for: .touchUpInside)
        return button
    }()
    lazy var commitButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle(localStr("kCommit"), for: .normal)
        button.backgroundColor = ConstValue.kAppDefaultColor
        button.layer.cornerRadius = 22.5
        button.layer.masksToBounds = true
        // button.isEnabled = false
        button.addTarget(self, action: #selector(commitButtonClick), for: .touchUpInside)
        return button
    }()
    
    var loginButtonClickHandler:(() -> Void)?
    var pswLoginClickHandler:(() -> Void)?
    var navHidenCallBackHandler:((_ navAnimation: Bool) -> Void)?
    
    let viewModel = RegisterLoginViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        title = localStr("kResetPswTitle")
        view.addSubview(navBar)
        view.addSubview(phoneImage)
        view.addSubview(countryCodeBtn)
        view.addSubview(phoneText)
        view.addSubview(codeImage)
        view.addSubview(codeText)
        view.addSubview(codeBtn)
        view.addSubview(pswImage)
        view.addSubview(pswText)
        view.addSubview(seePswBtn)
        view.addSubview(commitButton)
        layoutPageSubviews()
        addSendCodeCallback()
        addViewModelCallBackHandler()
    }
    
    
    /// ViewModel 回调
    func addViewModelCallBackHandler() {
        viewModel.loadSendCodeApiSuccess = { [weak self] in
            guard let strongSelf = self else { return }
            self?.codeBtn.isCounting = true
            XSAlert.show(type: .success, text: strongSelf.localStr("kSendCodeSuccess"))
        }
        viewModel.loadSendCodeApiFail = { (msg) in
            XSAlert.show(type: .warning, text: msg)
        }
        viewModel.loadChangePswApiSuccess = { [weak self] in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            strongSelf.showDialog(title: nil, message: strongSelf.localStr("kResetPswSuccessAlert"), okTitle: strongSelf.localStr("kSure"), cancelTitle: strongSelf.localStr("kCancle"), okHandler: {
                strongSelf.navigationController?.popToRootViewController(animated: true)
            }, cancelHandler: nil)
        }
        viewModel.loadChangePswApiFail = { [weak self] (msg) in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            XSAlert.show(type: .error, text: msg)
        }
    }
    
    /// 验证码按钮点击回调
    func addSendCodeCallback() {
        codeBtn.sendCodeButtonClickHandler = { [weak self] in
            var params = [String: Any]()
            if let phoneStr = self?.phoneText.text {
                let phone = phoneStr.removeAllSpace()
                params[SendCodeApi.kMobile] = phone
            }
            self?.viewModel.sendCode(params)
        }
    }
    
    @objc func countryCodeButtonClick() {
        
    }
  
    @objc func showPswText(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        pswText.isSecureTextEntry = !sender.isSelected
    }
    
    @objc func commitButtonClick() {
        var params = [String: Any]()
        if let phoneStr = phoneText.text {
            let phone = phoneStr.removeAllSpace()
            if phone == nil || phone!.isEmpty {
                XSAlert.show(type: .warning, text: localStr("kPleaceInputPhoneNum"))
                return
            }
            if !phone!.isValidPhoneNumber() {
                XSAlert.show(type: .warning, text: localStr("kPleaceInputCorrectPhoneNum"))
                return
            }
            params[UserResetPswApi.kMobile] = phone!
        }
        if let codeStr = codeText.text {
            let code = codeStr.removeAllSpace()
            if code == nil || code!.isEmpty {
                XSAlert.show(type: .warning, text: localStr("kPleaceInputMsgCode"))
                return
            }
            params[UserResetPswApi.kCode] = code!
        }
        if let pswStr = pswText.text {
            let psw = pswStr.removeAllSpace()
            if psw == nil || psw!.isEmpty {
                XSAlert.show(type: .warning, text: localStr("kPleaceInputPassword"))
                return
            }
            params[UserResetPswApi.kPassword] = psw!
            params[UserResetPswApi.kPassword_confirmation] = psw!
        }
        params[UserResetPswApi.kVerification_key] = viewModel.getCodeModel().verification_key
        // 修改密码
        XSProgressHUD.showProgress(msg: nil, onView: view, animated: false)
        viewModel.changePsw(params)
    }
    
    
}

// MARK: - QHNavigationBarDelegate
extension ForgetPswController:  QHNavigationBarDelegate  {
    
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}

// MARK: - Layout
private extension ForgetPswController {
    
    func layoutPageSubviews() {
        layoutNavbar()
        layoutPhoneItem()
        layoutCodeItem()
        layoutPswItem()
        layoutCommitButton()
    }
    
    func layoutNavbar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(ConstValue.kStatusBarHeight + 44)
        }
    }
    
    func layoutPhoneItem() {
        phoneImage.snp.makeConstraints { (make) in
            make.top.equalTo(navBar.snp.bottom).offset(70)
            make.leading.equalTo(25)
            make.width.height.equalTo(20)
        }
        countryCodeBtn.snp.makeConstraints { (make) in
            make.leading.equalTo(phoneImage.snp.trailing).offset(15)
            make.centerY.equalTo(phoneImage)
            make.height.equalTo(30)
            make.width.equalTo(40)
        }
        phoneText.snp.makeConstraints { (make) in
            make.leading.equalTo(countryCodeBtn.snp.trailing).offset(10)
            make.centerY.equalTo(countryCodeBtn)
            make.height.equalTo(35)
            make.trailing.equalTo(-40)
        }
    }
    
    func layoutPswItem() {
        pswImage.snp.makeConstraints { (make) in
            make.leading.equalTo(25)
            make.top.equalTo(codeText.snp.bottom).offset(35)
            make.height.width.equalTo(20)
        }
        seePswBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-40)
            make.centerY.equalTo(pswImage)
            make.height.equalTo(30)
            make.width.equalTo(30)
        }
        pswText.snp.makeConstraints { (make) in
            make.leading.equalTo(pswImage.snp.trailing).offset(15)
            make.centerY.equalTo(pswImage)
            make.height.equalTo(35)
            make.trailing.equalTo(seePswBtn.snp.leading).offset(-10)
        }
        
    }
    
    func layoutCodeItem() {
        codeImage.snp.makeConstraints { (make) in
            make.leading.equalTo(phoneImage)
            make.top.equalTo(phoneText.snp.bottom).offset(35)
            make.width.height.equalTo(20)
        }
        codeBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-40)
            make.centerY.equalTo(codeImage)
            make.height.equalTo(30)
            make.width.equalTo(90)
        }
        codeText.snp.makeConstraints { (make) in
            make.leading.equalTo(codeImage.snp.trailing).offset(15)
            make.centerY.equalTo(codeBtn)
            make.height.equalTo(35)
            make.trailing.equalTo(codeBtn.snp.leading).offset(-10)
        }
    }
    
    
    
    func layoutCommitButton() {
        commitButton.snp.makeConstraints { (make) in
            make.top.equalTo(pswText.snp.bottom).offset(45)
            make.height.equalTo(45)
            make.leading.equalTo(25)
            make.trailing.equalTo(-25)
        }
    }
    
    
    
}


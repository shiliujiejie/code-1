//
//  QHFindViewController.swift
//  QHAwemeDemo
//
//  Created by Anakin chen on 2017/10/16.
//  Copyright © 2017年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import NicooNetwork
import MJRefresh

class QHFindViewController: QHBaseViewController {
    
    static let videoItemWidth: CGFloat = (ConstValue.kScreenWdith - 30)/2
    static let videoItemHieght: CGFloat = videoItemWidth * 1.2
    static let videoItemSize: CGSize = CGSize(width: videoItemWidth, height: videoItemHieght)
    
    private let layout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = videoItemSize
        layout.minimumLineSpacing = 15   // 垂直最小间距
        layout.minimumInteritemSpacing = 5.0 // 水平最小间距
        layout.sectionInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        return layout
    }()
    private lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.backgroundColor = UIColor.clear
        collection.showsVerticalScrollIndicator = false
       collection.register(UINib.init(nibName: "SeriesMainCell", bundle: Bundle.main), forCellWithReuseIdentifier: SeriesMainCell.cellId)
        collection.mj_header = refreshView
        //collection.mj_footer = loadMoreView
        return collection
    }()
    private var backgroupImage: UIImageView = {
        let image = UIImageView()
        image.backgroundColor = UIColor.white
        image.isUserInteractionEnabled = true
        return image
    }()
//    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
//        weak var weakSelf = self
//        let loadmore = MJRefreshAutoNormalFooter(refreshingBlock: {
//            weakSelf?.loadNextPage()
//        })
//        loadmore?.setTitle("", for: .idle)
//        loadmore?.setTitle("已经到底了", for: .noMoreData)
//        return loadmore!
//    }()
    lazy private var refreshView: MJRefreshGifHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshGifHeader(refreshingBlock: {
            weakSelf?.isRefreshOperation = true
            weakSelf?.loadData()
        })
        var gifImages = [UIImage]()
        for string in ConstValue.refreshImageNames {
            gifImages.append(UIImage(named: string)!)
        }
        mjRefreshHeader?.setImages(gifImages, for: .refreshing)
        mjRefreshHeader?.setImages(gifImages, for: .idle)
        return mjRefreshHeader!
    }()
    private lazy var videoCateApi: VideoModuleListApi =  {
        let api = VideoModuleListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    var cateModels = [VideoCategoryModel]()
    
    var isRefreshOperation = false

    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(backgroupImage)
        view.addSubview(collectionView)
        layoutPageSubviews()
        loadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
 
}

// MARK: - Private - Funcs
private extension QHFindViewController {
    
    func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        if !isRefreshOperation {
            XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        } else {
            isRefreshOperation = false
        }
        let _ = videoCateApi.loadData()
    }
    
    func loadNextPage() {
        let _ = videoCateApi.loadNextPage()
    }
    
    func endRefreshing() {
        collectionView.mj_header.endRefreshing()
        //collectionView.mj_footer.endRefreshing()
    }
    
    func succeedRequest(_ models: [VideoCategoryModel]) {
        cateModels = models
        endRefreshing()
        collectionView.reloadData()
    }
    
    func failedRequest(_ manager: NicooBaseAPIManager) {
        endRefreshing()
        NicooErrorView.showErrorMessage(.noNetwork, on: self.view) {
            self.loadData()
        }
    }
}


// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension QHFindViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return cateModels.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cellForRow(with: indexPath)
        return cell
    }
    
    /// 配置cell
    func cellForRow(with indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SeriesMainCell.cellId, for: indexPath) as! SeriesMainCell
        let model = cateModels[indexPath.row]
        cell.nameLable.text = "系列 + \(model.title ?? "")"
        cell.seriesImage.backgroundColor = UIColor.gray
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let seriesVideoVC =  SeriesVideosController()
        navigationController?.pushViewController(seriesVideoVC, animated: true)
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension QHFindViewController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if let videoCateList = manager.fetchJSONData(VideoReformer()) as? [VideoCategoryModel] {
            if manager is VideoModuleListApi {
                succeedRequest(videoCateList)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is VideoModuleListApi {
            failedRequest(manager)
        }
    }
}


// MARK: - Layout
private extension QHFindViewController {
    
    func layoutPageSubviews() {
        layoutBackGroundImage()
        layoutCollection()
    }
    
    func layoutCollection() {
        collectionView.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-44)
            } else {
                make.bottom.equalToSuperview().offset(-44)
            }
        }
    }
    
    func layoutBackGroundImage() {
        backgroupImage.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
}

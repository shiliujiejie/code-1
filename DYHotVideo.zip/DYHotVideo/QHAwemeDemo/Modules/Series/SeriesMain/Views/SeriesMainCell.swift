//
//  SeriesMainCell.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/3.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

class SeriesMainCell: UICollectionViewCell {

    static let cellId = "SeriesMainCell"
    
    @IBOutlet weak var seriesImage: UIImageView!
    
    @IBOutlet weak var nameLable: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }

}

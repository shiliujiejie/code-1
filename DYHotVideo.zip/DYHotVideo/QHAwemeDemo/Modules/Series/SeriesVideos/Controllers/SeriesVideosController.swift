//
//  SeriesVideosController.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/3.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import MJRefresh

class SeriesVideosController: UIViewController {
    
    static let videoItemWidth: CGFloat = (ConstValue.kScreenWdith - 30)/2
    static let videoItemHieght: CGFloat = videoItemWidth * 9/16
    static let videoItemSize: CGSize = CGSize(width: videoItemWidth, height: videoItemHieght)
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    private lazy var navBar: QHNavigationBar = {
        let bar = QHNavigationBar()
        bar.titleLabel.text = "wkkkkk"
        bar.backgroundColor = UIColor.clear
        bar.delegate = self
        return bar
    }()
    private let layout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = videoItemSize
        layout.minimumLineSpacing = 15   // 垂直最小间距
        layout.minimumInteritemSpacing = 5.0 // 水平最小间距
        layout.sectionInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        return layout
    }()
    lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.backgroundColor = UIColor.clear
        collection.showsVerticalScrollIndicator = false
        collection.register(UICollectionViewCell.classForCoder(), forCellWithReuseIdentifier: "sssss")
        collection.mj_header = refreshView
        collection.mj_footer = loadMoreView
        return collection
    }()
    var backgroupImage: UIImageView = {
        let image = UIImageView()
        image.backgroundColor = UIColor.white
        return image
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        let loadmore = MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.viewModel.loadNextPage()
        })
        loadmore?.setTitle("", for: .idle)
        loadmore?.setTitle("已经到底了", for: .noMoreData)
        return loadmore!
    }()
    lazy private var refreshView: MJRefreshGifHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshGifHeader(refreshingBlock: {
            weakSelf?.viewModel.isRefreshOperation = true
            weakSelf?.loadData()
        })
        var gifImages = [UIImage]()
        for string in ConstValue.refreshImageNames {
            gifImages.append(UIImage(named: string)!)
        }
        mjRefreshHeader?.setImages(gifImages, for: .refreshing)
        mjRefreshHeader?.setImages(gifImages, for: .idle)
        return mjRefreshHeader!
    }()
    
    private let viewModel = VideoViewModel()
    
    let scalePresentAnimation = ScalePresentAnimation()
    let scaleDismissAnimation = ScaleDismissAnimation()
    let swipeLeftInteractiveTransition = SwipeLeftInteractiveTransition()
    
    var selectIndex:Int = 0
    /// 是否弹出了播放器
    var isCoverPlayer = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(backgroupImage)
        view.addSubview(collectionView)
        view.addSubview(navBar)
        layoutPageSubviews()
        addViewModelCallBack()
        loadData()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    private func loadData() {
        if !viewModel.isRefreshOperation {
            XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        } else {
            viewModel.isRefreshOperation = false
        }
        viewModel.loadData()
    }
    
    private func addViewModelCallBack() {
        viewModel.requestListSuccessHandle = { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.endRefreshing()
            strongSelf.collectionView.reloadData()
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
        }
        viewModel.requestMoreListSuccessHandle = { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.endRefreshing()
            if !strongSelf.isCoverPlayer {
                 strongSelf.collectionView.reloadData()
            }
           // strongSelf.viewModel.sourceCount = strongSelf.viewModel.getVideoList().count
        }
        viewModel.requestFailedHandle = { [weak self] (msg) in
            guard let strongSelf = self else { return }
            strongSelf.endRefreshing()
            XSAlert.show(type: .error, text: "数据走丢了。")
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
        }
    }
    
    private func endRefreshing() {
        collectionView.mj_header.endRefreshing()
        collectionView.mj_footer.endRefreshing()
    }
    
    
}

// MARK: - QHNavigationBarDelegate
extension SeriesVideosController:  QHNavigationBarDelegate  {
    
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}


// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension SeriesVideosController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.getVideoList().count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cellForRow(with: indexPath)
        return cell
    }
    
    /// 配置cell
    func cellForRow(with indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "sssss", for: indexPath)
        
        cell.contentView.backgroundColor = UIColor.yellow
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
//        LoginManager().login {
//
//        }
        selectIndex = indexPath.row
        let controller = PresentPlayController()
        controller.viewModelForPlay = self.viewModel
        controller.currentIndex = selectIndex
        controller.currentPlayIndex = selectIndex
        controller.transitioningDelegate = self
        controller.modalPresentationStyle = .overCurrentContext
        self.modalPresentationStyle = .currentContext
        self.present(controller, animated: true, completion: nil)
    }
}

// MARK: - UIViewControllerTransitioningDelegate
extension SeriesVideosController: UIViewControllerTransitioningDelegate {
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        isCoverPlayer = true
        viewModel.sourceCount = viewModel.getVideoList().count
        return scalePresentAnimation
    }
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        isCoverPlayer = false
        return scaleDismissAnimation
    }
    
    func interactionControllerForDismissal(using animator: UIViewControllerAnimatedTransitioning) -> UIViewControllerInteractiveTransitioning? {
        return nil
    }
}

// MARK: - Layout
private extension SeriesVideosController {
    
    func layoutPageSubviews() {
        layoutNavBar()
        layoutBackGroundImage()
        layoutCollection()
    }
    
    func layoutNavBar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kStatusBarHeight + 44)
        }
    }
    
    func layoutCollection() {
        collectionView.snp.makeConstraints { (make) in
            make.top.equalTo(navBar.snp.bottom)
            make.leading.trailing.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalToSuperview()
            }
        }
    }
    
    func layoutBackGroundImage() {
        backgroupImage.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
}

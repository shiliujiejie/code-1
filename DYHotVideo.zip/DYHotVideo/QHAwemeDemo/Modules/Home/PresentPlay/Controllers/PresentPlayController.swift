//
//  PresentPlayController.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/3.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import Kingfisher

/// 模态出来的播放页面
class PresentPlayController: UIViewController {

    var currentIndex:Int = 0
    var currentPlayIndex: Int = 0
    
    var urls = [String]()
        
    
    var imageSource = ["https://p1.pstatp.com/aweme/300x400/7ac7000f1a5738f38b76.jpeg",
                       "https://p3.pstatp.com/aweme/300x400/7c1d0006d56122fedaa9.jpeg",
                       "https://p3.pstatp.com/aweme/300x400/7c3500090e4712f1efae.jpeg",
                       "https://p1.pstatp.com/aweme/720x720/7bee0023942173e1f3f4.jpeg",
                       "https://p3.pstatp.com/aweme/300x400/8fed000133e042306180.jpeg",
                       "https://p3.pstatp.com/aweme/300x400/7cd6000ef90b978b8555.jpeg",
                       "https://p3.pstatp.com/aweme/300x400/7d0a000969c9dedf8ab1.jpeg",
                       "https://p3.pstatp.com/aweme/300x400/7d4800064beb076774d0.jpeg",
                       "https://p3.pstatp.com/aweme/300x400/7f44000ed076be907d61.jpeg",
                       "https://p1.pstatp.com/aweme/300x400/81bb000d8efa1c73f452.jpeg",
                       "https://p3.pstatp.com/aweme/300x400/81c5000123c4bf0d8b44.jpeg",
                       "https://p3.pstatp.com/aweme/300x400/81e70004a52c419ba32c.jpeg",
                       "https://p9.pstatp.com/aweme/300x400/81f60000296afdbdd40f.jpeg",
                       "https://p9.pstatp.com/aweme/300x400/826a000fa304abf49b96.jpeg"]
    lazy var screenScaleBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "icon_home_comment"), for: .normal)
        button.addTarget(self, action: #selector(screenScaleSizeChange(_:)), for: .touchUpInside)
        return button
    }()
    lazy var playerView: NicooPlayerView = {
        let player = NicooPlayerView(frame: view.bounds, bothSidesTimelable: true)
        player.videoLayerGravity = .resizeAspect
        player.videoNameShowOnlyFullScreen = true
        player.delegate = self
        player.customViewDelegate = self
        return player
    }()
    
    lazy var leftBackButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "navBackWhite"), for: .normal)
        button.backgroundColor = UIColor(white: 0.0, alpha: 0.2)
        button.layer.cornerRadius = 17.5
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(backButtonClick), for: .touchUpInside)
        return button
    }()
    
    let flowLayout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        //每个Item之间最小的间距
        layout.minimumInteritemSpacing = 0
        //每行之间最小的间距
        layout.minimumLineSpacing = 0
        return layout
    }()
    
    lazy var collection: UICollectionView = {
        let collectionView = UICollectionView(frame: view.bounds, collectionViewLayout: flowLayout)
        collectionView.backgroundColor = UIColor.clear
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.scrollsToTop = false
        collectionView.register(PresentPlayCell.classForCoder(), forCellWithReuseIdentifier: PresentPlayCell.cellId)
        return collectionView
    }()
    
    var isRefreshOperation = false
    
    var isFirstIn = true
    
    var viewModelForPlay: VideoViewModel!
    
    deinit {
        print("release ---- PresentPlayVC")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(white: 0, alpha: 0.3)
        setUpUI()
        collection.scrollToItem(at: IndexPath.init(item: currentIndex, section: 0), at: .top, animated: false)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if currentIndex > viewModelForPlay.getVideoList().count - 4 {
            viewModelForPlay.loadNextPage()
        }
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        playerView.playerStatu = PlayerStatus.Pause
    }
    
    private func setUpUI() {
        view.addSubview(collection)
        if #available(iOS 11.0, *) {
            collection.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
        view.addSubview(leftBackButton)
        view.addSubview(screenScaleBtn)
        
        layoutPageSubviews()
        
    }
    
    @objc func screenScaleSizeChange(_ sender: UIButton) {
        if playerView.videoLayerGravity == .resizeAspect {
            playerView.videoLayerGravity = .resize
        } else if playerView.videoLayerGravity == .resize {
            playerView.videoLayerGravity = .resizeAspect
        }
    }
    
    @objc func backButtonClick() {
        self.dismiss(animated: true, completion: nil)
    }

}


// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension PresentPlayController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModelForPlay.getVideoList().count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: PresentPlayCell.cellId, for: indexPath) as! PresentPlayCell
        cell.backgroundColor = UIColor.darkText
        let models = viewModelForPlay.getVideoList()
        if models.count > indexPath.row {
            let videoModel = models[indexPath.row]
            if let urlImage = URL(string: videoModel.cover_path ?? ""), let urlheade = URL(string: "https://p3.pstatp.com/aweme/100x100/93b000053eeb354d5ad6.jpeg") {
                cell.imageBackGroup.kf.setImage(with: urlImage)
                cell.seriesButton.kf.setBackgroundImage(with: urlheade, for: .normal)
            }
            cell.introLable.text = videoModel.title ?? ""
            cell.commentItem.msgLable.text = String(format: "%d", videoModel.comment_count ?? 0)
            cell.favorLable.text = String(format: "%d", videoModel.appraise_count ?? 0)
            cell.favorBtn.dyState = (videoModel.recommend?.isFavor ?? false) ? DYButton.DYButtonState.selected : DYButton.DYButtonState.cancel
            /// 第一次进入，播放第currentIndex条
            if indexPath.row == currentIndex && isFirstIn {
                let url = URL(string: models[currentIndex].play_url_m3u8 ?? "")
                self.playerView.playVideo(url, "", cell.imageBackGroup)
                isFirstIn = false
                cell.startLoadingPlayItemAnim(true)
            }
        }
        cell.commentItemClick = { [weak self] in
            let commentVC = CommentsController()
            commentVC.modalPresentationStyle = .overCurrentContext
            commentVC.definesPresentationContext = true
            commentVC.view.backgroundColor = UIColor(white: 0.0, alpha: 0.3)
            self?.present(commentVC, animated: true, completion: nil)
        }
        cell.shareItemClick = { [weak self] in
            self?.share()
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
    }
}


// MARK: - UICollectionViewDelegateFlowLayout
extension PresentPlayController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return UIScreen.main.bounds.size;
    }
}

// MARK: - UIScrollViewDelegate
extension PresentPlayController: UIScrollViewDelegate {
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        DispatchQueue.main.async {
            /// 禁用手势
            let translatedPoint = scrollView.panGestureRecognizer.translation(in: scrollView)
            scrollView.panGestureRecognizer.isEnabled = false
            
            if translatedPoint.y < -50 && self.currentIndex < (self.viewModelForPlay.getVideoList().count - 1) {
                /// 上滑
                self.currentIndex += 1
            }
            if translatedPoint.y > 50 && self.currentIndex > 0 {
                /// 下滑
                self.currentIndex -= 1
            }
            if self.currentIndex == self.viewModelForPlay.sourceCount - 1 {
                self.collection.reloadData()
                self.viewModelForPlay.sourceCount = self.viewModelForPlay.getVideoList().count
            }
            let indexPath = IndexPath(row: self.currentIndex, section: 0)
            print("indexpath = \(indexPath), currentIndex = \(self.currentIndex), currentPlayIndex= \(self.currentPlayIndex) , sourceCoubt = \(self.viewModelForPlay.getVideoList().count),sourcccccc= \(self.viewModelForPlay.sourceCount)")
//            if indexPath == nil {
//                return
//            }
            UIView.animate(withDuration: 0.15, delay: 0.0, options: .curveEaseOut, animations: {
                if self.viewModelForPlay.getVideoList().count > indexPath.row {
                    self.collection.scrollToItem(at: indexPath, at: .top, animated: true)
                } else {
                    
                }
            }, completion: { finished in
                scrollView.panGestureRecognizer.isEnabled = true
                if let cell = self.collection.cellForItem(at: indexPath) as? PresentPlayCell {
                    if self.currentPlayIndex != self.currentIndex { // 上下滑动
                        let urlstr = self.viewModelForPlay.getVideoList()[indexPath.row].play_url_m3u8
                        let url = URL(string: urlstr ?? "")
                        self.playerView.playVideo(url, "", cell.imageBackGroup)
                        cell.startLoadingPlayItemAnim(true)
                        self.currentPlayIndex = self.currentIndex
                    }
                }
                
                if self.currentIndex == self.viewModelForPlay.getVideoList().count - 4 {
                    print("给您补给数据。。， ")
                    self.viewModelForPlay.loadNextPage()
                    // 这里先不刷新
                }
            })
        }
    }
}


// MARK: - NicooPlayerDelegate
extension PresentPlayController: NicooPlayerDelegate, NicooCustomMuneDelegate {
    
    func customTopBarActions() -> [UIButton]? {
        var buttonS = [UIButton]()
        //        for i in 0..<3 {
        //            let button = UIButton(type: .custom)
        //            button.backgroundColor = UIColor.white
        //            button.setImage(UIImage(named: ["collection","downLoad","shareAction"][i]), for: .normal)
        //            button.addTarget(self, action: #selector(topBarCustonButtonClick(_:)), for: .touchUpInside)
        //            buttonS.append(button)
        //        }
        return buttonS
    }
    
    func retryToPlayVideo(_ player: NicooPlayerView, _ videoModel: NicooVideoModel?, _ fatherView: UIView?) {
        print("网络不可用时调用")
        let url = URL(string: videoModel?.videoUrl ?? "")
        if  let sinceTime = videoModel?.videoPlaySinceTime, sinceTime > 0 {
            player.replayVideo(url, videoModel?.videoName, fatherView, sinceTime)
        } else {
            player.playVideo(url, videoModel?.videoName, fatherView)
        }
    }
    
    func showOrHideLoadingview(_ isPlaying: Bool) {
        let indexPath = IndexPath(row: self.currentIndex, section: 0)
        if let cell = collection.cellForItem(at: indexPath) as? PresentPlayCell {
            cell.startLoadingPlayItemAnim(!isPlaying)
        }
    }
    
//    func enableScrollAndPanGestureOrNoteWith(isEnable: Bool) {
//        (self.navigationController as! QHNavigationController).pan?.isEnabled = isEnable
//        if let vc = getCurrentVC() {
//            vc.mainScrollV.isScrollEnabled = isEnable
//        }
//    }
    
    
}

// MARK: - Layout
private extension PresentPlayController {
    
    func layoutPageSubviews() {
        layoutLeftBackButton()
        layoutScaleChangeBtn()
    }
    
    func layoutScaleChangeBtn() {
        screenScaleBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-20)
            make.top.equalTo(80)
            make.width.height.equalTo(50)
        }
    }
    
    func layoutLeftBackButton() {
        leftBackButton.snp.makeConstraints { (make) in
            make.leading.equalTo(16)
            make.top.equalTo(ConstValue.kStatusBarHeight + 10)
            make.width.height.equalTo(35)
        }
    }
}

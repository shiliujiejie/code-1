//
//  QHHomeCollectionViewCell.swift
//  QHAwemeDemo
//
//  Created by Anakin chen on 2017/10/22.
//  Copyright © 2017年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

public protocol QHHomeCollectionViewCellDelegate: NSObjectProtocol {
    
    func showDetails(_ view: QHHomeCollectionViewCell)
}

public class QHHomeCollectionViewCell: UICollectionViewCell {
    
    static let cellId = "QHHomeCellIdentifier"
    
    @IBOutlet weak var bgImage: UIImageView!
    // 加载
    var playerStatusBar: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.clear
        view.isHidden = true
        return view
    }()
    /// Right  Side  Menus
    lazy var favorBtn: DYButton = {
        let button = DYButton(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
        button.addTarget(self, action: #selector(favorCurrentVideo(_:)), for: .touchUpInside)
        return button
    }()
    lazy var favorLable: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .center
        lable.textColor = UIColor.white
        lable.font = UIFont.systemFont(ofSize: 12)
        lable.text = "34.4w"
        return lable
    }()
    lazy var commentItem: DYControltem = {
        let item = DYControltem(frame: CGRect.zero)
        return item
    }()
    lazy var shareItem: DYControltem = {
        let item = DYControltem(frame: CGRect.zero)
        return item
    }()
    lazy var seriesButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("Ser", for: .normal)
        button.setTitleColor(UIColor.darkGray, for: .normal)
        button.layer.cornerRadius = 25
        button.layer.masksToBounds = true
        button.backgroundColor = UIColor.white
        button.layer.borderColor = UIColor.lightGray.cgColor
        button.layer.borderWidth = 0.5
        button.addTarget(self, action: #selector(showDetailsAction(_:)), for: .touchUpInside)
        return button
    }()
    /// Left Side Menus
    lazy var nameLable: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .left
        lable.textColor = UIColor.white
        lable.font = UIFont.systemFont(ofSize: 16)
        return lable
    }()
    lazy var introLable: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .left
        lable.numberOfLines = 2
        lable.textColor = UIColor(white: 1, alpha: 0.8)
        lable.font = UIFont.systemFont(ofSize: 14)
        lable.text = ""
        return lable
    }()
    
    weak var delegate: QHHomeCollectionViewCellDelegate?
    
    var commentItemClick:(() -> Void)?
    var shareItemClick:(() -> Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpUI()
    }
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setUpUI()
    }
    
    //MARK: Private
    
    func setUpUI() {
        contentView.addSubview(playerStatusBar)
        contentView.addSubview(favorLable)
        contentView.addSubview(favorBtn)
        contentView.addSubview(shareItem)
        contentView.addSubview(commentItem)
        contentView.addSubview(seriesButton)
        contentView.addSubview(introLable)
        contentView.addSubview(nameLable)
        layoutPageSubviews()
        configItems()
    }
    
    func configItems() {
        shareItem.iconImage = "icon_home_share"
        shareItem.title =  "分享"
        commentItem.iconImage = "icon_home_comment"
        commentItem.title = "789"
        shareItem.itemClickHandle = { [weak self] in
            self?.shareItemClick?()
        }
        commentItem.itemClickHandle = { [weak self] in
            self?.commentItemClick?()
        }
    }
    
    //MARK: Action
    @objc func showDetailsAction(_ sender: Any) {
        if let del = delegate {
            del.showDetails(self)
        }
    }
    
    @objc func favorCurrentVideo(_ sender: DYButton) {
        if sender.dyState == .cancel {
            
            print("不喜欢这个Video")
        }
        if sender.dyState == .selected {
            print("喜欢这个Video")
        }
        
    }
    
    func startLoadingPlayItemAnim(_ isStart: Bool = true) {
        if isStart {
            playerStatusBar.backgroundColor = UIColor.green
            playerStatusBar.isHidden = false
            playerStatusBar.layer.removeAllAnimations()
            
            let animationGroup = CAAnimationGroup()
            animationGroup.duration = 0.6
            animationGroup.beginTime = CACurrentMediaTime()
            animationGroup.repeatCount = .infinity
            animationGroup.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
            
            let scaleAnimX = CABasicAnimation()
            scaleAnimX.keyPath = "transform.scale.x"
            scaleAnimX.fromValue = 1.0
            scaleAnimX.toValue = 10.0 * UIScreen.main.bounds.width
            
            let scaleAnimY = CABasicAnimation()
            scaleAnimY.keyPath = "transform.scale.y"
            scaleAnimY.fromValue = 1.0
            scaleAnimY.toValue = 0.2
            
            let alphaAnim = CABasicAnimation()
            alphaAnim.keyPath = "opacity"
            alphaAnim.fromValue = 1.0
            alphaAnim.toValue = 0.4
            
            animationGroup.animations = [scaleAnimX, scaleAnimY, alphaAnim]
            playerStatusBar.layer.add(animationGroup, forKey: nil)
        } else {
            playerStatusBar.layer.removeAllAnimations()
            playerStatusBar.isHidden = true
        }
        
    }
    
    override public func layoutSubviews() {
        super.layoutSubviews()
        playerStatusBar.frame = CGRect(x: self.bounds.midX - 0.5, y: self.bounds.maxY - 48 - safeAreaBottomHeight, width: 0.1, height: 2.5)
       
    }
    
}

// MARK: - layout
private extension QHHomeCollectionViewCell {
    
    func layoutPageSubviews() {
        layoutShareItem()
        layoutCommentItem()
        layoutFavorLable()
        layoutFavorButton()
        layoutSeriesButton()
        layoutIntrolLable()
        layoutNameLable()
    }
    
    func layoutFavorButton() {
        favorBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-15)
            make.bottom.equalTo(favorLable.snp.top)
            make.width.height.equalTo(50)
        }
    }
    func layoutFavorLable() {
        favorLable.snp.makeConstraints { (make) in
            make.centerX.equalTo(commentItem)
            make.bottom.equalTo(commentItem.snp.top).offset(-10)
            make.height.equalTo(20)
            make.width.equalTo(60)
        }
    }
    
    func layoutSeriesButton() {
        seriesButton.snp.makeConstraints { (make) in
            make.trailing.equalTo(-15)
            make.bottom.equalTo(favorBtn.snp.top).offset(-15)
            make.width.height.equalTo(50)
        }
    }
    
    func layoutCommentItem() {
        commentItem.snp.makeConstraints { (make) in
            make.trailing.equalTo(-10)
            make.bottom.equalTo(shareItem.snp.top).offset(-10)
            make.width.equalTo(50)
            make.height.equalTo(60)
        }
    }
    
    func layoutShareItem() {
        shareItem.snp.makeConstraints { (make) in
            make.trailing.equalTo(-10)
            make.bottom.equalTo(-(115 + safeAreaBottomHeight))
            make.width.equalTo(50)
            make.height.equalTo(60)
        }
    }
    
    func layoutIntrolLable() {
        introLable.snp.makeConstraints { (make) in
            make.leading.equalTo(10)
            make.centerY.equalTo(shareItem)
            make.trailing.equalTo(shareItem.snp.leading).offset(-40)
            make.height.equalTo(45)
        }
    }
    
    func layoutNameLable() {
        nameLable.snp.makeConstraints { (make) in
            make.leading.equalTo(introLable)
            make.bottom.equalTo(introLable.snp.top)
            make.height.equalTo(25)
            make.trailing.equalTo(introLable)
        }
    }
   
}

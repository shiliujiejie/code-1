
import UIKit
import MJRefresh
import NicooNetwork
import IQKeyboardManagerSwift

/// 评论列表
class CommentsController: QHBaseViewController {

    lazy var tapGesture: UITapGestureRecognizer = {
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapAndDissmiss(_:)))
        return tap
    }()
    let clearView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.clear
        return view
    }()
    let titleLab: UILabel = {
        let lable = UILabel()
        lable.text = "用户评论"
        lable.textColor = UIColor.lightGray
        lable.backgroundColor = ConstValue.kVcViewColor
        lable.layer.borderWidth = 0.5
        lable.layer.borderColor = ConstValue.kAppSepLineColor.cgColor
        lable.textAlignment = .center
        lable.font = UIFont.systemFont(ofSize: 16)
        return lable
    }()
    private lazy var  closeBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "arrowDown"), for: .normal)
        button.addTarget(self, action: #selector(closeBtnAction), for: .touchUpInside)
        return button
    }()
    private lazy var videoCommentView: VideoCommentView = {
        let view = VideoCommentView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 50))
        view.backgroundColor = ConstValue.kVcViewColor
        return view
    }()
    private lazy var tableView: UITableView = {
        let table = UITableView(frame: view.bounds, style: .plain)
        table.backgroundColor =  UIColor(red: 22/255.0, green: 24/255.0, blue: 36/255.0, alpha: 0.9)   //ConstValue.kVcViewColor
        table.estimatedRowHeight = 100
        table.showsVerticalScrollIndicator = false
        table.showsHorizontalScrollIndicator = false
        table.delegate = self
        table.dataSource = self
        table.separatorStyle = .none
        table.tableFooterView = UIView.init(frame: CGRect.zero)
        table.register(UINib(nibName: "VideoComListCell", bundle: Bundle.main), forCellReuseIdentifier: VideoComListCell.cellId)
        table.mj_footer = loadMoreView
        table.mj_header = refreshView
        return table
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        return MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
    }()
    lazy private var refreshView: MJRefreshGifHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshGifHeader(refreshingBlock: {
            weakSelf?.isRefreshOperation = true
            weakSelf?.loadData()
        })
        var gifImages = [UIImage]()
        for string in ConstValue.refreshImageNames {
            gifImages.append(UIImage(named: string)!)
        }
        mjRefreshHeader?.setImages(gifImages, for: .refreshing)
        mjRefreshHeader?.setImages(gifImages, for: .idle)
        mjRefreshHeader?.stateLabel.font = ConstValue.kRefreshLableFont
        mjRefreshHeader?.lastUpdatedTimeLabel.font = ConstValue.kRefreshLableFont
        return mjRefreshHeader!
    }()
    
    /// 是否是下拉刷新操作
    private var isRefreshOperation = false
    private lazy var commentLsApi: VideoCommentListApi = {
        let api = VideoCommentListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var commentApi: VideoCommentApi = {
        let api = VideoCommentApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var commentAdLsApi: AdCommentListApi = {
        let api = AdCommentListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var commentAdApi: AdCommentApi = {
        let api = AdCommentApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    /// 是否是广告
    var isAd: Bool = false
    var videoId: Int = 0
    var adId: Int = 0
    var commentModels = [VideoCommentModel]()
    var commentMsg = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        clearView.addGestureRecognizer(tapGesture)
        view.addSubview(clearView)
        view.addSubview(titleLab)
        view.addSubview(closeBtn)
        view.addSubview(tableView)
        view.addSubview(videoCommentView)
        layoutPageSubviews()
        addCommentViewCallBackHandler()
        
        //videoCommentView.layer.cornerRadius = 10
        videoCommentView.layer.shadowColor = UIColor.darkGray.cgColor
        videoCommentView.layer.shadowOffset = CGSize()
        videoCommentView.layer.shadowOpacity = 1
        videoCommentView.layer.shadowRadius = 6
        videoCommentView.clipsToBounds = false
       
        loadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        IQKeyboardManager.shared.enable = false
    }
    
    
    private func loadData() {
        NicooErrorView.removeErrorMeesageFrom(self.view)
        if !isRefreshOperation {
            XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        }
        if isAd {
            let _ = commentAdLsApi.loadData()
        } else {
            let _ = commentLsApi.loadData()
        }
    }
    
    private func loadNextPage() {
        if isAd {
             let _ = commentAdLsApi.loadNextPage()
        } else {
             let _ = commentLsApi.loadNextPage()
        }
       
    }
    
    private func commentVideo() {
        if isAd {
            let _ = commentAdApi.loadData()
        } else {
            let _ = commentApi.loadData()
        }
        
    }
    
    private func commentListSuccess(_ listModel: VideoCommentListModel) {
        if let models = listModel.data, let currentPage = listModel.current_page {
            if currentPage ==  1 {
                commentModels = models
                if commentModels.count == 0 {
                    NicooErrorView.showErrorMessage("暂无相关评论，快来说两句吧 ～", on: view, customerTopMargin: ConstValue.kScreenHeight * 0.45, clickHandler: nil)
                }
                if commentModels.count >= VideoCommentListApi.kDefaultCount {
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
            } else {
                commentModels.append(contentsOf: models)
                if models.count >= VideoCommentListApi.kDefaultCount {
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
            }
        }
        endRefreshing()
        tableView.reloadData()
        if commentModels.count > 0 {
            tableView.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: false)
        }
    }
    private func commentListFailed() {
        if !isRefreshOperation {
            NicooErrorView.showErrorMessage(.noNetwork, on: view, topMargin: ConstValue.kScreenHeight * 0.35) {
                self.loadData()
            }
        }
    }
    
    private func endRefreshing() {
        tableView.mj_header.endRefreshing()
        tableView.mj_footer.endRefreshing()
    }

    
    /// 添加评论栏点击回调
    func addCommentViewCallBackHandler() {
        videoCommentView.sendCommentTextHandler = { [weak self] (text) in
            guard let strongSelf = self else { return }
            strongSelf.commentMsg = text
            strongSelf.commentVideo()
        }
    }

    @objc func tapAndDissmiss(_ sender: UITapGestureRecognizer) {
        IQKeyboardManager.shared.enable = true
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc func closeBtnAction() {
        IQKeyboardManager.shared.enable = true
        self.dismiss(animated: true, completion: nil)
    }
    
    private func randomColor(_ userId: Int) -> String {
        let colors = ["#e57373",
                      "#f06292",
                      "#ba68c8",
                      "#9575cd",
                      "#7986cb",
                      "#64b5f6",
                      "#4fc3f7",
                      "#4dd0e1",
                      "#4db6ac",
                      "#81c784",
                      "#aed581",
                      "#ff8a65",
                      "#d4e157",
                      "#ffd54f",
                      "#ffb74d",
                      "#a1887f",
                      "#90a4ae"]
        return colors[Int(userId%17)]
    }

}


// MARK: - UITableViewDelegate, UITableViewDataSource
extension CommentsController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 100.0
        return tableView.rowHeight
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return commentModels.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: VideoComListCell.cellId, for: indexPath) as! VideoComListCell
        let commentModel = commentModels[indexPath.row]
        cell.nameLable.text = commentModel.nikename ?? "老湿"
        cell.contentLable.text = commentModel.content ?? ""
        cell.timeLable.text = commentModel.created_at ?? ""
        cell.headerNameLab.backgroundColor = UIColor(hexadecimalString: randomColor(commentModel.user_id ?? 9))
        if let headerTitle = commentModel.nikename , headerTitle.count > 2 {
            let subTitle =  (headerTitle as NSString).substring(to: 1)
            cell.headerNameLab.text = subTitle
        } else {
            cell.headerNameLab.text = commentModel.nikename ?? "忍"
        }
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension CommentsController: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        if manager is VideoCommentListApi {
            return [VideoCommentListApi.kVideo_Id : videoId]
        }
        if manager is VideoCommentApi {
            return [VideoCommentApi.kVideo_Id : videoId, VideoCommentApi.kContent: commentMsg]
        }
        if manager is AdCommentListApi {
            return [AdCommentListApi.kAd_id: adId]
        }
        if manager is AdCommentApi {
            return [AdCommentApi.kAd_id : adId, AdCommentApi.kContent: commentMsg]
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is VideoCommentListApi || manager is AdCommentListApi {
            if let commentList = manager.fetchJSONData(VideoReformer()) as?  VideoCommentListModel {
                commentListSuccess(commentList)
            }
        }
        if manager is VideoCommentApi || manager is AdCommentApi {
            commentMsg = ""
            self.loadData()
        }
        
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is VideoCommentListApi || manager is AdCommentListApi {
           commentListFailed()
        }
        if manager is VideoCommentApi || manager is AdCommentApi {
            XSAlert.show(type: .error, text: manager.errorMessage)
        }
        
    }
}

// MARK: - Layout
private extension CommentsController {
    
    func layoutPageSubviews() {
        layoutClearView()
        layoutCommentView()
        layoutTableView()
        layoutTitleLable()
        layoutCloseBtn()
    }
    
    func layoutClearView() {
        clearView.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kScreenHeight * 0.35)
        }
    }
    
    func layoutTitleLable() {
        titleLab.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(0)
            make.bottom.equalTo(tableView.snp.top)
            make.height.equalTo(40)
        }
    }
    
    func layoutCloseBtn() {
        closeBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(titleLab)
            make.trailing.equalTo(-10)
            make.width.height.equalTo(40)
        }
    }
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            make.bottom.equalTo(videoCommentView.snp.top)
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(clearView.snp.bottom)
        }
    }
    
    func layoutCommentView() {
        videoCommentView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalToSuperview()
            }
            make.height.equalTo(50)
        }
    }
    
}

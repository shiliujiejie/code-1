//
//  CommentsController.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/3.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

class CommentsController: UIViewController {

    lazy var tapGesture: UITapGestureRecognizer = {
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapAndDissmiss(_:)))
        return tap
    }()
    let clearView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.clear
        return view
    }()
    
    private lazy var tableView: UITableView = {
        let table = UITableView(frame: view.bounds, style: .plain)
        table.backgroundColor = UIColor.white
        table.rowHeight = 60
        table.showsVerticalScrollIndicator = false
        table.showsHorizontalScrollIndicator = false
        table.delegate = self
        table.dataSource = self
        //table.separatorStyle = .none
        table.tableFooterView = UIView.init(frame: CGRect.zero)
//        table.mj_header = refreshView
//        table.mj_footer = loadMoreView
        table.register(UITableViewCell.classForCoder(), forCellReuseIdentifier:"2333ss")
        return table
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        clearView.addGestureRecognizer(tapGesture)
        view.addSubview(clearView)
        view.addSubview(tableView)
        layoutPageSubviews()
    }
    

    @objc func tapAndDissmiss(_ sender: UITapGestureRecognizer) {
        self.dismiss(animated: true, completion: nil)
    }

}


extension CommentsController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "2333ss", for: indexPath)
        //cell.contentView.backgroundColor = UIColor.red
        cell.textLabel?.text = "sssss"
        return cell
    }
    
    
    
}


// MARK: - Layout
private extension CommentsController {
    
    func layoutPageSubviews() {
        layoutClearView()
        layoutTableView()
    }
    
    func layoutClearView() {
        clearView.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kScreenHeight * 0.35)
        }
    }
    
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview()
            make.leading.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kScreenHeight * 0.65)
        }
    }
    
}

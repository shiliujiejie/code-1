//
//  QHHomeViewController.swift
//  QHAwemeDemo
//
//  Created by Anakin chen on 2017/10/16.
//  Copyright © 2017年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import SnapKit
import Kingfisher
import MJRefresh

class QHHomeViewController: QHBaseViewController, UICollectionViewDelegateFlowLayout, UICollectionViewDataSource,  QHHomeCollectionViewCellDelegate {
   
    var currentIndex:Int = 0
    var currentPlayIndex: Int = 0
    //var sourceCount: Int = 0
    
    lazy var screenScaleBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "icon_home_comment"), for: .normal)
        button.addTarget(self, action: #selector(screenScaleSizeChange(_:)), for: .touchUpInside)
        return button
    }()
    lazy var playerView: NicooPlayerView = {
        let player = NicooPlayerView(frame: view.bounds, bothSidesTimelable: true)
        player.videoLayerGravity = .resizeAspect
        player.videoNameShowOnlyFullScreen = true
        player.delegate = self
        player.customViewDelegate = self
        return player
    }()
   
    private let viewModel = VideoViewModel()
    private let userInfoViewModel = UserInfoViewModel()
    private let registerViewModel = RegisterLoginViewModel()
    
    var isRefreshOperation = false
    
    var isFirstIn = true
    
    @IBOutlet weak var mainCV: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(white: 0.0, alpha: 0.1)
        setUpUI()
        addViewModelCallBack()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        playerView.playerStatu = PlayerStatus.Playing
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        playerView.playerStatu = PlayerStatus.Pause
    }
  
    private func setUpUI() {
        //固定设置layut，或者通过UICollectionViewDelegateFlowLayout设置，这样可以动态调整
        if let layout = mainCV.collectionViewLayout as? UICollectionViewFlowLayout {
            //每个Item之间最小的间距
            layout.minimumInteritemSpacing = 0
            //每行之间最小的间距
            layout.minimumLineSpacing = 0
        }
        
        if #available(iOS 11.0, *) {
            mainCV.contentInsetAdjustmentBehavior = .never
        } else {
            self.automaticallyAdjustsScrollViewInsets = false
        }
       // mainCV.mj_header = refreshView
        mainCV.scrollsToTop = false
        mainCV.isScrollEnabled = false
        view.addSubview(screenScaleBtn)
        layoutPageSubviews()
        registerDevice()
        
    }
    
    private func loadData() {
        if !viewModel.isRefreshOperation {
            XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        } else {
            viewModel.isRefreshOperation = false
        }
        viewModel.loadData()
    }
    
    /// 跳转到系列列表页面
    private func p_showDetails() {
        let vc = SeriesVideosController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    //MARK: Public
    func showDetails() {
        p_showDetails()
    }
    
    //MARK: Action
    
    @objc func panAction(_ sender: UIPanGestureRecognizer) {
        print("\(sender)")
    }
    
    @objc func screenScaleSizeChange(_ sender: UIButton) {
                if playerView.videoLayerGravity == .resizeAspect {
                    playerView.videoLayerGravity = .resize
                } else if playerView.videoLayerGravity == .resize {
                    playerView.videoLayerGravity = .resizeAspect
                }
//        if let cell = mainCV.cellForItem(at: IndexPath.init(item: currentIndex, section: 0)) as? QHHomeCollectionViewCell {
//
//            let tran = CGAffineTransform.init(rotationAngle: .pi/2)
//            cell.bgImage.transform = tran
//        }
        
        
    }
    
    /// 设备号注册
    private func registerDevice() {
        if let token = UserDefaults.standard.string(forKey: UserDefaults.kUserToken) {
            UserModel.share().api_token = token
            userInfoViewModel.loadUserInfo()
            loadData()
        } else {
            registerViewModel.registerDevice()
        }
    }
    
    private func addViewModelCallBack() {
        viewModel.requestListSuccessHandle = { [weak self] in
            guard let strongSelf = self else { return }
            //strongSelf.sourceCount = strongSelf.viewModel.getVideoList().count
            if strongSelf.viewModel.sourceCount > 0 {
                 strongSelf.mainCV.isScrollEnabled = true
            }
            strongSelf.mainCV.reloadData()
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
        }
        viewModel.requestFailedHandle = { [weak self] (msg) in
            guard let strongSelf = self else { return }
            XSAlert.show(type: .error, text: "数据走丢了。")
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            
        }
        registerViewModel.loadDeviceRegisterSuccess = { [weak self] in
            self?.loadData()
        }
    }
    
    
    func getCurrentVC() -> QHRootScrollViewController? {
        var next = view.superview
        while (next != nil) {
            let nextResponder = next?.next
            if (nextResponder is QHRootScrollViewController) {
                return nextResponder as? QHRootScrollViewController
            }
            next = next?.superview
        }
        return nil
    }
    
    //MARK: UICollectionViewDataSource
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.getVideoList().count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell : QHHomeCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: QHHomeCollectionViewCell.cellId, for: indexPath) as! QHHomeCollectionViewCell
        cell.backgroundColor = UIColor.darkText
        cell.delegate = self
        let models = viewModel.getVideoList()
        if models.count > indexPath.row {
            let videoModel = models[indexPath.row]
            if let urlImage = URL(string: videoModel.cover_path ?? ""), let urlheade = URL(string: "https://p3.pstatp.com/aweme/100x100/93b000053eeb354d5ad6.jpeg") {
                cell.bgImage.kf.setImage(with: urlImage)
                cell.seriesButton.kf.setBackgroundImage(with: urlheade, for: .normal)
            }
            cell.introLable.text = videoModel.title ?? ""
            cell.commentItem.msgLable.text = String(format: "%d", videoModel.comment_count ?? 0)
            cell.favorLable.text = String(format: "%d", videoModel.appraise_count ?? 0)
            cell.favorBtn.dyState = (videoModel.recommend?.isFavor ?? false) ? DYButton.DYButtonState.selected : DYButton.DYButtonState.cancel
            /// 第一次进入，播放第一条
            if indexPath.row == 0 && isFirstIn {
                let url = URL(string: "https://hls-hw.xvideos-cdn.com/videos/hls/f3/22/b0/f322b06901263d6279c92517659ea937/hls.m3u8?e=1551958082&l=0&h=c738ee164ec51ec0f8b47abac3df9029")   //URL(string: models[0].play_url_m3u8 ?? "")
                self.playerView.playVideo(url, "", cell.bgImage)
                isFirstIn = false
                cell.startLoadingPlayItemAnim(true)
            }
        }
        cell.commentItemClick = { [weak self] in
            let commentVC = CommentsController()
            commentVC.modalPresentationStyle = .overCurrentContext
            commentVC.definesPresentationContext = true
            commentVC.view.backgroundColor = UIColor(white: 0.0, alpha: 0.3)
          self?.present(commentVC, animated: true, completion: nil)
        }
        cell.shareItemClick = { [weak self] in
            self?.share()
//            LoginManager().login { [weak self] in
//
//            }
        }
        
        return cell
    }
    
    //MARK: UICollectionViewDelegate

    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return UIScreen.main.bounds.size;
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
    }
 
}


// MARK: - UIGestureRecognizerDelegate
extension QHHomeViewController: UIGestureRecognizerDelegate {
    
    //MARK: UIGestureRecognizerDelegate
    
    func showDetails(_ view: QHHomeCollectionViewCell) {
        p_showDetails()
    }
    
}

// MARK: - UIScrollViewDelegate
extension QHHomeViewController: UIScrollViewDelegate {
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        DispatchQueue.main.async {
            /// 禁用手势
            let translatedPoint = scrollView.panGestureRecognizer.translation(in: scrollView)
            scrollView.panGestureRecognizer.isEnabled = false
            
            if translatedPoint.y < -50 && self.currentIndex < (self.viewModel.getVideoList().count - 1) {
                /// 上滑
                self.currentIndex += 1
            }
            if translatedPoint.y > 50 && self.currentIndex > 0 {
                /// 下滑
                self.currentIndex -= 1
            }
            if self.currentIndex == self.viewModel.sourceCount - 1 {
                self.mainCV.reloadData()
                self.viewModel.sourceCount = self.viewModel.getVideoList().count
            }
            let indexPath = IndexPath(row: self.currentIndex, section: 0)
            UIView.animate(withDuration: 0.15, delay: 0.0, options: .curveEaseOut, animations: {
                self.mainCV.scrollToItem(at: indexPath, at: .top, animated: true)
            }, completion: { finished in
                scrollView.panGestureRecognizer.isEnabled = true
                if let cell = self.mainCV.cellForItem(at: indexPath) as? QHHomeCollectionViewCell {
                    if self.currentPlayIndex != self.currentIndex { // 上下滑动
                        let urlstr = self.viewModel.getVideoList()[indexPath.row].play_url_m3u8
                        let url = URL(string: urlstr ?? "")
                        self.playerView.playVideo(url, "", cell.bgImage)
                        cell.startLoadingPlayItemAnim(true)
                        self.currentPlayIndex = self.currentIndex
                    }
                }
                
                if self.currentIndex == self.viewModel.getVideoList().count - 4 {
                    print("给您补给数据。。， ")
                    self.viewModel.loadNextPage()
                    // 这里先不刷新
                }
            })
        }
    }
}

// MARK: - NicooPlayerDelegate

extension QHHomeViewController: NicooPlayerDelegate, NicooCustomMuneDelegate {
    
    func customTopBarActions() -> [UIButton]? {
        var buttonS = [UIButton]()
        //        for i in 0..<3 {
        //            let button = UIButton(type: .custom)
        //            button.backgroundColor = UIColor.white
        //            button.setImage(UIImage(named: ["collection","downLoad","shareAction"][i]), for: .normal)
        //            button.addTarget(self, action: #selector(topBarCustonButtonClick(_:)), for: .touchUpInside)
        //            buttonS.append(button)
        //        }
        return buttonS
    }
    
    func retryToPlayVideo(_ player: NicooPlayerView, _ videoModel: NicooVideoModel?, _ fatherView: UIView?) {
        print("网络不可用时调用")
        let url = URL(string: videoModel?.videoUrl ?? "")
        if  let sinceTime = videoModel?.videoPlaySinceTime, sinceTime > 0 {
            player.replayVideo(url, videoModel?.videoName, fatherView, sinceTime)
        } else {
            player.playVideo(url, videoModel?.videoName, fatherView)
        }
    }
    
    func showOrHideLoadingview(_ isPlaying: Bool) {
        let indexPath = IndexPath(row: self.currentIndex, section: 0)
        if let cell = self.mainCV.cellForItem(at: indexPath) as? QHHomeCollectionViewCell {
            
            cell.startLoadingPlayItemAnim(!isPlaying)
           
        }
    }
    
    func enableScrollAndPanGestureOrNoteWith(isEnable: Bool) {
        (self.navigationController as! QHNavigationController).pan?.isEnabled = isEnable
        if let vc = getCurrentVC() {
            vc.mainScrollV.isScrollEnabled = isEnable
        }
    }
    
    
}

// MARK: - Layout
private extension QHHomeViewController {
    
    func layoutPageSubviews() {
        layoutScaleChangeBtn()
    }
    
    func layoutScaleChangeBtn() {
        screenScaleBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-20)
            make.top.equalTo(80)
            make.width.height.equalTo(50)
        }
    }
}

//
//  UserModel.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/14.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 用户单利
class UserModel: Codable {
    
    static private let shareModel: UserModel = UserModel()
    class func share() -> UserModel {
        return shareModel
    }
    var userInfo: UserInfoModel?
    /// 是否已登录
    var isLogin: Bool = false
    /// 是否是真实注册用户
    var isRealUser: Bool = false
}

/// 上传任务管理单利
class UploadTask: NSObject {
    static private let task: UploadTask = UploadTask()
    class func shareTask() -> UploadTask {
        return task
    }
    var tasks: [PushPresenter]?
}

/// 系统单利
class SystemMsg: Codable {
    static private let shareMsg: SystemMsg = SystemMsg()
    class func share() -> SystemMsg {
        return shareMsg
    }
    var systemMsgs: [SystemMsgModel]?
    var videoChannels: [VideoChannelModel]?
}

/// 系统公告
struct SystemMsgModel: Codable {
    var id: Int?
    var message: String?
    var status: Int?
    var created_at: String?
    var updated_at: String?
}

/// 线路
struct VideoChannelModel: Codable {
    var id: Int?
    var title: String?
    var key: String?
    var domain: String?
    var status: Int?
    var sort: Int?
    var remark: String?
    var created_at: String?
    var updated_at: String?
}

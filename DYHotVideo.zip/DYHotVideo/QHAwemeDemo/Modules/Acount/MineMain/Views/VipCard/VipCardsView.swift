//
//  VipCardsView.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/12.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

/// VipCardView
class VipCardsView: UIView {

    let vipCardBgImage: UIImageView = {
        let image = UIImageView()
        image.contentMode = .scaleAspectFill
        image.clipsToBounds = true
        return image
    }()
    let cardBottomView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(white: 1, alpha: 0.15)
        return view
    }()
    let cardNameImage: UIImageView = {
        let image = UIImageView()
        image.contentMode = .scaleAspectFit
        return image
    }()
    let cardMsgLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 12)
        lable.textColor = UIColor.darkText
        lable.lineBreakMode = .byCharWrapping
        lable.numberOfLines = 2
        return lable
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(vipCardBgImage)
        addSubview(cardNameImage)
        addSubview(cardBottomView)
        cardBottomView.addSubview(cardMsgLable)
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        cardBottomView.backgroundColor = UIColor(white: 1, alpha: 0.15)
        //vipCardBgImage.contentMode = .scaleAspectFill
      
    }
    
    func setCardLayer(cardLayer: VipCardLayer) {
        vipCardBgImage.image = UIImage(named: cardLayer.cardBgName ?? "")
        cardNameImage.image = UIImage(named: cardLayer.cardName ?? "")
        
        if cardLayer.cardType == VipKey.card_Normal || cardLayer.cardType == VipKey.card_Novice || cardLayer.cardType == VipKey.card_TiYan {
            cardMsgLable.textColor = UIColor.darkText
        } else if cardLayer.cardType == VipKey.card_YouXiang ||  cardLayer.cardType == VipKey.card_GuiBing {
            cardMsgLable.textColor = UIColor(red: 122/255.0, green: 74/255.0, blue: 49/255.0, alpha: 1)
        } else {
            cardMsgLable.textColor = UIColor(red: 213/255.0, green: 174/255.0, blue: 114/255.0, alpha: 1)
        }
    }
}


// MARK: - Layout
private extension VipCardsView {
    
    func layoutPageSubviews() {
        layoutVipCardBgImage()
        layoutCardBottomView()
        layoutCardNameImage()
        layoutCardMsgLable()
        
    }
    func layoutVipCardBgImage() {
        vipCardBgImage.snp.makeConstraints { (make) in
            make.top.equalTo(15)
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.height.equalTo((ConstValue.kScreenWdith - 30)/2.4)
        }
        
    }
    func layoutCardBottomView() {
        cardBottomView.snp.makeConstraints { (make) in
            make.leading.trailing.bottom.equalTo(vipCardBgImage)
            make.height.equalTo(55)
        }
    }
    func layoutCardNameImage() {
        cardNameImage.snp.makeConstraints { (make) in
            make.leading.equalTo(vipCardBgImage.snp.leading).offset(25)
            make.top.equalTo(vipCardBgImage).offset(25)
            make.width.equalTo(100)
            make.height.equalTo(45)
        }
    }
    
    func layoutCardMsgLable() {
        cardMsgLable.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.height.equalTo(50)
            make.centerY.equalToSuperview()
        }
    }
    
}

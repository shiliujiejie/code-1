//
//  PayTypeChoseCell.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/26.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

class PayTypeChoseCell: UITableViewCell {
    
    static let cellId = "PayTypeChoseCell"
    
    lazy var payOneBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("支付宝", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        button.setTitleColor(UIColor.white, for: .normal)
        button.setTitleColor(ConstValue.kTitleYelloColor, for: .selected)
        button.setTitleColor(UIColor.gray, for: .disabled)
        button.setImage(UIImage(named: "zhifubaoIcon"), for: .normal)
        button.setBackgroundImage(UIImage(named: "payTypeBtnback"), for: .selected)
        button.setImage(UIImage(named: "alipayenAble"), for: .disabled)
        button.setBackgroundImage(UIImage(named: ""), for: .normal)
        button.layer.cornerRadius = 5
        button.layer.borderColor = ConstValue.kTitleYelloColor.cgColor
        button.layer.borderWidth = 1.0
        button.layer.masksToBounds = true
        button.titleEdgeInsets = UIEdgeInsets.init(top: 0, left: 10, bottom: 0, right: 0)
        button.isSelected = true
        button.addTarget(self, action: #selector(alipayItemClick(_:)), for: .touchUpInside)
        return button
    }()
    lazy var payTwoBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("微信支付", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        button.setTitleColor(UIColor.white, for: .normal)
        button.setTitleColor(ConstValue.kTitleYelloColor, for: .selected)
        button.setTitleColor(UIColor.gray, for: .disabled)
        button.setImage(UIImage(named: "wechatIcon"), for: .normal)
        button.setImage(UIImage(named: "wechatPayEnble"), for: .disabled)
        button.setBackgroundImage(UIImage(named: "payTypeBtnback"), for: .selected)
        button.setBackgroundImage(UIImage(named: ""), for: .normal)
        button.layer.cornerRadius = 5
        button.layer.borderColor = UIColor.gray.cgColor
        button.layer.borderWidth = 1.0
        button.layer.masksToBounds = true
        button.titleEdgeInsets = UIEdgeInsets.init(top: 0, left: 10, bottom: 0, right: 0)
        button.addTarget(self, action: #selector(wechatpayItemClick(_:)), for: .touchUpInside)
        return button
    }()
    var payTypeSelectedHandler:((_ index: Int) -> Void)?

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.backgroundColor = UIColor.clear
        self.backgroundColor = UIColor.clear
        contentView.addSubview(payOneBtn)
        contentView.addSubview(payTwoBtn)
        layoutPageSubview()
        //setPayTypeEnable()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setPayTypeEnable() {
        payTwoBtn.isEnabled = false
        payTwoBtn.layer.borderColor = UIColor.gray.cgColor
    }
    
    @objc private func alipayItemClick(_ sender: UIButton) {
        sender.isSelected = true
        sender.layer.borderColor = ConstValue.kTitleYelloColor.cgColor
        payTwoBtn.isSelected = false
        payTwoBtn.layer.borderColor = UIColor.gray.cgColor
        payTypeSelectedHandler?(1)
    }
    
    @objc private func wechatpayItemClick(_ sender: UIButton) {
        sender.isSelected = true
        sender.layer.borderColor = ConstValue.kTitleYelloColor.cgColor
        payOneBtn.isSelected = false
        payOneBtn.layer.borderColor = UIColor.gray.cgColor
        payTypeSelectedHandler?(2)
    }
}

// MARK: - Layout
private extension PayTypeChoseCell {
    func layoutPageSubview() {
        layoutAlipayButton()
        layoutWechatPayButton()
    }
    
    func layoutAlipayButton() {
        payOneBtn.snp.makeConstraints { (make) in
            make.leading.equalTo(25)
            make.centerY.equalToSuperview()
            make.height.equalTo(50)
            make.width.equalTo(110)
        }
    }
    
    func layoutWechatPayButton() {
        payTwoBtn.snp.makeConstraints { (make) in
            make.leading.equalTo(payOneBtn.snp.trailing).offset(20)
            make.centerY.equalToSuperview()
            make.height.equalTo(50)
            make.width.equalTo(110)
        }
    }
}


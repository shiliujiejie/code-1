//
//  IDCardView.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/4/17.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

class IDCardView: UIView {

    @IBOutlet weak var containerView: UIView!
    
    @IBOutlet weak var logalImage: UIImageView!
    
    @IBOutlet weak var nickNameLable: UILabel!
    
    @IBOutlet weak var userNameLabel: UILabel!
    
    @IBOutlet weak var copyButton: UIButton!
    
    @IBOutlet weak var userIDCode: UILabel!
    
    @IBOutlet weak var userIDCodeTitle: UILabel!
    
    @IBOutlet weak var qrCodeImage: UIImageView!
    
    @IBOutlet weak var webSiteLable: UILabel!
    
    @IBOutlet weak var tipsLabel: UILabel!
    
    @IBOutlet weak var saveButton: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = UIColor.clear
        self.containerView.backgroundColor = UIColor(red: 71/255.0, green: 76/255.0, blue: 96/255.0, alpha: 1)
        self.containerView.layer.cornerRadius = 10
        self.containerView.layer.masksToBounds = true
        logalImage.layer.cornerRadius = 25
        logalImage.layer.masksToBounds = true
        logalImage.layer.borderColor = UIColor.white.cgColor
        logalImage.layer.borderWidth = 1.0
        saveButton.layer.cornerRadius = 25
        saveButton.layer.masksToBounds = true
        saveButton.backgroundColor = UIColor(red: 235/255.0 , green: 94/255.0, blue: 71/255.0, alpha: 0.99)
        webSiteLable.layer.cornerRadius = 15
        webSiteLable.layer.masksToBounds = true
        webSiteLable.backgroundColor = UIColor.gray
        setUpUI()
    }
    
    func setUpUI() {
        let userInfo = UserModel.share().userInfo
        nickNameLable.text = userInfo?.nikename ?? "老湿"
        userNameLabel.text = "编码: \(userInfo?.name ?? "--")"
        //userIDCode.text = userInfo?.code ?? ""
        let uidSalt = "\(userInfo?.id ?? 0)\(userInfo?.salt ?? "")"
        if !uidSalt.isEmpty {
            let idFake = "dyqra/\(uidSalt)"
            createQRCode(idFake.encodeWithXorByte(key: 101))
        }
        webSiteLable.text = "官网地址: \(ConstValue.kAppDownLoadLoadUrl)"
    }

    
    @IBAction func saveImage(_ sender: UIButton) {
        let image = screenSnapshot(save: true)
        if  image != nil {
            let showMessage = "保存成功！"
            XSAlert.show(type: .success, text: showMessage)
        }
    }
    
    func createQRCode(_ idString: String) {
        let qrImg = LBXScanWrapper.createCode(codeType: "CIQRCodeGenerator", codeString: idString, size: CGSize(width: 120, height: 120), qrColor: UIColor.black, bkColor: UIColor.white)
        qrCodeImage.image = qrImg //LBXScanWrapper.addImageLogo(srcImg: qrImg!, logoImg: logoImg!, logoSize: CGSize(width: 30, height: 30))
    }
    
    @IBAction func copyCode(_ sender: UIButton) {
        
    }
    
    private func screenSnapshot(save: Bool) -> UIImage? {
        guard let window = UIApplication.shared.keyWindow else { return nil }
        // 用下面这行而不是UIGraphicsBeginImageContext()，因为前者支持Retina
        UIGraphicsBeginImageContextWithOptions(window.bounds.size, false, 0.0)
        window.layer.render(in: UIGraphicsGetCurrentContext()!)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        if save { UIImageWriteToSavedPhotosAlbum(image ?? qrCodeImage.image!, self, nil, nil) }
        return image
    }
}

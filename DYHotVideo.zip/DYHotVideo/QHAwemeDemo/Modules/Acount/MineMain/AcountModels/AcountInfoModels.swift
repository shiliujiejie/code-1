//
//  AcountInfoModels.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/17.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import Foundation


/// ----- 订单列表model
struct OrderListModel: Codable {
    var current_page: Int?
    var data:[OrderInfoModel]?
}

/// ----- 订单model
struct OrderInfoModel: Codable {
    var id: Int?
    var order_no: String?  // 订单号
    var order_type: Int? //订单类型
    var vc_title: String?
    var vc_daily_until: Int?
    var pay_status_label: String?
    var pay_status: Int?
    var paid_at: String?
    var price_original: String?
    var price_current: String?
    var status: Int? // ding
  
}


struct VipCardListModel: Codable {
    var current_page: Int?
    var data: [VipCardModel]?
}

/// -----  VIP cards
struct VipCardModel: Codable {
    var id: Int?
    var title: String?  // 卡片名
    var key: VipKey? //卡片类型
    var remark: String?
    var daily_until: Int? // 使用天数
    var view_count_daily: Int? // 每天使用次数 ,0 表示无限次数 或者没有次数。取决于卡的类型
    var price_original: String? // 正常价格
    var price_current: String?  // 当前价格
    var level: Int? // 卡等级 1 - 6
    var sort: Int? // 排序号
    var status: Int? //
    var display: Int?
    var created_at: String?
}


/// VIP 卡类型
///
/// - card_Novice: 新手卡
/// - card_Normal: 游客卡
/// - card_TiYan: 体验卡
/// - card_YouXiang: 优享卡
/// - card_GuiBing: 贵宾卡
/// - card_ZhiZun: 至尊卡
enum VipKey: String, Codable {
    case card_Novice = "NOVICE"
    case card_Normal = "NORMAL"
    case card_TiYan  = "TIYAN"
    case card_YouXiang = "YOUXIANG"
    case card_GuiBing  = "GUIBING"
    case card_ZhiZun  = "ZHIZUN"
}


/// 已获得 折扣卡 列表
struct  WelfareGetCardList: Codable {
    var current_page: Int?
    var data:[WelfareGetCard]?
}

/// 折扣卡 统一
struct WelfareGetCard: Codable {
    var id: Int?
    var vc_id: Int?
    var wc_id: Int?
   
    var title: String?
    var remark: String?
    var discount: String?   // 折扣
    var invite_mini: Int?
    
    var user_id: Int?
    var created_at: String?
    var status: Int?
    var expire: String? // 有效期
}

/// 未获得卡
struct WelfareUnowedCard: Codable {
    var id: Int?
    var invite_count: Int?
    var title: String?
    var remark: String?
    var discount: String?   // 折扣
    var invite_mini: Int?

}


/// 用户邀请历史列表 model
struct InviteListModel: Codable {
    var current_page: Int?
    var data: [inviteUserModel]?
}

struct inviteUserModel: Codable {
    var code: String?
    var owner_user_id: Int?
    var name: String?
    var nikename: String?
    var mobile: String?
    var use_user_id: Int?
    var created_at: String?
}


/// 订单详情
struct OrderDetailModel: Codable {
    var id: Int?
    var title: String?
    var remark: String?
    var price_original: String?
    var price_current: String?
    var welfareCard: [WelfareGetCard]?
}

/// 是否强制更新
enum GoPay: Int, Codable {
    case enable = 0
    case disable = 1
    var allowPay: Bool {
        switch self {
        case .enable:
            return true
        case .disable:
            return false
        }
    }
}
/// 订单model
struct OrderAddModel: Codable {
    var oid: String?
    var payUrl: String?
    var sign: String?
    var target: GoPay?
}

/// 是否强制更新
enum PayTypeState: Int, Codable {
    case disable = 0
    case enable = 1
    var allowPay: Bool {
        switch self {
        case .enable:
            return true
        case .disable:
            return false
        }
    }
}

/// 支付方式列表
struct PayTypeModel: Codable {
    var id: Int?
    var title: String?
    var key: String?
    var status: PayTypeState?
    var created_at: String?
    var updated_at: String?
}


/// 问题列表
struct QuestionModel: Codable {
    var key: String?
    var value: String?
}

//
//  AcountViewModel.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/4/18.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

/// 用于处理页面代码太多的网络请求，数据处理
class AcountViewModel: NSObject {
    
   
}

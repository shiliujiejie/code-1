//
//  VipCardsController.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/12.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import NicooNetwork

/// 会员卡
class VipCardsController: UIViewController {
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    private lazy var navBar: QHNavigationBar = {
        let bar = QHNavigationBar()
        bar.titleLabel.text = "VIP会员"
        bar.titleLabel.textColor = UIColor.white
        bar.backgroundColor = UIColor.clear
        bar.delegate = self
        return bar
    }()
//    private let lineView: UIView = {
//        let view = UIView()
//        view.backgroundColor = ConstValue.kAppSepLineColor
//        return view
//    }()
    private lazy var recordBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("购买记录", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        button.setTitleColor(ConstValue.kTitleYelloColor, for: .normal)
        button.addTarget(self, action: #selector(recordBtnBtnClick(_:)), for: .touchUpInside)
        // button.isHidden = true
        return button
    }()
    
    private lazy var userView: UserInfoCardView = {
        guard let view = Bundle.main.loadNibNamed("UserInfoCardView", owner: nil, options: nil)?[0] as? UserInfoCardView else { return UserInfoCardView() }
        view.frame = CGRect(x: 0, y: 0, width: view.bounds.width, height: 90)
        return view
    }()
    
    private lazy var tableView: UITableView = {
        let table = UITableView()
        table.backgroundColor = UIColor.clear
        table.showsVerticalScrollIndicator = false
        table.allowsSelection = false
        table.delegate = self
        table.dataSource = self
        table.separatorStyle = .none
        table.register(UINib(nibName: "VipCardsCell", bundle: Bundle.main), forCellReuseIdentifier: VipCardsCell.cellId)
        return table
    }()
    private lazy var vipCardApi: VipCardsApi = {
        let api = VipCardsApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var buyActionApi: UserBuyVipActionApi = {
        let api = UserBuyVipActionApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    
    var vipCards = [VipCardModel]()
    var selectedIndex: Int = 0
    
    var orderDetailModel: OrderDetailModel?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        navBar.navBarView.addSubview(recordBtn)
        view.addSubview(navBar)
        view.addSubview(userView)
        view.addSubview(tableView)
        layoutPageSubviews()
        loadData()
        setUpUserView()
    }
    
    private func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        let _ = vipCardApi.loadData()
    }
    
    private func setUpUserView() {
        userView.nickNameLab.text = UserModel.share().userInfo?.nikename ?? "老湿"
        if let headerTitle = UserModel.share().userInfo?.nikename , headerTitle.count > 2 {
            let subTitle =  (headerTitle as NSString).substring(to: 1)
            userView.headerLable.text = subTitle
        } else {
            userView.headerLable.text = UserModel.share().userInfo?.nikename ?? "老湿"
        }
        userView.cardTypeName.text = UserModel.share().userInfo?.vip_card?.title ?? "游客卡"
        if let cardKey = UserModel.share().userInfo?.vip_card?.key {
            if cardKey == VipKey.card_Normal || cardKey == VipKey.card_Novice {
                userView.tipsLab.text = "开通VIP 享无限次观看"
            } else {
                userView.tipsLab.text = "您是尊敬的\(UserModel.share().userInfo?.vip_card?.title ?? "")会员用户。"
            }
        } else {
            userView.tipsLab.text = "开通VIP 享无限次观看"
        }
    }
    
    private func loadWelfareCardData() {
        let _ = buyActionApi.loadData()
    }
    
    @objc func recordBtnBtnClick(_ sender: UIButton) {
        let payRecordVC = PayRecordController()
        navigationController?.pushViewController(payRecordVC, animated: true)
    }
    
}

// MARK: - QHNavigationBarDelegate
extension VipCardsController:  QHNavigationBarDelegate  {
    
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension VipCardsController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 140
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return vipCards.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: VipCardsCell.cellId, for: indexPath) as! VipCardsCell
        let cardModel = vipCards[indexPath.row]
        cell.pricceLable.textColor = VipCardManager.getCardTitleColorWith(cardType: cardModel.key ?? .card_YouXiang)
        cell.msglable.textColor = VipCardManager.getCardMsgColorWith(cardType: cardModel.key ?? .card_YouXiang)
        cell.cardImageBg.image = VipCardManager.getCardBgImageWith(cardType: cardModel.key ?? .card_YouXiang)
        cell.tipsLab.isHidden = indexPath.row != 0
        cell.pricceLable.text = cardModel.price_current ?? "0"
        cell.msglable.text = "\(cardModel.title ?? "")" + " · " + "\(cardModel.remark ?? "")"
        
        cell.buyCardActionHandler = { [weak self] in
            self?.selectedIndex = indexPath.row
            self?.loadWelfareCardData()
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        
    }
    
    
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension VipCardsController: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        if manager is UserBuyVipActionApi {
            let model = vipCards[selectedIndex]
            return [UserBuyVipActionApi.kVip_id: model.id ?? 0]
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is VipCardsApi {
            if let cardList = manager.fetchJSONData(UserReformer()) as? VipCardListModel {
                if let list = cardList.data {
                    vipCards = list
                    tableView.reloadData()
                }
            }
        }
        if manager is UserBuyVipActionApi {
            if let orderDetail = manager.fetchJSONData(UserReformer()) as? OrderDetailModel {
                let orderVC = OrderConfirmController()
                orderVC.cardModel = vipCards[selectedIndex]
                orderVC.orderdetail = orderDetail
                navigationController?.pushViewController(orderVC, animated: true)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is VipCardsApi {
            NicooErrorView.showErrorMessage(.noData, on: view, clickHandler: {
                self.loadData()
            })
        }
        if manager is UserBuyVipActionApi {
            let orderVC = OrderConfirmController()
            orderVC.cardModel = vipCards[selectedIndex]
            navigationController?.pushViewController(orderVC, animated: true)
        }
        
    }
}



// MARK: - Layout
private extension VipCardsController {
    
    func layoutPageSubviews() {
        layoutNavBar()
        layoutRecordBtn()
        layoutUserInfoView()
        layoutTableView()
    }
    
    func layoutUserInfoView() {
        userView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(navBar.snp.bottom)
            make.height.equalTo(70)
        }
    }
    
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalToSuperview()
            }
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(userView.snp.bottom)
        }
    }
    
    func layoutNavBar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kStatusBarHeight + 44)
        }
    }
    
    func layoutRecordBtn() {
        recordBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-12)
            make.centerY.equalToSuperview()
            make.width.equalTo(65)
            make.height.equalTo(35)
        }
    }
    
}



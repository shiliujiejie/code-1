//
//  QHMineViewController.swift
//  QHAwemeDemo
//
//  Created by Anakin chen on 2017/10/16.
//  Copyright © 2017年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import LTScrollView
private let glt_iphoneX = (UIScreen.main.bounds.height >= 812.0)

class QHMineViewController: QHBaseViewController {

    lazy var viewControllers: [UIViewController] = {
        let oneVc = FavorVideosController()
        let twoVc = WorkVideosController()
        return [oneVc, twoVc]
    }()
    private lazy var navBar: QHNavigationBar = {
        let bar = QHNavigationBar()
        bar.titleLabel.text = UserModel.share().userInfo?.nikename ?? "老湿"
        bar.titleLabel.textColor = UIColor.white
        bar.backgroundColor = UIColor.clear
        bar.backButton.isHidden = true
        bar.titleLabel.isHidden = true
        bar.lineView.isHidden = true
        bar.delegate = self
        return bar
    }()
    private lazy var seriverButton: ServerButton = {
        let frame = CGRect.init(x: ConstValue.kScreenWdith - 80, y: 345 + ConstValue.kStatusBarHeight + 60, width: 60, height: 60)
        let allbutton = ServerButton(frame: frame)
        allbutton.radiuOfButton = 30
        allbutton.paddingOfbutton = 15
        allbutton.delegate = self
        allbutton.setImage(UIImage(named: "touchBtn"), for: .normal)
        return allbutton
    }()
    private lazy var userInfoHeader: AcountHeaderView = {
        if let satisfyAlert = Bundle.main.loadNibNamed("AcountHeaderView", owner: nil, options: nil)?[0] as? AcountHeaderView {
            satisfyAlert.frame = CGRect(x: 0, y: 0, width: view.bounds.width, height: 345 + ConstValue.kStatusBarHeight)
            satisfyAlert.imgTopMargin.constant = ConstValue.kStatusBarHeight + 44
            addHeaderItemCLickHandler(satisfyAlert)
            return satisfyAlert
        }
        return AcountHeaderView()
    }()
    private lazy var settingBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "settingBtn"), for: .normal)
        button.addTarget(self, action: #selector(settingBtnClick(_:)), for: .touchUpInside)
       // button.isHidden = true
        return button
    }()
    private lazy var msgBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "msgAcountIcon"), for: .normal)
        button.addTarget(self, action: #selector(msgBtnClick(_:)), for: .touchUpInside)
        button.isHidden = true
        return button
    }()
    
    private lazy var titles: [String] = {
        return ["喜欢", "作品"]
    }()
    
    private lazy var layout: LTLayout = {
        let layout = LTLayout()
        layout.isAverage = true
        layout.titleViewBgColor = UIColor(red: 35/255.0, green: 38/255.0, blue: 53/255.0, alpha: 0.99)
        layout.sliderWidth = 80
        layout.titleColor = UIColor(red: 255/255.0, green: 255/255.0, blue: 255/255.0, alpha: 1)
        layout.titleFont = UIFont.systemFont(ofSize: 14)
        layout.scale = 1.2
        layout.pageBottomLineHeight = 0.1
        layout.titleSelectColor = UIColor(red: 251/255.0, green: 211/255.0, blue: 16/255.0, alpha: 0.99)
        layout.bottomLineColor = UIColor(red: 251/255.0, green: 211/255.0, blue: 16/255.0, alpha: 0.99)
        /* 更多属性设置请参考 LTLayout 中 public 属性说明 */
        return layout
    }()
    
    private func managerReact() -> CGRect {
        return CGRect(x: 0, y: 0, width: view.bounds.width, height: ConstValue.kScreenHeight)
    }
    
    private lazy var advancedManager: LTAdvancedManager = {
        let advancedManager = LTAdvancedManager(frame: managerReact(), viewControllers: viewControllers, titles: titles, currentViewController: self, layout: layout, headerViewHandle: {[weak self] in
            guard let strongSelf = self else { return UIView() }
            let headerView = strongSelf.userInfoHeader
            return headerView
        })
        /* 设置代理 监听滚动 */
        advancedManager.delegate = self
        advancedManager.backgroundColor = UIColor.clear
        
        /* 设置悬停位置 */
        let statusBarH = UIApplication.shared.statusBarFrame.size.height
        advancedManager.hoverY = 44 + statusBarH
        
        /* 点击切换滚动过程动画 */
        //        advancedManager.isClickScrollAnimation = true
        
        /* 代码设置滚动到第几个位置 */
        //        advancedManager.scrollToIndex(index: viewControllers.count - 1)
        
        return advancedManager
    }()
    private let userViewModel = UserInfoViewModel()
    
    
    deinit {
        print(" < --> deinit")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        view.backgroundColor = ConstValue.kVcViewColor
        self.automaticallyAdjustsScrollViewInsets = false
        view.addSubview(advancedManager)
        advancedManagerConfig()
        navBar.navBarView.addSubview(settingBtn)
        navBar.navBarView.addSubview(msgBtn)
        view.addSubview(navBar)
        layoutPageSubviews()
        setUpUserInfo()
        userInfoViewModelCallBack()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        userViewModel.loadUserInfo()
        view.addSubview(seriverButton)
    }
    
    @objc func settingBtnClick(_ sender: UIButton) {
        let settingVC = SettingController()
        navigationController?.pushViewController(settingVC, animated: true)
    }
    
    @objc func msgBtnClick(_ sender: UIButton) {
        let msgVC = MsgCenterController()
        navigationController?.pushViewController(msgVC, animated: true)
    } 
    
}

// MARK: - FloatDelegate
extension QHMineViewController: FloatDelegate {
    
    func singleClick() {
        if let url = URL(string: AppInfo.share().potato_invite_link ?? "") {
            if #available(iOS 10, *) {
                UIApplication.shared.open(url, options: [:], completionHandler: { (success) in
                })
            } else {
                UIApplication.shared.openURL(url)
            }
        }
    }
    
    func repeatClick() {
        
    }
    
}

// MARK: - Create Header View
extension QHMineViewController {
    
    private func userInfoViewModelCallBack() {
        userViewModel.loadUserInfoSuccessHandler = { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.setUpUserInfo()
            strongSelf.checkVipCardUpOrNot()
        }
    }
    
    private func setUpUserInfo() {
        let userInfo = UserModel.share().userInfo
        let cardLayer = VipCardManager.fixVipWithCardType(cardType: userInfo?.vip_card?.key ?? VipKey.card_Normal)
        userInfoHeader.setCardLayer(cardLayer: cardLayer)
        
        userInfoHeader.nickName.text = userInfo?.nikename ?? "匿名"
        if let headerTitle = userInfo?.nikename , headerTitle.count > 2 {
            let subTitle =  (headerTitle as NSString).substring(to: 1)
            userInfoHeader.headLable.text = subTitle
        } else {
            userInfoHeader.headLable.text = userInfo?.nikename ?? "匿名"
        }
        if let phone = userInfo?.mobile, !phone.isEmpty {
            userInfoHeader.userIdLab.text = phone
        } else {
            userInfoHeader.userIdLab.text = "开通VIP 享无限次观看"
        }
        userInfoHeader.leaseCountLab.text =  "\(UserModel.share().userInfo?.remain_count ?? "--")"
        userInfoHeader.leaseDayCountLab.text = "\(userInfo?.vip_remain_day ?? "--")"
        userInfoHeader.endTimeLab.text = "\(userInfo?.vip_expire ?? "--")"
        userInfoHeader.scoreBtn.setTitle(String(format: "邀请数: %d", userInfo?.invite_count ?? 0), for: .normal)
        if let welfCount = userInfo?.wc_count, welfCount > 0 {
            userInfoHeader.welfCardCountLable.text = "\(welfCount)"
            userInfoHeader.welfCardCountLable.isHidden = false
        } else {
            userInfoHeader.welfCardCountLable.isHidden = true
        }
    }
    
    private func addHeaderItemCLickHandler(_ view: AcountHeaderView) {
        view.buttonItemClickHandler = { [weak self] (tag) in
            guard let strongdSelf = self else { return }
            if tag == 1 { // 会员卡
                let cardVC = VipCardsController()
                strongdSelf.navigationController?.pushViewController(cardVC, animated: true)
            } else if tag == 2 { // 折扣卡
                let luckCardVC = LuckCardMainController()
                strongdSelf.navigationController?.pushViewController(luckCardVC, animated: true)
            } else if tag == 3 {
                XSAlert.show(type: .error, text: "小姐姐在路上，敬请期待...")
            } else if tag == 4 {
                let vc = InviteContenController()
                strongdSelf.navigationController?.pushViewController(vc, animated: true)
            } else {
                if let url = URL(string: AppInfo.share().potato_invite_link ?? "") {
                    if #available(iOS 10, *) {
                        UIApplication.shared.open(url, options: [:], completionHandler: { (success) in
                        })
                    } else {
                        UIApplication.shared.openURL(url)
                    }
                }
            }
        }
        view.inviteRecordClickHandler = { [weak self] in
            guard let strongdSelf = self else { return }
            let recordVC = InviteRecordController()
            strongdSelf.navigationController?.pushViewController(recordVC, animated: true)
        }
        view.upVipCardLevelActionHandler = { [weak self] in
            guard let strongdSelf = self else { return }
            /// 新手卡 或者 游客卡跳转 到 分享页面
            if UserModel.share().userInfo?.vip_card?.key == VipKey.card_Novice || UserModel.share().userInfo?.vip_card?.key == VipKey.card_Normal {
                let vc = InviteContenController()

                strongdSelf.navigationController?.pushViewController(vc, animated: true)
            } else {
                /// 体验卡以上， 跳转到 会员卡页面
                let cardVC = VipCardsController()
                strongdSelf.navigationController?.pushViewController(cardVC, animated: true)
            }
        }
    }
    
    /// 检查vip是否升级了
    private func checkVipCardUpOrNot() {
        guard let vipLevelCurrent = UserModel.share().userInfo?.vip_card?.level else { return }
        if vipLevelCurrent <= 2 { return }
        let vipLevelSave = UserDefaults.standard.integer(forKey: UserDefaults.kVipCardLevel)
        if vipLevelCurrent > vipLevelSave { /// vip 等级升了， 弹框
            let card = UserModel.share().userInfo?.vip_card
            let controller = AlertManagerController(vipCard: card!)
            controller.modalPresentationStyle = .overCurrentContext
            self.modalPresentationStyle = .currentContext
            self.present(controller, animated: true, completion: nil)
            UserDefaults.standard.set(vipLevelCurrent, forKey: UserDefaults.kVipCardLevel)
        }
    }
}


// MARK: - LTAdvancedScrollViewDelegate
extension QHMineViewController: LTAdvancedScrollViewDelegate {
    
    //MARK: 具体使用请参考以下
    private func advancedManagerConfig() {
        //MARK: 选中事件
        advancedManager.advancedDidSelectIndexHandle = {
            print("选中了 -> \($0)")
        }
        
    }
    
    func glt_scrollViewOffsetY(_ offsetY: CGFloat) {
        if offsetY > 100 {
            navBar.backgroundColor = UIColor.black
            navBar.titleLabel.isHidden = false
        } else {
            navBar.backgroundColor = UIColor.clear
            navBar.titleLabel.isHidden = true
        }
    }
}

// MARK: - QHNavigationBarDelegate
extension QHMineViewController:  QHNavigationBarDelegate  {
    
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}


// MARK: - Layout
private extension QHMineViewController {
    
    func  layoutPageSubviews() {
        layoutNavBar()
        layoutSettingBtn()
        layoutMsgBtn()
    }
    
    func layoutNavBar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kStatusBarHeight + 44)
        }
    }
    
    func layoutSettingBtn() {
        settingBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-12)
            make.centerY.equalToSuperview()
            make.height.width.equalTo(30)
        }
    }
    func layoutMsgBtn() {
        msgBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(settingBtn.snp.leading).offset(-12)
            make.centerY.equalToSuperview()
            make.height.width.equalTo(30)
        }
    }
}


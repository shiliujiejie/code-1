//
//  LuckCardCodeController.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/26.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import NicooNetwork

class LuckCardCodeController: UIViewController {

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    private lazy var navBar: QHNavigationBar = {
        let bar = QHNavigationBar()
        bar.titleLabel.text = "福利卡兑换"
        bar.titleLabel.textColor = UIColor.white
        bar.backgroundColor = UIColor.clear
        bar.delegate = self
        return bar
    }()
    private lazy var codeView: TDWVerifyCodeView = {
        let codeView = TDWVerifyCodeView.init(inputTextNum: 6)
        codeView.backgroundColor = UIColor.clear
        codeView.layer.cornerRadius = 6
        codeView.padding = 10
        codeView.layer.masksToBounds = true
        return codeView
    }()
    private let tipsLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.white
        label.font = UIFont.systemFont(ofSize: 15)
        label.textAlignment = .center
        label.text = "请 填 写 您 获 得 的 兑 换 码"
        label.numberOfLines = 0
        return label
    }()
    let containView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(red: 51/255.0 , green: 54/255.0, blue:  69/255.0, alpha: 0.99)
        view.layer.cornerRadius = 10
        view.layer.masksToBounds = true
        return view
    }()
    
    private lazy var convertCardApi: WelCardConvertApi = {
        let api = WelCardConvertApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    
    var code: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        view.addSubview(navBar)
        view.addSubview(containView)
        containView.addSubview(codeView)
        view.addSubview(tipsLabel)
        codeView.textFiled.becomeFirstResponder()
        
        layoutPageSubviews()

        // 监听验证码输入的过程
        codeView.textValueChange = { str in
            // 要做的事情
            DLog("str = \(str)")
        }
        
        // 监听验证码输入完成
        codeView.inputFinish = {  [weak self] str in
            // 要做的事情
            DLog("strend = \(str)")
            self?.code = str
            let _ = self?.convertCardApi.loadData()
        }
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
    
    private func showAlert(_ success: Bool) {
        let succeedModel = ConvertCardAlertModel.init(title: "兑换成功", msgInfo: "恭喜恭喜，快去查看福利卡吧", success: true)
        let failedModel = ConvertCardAlertModel.init(title: "兑换失败", msgInfo: "啊哦，兑换失败，请重试。", success: false)
        let controller = AlertManagerController(cardModel: success ? succeedModel : failedModel)
        controller.modalPresentationStyle = .overCurrentContext
        controller.view.backgroundColor = UIColor(white: 0.0, alpha: 0.3)
        controller.commitActionHandler = { [weak self] in
            self?.codeView.cleanCodes()
            if success {
               self?.navigationController?.popViewController(animated: true)
            }
        }
        self.modalPresentationStyle = .currentContext
        self.present(controller, animated: true, completion: nil)
    }

}

// MARK: - QHNavigationBarDelegate
extension LuckCardCodeController:  QHNavigationBarDelegate  {
    
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension LuckCardCodeController: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        XSProgressHUD.showCustomAnimation(msg: nil, onView: self.view, imageNames: nil, bgColor: UIColor.clear, animated: false)
        return [WelCardConvertApi.kCode: code!]
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is WelCardConvertApi {
            showAlert(true)
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is WelCardConvertApi {
            showAlert(false)
        }
    }
}

// MARK: - Layout
private extension LuckCardCodeController {
    
    func layoutPageSubviews() {
        layoutNavBar()
        layoutInputView()
        layoutCodeView()
        layoutTipsLabel()
    }
    
    func layoutNavBar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kStatusBarHeight + 44)
        }
    }
    
    func layoutInputView() {
        containView.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(navBar.snp.bottom).offset(40)
            make.height.equalTo(50)
        }
    }
    
    func layoutCodeView() {
        codeView.snp.makeConstraints { (make) in
            make.leading.equalTo(0)
            make.trailing.equalTo(0)
            make.centerY.equalToSuperview()
            make.height.equalTo(50)
        }
    }
    
    func layoutTipsLabel() {
        tipsLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(containView.snp.bottom).offset(15)
        }
    }
}

//
//  LuckCardMainController.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/13.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import LTScrollView
import NicooNetwork

private let glt_iphoneX = (UIScreen.main.bounds.height >= 812.0)

class LuckCardMainController: UIViewController {
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    private lazy var navBar: QHNavigationBar = {
        let bar = QHNavigationBar()
        bar.titleLabel.text = "福利卡"
        bar.titleLabel.textColor = UIColor.white
        bar.backgroundColor = UIColor.clear
        bar.delegate = self
        return bar
    }()

    private lazy var viewControllers: [UIViewController] = {
        let oneVc = LuckCardUnownedController()
        let twoVc = LuckCardUnusedController()
        let threeVc = LuckCardInvailController()
        return [oneVc, twoVc, threeVc]
    }()
    
    private lazy var titles: [String] = {
        return ["未激活", "已拥有", "已失效"]
    }()
    
    private lazy var layout: LTLayout = {
        let layout = LTLayout()
        layout.sliderWidth = 50
        layout.titleMargin = 40
        layout.lrMargin = 26
        layout.titleFont = UIFont.systemFont(ofSize: 13)
        layout.titleColor = UIColor(red: 1, green: 1, blue: 1, alpha: 1)
        layout.titleSelectColor = ConstValue.kTitleYelloColor
        layout.titleViewBgColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0)
        layout.bottomLineColor = ConstValue.kTitleYelloColor
        layout.pageBottomLineColor = ConstValue.kAppSepLineColor
        layout.isShowBounces = true
        layout.scale = 1.1
        return layout
    }()
    
    private lazy var pageView: LTPageView = {
        let Y: CGFloat = ConstValue.kStatusBarHeight + 44
        let H: CGFloat = glt_iphoneX ? (view.bounds.height - Y - 34) : view.bounds.height - Y
        let pageView = LTPageView(frame: CGRect(x: 0, y: Y, width: view.bounds.width, height: H), currentViewController: self, viewControllers: viewControllers, titles: titles, layout: layout)
        pageView.isClickScrollAnimation = true
        return pageView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        view.addSubview(navBar)
        automaticallyAdjustsScrollViewInsets = false
        view.addSubview(pageView)
        pageView.didSelectIndexBlock = {(_, index) in
            print("pageView.didSelectIndexBlock", index)
        }
        view.addSubview(pageView)
        layoutPageSubviews()
    }
   
    
}

// MARK: - QHNavigationBarDelegate
extension LuckCardMainController:  QHNavigationBarDelegate  {
    
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}


// MARK: - Layout
private extension LuckCardMainController {
    
    func layoutPageSubviews() {
        layoutNavBar()
    }
   
    func layoutNavBar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kStatusBarHeight + 44)
        }
    }
    
    
}

//
//  RewardRuleListCell.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/14.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

class RewardRuleListCell: UITableViewCell {

    static let cellId = "RewardRuleListCell"
    
    @IBOutlet weak var daysLable: UILabel!
    @IBOutlet weak var countLable: UILabel!
    @IBOutlet weak var rewordLable: UILabel!
    @IBOutlet weak var finishStatuLable: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

//
//  RewardInviteController.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/14.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import NicooNetwork

class RewardInviteController: UIViewController {
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    private lazy var navBar: QHNavigationBar = {
        let bar = QHNavigationBar()
        bar.titleLabel.text = "推广奖励"
        bar.titleLabel.textColor = UIColor.white
        bar.backgroundColor = UIColor.clear
        bar.backButton.isHidden = isLeftSide
        bar.delegate = self
        return bar
    }()
    private let bgImage: UIImageView = {
        let image  = UIImageView()
        image.image = UIImage(named: "inviteImageBg")
        return image
    }()
    private lazy var upButton: UIButton = {
        let button = UIButton(type: .custom)
        button.backgroundColor = UIColor.clear
        button.addTarget(self, action: #selector(upButtonClick), for: .touchUpInside)
        button.setImage(UIImage(named: "doubleArrowUp"), for: .normal)
        return button
    }()
    private let tipsLable: UILabel = {
        let lable = UILabel()
        lable.textColor = ConstValue.kTitleYelloColor
        lable.numberOfLines = 0
        lable.textAlignment = .center
        lable.font = UIFont.systemFont(ofSize: 13)
        lable.text = "成功邀请好友安装APP,并填写您的推广码,可享受每日无限次数观看"
        return lable
    }()
    private let webLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.white
        lable.numberOfLines = 0
        lable.textAlignment = .center
        lable.font = UIFont.systemFont(ofSize: 16)
        lable.text = AppInfo.share().official_url ?? ConstValue.kAppDownLoadLoadUrl
        return lable
    }()
    private let warningLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.white
        lable.numberOfLines = 0
        lable.textAlignment = .center
        lable.font = UIFont.systemFont(ofSize: 14)
        lable.text = "看片前请保存官网\n如果被封后可在官网下载新的APP"
        return lable
    }()
    
    private lazy var tableView: UITableView = {
        let table = UITableView()
        table.backgroundColor = UIColor(red: 22/255.0 , green: 24/255.0 , blue: 36/255.0, alpha: 1)
        table.showsVerticalScrollIndicator = false
        table.allowsSelection = false
        table.delegate = self
        table.dataSource = self
        table.separatorStyle = .none
        table.register(UINib(nibName: "RewardRuleListCell", bundle: Bundle.main), forCellReuseIdentifier: RewardRuleListCell.cellId)
        table.layer.cornerRadius = 10
        table.layer.masksToBounds = true
        return table
    }()
    
    private lazy var invitRuleApi: InvitationRulesApi = {
        let api = InvitationRulesApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    var upActionHandler:(() -> Void)?
    
    var isLeftSide = true
    
    var inviteRules = [InviteRuleModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpSubviews()
        loadData()
    }
    
    private func setUpSubviews() {
        view.backgroundColor = ConstValue.kVcViewColor
        view.addSubview(bgImage)
        view.addSubview(navBar)
        view.addSubview(upButton)
        view.addSubview(tipsLable)
        view.addSubview(webLable)
        view.addSubview(warningLable)
        view.addSubview(tableView)
        layoutPageSubviews()
    }
    
    private func loadData() {
        let _ = invitRuleApi.loadData()
    }
    
    @objc func upButtonClick() {
        upActionHandler?()
    }
    
    
    
}

// MARK: - QHNavigationBarDelegate
extension RewardInviteController:  QHNavigationBarDelegate  {
    
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension RewardInviteController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 75
        }
        return 60
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return inviteRules.count + 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: RewardRuleListCell.cellId, for: indexPath) as! RewardRuleListCell
        if indexPath.row == 0 {
            cell.countLable.text = "邀请人数"
            cell.daysLable.text = "观影天数"
            cell.rewordLable.text = "额外奖励"
            cell.finishStatuLable.text = "完成情况"
        } else {
            let model = inviteRules[indexPath.row - 1]
            cell.countLable.text = "\(model.person ?? 0)"
            cell.daysLable.text = "\(model.view_daily ?? 0)"
            cell.rewordLable.text = "\(model.title ?? "无")"
            cell.finishStatuLable.text = (model.invite_count ?? 0) >= (model.person ?? 0) ? "完成" : "未完成"
            cell.finishStatuLable.textColor = (model.invite_count ?? 0) >= (model.person ?? 0) ? ConstValue.kTitleYelloColor : UIColor.white
        }
     
        return cell
    }
    
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension RewardInviteController: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is InvitationRulesApi {
            if let ruleList = manager.fetchJSONData(UserReformer()) as? [InviteRuleModel] {
                inviteRules = ruleList
                tableView.reloadData()
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
    }
}


// MARK: - Layout
private extension RewardInviteController {
    
    func layoutPageSubviews() {
        layoutBgimage()
        layoutNavBar()
        layoutUpButton()
        layoutTipLable()
        layoutTableView()
        layoutWarningLable()
        layoutWebLable()
    }
    func layoutBgimage() {
        bgImage.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            make.height.equalTo(75 + (inviteRules.count > 4 ? 5 : 4)  * 60)
            make.leading.equalTo(25)
            make.trailing.equalTo(-25)
            make.top.equalTo(tipsLable.snp.bottom).offset(20)
        }
    }
    
    func layoutNavBar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kStatusBarHeight + 44)
        }
    }
    func layoutUpButton() {
        upButton.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.height.width.equalTo(35)
            make.top.equalTo(navBar.snp.bottom).offset(20)
        }
    }
    func layoutTipLable() {
        tipsLable.snp.makeConstraints { (make) in
            make.leading.equalTo(50)
            make.trailing.equalTo(-50)
            make.top.equalTo(upButton.snp.bottom).offset(10)
        }
    }
    func layoutWarningLable() {
        warningLable.snp.makeConstraints { (make) in
            make.leading.equalTo(50)
            make.trailing.equalTo(-50)
            make.top.equalTo(tableView.snp.bottom).offset(15)
        }
    }
   
    func layoutWebLable() {
        webLable.snp.makeConstraints { (make) in
            make.leading.equalTo(50)
            make.trailing.equalTo(-50)
            make.top.equalTo(warningLable.snp.bottom).offset(15)
        }
    }
    
}

//
//  PushVideoController.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/4/26.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import AVKit
import Photos

/// 视频上传确认页面
class PushVideoController: UIViewController {
    
    static let videoItemWidth: CGFloat = (ConstValue.kScreenWdith - 80)/4
    static let videoItemHieght: CGFloat = 35
    static let videoItemSize: CGSize = CGSize(width: videoItemWidth, height: videoItemHieght)
    
    static let kLocalTaskTitles = "localTaskTitles"

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    private lazy var navBar: QHNavigationBar = {
        let bar = QHNavigationBar()
        bar.titleLabel.text = "发布"
        bar.titleLabel.textColor = UIColor.white
        bar.backgroundColor = UIColor.clear
        bar.delegate = self
        return bar
    }()
    let lineView: UIView = {
        let view = UIView()
        view.backgroundColor = ConstValue.kAppSepLineColor
        return view
    }()
    let lineView1: UIView = {
        let view = UIView()
        view.backgroundColor = ConstValue.kAppSepLineColor
        return view
    }()
    lazy var textView: UITextView = {
        let textView = UITextView()
        textView.textColor = UIColor.groupTableViewBackground
        textView.font = UIFont.systemFont(ofSize: 14)
        textView.backgroundColor = UIColor.clear
        textView.delegate = self
        return textView
    }()
    let placeHodlerLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor(white: 0.7, alpha: 0.6)
        lable.font = UIFont.systemFont(ofSize: 14)
        lable.numberOfLines = 2
        lable.text = "请填写合适的描述，能让更多的人看到(50字以内)"
        return lable
    }()
    let cateTitleLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.white
        lable.font = UIFont.systemFont(ofSize: 15)
        lable.text = "选择分类"
        return lable
    }()
    lazy var fakeChoseBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage.imageFromColor(UIColor(red: 56/255.0, green: 59/255.0, blue: 71/255.0, alpha: 0.99), frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 48)), for: .highlighted)
        button.addTarget(self, action: #selector(choseCateTips), for: .touchUpInside)
        return button
    }()
    lazy var videoBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(videoImage, for: .normal)
        button.addTarget(self, action: #selector(videoWatch), for: .touchUpInside)
        return button
    }()
    let progressCover: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.white
        label.font = UIFont.systemFont(ofSize: 12)
        label.backgroundColor = UIColor(white: 0.0, alpha: 0.5)
        label.textAlignment = .center
        return label
    }()
    lazy var saveBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("保存本地", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = UIColor(red: 56/255.0, green: 59/255.0, blue: 71/255.0, alpha: 0.99)
        button.addTarget(self, action: #selector(saveTask), for: .touchUpInside)
        button.layer.cornerRadius = 5
        button.layer.masksToBounds = true
        return button
    }()
    lazy var commitBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("发布作品", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        button.setTitleColor(UIColor.darkText, for: .normal)
        button.backgroundColor = UIColor(red: 251/255.0, green: 211/255.0, blue: 16/255.0, alpha: 0.99)
        button.addTarget(self, action: #selector(commitPushVideo(_:)), for: .touchUpInside)
        button.layer.cornerRadius = 5
        button.layer.masksToBounds = true
        return button
    }()
    var cateChoseImage: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "cateChoseImage")
        image.isUserInteractionEnabled = true
        return image
    }()
    var arrowImage: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "arrowRight")
        image.isUserInteractionEnabled = true
        return image
    }()
    
    private let layout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 10
        layout.minimumInteritemSpacing = 10
        layout.sectionInset = UIEdgeInsets(top: 10 ,left: 10, bottom: 10, right: 10)
        return layout
    }()
    lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.backgroundColor = UIColor.clear
        collection.register(TagCell.classForCoder(), forCellWithReuseIdentifier: TagCell.cellId)
        return collection
    }()
    var pushTask = PushPresenter()
    
    var videoImage: UIImage?
    var videoDuration: Int = 0
    var tagModels = [CateTagModel]()
    /// 是否是上传上次保存的视频
    var isUploadFormLastTimeSave = false
    var isChangeparams = false
    
    deinit {
        print("PushVideoController -- release")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        setUpUI()
        if isUploadFormLastTimeSave {
            loadLoaclData()
        }
        addUploadPresenterCallBack()
    }
    
    private func setUpUI() {
        view.addSubview(navBar)
        view.addSubview(videoBtn)
        view.addSubview(progressCover)
        view.addSubview(textView)
        view.addSubview(placeHodlerLable)
        view.addSubview(lineView)
        view.addSubview(fakeChoseBtn)
        view.addSubview(cateChoseImage)
        view.addSubview(cateTitleLable)
        view.addSubview(arrowImage)
        view.addSubview(lineView1)
        view.addSubview(collectionView)
        view.addSubview(saveBtn)
        view.addSubview(commitBtn)
        layoutPageSubviews()
    }
    
    private func loadLoaclData() {
        guard let localTasks = UploadTask.shareTask().tasks else { return }
        if localTasks.count == 0 { return }
        let localTask = localTasks[0]
        self.pushTask = localTask
        if let tagTitles = localTask.pushModel.commitParams?[PushVideoController.kLocalTaskTitles] as? [String] {
            var tagsModels = [CateTagModel]()
            for tagTitle in tagTitles {
                let tagsModel = CateTagModel(id: 0, title: tagTitle, isSelected: false)
                tagsModels.append(tagsModel)
            }
            tagModels = tagsModels
            collectionView.reloadData()
        }
        if let title = pushTask.pushModel.commitParams?[PushVideoApi.kTitle] as? String {
            textView.text = title
            placeHodlerLable.text = ""
        }
        videoImage = pushTask.pushModel.videoCover
        videoBtn.setBackgroundImage(videoImage, for: .normal)
    }
    
    private func addUploadPresenterCallBack() {
        pushTask.videoUploadProgressHandler = { [weak self] (progress) in
            self?.updateProgressUI(progress)
        }
        pushTask.videoUploadSucceedHandler = { [weak self]  in
            self?.progressCover.text = "封面上传中..."
            DLog("视频上传成功，准备上传图片。。。")
        }
        pushTask.videoUploadFailedHandler = { [weak self] (errorMsg) in
            DLog("videoUploadFailed")
            self?.alertForUpload("视频上传失败!", step: 1)
        }
        pushTask.imageUploadSucceedHandler = {
            DLog("封面图上传成功， 开始提交视频。。。")
        }
        pushTask.imageUploadFailedHandler = { [weak self] (errorMsg) in
            DLog("封面图上传失败， 点击后从这一步继续？")
            self?.alertForUpload("封面上传失败!", step: 2)
        }
        
        pushTask.commitUploadSucceedHandler = { [weak self] in
            DLog("视频提交成功，删除本地任删除本地任务，刷新列表")
           // XSAlert.show(type: .success, text: "视频上传成功！")
            self?.progressCover.text = "上传成功"
            self?.removeTasks()
            self?.showSucceedAlert()
        }
        
        pushTask.commitUploadFailedHandler = { [weak self] (errorMsg) in
             DLog("commitUploadFailed")
             self?.alertForUpload("视频提交失败！", step: 3)
        }
    }
    
    private func alertForUpload(_ msg: String, step: Int) {
        let alertContro = UIAlertController.init(title: nil, message: msg, preferredStyle: .alert)
        let okAction = UIAlertAction(title: step == 3 ? "重新提交" : "重新上传", style: .default) { (action) in
            if step == 1 { // 视频文件上传失败
                self.pushTask.uploadVideo()
            } else if step == 2 { // 图片上传失败
                self.pushTask.uploadVideoCover()
            } else if step == 3 { // 提交失败
                self.pushTask.commitForPush()
            }
        }
        let cancleAction = UIAlertAction(title: "取消", style: .cancel) { (action) in
            self.saveBtn.isEnabled = true
            // 这里需要检测
        }
        alertContro.addAction(okAction)
        alertContro.addAction(cancleAction)
        self.present(alertContro, animated: true, completion: nil)
    }
    
    /// 移除任务
    func removeTasks() {
        guard let _ = UploadTask.shareTask().tasks else { return }
        DLog("removeTasks")
        UploadTask.shareTask().tasks!.removeAll()
        UserDefaults.standard.removeObject(forKey: UserDefaults.kUploadTaskImage)
        UserDefaults.standard.removeObject(forKey: UserDefaults.kUploadTaskParams)
        UserDefaults.standard.set(0, forKey: UserDefaults.kUploadTaskStatu)
    }

    func showSucceedAlert() {
        let succeedModel = ConvertCardAlertModel.init(title: "作品上传成功", msgInfo: "请到‘个人中心-作品‘查看", success: true)
        let controller = AlertManagerController(alertInfoModel: succeedModel)
        controller.modalPresentationStyle = .overCurrentContext
        controller.view.backgroundColor = UIColor(white: 0.0, alpha: 0.3)
        controller.commitActionHandler = { [weak self] in
             self?.navigationController?.popToRootViewController(animated: true)
        }
        self.modalPresentationStyle = .currentContext
        self.present(controller, animated: true, completion: nil)
    }
    
}

// MARK: - User Actions
private extension PushVideoController {
    
    /// 预览播放
    @objc func videoWatch() {
        let playerVc = AVPlayerViewController()
        playerVc.player = AVPlayer(url: FileManager.videoExportURL)
        playerVc.player?.play()
        self.present(playerVc, animated: false, completion: nil)
    }
    
    @objc func choseCateTips() {
        let cateTagsVc = CateAllTagsController()
        cateTagsVc.saveButtonClickHandler = { (allTags) in
            self.tagModels = allTags
            self.isChangeparams = true
            self.collectionView.reloadData()
        }
        navigationController?.pushViewController(cateTagsVc, animated: true)
    }
    
    /// 上传任务存本地
    @objc func saveTask() {
        let allowed = allowedForUploadOrSave(true)
        if allowed {
            if videoImage == nil {
                return
            }
            var params = [String: Any]()
            params[PushVideoApi.kTitle] = textView.text
            params[PushVideoApi.kKey_id] = getVideokeysIds() ?? ""
            params[PushVideoApi.kDuration] = videoDuration
            params[PushVideoController.kLocalTaskTitles] = getVideokeysTitles()
            let pushTasks = PushPresenter()
            pushTasks.pushModel = PushVideoModel.init(videoCover: videoImage, videoUrl: FileManager.videoExportURL, commitParams: params)
            // 这里用 UploadTask持有 task
            UploadTask.shareTask().tasks = [pushTasks]
            // 保存本地
            pushTasks.saveUploadTask()
            XSAlert.show(type: .success, text: "保存成功，请到个人中心查看。")
            navigationController?.popToRootViewController(animated: true)
        }
    }
    
    /// 上传业务 1.判断必传参数。 2.上传封面图， 3。上传视频文件 4. 吊用提交接口。
    @objc func commitPushVideo(_ sender: UIButton) {
        let allowed = allowedForUploadOrSave(false)
        if allowed {
            sender.isEnabled = false
            saveBtn.isEnabled = false
            if isUploadFormLastTimeSave {
                if var params = pushTask.pushModel.commitParams {
                    params.removeValue(forKey: PushVideoController.kLocalTaskTitles)
                    params[PushVideoApi.kTitle] = textView.text
                    if isChangeparams {
                        params[PushVideoApi.kKey_id] = getVideokeysIds()
                    }
                    pushTask.pushModel.commitParams = params
                }
            } else {
                var params = [String: Any]()
                params[PushVideoApi.kTitle] = textView.text
                params[PushVideoApi.kKey_id] = getVideokeysIds() ?? ""
                params[PushVideoApi.kDuration] = videoDuration
                pushTask.pushModel = PushVideoModel.init(videoCover: videoImage, videoUrl: FileManager.videoExportURL, commitParams: params)
            }
            pushTask.uploadVideo()
            // 这里用 UploadTask持有 task,
            UploadTask.shareTask().tasks = [self.pushTask]
        }
    }
    
    func updateProgressUI(_ progress: Double) {
        let height = Float(progress * 145.0)
        progressCover.snp.updateConstraints { (make) in
            make.height.equalTo(height)
        }
        progressCover.text = String(format: "%.1f%@", Float(progress * 100.0), "%")
    }
    
    /// 取出所有的ids
    func getVideokeysIds() -> String? {
        var tagKeyIds = [Int]()
        for tagModel in tagModels {
            tagKeyIds.append(tagModel.id ?? 0)
        }
        if let data = try? JSONSerialization.data(withJSONObject: tagKeyIds, options: []) {
            if let json = NSString.init(data: data, encoding: String.Encoding.utf8.rawValue) {
                return json as String
            }
        }
        return nil
    }
    
    /// 取出所有titles
    func getVideokeysTitles() -> [String] {
        var tagKeyTitles = [String]()
        for tagModel in tagModels {
            tagKeyTitles.append(tagModel.title ?? "")
        }
        return tagKeyTitles
    }
    
    func allowedForUploadOrSave(_ isSaveAction: Bool) -> Bool {
      
        if let currentTasks = UploadTask.shareTask().tasks, currentTasks.count > 0 {
            if isUploadFormLastTimeSave {
                if isSaveAction {
                    // 当前有任务在上传中
                    XSAlert.show(type: .warning, text: "您已保存过该作品.")
                    return false
                }
            } else {
                // 当前有任务在上传中
                XSAlert.show(type: .warning, text: "您有一个作品未处理.")
                return false
            }
        }
        
        if textView.text.isEmpty {
            XSAlert.show(type: .warning, text: "请填写对视频的描述")
            return  false
        }
        if tagModels.count == 0 {
            XSAlert.show(type: .warning, text: "请选择视频分类")
            return false
        }
        return true
    }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension PushVideoController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return tagModels.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cellForRow(with: indexPath)
        return cell
    }
    
    /// 配置cell
    func cellForRow(with indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: TagCell.cellId, for: indexPath) as! TagCell
        cell.tagLabel.text = tagModels[indexPath.row].title ?? ""
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return PushVideoController.videoItemSize
    }
}

// MARK: - QHNavigationBarDelegate
extension PushVideoController:  QHNavigationBarDelegate  {
    
    func backAction() {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
}

// MARK: - UITextViewDelegate
extension PushVideoController: UITextViewDelegate {
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        placeHodlerLable.text = ""
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if textView.text.count >= 50 {
            return false
        }
        return true
    }
    
    func textViewShouldEndEditing(_ textView: UITextView) -> Bool {
        if textView.text.isEmpty {
            placeHodlerLable.text = "请填写合适的描述，能让更多的人看到(50字以内)"
        }
        return true
    }
}


// MARK: - Layout
private extension PushVideoController {
    
    func layoutPageSubviews() {
        layoutNavBar()
        layoutVideoPart()
        layoutCateChosePart()
        layoutBottomPart()
        layoutCollectionView()
    }
    
    func layoutNavBar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kStatusBarHeight + 44)
        }
    }
    
    func layoutVideoPart() {
        videoBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-15)
            make.top.equalTo(navBar.snp.bottom).offset(15)
            make.width.equalTo(90)
            make.height.equalTo(145)
        }
        progressCover.snp.makeConstraints { (make) in
            make.leading.trailing.bottom.equalTo(videoBtn)
            make.height.equalTo(0)
        }
        textView.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalTo(navBar.snp.bottom).offset(15)
            make.trailing.equalTo(videoBtn.snp.leading).offset(-15)
            make.height.equalTo(145)
        }
        placeHodlerLable.snp.makeConstraints { (make) in
            make.top.equalTo(navBar.snp.bottom).offset(15)
            make.leading.equalTo(textView).offset(10)
            make.trailing.equalTo(textView).offset(-10)
            make.height.equalTo(40)
        }
        lineView.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(videoBtn.snp.bottom).offset(15)
            make.height.equalTo(0.5)
        }
    }
    
    func layoutCateChosePart() {
        cateChoseImage.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalTo(lineView.snp.bottom).offset(15)
            make.height.width.equalTo(18)
        }
        cateTitleLable.snp.makeConstraints { (make) in
            make.centerY.equalTo(cateChoseImage)
            make.leading.equalTo(cateChoseImage.snp.trailing).offset(15)
            make.height.equalTo(24)
        }
        arrowImage.snp.makeConstraints { (make) in
            make.trailing.equalTo(-15)
            make.centerY.equalTo(cateChoseImage)
        }
        lineView1.snp.makeConstraints { (make) in
            make.leading.equalTo(cateChoseImage)
            make.trailing.equalTo(arrowImage)
            make.top.equalTo(cateChoseImage.snp.bottom).offset(15)
            make.height.equalTo(0.5)
        }
        fakeChoseBtn.snp.makeConstraints { (make) in
            make.leading.equalTo(0)
            make.trailing.equalTo(0)
            make.top.equalTo(lineView.snp.bottom)
            make.height.equalTo(48)
        }
    }
    
    func layoutBottomPart() {
        saveBtn.snp.makeConstraints { (make) in
            make.leading.equalTo(25)
            make.width.equalTo((ConstValue.kScreenWdith - 70)/2)
            make.height.equalTo(45)
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-20)
            } else {
                make.bottom.equalTo(-20)
            }
        }
        commitBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-25)
            make.width.equalTo((ConstValue.kScreenWdith - 70)/2)
            make.height.equalTo(45)
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-20)
            } else {
                make.bottom.equalTo(-20)
            }
        }
    }
    
    func layoutCollectionView() {
        collectionView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(lineView1.snp.bottom).offset(10)
            make.bottom.equalTo(saveBtn.snp.top).offset(-10)
        }
    }
}

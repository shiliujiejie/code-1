//
//  PushPresenter.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/5/3.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import Alamofire
import NicooNetwork

/// 视频上传状态
///
/// - waitForUpload: 视频等待上传
/// - videoUploading: 视频上传中...
/// - videoUploadFailed: 视频上传失败
/// - imageUploading: 封面图上传中...
/// - imageUploadFailed: 封面图上传失败
/// - commitFailed: 提交失败
/// - videoChecking: 提交成功之后，视频进入审核状态 （下一次拉去列表这个状态应该有后台数据 控制）
enum VideoPushStatu: Int {
    case waitForUpload = 0
    case videoUploading = 1
    case videoUploadFailed = 2
    case imageUploading = 3
    case imageUploadFailed = 4
    case commitFailed = 5
    case videoChecking = 6
}

class PushPresenter: NSObject {

    /// 封面图上传Api
    private lazy var imageUpLoad: UploadImageTool = {
        let upload = UploadImageTool()
        upload.delegate = self
        return upload
    }()
    /// 视频上传Api
    private lazy var videoUpLoad: UploadVideoTool = {
        let upload = UploadVideoTool()
        upload.delegate = self
        return upload
    }()
    /// 上传提交Api
    private lazy var pushUpApi: PushVideoApi = {
        let pushApi = PushVideoApi()
        pushApi.paramSource = self
        pushApi.delegate = self
        return pushApi
    }()
    var videoPushStatu: VideoPushStatu = .waitForUpload
    
    /// 上传所需资源，参数
    var pushModel = PushVideoModel()
    var videoProgress: Double = 0.0
    
    /// 视频上传进度回调
    var videoUploadProgressHandler:((_ progress: Double) -> Void)?
    /// 视频上传成功
    var videoUploadSucceedHandler:(() -> Void)?
    /// 视频上传失败
    var videoUploadFailedHandler:((_ errorMsg: String) -> Void)?
    
    /// 图片上传成功
    var imageUploadSucceedHandler:(() -> Void)?
    /// 图片上传失败
    var imageUploadFailedHandler:((_ errorMsg: String) -> Void)?
    
    /// 提交成功
    var commitUploadSucceedHandler:(() -> Void)?
    /// 提交失败
    var commitUploadFailedHandler:((_ errorMsg: String) -> Void)?
 
}

// MARK: - Open func
extension PushPresenter {
    
    /// 上传视频封面
    func uploadVideoCover() {
        videoPushStatu = .imageUploading
        imageUpLoad.upload(pushModel.videoCover)
    }
    
    /// 上传视频
    func uploadVideo() {
        videoPushStatu = .videoUploading
        videoUpLoad.upload(pushModel.videoUrl)
    }
    
    /// 资源上传完，提交
    func commitForPush() {
        let _ = pushUpApi.loadData()
    }
    
    /// 上传失败时，存本地
    func saveUploadTask() {
        guard let tasks = UploadTask.shareTask().tasks else { return }
        if tasks.count == 0 { return }
        let image = UIImage(cgImage: (pushModel.videoCover!.cgImage!), scale: pushModel.videoCover!.scale,
                            orientation: pushModel.videoCover!.imageOrientation)
        let taskImage = NSKeyedArchiver.archivedData(withRootObject: image)
        UserDefaults.standard.set(pushModel.commitParams, forKey: UserDefaults.kUploadTaskParams)
        UserDefaults.standard.setValue(taskImage, forKey: UserDefaults.kUploadTaskImage)
        let taskData = NSKeyedArchiver.archivedData(withRootObject: image)
        UserDefaults.standard.set(taskData, forKey: UserDefaults.kUploadTaskImage)
        UserDefaults.standard.set(videoPushStatu.rawValue, forKey: UserDefaults.kUploadTaskStatu)
    }
}

// MARK: - UploadImageDelegate
extension PushPresenter: UploadImageDelegate {
    
    func paramsForAPI(_ uploadImageTool: UploadImageTool) -> [String : String]? {
        return nil
    }
    
    func uploadImageMethod(_ uploadImageTool: UploadImageTool) -> String {
        return "/\(ConstValue.kApiVersion)/video/cover/upload"
    }
    
    func uploadImageSuccess(_ uploadImageTool: UploadImageTool, resultDic: [String : Any]?) {
        var paramsStep2 = [String: Any]()
        if let imageFileName = resultDic?["result"] as? String, var params = pushModel.commitParams {
            params[PushVideoApi.kCoverName] = imageFileName
            paramsStep2 = params
        }
        pushModel.commitParams = paramsStep2
        ///  图片上传成功回调
        imageUploadSucceedHandler?()
        /// 这里吊用提交接口
        commitForPush()
    }
    
    func uploadImageFailed(_ uploadImageTool: UploadImageTool, errorMessage: String?) {
        videoPushStatu = .imageUploadFailed
        saveUploadTask()
        imageUploadFailedHandler?(errorMessage ?? "封面图上传失败！")
    }
    

}

// MARK: - UploadVideoDelegate
extension PushPresenter: UploadVideoDelegate {
    
    func uploadVideoMethod(_ uploadVideoTool: UploadVideoTool) -> String {
        return "/upload"
    }
    
    func uploadVideoSuccess(_ uploadVideoTool: UploadVideoTool, resultDic: [String : Any]?) {
        var paramsStep1 = [String: Any]()
        if let videoFileInfo = resultDic?["result"] as? [String: String], var params = pushModel.commitParams {
            params[PushVideoApi.kFile_name] = videoFileInfo["file_name"]
            params[PushVideoApi.kFile_path] = videoFileInfo["file_path"]
            paramsStep1 = params
        }
        pushModel.commitParams = paramsStep1
        /// 视频上传成功回调
        videoUploadSucceedHandler?()
        /// 上传图片
        uploadVideoCover()
    }
    
    func uploadVideoProgress(_ progress: Double) {
        videoProgress = progress
        videoUploadProgressHandler?(progress)
    }
    
    func uploadVideoFailed(_ uploadVideoTool: UploadVideoTool, errorMessage: String?) {
        videoPushStatu = .videoUploadFailed
        saveUploadTask()
        videoUploadFailedHandler?(errorMessage ?? "视频上传失败！")
    }
    
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension PushPresenter: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        return pushModel.commitParams
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        if manager is PushVideoApi {
            videoPushStatu = .videoChecking
            commitUploadSucceedHandler?()
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        if manager is PushVideoApi {
            videoPushStatu = .commitFailed
            saveUploadTask()
            commitUploadFailedHandler?(manager.errorMessage)
        }
    }
}


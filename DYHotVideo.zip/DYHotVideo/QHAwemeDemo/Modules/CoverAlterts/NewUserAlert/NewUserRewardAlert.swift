//
//  NewUserRewardAlert.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/15.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

class NewUserRewardAlert: UIView {

    @IBOutlet weak var alterBgImage: UIImageView!
    @IBOutlet weak var rewardInfo: UILabel!
    @IBOutlet weak var getItButton: UIButton!
    @IBOutlet weak var availTime: UILabel!
    
    var verbRewardActionHandler:(() ->Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        backgroundColor = UIColor.clear
        getItButton.layer.cornerRadius = 21
        getItButton.layer.masksToBounds = true
        rewardInfo.textColor = ConstValue.kTitleYelloColor
    }
    
    @IBAction func verbRewardAction(_ sender: UIButton) {
        verbRewardActionHandler?()
    }
    
}

//
//  SeriesHeaderCell.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/14.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

class SeriesHeaderCell: UITableViewCell {
    
    static let cellId = "SeriesHeaderCell"

    @IBOutlet weak var seriesIconBtn: UIButton!
    @IBOutlet weak var seriesIcon: UIImageView!
    @IBOutlet weak var seriesName: UILabel!
    @IBOutlet weak var keysLable: UILabel!
    var moreBtnClickHandler:(() ->Void)?
    override func awakeFromNib() {
        super.awakeFromNib()
        seriesName.textColor = UIColor.white
        seriesIconBtn.layer.cornerRadius = 30
        seriesIconBtn.layer.masksToBounds = true
        seriesIconBtn.backgroundColor = ConstValue.kIconBgColor
        seriesIconBtn.setTitleColor(ConstValue.kTitleYelloColor, for: .normal)
    }
    
    @IBAction func moreBtnClick(_ sender: UIButton) {
        moreBtnClickHandler?()
    }
}

//
//  FindVideosController.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/14.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import NicooNetwork
import MJRefresh

/// 搜索视频系列
class FindVideosController: UIViewController {

   lazy var tableView: UITableView = {
        let table = UITableView.init(frame: view.bounds, style: .plain)
        table.backgroundColor = UIColor.clear
        table.showsVerticalScrollIndicator = false
        table.allowsSelection = true
        table.delegate = self
        table.dataSource = self
        table.separatorStyle = .none
        table.register(UINib(nibName: "SeriesHeaderCell", bundle: Bundle.main), forCellReuseIdentifier: SeriesHeaderCell.cellId)
        table.register(HistoryWatchedCell.classForCoder(), forCellReuseIdentifier: HistoryWatchedCell.cellId)
        table.mj_header = refreshView
        table.mj_footer = loadMoreView
        return table
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        return MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
    }()
    lazy private var refreshView: MJRefreshGifHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshGifHeader(refreshingBlock: {
            weakSelf?.isRefreshOperation = true
            weakSelf?.loadData()
        })
        var gifImages = [UIImage]()
        for string in ConstValue.refreshImageNames {
            gifImages.append(UIImage(named: string)!)
        }
        mjRefreshHeader?.setImages(gifImages, for: .refreshing)
        mjRefreshHeader?.setImages(gifImages, for: .idle)
        mjRefreshHeader?.stateLabel.font = ConstValue.kRefreshLableFont
        mjRefreshHeader?.lastUpdatedTimeLabel.font = ConstValue.kRefreshLableFont
        return mjRefreshHeader!
    }()
    
    private lazy var videoKeyApi: VideoSeriesListApi =  {
        let api = VideoSeriesListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    /// 选中index
    var selectIndex = 0
    /// 当前点击区域
    var selectSction = 0
    /// 是否是下拉刷新操作
    private var isRefreshOperation = false
    
    var cateModels = [VideoCategoryModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        view.addSubview(tableView)
        layoutPageSubviews()
        loadMoreView.isHidden = true
        loadData()
    }
    
    private func loadData() {
        NicooErrorView.removeErrorMeesageFrom(self.view)
        if !isRefreshOperation {
            XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        }
        let _  = videoKeyApi.loadData()
    }
    
    private func loadNextPage() {
        let _  = videoKeyApi.loadNextPage()
    }
    
    func succeedRequest(_ model: CateTypeListModel) {
        if let models = model.data, let currentPage = model.current_page {
            if currentPage ==  1 {
                cateModels = models
                if models.count == 0 {
                    NicooErrorView.showErrorMessage("小姐姐走丢了，点击这里刷新", on: view, customerTopMargin: 150) {
                        self.loadData()
                    }
                }
                if models.count == VideoSeriesListApi.kDefaultCount {
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
            } else {
                cateModels.append(contentsOf: models)
                if models.count == VideoSeriesListApi.kDefaultCount {
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
            }
        }
        endRefreshing()
        tableView.reloadData()
    }
    
    private func  endRefreshing() {
        tableView.mj_header.endRefreshing()
        tableView.mj_footer.endRefreshing()
    }

}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension FindVideosController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view = UIView.init(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 8))
        view.backgroundColor = UIColor(red: 16/255.0, green: 18/255.0, blue: 29/255.0, alpha: 0.98)
        return view
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 8
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return cateModels.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 90
        }
        if indexPath.row == 1 {
            return 230
        }
        return 0
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  (cateModels[section].video_lists?.count ?? 0) > 0 ? 2 : 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: SeriesHeaderCell.cellId, for: indexPath) as! SeriesHeaderCell
            let serModel = cateModels[indexPath.section]
            cell.seriesName.text = serModel.keys_title ?? ""
            let mutString: NSMutableString = ""
            if let relationKeys = serModel.relation_keys, relationKeys.count > 0 {
                for key in relationKeys {
                    mutString.append(" \(key.title ?? "")")
                }
            }
            cell.keysLable.text = mutString as String
            cell.seriesIconBtn.setTitle(serModel.keys_title ?? "", for: .normal)
            if let keyTitle = serModel.keys_title , keyTitle.count > 2 {
                let subTitle =  (keyTitle as NSString).substring(to: 2)
                cell.seriesIconBtn.setTitle(subTitle, for: .normal)
            } else {
                cell.seriesIconBtn.setTitle(serModel.keys_title ?? "系列", for: .normal)
            }
            cell.moreBtnClickHandler = { [weak self] in
                let serVC = SeriesVideosController()
                serVC.keyCateModel = serModel
                serVC.keyId = serModel.key_id ?? 1
                self?.navigationController?.pushViewController(serVC, animated: true)
            }
            cell.selectionStyle = .none
            return cell
        } else if indexPath.row == 1 {
            let cell = tableView.dequeueReusableCell(withIdentifier: HistoryWatchedCell.cellId, for: indexPath) as! HistoryWatchedCell
            cell.selectionStyle = .none
            if let list = cateModels[indexPath.section].video_lists, list.count > 0 {
                cell.setVideoList(list)
            }
            cell.itemClickHandlerIn = { [weak self] (index) in
                if let models = self?.cateModels[indexPath.section].video_lists, models.count > 0 {
                    let controller = AcountVideoPlayController()
                    controller.videos = models
                    controller.currentIndex = index
                    controller.currentPlayIndex = index
                    //controller.transitioningDelegate = self
                    controller.modalPresentationStyle = .overCurrentContext
                    self?.selectIndex = index
                    self?.selectSction = indexPath.section
                    controller.goVerbOrRefreshActionHandler = { [weak self] (isVerb) in
                        if isVerb {
                            let vipvc = VipCardsController()
                            self?.navigationController?.pushViewController(vipvc, animated: false)
                        } else {
                            self?.tableView.mj_header.beginRefreshing()
                        }
                    }
                    self?.present(controller, animated: true, completion: nil)
                }
            }
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        if indexPath.row == 0 {
            let serModel = cateModels[indexPath.section]
            let serVC = SeriesVideosController()
            serVC.keyCateModel = serModel
            serVC.keyId = serModel.key_id ?? 1
            navigationController?.pushViewController(serVC, animated: true)
        }
    }
}

// MARK: - UIViewControllerTransitioningDelegate
extension FindVideosController :UIViewControllerTransitioningDelegate {
    
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        
        return  ScalePresentAnimationForFind()  //ScreenShotAnimation(presentingStyle: .presenting)
    }
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        
        return  ScaleDismissAnimationForFind() //ScreenShotAnimation(presentingStyle: .dismissing)
    }
}

// MARK: - UIScrollViewDelegate
extension FindVideosController: UIScrollViewDelegate {
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let sectionHeaderHeight: CGFloat = 45
        if scrollView.contentOffset.y <= sectionHeaderHeight && scrollView.contentOffset.y > 0 {
            scrollView.contentInset = UIEdgeInsets(top: -scrollView.contentOffset.y, left: 0, bottom: 0, right: 0)
            
        } else if scrollView.contentOffset.y >= sectionHeaderHeight {
            scrollView.contentInset = UIEdgeInsets(top: -sectionHeaderHeight, left: 0, bottom: 0, right: 0)
        }
    }
    
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension FindVideosController: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        //XSProgressHUD.showCustomAnimation(msg: nil, onView: self.view, imageNames: nil, bgColor: UIColor.clear, animated: false)
        return [VideoSeriesListApi.kType: "FAXIAN2"]
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if let videoList = manager.fetchJSONData(VideoReformer()) as? CateTypeListModel {
            if manager is VideoSeriesListApi {
                succeedRequest(videoList)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if !isRefreshOperation {
            NicooErrorView.showErrorMessage("小姐姐走丢了，点击这里刷新", on: view, customerTopMargin: 150) {
                self.loadData()
            }
        }
    }
}



// MARK: - Layout
private extension FindVideosController {
    
    func layoutPageSubviews() {
      
        layoutTableView()
    }
    
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-44)
            } else {
                make.bottom.equalToSuperview().offset(-44)
            }
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(0)
        }
    }
   
    
}



//
//  InviteCodeController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/19.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class InviteCodeController: UIViewController {

    @IBOutlet weak var bgImageView: UIImageView!
    @IBOutlet weak var titleLab: UILabel!
    @IBOutlet weak var inviteCodeTitleLab: UILabel!
    @IBOutlet weak var inviteCodeLable: UILabel!
    @IBOutlet weak var qrCodeImage: UIImageView!
    @IBOutlet weak var warningLable: UILabel!
    @IBOutlet weak var copyInviteCodeBtn: UIButton!
    @IBOutlet weak var saveQRCodeBtn: UIButton!
    @IBOutlet weak var inviteFrientBtn: UIButton!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var scanTipsLable: UILabel!
    
    @IBOutlet weak var titLab: UILabel!
    var codeImage: UIImage?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configUI()
        loadQRcode()
        getUserInviteCode()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    @IBAction func backButtonClick(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    
    private func configUI() {
        copyInviteCodeBtn.layer.cornerRadius = 10
        copyInviteCodeBtn.layer.masksToBounds = true
        saveQRCodeBtn.layer.cornerRadius = 10
        saveQRCodeBtn.layer.masksToBounds = true
        inviteFrientBtn.layer.cornerRadius = 10
        inviteFrientBtn.layer.masksToBounds = true
        backButton.backgroundColor = UIColor(white: 0.9, alpha: 0.2)
        backButton.layer.cornerRadius = 15
        backButton.layer.masksToBounds = true
        inviteCodeLable.text = localStr("kNot")
        titLab.text = "ssssssssdsddsdsdsdsd"
        titleLab.text = "asdadasdasdadasdasdasdasdasdasda"
        inviteCodeTitleLab.text = "SDFTG"
        copyInviteCodeBtn.setTitle("复制", for: .normal)
        scanTipsLable.text = "bushish"
        saveQRCodeBtn.setTitle(localStr("保存二维码"), for: .normal)
        inviteFrientBtn.setTitle(localStr("邀请朋友e"), for: .normal)
        warningLable.text = localStr("提示随时随地是撒打算打算打算打算打算大大桑达大厦的")
    }
    
    private func getUserInviteCode() {
        if let userInviteCode = UserModel.share().invite_code {
            inviteCodeLable.text = "\(userInviteCode)"
        } else {
            if let codeSave = UserDefaults.standard.object(forKey: UserDefaults.kUserInviteCode) as? String {
               inviteCodeLable.text = "\(codeSave)"
            }
        }
    }

    @IBAction func copyInviteCode(_ sender: Any) {
        UIPasteboard.general.string = inviteCodeLable.text ?? ""
        XSAlert.show(type: .success, text: "复制成功！")
    }
    
    @IBAction func saveQrcode(_ sender: UIButton) {
        if codeImage != nil {
            UIImageWriteToSavedPhotosAlbum(codeImage!, self, #selector(saveImage(image:didFinishSavingWithError:contextInfo:)), nil)
        }
    }
    
    @IBAction func inviteFriends(_ sender: Any) {
        share()
    }
    
    @objc private func saveImage(image: UIImage, didFinishSavingWithError error: NSError?, contextInfo: AnyObject) {
        let showMessage = "保存成功！"
        if error != nil{
        } else{ }
        XSAlert.show(type: .success, text: showMessage)
    }
    
}

// MARK: - Private Func
private extension InviteCodeController {
    
    func loadQRcode() {
        var downString = String(format: "%@/share", ConstValue.kAppDownLoadLoadUrl)
        if let downloadString = UserDefaults.standard.value(forKey: UserDefaults.kAppShareUrl) as? String {
            downString = String(format: "%@/share", downloadString)
        }
        if let userInviteCode = UserModel.share().invite_code {
            downString = String(format: "%@/%@",downString, userInviteCode)
        } else {
            if let codeSave = UserDefaults.standard.object(forKey: UserDefaults.kUserInviteCode) as? String {
                downString = String(format: "%@/%@", downString, codeSave)
            } else {
                downString = String(format: "%@", downString)
            }
        }
        if let tisImage = EFQRCode.generate(content: downString, size: EFIntSize(width: 200, height: 200), backgroundColor: UIColor.white.cgColor, foregroundColor: UIColor.darkText.cgColor, watermark: UIImage(named: "")?.toCGImage(), watermarkMode: .center, icon: UIImage(named: "launchAppLog")?.toCGImage(), iconSize: EFIntSize(width:60, height: 60)) {
            qrCodeImage.image = UIImage(cgImage: tisImage)
            codeImage = UIImage(cgImage: tisImage)
        }
        
    }
}

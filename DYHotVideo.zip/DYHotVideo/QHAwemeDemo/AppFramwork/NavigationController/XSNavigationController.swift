//
//  XSNavigationController.swift
//  XSVideo
//
//  Created by pro5 on 2018/11/26.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class XSNavigationController: UINavigationController {

    public var navBarColor: UIColor?

    override func viewDidLoad() {
        super.viewDidLoad()
       
        //fd_fullscreenPopGestureRecognizer.isEnabled = true
        navigationBar.isTranslucent = false
        view.backgroundColor = UIColor.white
        if navBarColor == nil {
             navBarColor = UIColor.groupTableViewBackground
        }
        // 修改黑线颜色
        navigationBar.setBackgroundImage(UIImage(), for: .any, barMetrics: .default)
        navigationBar.shadowImage = UIImage.imageFromColor(ConstValue.kDefaultTableSeparatorColor, frame: CGRect(x: 0, y: 0, width: 1, height: 1))
        
    }
    
    override func pushViewController(_ viewController: UIViewController, animated: Bool) {
       /// 各个模块主界面，不隐藏tabbar
       
        
        viewController.hidesBottomBarWhenPushed = true
        
        super.pushViewController(viewController, animated: animated)
    }

}

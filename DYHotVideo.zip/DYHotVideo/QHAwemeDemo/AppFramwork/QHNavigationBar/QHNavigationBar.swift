
import UIKit

public protocol QHNavigationBarDelegate: NSObjectProtocol {
    func backAction()
}

class QHNavigationBar: UIView {
    
    weak open var delegate: QHNavigationBarDelegate?
    
    lazy var bgImageView: UIImageView = {
        let image = UIImageView()
        image.isUserInteractionEnabled = true
        image.backgroundColor = UIColor.groupTableViewBackground
        return image
    }()
    lazy var navBarView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.clear
        return view
    }()
    lazy var titleLabel: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .center
        lable.textColor = UIColor.darkText
        return lable
    }()
    lazy var backButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "navBackWhite"), for: .normal)
        button.addTarget(self, action: #selector(backAction), for: .touchUpInside)
        return button
    }()
   
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        p_setup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func p_setup() {
        addSubview(bgImageView)
        addSubview(navBarView)
        addSubview(backButton)
        navBarView.addSubview(titleLabel)
        layoutPageSubviews()
    }

    @objc func backAction() {
        delegate?.backAction()
    }
}

// MARK: - Layout
private extension QHNavigationBar {
    
    func layoutPageSubviews() {
        layoutBgImageView()
        layoutNavBarView()
        layoutBackButton()
        layoutTitleLable()
    }
    
    func layoutBackButton() {
        backButton.snp.makeConstraints { (make) in
            make.leading.equalTo(10)
            make.top.equalTo(ConstValue.kStatusBarHeight)
            make.bottom.equalToSuperview()
            make.width.equalTo(30)
        }
    }
    
    func layoutTitleLable() {
        titleLabel.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.leading.equalTo(backButton.snp.trailing)
            make.trailing.equalTo(-40)
        }
    }
    
    func layoutBgImageView() {
        bgImageView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    func layoutNavBarView() {
        navBarView.snp.makeConstraints { (make) in
            make.leading.trailing.bottom.equalToSuperview()
            make.top.equalTo(ConstValue.kStatusBarHeight)
        }
    }
}

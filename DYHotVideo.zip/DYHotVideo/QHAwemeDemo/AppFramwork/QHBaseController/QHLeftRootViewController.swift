

import UIKit

class QHLeftRootViewController: QHBaseViewController {
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        let vc = InviteCodeController()
        self.addChild(vc)
        view.addSubview(vc.view)
        layoutPageSubviews(vc.view)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
       
    }

   

}


// MARK: - Layout
private extension QHLeftRootViewController {
    
    func layoutPageSubviews(_ subview: UIView) {
        subview.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
   
}
